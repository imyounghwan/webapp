var Vw=Object.defineProperty;var Yh=r=>{throw TypeError(r)};var Xw=(r,t,e)=>t in r?Vw(r,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):r[t]=e;var L=(r,t,e)=>Xw(r,typeof t!="symbol"?t+"":t,e),Zh=(r,t,e)=>t.has(r)||Yh("Cannot "+e),Qt=(r,t)=>Object(t)!==t?Yh('Cannot use the "in" operator on this value'):r.has(t),a=(r,t,e)=>(Zh(r,t,"read from private field"),e?e.call(r):t.get(r)),m=(r,t,e)=>t.has(r)?Yh("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(r):t.set(r,e),_=(r,t,e,n)=>(Zh(r,t,"write to private field"),n?n.call(r,e):t.set(r,e),e),I=(r,t,e)=>(Zh(r,t,"access private method"),e);var Vs=(r,t,e,n)=>({set _(i){_(r,t,i,e)},get _(){return a(r,t,n)}});import{Buffer as Uu}from"node:buffer";function Jw(r,t){for(var e=0;e<t.length;e++){const n=t[e];if(typeof n!="string"&&!Array.isArray(n)){for(const i in n)if(i!=="default"&&!(i in r)){const s=Object.getOwnPropertyDescriptor(n,i);s&&Object.defineProperty(r,i,s.get?s:{enumerable:!0,get:()=>n[i]})}}}return Object.freeze(Object.defineProperty(r,Symbol.toStringTag,{value:"Module"}))}var fg=(r,t,e)=>(n,i)=>{let s=-1;return o(0);async function o(c){if(c<=s)throw new Error("next() called multiple times");s=c;let l,d=!1,u;if(r[c]?(u=r[c][0][0],n.req.routeIndex=c):u=c===r.length&&i||void 0,u)try{l=await u(n,()=>o(c+1))}catch(h){if(h instanceof Error&&t)n.error=h,l=await t(h,n),d=!0;else throw h}else n.finalized===!1&&e&&(l=await e(n));return l&&(n.finalized===!1||d)&&(n.res=l),n}},Qw=Symbol(),Yw=async(r,t=Object.create(null))=>{const{all:e=!1,dot:n=!1}=t,s=(r instanceof Jy?r.raw.headers:r.headers).get("Content-Type");return s!=null&&s.startsWith("multipart/form-data")||s!=null&&s.startsWith("application/x-www-form-urlencoded")?Zw(r,{all:e,dot:n}):{}};async function Zw(r,t){const e=await r.formData();return e?ev(e,t):{}}function ev(r,t){const e=Object.create(null);return r.forEach((n,i)=>{t.all||i.endsWith("[]")?tv(e,i,n):e[i]=n}),t.dot&&Object.entries(e).forEach(([n,i])=>{n.includes(".")&&(nv(e,n,i),delete e[n])}),e}var tv=(r,t,e)=>{r[t]!==void 0?Array.isArray(r[t])?r[t].push(e):r[t]=[r[t],e]:t.endsWith("[]")?r[t]=[e]:r[t]=e},nv=(r,t,e)=>{let n=r;const i=t.split(".");i.forEach((s,o)=>{o===i.length-1?n[s]=e:((!n[s]||typeof n[s]!="object"||Array.isArray(n[s])||n[s]instanceof File)&&(n[s]=Object.create(null)),n=n[s])})},qy=r=>{const t=r.split("/");return t[0]===""&&t.shift(),t},rv=r=>{const{groups:t,path:e}=iv(r),n=qy(e);return sv(n,t)},iv=r=>{const t=[];return r=r.replace(/\{[^}]+\}/g,(e,n)=>{const i=`@${n}`;return t.push([i,e]),i}),{groups:t,path:r}},sv=(r,t)=>{for(let e=t.length-1;e>=0;e--){const[n]=t[e];for(let i=r.length-1;i>=0;i--)if(r[i].includes(n)){r[i]=r[i].replace(n,t[e][1]);break}}return r},Kd={},av=(r,t)=>{if(r==="*")return"*";const e=r.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(e){const n=`${r}#${t}`;return Kd[n]||(e[2]?Kd[n]=t&&t[0]!==":"&&t[0]!=="*"?[n,e[1],new RegExp(`^${e[2]}(?=/${t})`)]:[r,e[1],new RegExp(`^${e[2]}$`)]:Kd[n]=[r,e[1],!0]),Kd[n]}return null},Kp=(r,t)=>{try{return t(r)}catch{return r.replace(/(?:%[0-9A-Fa-f]{2})+/g,e=>{try{return t(e)}catch{return e}})}},ov=r=>Kp(r,decodeURI),Ky=r=>{const t=r.url,e=t.indexOf("/",t.indexOf(":")+4);let n=e;for(;n<t.length;n++){const i=t.charCodeAt(n);if(i===37){const s=t.indexOf("?",n),o=t.slice(e,s===-1?void 0:s);return ov(o.includes("%25")?o.replace(/%25/g,"%2525"):o)}else if(i===63)break}return t.slice(e,n)},cv=r=>{const t=Ky(r);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},ta=(r,t,...e)=>(e.length&&(t=ta(t,...e)),`${(r==null?void 0:r[0])==="/"?"":"/"}${r}${t==="/"?"":`${(r==null?void 0:r.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),Gy=r=>{if(r.charCodeAt(r.length-1)!==63||!r.includes(":"))return null;const t=r.split("/"),e=[];let n="";return t.forEach(i=>{if(i!==""&&!/\:/.test(i))n+="/"+i;else if(/\:/.test(i))if(/\?/.test(i)){e.length===0&&n===""?e.push("/"):e.push(n);const s=i.replace("?","");n+="/"+s,e.push(n)}else n+="/"+i}),e.filter((i,s,o)=>o.indexOf(i)===s)},ef=r=>/[%+]/.test(r)?(r.indexOf("+")!==-1&&(r=r.replace(/\+/g," ")),r.indexOf("%")!==-1?Kp(r,Xy):r):r,Vy=(r,t,e)=>{let n;if(!e&&t&&!/[%+]/.test(t)){let o=r.indexOf("?",8);if(o===-1)return;for(r.startsWith(t,o+1)||(o=r.indexOf(`&${t}`,o+1));o!==-1;){const c=r.charCodeAt(o+t.length+1);if(c===61){const l=o+t.length+2,d=r.indexOf("&",l);return ef(r.slice(l,d===-1?void 0:d))}else if(c==38||isNaN(c))return"";o=r.indexOf(`&${t}`,o+1)}if(n=/[%+]/.test(r),!n)return}const i={};n??(n=/[%+]/.test(r));let s=r.indexOf("?",8);for(;s!==-1;){const o=r.indexOf("&",s+1);let c=r.indexOf("=",s);c>o&&o!==-1&&(c=-1);let l=r.slice(s+1,c===-1?o===-1?void 0:o:c);if(n&&(l=ef(l)),s=o,l==="")continue;let d;c===-1?d="":(d=r.slice(c+1,o===-1?void 0:o),n&&(d=ef(d))),e?(i[l]&&Array.isArray(i[l])||(i[l]=[]),i[l].push(d)):i[l]??(i[l]=d)}return t?i[t]:i},lv=Vy,dv=(r,t)=>Vy(r,t,!0),Xy=decodeURIComponent,pg=r=>Kp(r,Xy),ga,Yt,wr,Qy,Yy,Nf,Mr,Ry,Jy=(Ry=class{constructor(r,t="/",e=[[]]){m(this,wr);L(this,"raw");m(this,ga);m(this,Yt);L(this,"routeIndex",0);L(this,"path");L(this,"bodyCache",{});m(this,Mr,r=>{const{bodyCache:t,raw:e}=this,n=t[r];if(n)return n;const i=Object.keys(t)[0];return i?t[i].then(s=>(i==="json"&&(s=JSON.stringify(s)),new Response(s)[r]())):t[r]=e[r]()});this.raw=r,this.path=t,_(this,Yt,e),_(this,ga,{})}param(r){return r?I(this,wr,Qy).call(this,r):I(this,wr,Yy).call(this)}query(r){return lv(this.url,r)}queries(r){return dv(this.url,r)}header(r){if(r)return this.raw.headers.get(r)??void 0;const t={};return this.raw.headers.forEach((e,n)=>{t[n]=e}),t}async parseBody(r){var t;return(t=this.bodyCache).parsedBody??(t.parsedBody=await Yw(this,r))}json(){return a(this,Mr).call(this,"text").then(r=>JSON.parse(r))}text(){return a(this,Mr).call(this,"text")}arrayBuffer(){return a(this,Mr).call(this,"arrayBuffer")}blob(){return a(this,Mr).call(this,"blob")}formData(){return a(this,Mr).call(this,"formData")}addValidatedData(r,t){a(this,ga)[r]=t}valid(r){return a(this,ga)[r]}get url(){return this.raw.url}get method(){return this.raw.method}get[Qw](){return a(this,Yt)}get matchedRoutes(){return a(this,Yt)[0].map(([[,r]])=>r)}get routePath(){return a(this,Yt)[0].map(([[,r]])=>r)[this.routeIndex].path}},ga=new WeakMap,Yt=new WeakMap,wr=new WeakSet,Qy=function(r){const t=a(this,Yt)[0][this.routeIndex][1][r],e=I(this,wr,Nf).call(this,t);return e&&/\%/.test(e)?pg(e):e},Yy=function(){const r={},t=Object.keys(a(this,Yt)[0][this.routeIndex][1]);for(const e of t){const n=I(this,wr,Nf).call(this,a(this,Yt)[0][this.routeIndex][1][e]);n!==void 0&&(r[e]=/\%/.test(n)?pg(n):n)}return r},Nf=function(r){return a(this,Yt)[1]?a(this,Yt)[1][r]:r},Mr=new WeakMap,Ry),uv={Stringify:1},Zy=async(r,t,e,n,i)=>{typeof r=="object"&&!(r instanceof String)&&(r instanceof Promise||(r=r.toString()),r instanceof Promise&&(r=await r));const s=r.callbacks;return s!=null&&s.length?(i?i[0]+=r:i=[r],Promise.all(s.map(c=>c({phase:t,buffer:i,context:n}))).then(c=>Promise.all(c.filter(Boolean).map(l=>Zy(l,t,!1,n,i))).then(()=>i[0]))):Promise.resolve(r)},hv="text/plain; charset=UTF-8",tf=(r,t)=>({"Content-Type":r,...t}),Fc,Dc,Jn,ya,Qn,kt,Oc,_a,ba,Ai,Lc,jc,Ar,na,Fy,fv=(Fy=class{constructor(r,t){m(this,Ar);m(this,Fc);m(this,Dc);L(this,"env",{});m(this,Jn);L(this,"finalized",!1);L(this,"error");m(this,ya);m(this,Qn);m(this,kt);m(this,Oc);m(this,_a);m(this,ba);m(this,Ai);m(this,Lc);m(this,jc);L(this,"render",(...r)=>(a(this,_a)??_(this,_a,t=>this.html(t)),a(this,_a).call(this,...r)));L(this,"setLayout",r=>_(this,Oc,r));L(this,"getLayout",()=>a(this,Oc));L(this,"setRenderer",r=>{_(this,_a,r)});L(this,"header",(r,t,e)=>{this.finalized&&_(this,kt,new Response(a(this,kt).body,a(this,kt)));const n=a(this,kt)?a(this,kt).headers:a(this,Ai)??_(this,Ai,new Headers);t===void 0?n.delete(r):e!=null&&e.append?n.append(r,t):n.set(r,t)});L(this,"status",r=>{_(this,ya,r)});L(this,"set",(r,t)=>{a(this,Jn)??_(this,Jn,new Map),a(this,Jn).set(r,t)});L(this,"get",r=>a(this,Jn)?a(this,Jn).get(r):void 0);L(this,"newResponse",(...r)=>I(this,Ar,na).call(this,...r));L(this,"body",(r,t,e)=>I(this,Ar,na).call(this,r,t,e));L(this,"text",(r,t,e)=>!a(this,Ai)&&!a(this,ya)&&!t&&!e&&!this.finalized?new Response(r):I(this,Ar,na).call(this,r,t,tf(hv,e)));L(this,"json",(r,t,e)=>I(this,Ar,na).call(this,JSON.stringify(r),t,tf("application/json",e)));L(this,"html",(r,t,e)=>{const n=i=>I(this,Ar,na).call(this,i,t,tf("text/html; charset=UTF-8",e));return typeof r=="object"?Zy(r,uv.Stringify,!1,{}).then(n):n(r)});L(this,"redirect",(r,t)=>{const e=String(r);return this.header("Location",/[^\x00-\xFF]/.test(e)?encodeURI(e):e),this.newResponse(null,t??302)});L(this,"notFound",()=>(a(this,ba)??_(this,ba,()=>new Response),a(this,ba).call(this,this)));_(this,Fc,r),t&&(_(this,Qn,t.executionCtx),this.env=t.env,_(this,ba,t.notFoundHandler),_(this,jc,t.path),_(this,Lc,t.matchResult))}get req(){return a(this,Dc)??_(this,Dc,new Jy(a(this,Fc),a(this,jc),a(this,Lc))),a(this,Dc)}get event(){if(a(this,Qn)&&"respondWith"in a(this,Qn))return a(this,Qn);throw Error("This context has no FetchEvent")}get executionCtx(){if(a(this,Qn))return a(this,Qn);throw Error("This context has no ExecutionContext")}get res(){return a(this,kt)||_(this,kt,new Response(null,{headers:a(this,Ai)??_(this,Ai,new Headers)}))}set res(r){if(a(this,kt)&&r){r=new Response(r.body,r);for(const[t,e]of a(this,kt).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const n=a(this,kt).headers.getSetCookie();r.headers.delete("set-cookie");for(const i of n)r.headers.append("set-cookie",i)}else r.headers.set(t,e)}_(this,kt,r),this.finalized=!0}get var(){return a(this,Jn)?Object.fromEntries(a(this,Jn)):{}}},Fc=new WeakMap,Dc=new WeakMap,Jn=new WeakMap,ya=new WeakMap,Qn=new WeakMap,kt=new WeakMap,Oc=new WeakMap,_a=new WeakMap,ba=new WeakMap,Ai=new WeakMap,Lc=new WeakMap,jc=new WeakMap,Ar=new WeakSet,na=function(r,t,e){const n=a(this,kt)?new Headers(a(this,kt).headers):a(this,Ai)??new Headers;if(typeof t=="object"&&"headers"in t){const s=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[o,c]of s)o.toLowerCase()==="set-cookie"?n.append(o,c):n.set(o,c)}if(e)for(const[s,o]of Object.entries(e))if(typeof o=="string")n.set(s,o);else{n.delete(s);for(const c of o)n.append(s,c)}const i=typeof t=="number"?t:(t==null?void 0:t.status)??a(this,ya);return new Response(r,{status:i,headers:n})},Fy),Ye="ALL",pv="all",mv=["get","post","put","delete","options","patch"],e0="Can not add a route since the matcher is already built.",t0=class extends Error{},gv="__COMPOSED_HANDLER",yv=r=>r.text("404 Not Found",404),mg=(r,t)=>{if("getResponse"in r){const e=r.getResponse();return t.newResponse(e.body,e)}return console.error(r),t.text("Internal Server Error",500)},ln,et,n0,dn,vi,du,uu,wa,_v=(wa=class{constructor(t={}){m(this,et);L(this,"get");L(this,"post");L(this,"put");L(this,"delete");L(this,"options");L(this,"patch");L(this,"all");L(this,"on");L(this,"use");L(this,"router");L(this,"getPath");L(this,"_basePath","/");m(this,ln,"/");L(this,"routes",[]);m(this,dn,yv);L(this,"errorHandler",mg);L(this,"onError",t=>(this.errorHandler=t,this));L(this,"notFound",t=>(_(this,dn,t),this));L(this,"fetch",(t,...e)=>I(this,et,uu).call(this,t,e[1],e[0],t.method));L(this,"request",(t,e,n,i)=>t instanceof Request?this.fetch(e?new Request(t,e):t,n,i):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${ta("/",t)}`,e),n,i)));L(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(I(this,et,uu).call(this,t.request,t,void 0,t.request.method))})});[...mv,pv].forEach(s=>{this[s]=(o,...c)=>(typeof o=="string"?_(this,ln,o):I(this,et,vi).call(this,s,a(this,ln),o),c.forEach(l=>{I(this,et,vi).call(this,s,a(this,ln),l)}),this)}),this.on=(s,o,...c)=>{for(const l of[o].flat()){_(this,ln,l);for(const d of[s].flat())c.map(u=>{I(this,et,vi).call(this,d.toUpperCase(),a(this,ln),u)})}return this},this.use=(s,...o)=>(typeof s=="string"?_(this,ln,s):(_(this,ln,"*"),o.unshift(s)),o.forEach(c=>{I(this,et,vi).call(this,Ye,a(this,ln),c)}),this);const{strict:n,...i}=t;Object.assign(this,i),this.getPath=n??!0?t.getPath??Ky:cv}route(t,e){const n=this.basePath(t);return e.routes.map(i=>{var o;let s;e.errorHandler===mg?s=i.handler:(s=async(c,l)=>(await fg([],e.errorHandler)(c,()=>i.handler(c,l))).res,s[gv]=i.handler),I(o=n,et,vi).call(o,i.method,i.path,s)}),this}basePath(t){const e=I(this,et,n0).call(this);return e._basePath=ta(this._basePath,t),e}mount(t,e,n){let i,s;n&&(typeof n=="function"?s=n:(s=n.optionHandler,n.replaceRequest===!1?i=l=>l:i=n.replaceRequest));const o=s?l=>{const d=s(l);return Array.isArray(d)?d:[d]}:l=>{let d;try{d=l.executionCtx}catch{}return[l.env,d]};i||(i=(()=>{const l=ta(this._basePath,t),d=l==="/"?0:l.length;return u=>{const h=new URL(u.url);return h.pathname=h.pathname.slice(d)||"/",new Request(h,u)}})());const c=async(l,d)=>{const u=await e(i(l.req.raw),...o(l));if(u)return u;await d()};return I(this,et,vi).call(this,Ye,ta(t,"*"),c),this}},ln=new WeakMap,et=new WeakSet,n0=function(){const t=new wa({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,_(t,dn,a(this,dn)),t.routes=this.routes,t},dn=new WeakMap,vi=function(t,e,n){t=t.toUpperCase(),e=ta(this._basePath,e);const i={basePath:this._basePath,path:e,method:t,handler:n};this.router.add(t,e,[n,i]),this.routes.push(i)},du=function(t,e){if(t instanceof Error)return this.errorHandler(t,e);throw t},uu=function(t,e,n,i){if(i==="HEAD")return(async()=>new Response(null,await I(this,et,uu).call(this,t,e,n,"GET")))();const s=this.getPath(t,{env:n}),o=this.router.match(i,s),c=new fv(t,{path:s,matchResult:o,env:n,executionCtx:e,notFoundHandler:a(this,dn)});if(o[0].length===1){let d;try{d=o[0][0][0][0](c,async()=>{c.res=await a(this,dn).call(this,c)})}catch(u){return I(this,et,du).call(this,u,c)}return d instanceof Promise?d.then(u=>u||(c.finalized?c.res:a(this,dn).call(this,c))).catch(u=>I(this,et,du).call(this,u,c)):d??a(this,dn).call(this,c)}const l=fg(o[0],this.errorHandler,a(this,dn));return(async()=>{try{const d=await l(c);if(!d.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return d.res}catch(d){return I(this,et,du).call(this,d,c)}})()},wa),r0=[];function bv(r,t){const e=this.buildAllMatchers(),n=((i,s)=>{const o=e[i]||e[Ye],c=o[2][s];if(c)return c;const l=s.match(o[0]);if(!l)return[[],r0];const d=l.indexOf("",1);return[o[1][d],l]});return this.match=n,n(r,t)}var zu="[^/]+",_c=".*",bc="(?:|/.*)",ra=Symbol(),wv=new Set(".\\+*[^]$()");function vv(r,t){return r.length===1?t.length===1?r<t?-1:1:-1:t.length===1||r===_c||r===bc?1:t===_c||t===bc?-1:r===zu?1:t===zu?-1:r.length===t.length?r<t?-1:1:t.length-r.length}var Ti,Pi,un,Ls,xv=(Ls=class{constructor(){m(this,Ti);m(this,Pi);m(this,un,Object.create(null))}insert(t,e,n,i,s){if(t.length===0){if(a(this,Ti)!==void 0)throw ra;if(s)return;_(this,Ti,e);return}const[o,...c]=t,l=o==="*"?c.length===0?["","",_c]:["","",zu]:o==="/*"?["","",bc]:o.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let d;if(l){const u=l[1];let h=l[2]||zu;if(u&&l[2]&&(h===".*"||(h=h.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(h))))throw ra;if(d=a(this,un)[h],!d){if(Object.keys(a(this,un)).some(p=>p!==_c&&p!==bc))throw ra;if(s)return;d=a(this,un)[h]=new Ls,u!==""&&_(d,Pi,i.varIndex++)}!s&&u!==""&&n.push([u,a(d,Pi)])}else if(d=a(this,un)[o],!d){if(Object.keys(a(this,un)).some(u=>u.length>1&&u!==_c&&u!==bc))throw ra;if(s)return;d=a(this,un)[o]=new Ls}d.insert(c,e,n,i,s)}buildRegExpStr(){const e=Object.keys(a(this,un)).sort(vv).map(n=>{const i=a(this,un)[n];return(typeof a(i,Pi)=="number"?`(${n})@${a(i,Pi)}`:wv.has(n)?`\\${n}`:n)+i.buildRegExpStr()});return typeof a(this,Ti)=="number"&&e.unshift(`#${a(this,Ti)}`),e.length===0?"":e.length===1?e[0]:"(?:"+e.join("|")+")"}},Ti=new WeakMap,Pi=new WeakMap,un=new WeakMap,Ls),uh,Bc,Dy,Sv=(Dy=class{constructor(){m(this,uh,{varIndex:0});m(this,Bc,new xv)}insert(r,t,e){const n=[],i=[];for(let o=0;;){let c=!1;if(r=r.replace(/\{[^}]+\}/g,l=>{const d=`@\\${o}`;return i[o]=[d,l],o++,c=!0,d}),!c)break}const s=r.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let o=i.length-1;o>=0;o--){const[c]=i[o];for(let l=s.length-1;l>=0;l--)if(s[l].indexOf(c)!==-1){s[l]=s[l].replace(c,i[o][1]);break}}return a(this,Bc).insert(s,t,n,a(this,uh),e),n}buildRegExp(){let r=a(this,Bc).buildRegExpStr();if(r==="")return[/^$/,[],[]];let t=0;const e=[],n=[];return r=r.replace(/#(\d+)|@(\d+)|\.\*\$/g,(i,s,o)=>s!==void 0?(e[++t]=Number(s),"$()"):(o!==void 0&&(n[Number(o)]=++t),"")),[new RegExp(`^${r}`),e,n]}},uh=new WeakMap,Bc=new WeakMap,Dy),kv=[/^$/,[],Object.create(null)],hu=Object.create(null);function i0(r){return hu[r]??(hu[r]=new RegExp(r==="*"?"":`^${r.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,e)=>e?`\\${e}`:"(?:|/.*)")}$`))}function Cv(){hu=Object.create(null)}function Ev(r){var d;const t=new Sv,e=[];if(r.length===0)return kv;const n=r.map(u=>[!/\*|\/:/.test(u[0]),...u]).sort(([u,h],[p,f])=>u?1:p?-1:h.length-f.length),i=Object.create(null);for(let u=0,h=-1,p=n.length;u<p;u++){const[f,y,w]=n[u];f?i[y]=[w.map(([C])=>[C,Object.create(null)]),r0]:h++;let b;try{b=t.insert(y,h,f)}catch(C){throw C===ra?new t0(y):C}f||(e[h]=w.map(([C,A])=>{const T=Object.create(null);for(A-=1;A>=0;A--){const[M,D]=b[A];T[M]=D}return[C,T]}))}const[s,o,c]=t.buildRegExp();for(let u=0,h=e.length;u<h;u++)for(let p=0,f=e[u].length;p<f;p++){const y=(d=e[u][p])==null?void 0:d[1];if(!y)continue;const w=Object.keys(y);for(let b=0,C=w.length;b<C;b++)y[w[b]]=c[y[w[b]]]}const l=[];for(const u in o)l[u]=e[o[u]];return[s,l,i]}function Xs(r,t){if(r){for(const e of Object.keys(r).sort((n,i)=>i.length-n.length))if(i0(e).test(t))return[...r[e]]}}var Tr,Pr,hh,s0,Oy,Iv=(Oy=class{constructor(){m(this,hh);L(this,"name","RegExpRouter");m(this,Tr);m(this,Pr);L(this,"match",bv);_(this,Tr,{[Ye]:Object.create(null)}),_(this,Pr,{[Ye]:Object.create(null)})}add(r,t,e){var c;const n=a(this,Tr),i=a(this,Pr);if(!n||!i)throw new Error(e0);n[r]||[n,i].forEach(l=>{l[r]=Object.create(null),Object.keys(l[Ye]).forEach(d=>{l[r][d]=[...l[Ye][d]]})}),t==="/*"&&(t="*");const s=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const l=i0(t);r===Ye?Object.keys(n).forEach(d=>{var u;(u=n[d])[t]||(u[t]=Xs(n[d],t)||Xs(n[Ye],t)||[])}):(c=n[r])[t]||(c[t]=Xs(n[r],t)||Xs(n[Ye],t)||[]),Object.keys(n).forEach(d=>{(r===Ye||r===d)&&Object.keys(n[d]).forEach(u=>{l.test(u)&&n[d][u].push([e,s])})}),Object.keys(i).forEach(d=>{(r===Ye||r===d)&&Object.keys(i[d]).forEach(u=>l.test(u)&&i[d][u].push([e,s]))});return}const o=Gy(t)||[t];for(let l=0,d=o.length;l<d;l++){const u=o[l];Object.keys(i).forEach(h=>{var p;(r===Ye||r===h)&&((p=i[h])[u]||(p[u]=[...Xs(n[h],u)||Xs(n[Ye],u)||[]]),i[h][u].push([e,s-d+l+1]))})}}buildAllMatchers(){const r=Object.create(null);return Object.keys(a(this,Pr)).concat(Object.keys(a(this,Tr))).forEach(t=>{r[t]||(r[t]=I(this,hh,s0).call(this,t))}),_(this,Tr,_(this,Pr,void 0)),Cv(),r}},Tr=new WeakMap,Pr=new WeakMap,hh=new WeakSet,s0=function(r){const t=[];let e=r===Ye;return[a(this,Tr),a(this,Pr)].forEach(n=>{const i=n[r]?Object.keys(n[r]).map(s=>[s,n[r][s]]):[];i.length!==0?(e||(e=!0),t.push(...i)):r!==Ye&&t.push(...Object.keys(n[Ye]).map(s=>[s,n[Ye][s]]))}),e?Ev(t):null},Oy),$r,Yn,Ly,Nv=(Ly=class{constructor(r){L(this,"name","SmartRouter");m(this,$r,[]);m(this,Yn,[]);_(this,$r,r.routers)}add(r,t,e){if(!a(this,Yn))throw new Error(e0);a(this,Yn).push([r,t,e])}match(r,t){if(!a(this,Yn))throw new Error("Fatal error");const e=a(this,$r),n=a(this,Yn),i=e.length;let s=0,o;for(;s<i;s++){const c=e[s];try{for(let l=0,d=n.length;l<d;l++)c.add(...n[l]);o=c.match(r,t)}catch(l){if(l instanceof t0)continue;throw l}this.match=c.match.bind(c),_(this,$r,[c]),_(this,Yn,void 0);break}if(s===i)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,o}get activeRouter(){if(a(this,Yn)||a(this,$r).length!==1)throw new Error("No active router has been determined yet.");return a(this,$r)[0]}},$r=new WeakMap,Yn=new WeakMap,Ly),Qo=Object.create(null),Rr,_t,$i,va,lt,Zn,xi,xa,Mv=(xa=class{constructor(t,e,n){m(this,Zn);m(this,Rr);m(this,_t);m(this,$i);m(this,va,0);m(this,lt,Qo);if(_(this,_t,n||Object.create(null)),_(this,Rr,[]),t&&e){const i=Object.create(null);i[t]={handler:e,possibleKeys:[],score:0},_(this,Rr,[i])}_(this,$i,[])}insert(t,e,n){_(this,va,++Vs(this,va)._);let i=this;const s=rv(e),o=[];for(let c=0,l=s.length;c<l;c++){const d=s[c],u=s[c+1],h=av(d,u),p=Array.isArray(h)?h[0]:d;if(p in a(i,_t)){i=a(i,_t)[p],h&&o.push(h[1]);continue}a(i,_t)[p]=new xa,h&&(a(i,$i).push(h),o.push(h[1])),i=a(i,_t)[p]}return a(i,Rr).push({[t]:{handler:n,possibleKeys:o.filter((c,l,d)=>d.indexOf(c)===l),score:a(this,va)}}),i}search(t,e){var l;const n=[];_(this,lt,Qo);let s=[this];const o=qy(e),c=[];for(let d=0,u=o.length;d<u;d++){const h=o[d],p=d===u-1,f=[];for(let y=0,w=s.length;y<w;y++){const b=s[y],C=a(b,_t)[h];C&&(_(C,lt,a(b,lt)),p?(a(C,_t)["*"]&&n.push(...I(this,Zn,xi).call(this,a(C,_t)["*"],t,a(b,lt))),n.push(...I(this,Zn,xi).call(this,C,t,a(b,lt)))):f.push(C));for(let A=0,T=a(b,$i).length;A<T;A++){const M=a(b,$i)[A],D=a(b,lt)===Qo?{}:{...a(b,lt)};if(M==="*"){const B=a(b,_t)["*"];B&&(n.push(...I(this,Zn,xi).call(this,B,t,a(b,lt))),_(B,lt,D),f.push(B));continue}const[U,O,K]=M;if(!h&&!(K instanceof RegExp))continue;const F=a(b,_t)[U],H=o.slice(d).join("/");if(K instanceof RegExp){const B=K.exec(H);if(B){if(D[O]=B[0],n.push(...I(this,Zn,xi).call(this,F,t,a(b,lt),D)),Object.keys(a(F,_t)).length){_(F,lt,D);const P=((l=B[0].match(/\//))==null?void 0:l.length)??0;(c[P]||(c[P]=[])).push(F)}continue}}(K===!0||K.test(h))&&(D[O]=h,p?(n.push(...I(this,Zn,xi).call(this,F,t,D,a(b,lt))),a(F,_t)["*"]&&n.push(...I(this,Zn,xi).call(this,a(F,_t)["*"],t,D,a(b,lt)))):(_(F,lt,D),f.push(F)))}}s=f.concat(c.shift()??[])}return n.length>1&&n.sort((d,u)=>d.score-u.score),[n.map(({handler:d,params:u})=>[d,u])]}},Rr=new WeakMap,_t=new WeakMap,$i=new WeakMap,va=new WeakMap,lt=new WeakMap,Zn=new WeakSet,xi=function(t,e,n,i){const s=[];for(let o=0,c=a(t,Rr).length;o<c;o++){const l=a(t,Rr)[o],d=l[e]||l[Ye],u={};if(d!==void 0&&(d.params=Object.create(null),s.push(d),n!==Qo||i&&i!==Qo))for(let h=0,p=d.possibleKeys.length;h<p;h++){const f=d.possibleKeys[h],y=u[d.score];d.params[f]=i!=null&&i[f]&&!y?i[f]:n[f]??(i==null?void 0:i[f]),u[d.score]=!0}}return s},xa),Ri,jy,Av=(jy=class{constructor(){L(this,"name","TrieRouter");m(this,Ri);_(this,Ri,new Mv)}add(r,t,e){const n=Gy(t);if(n){for(let i=0,s=n.length;i<s;i++)a(this,Ri).insert(r,n[i],e);return}a(this,Ri).insert(r,t,e)}match(r,t){return a(this,Ri).search(r,t)}},Ri=new WeakMap,jy),a0=class extends _v{constructor(r={}){super(r),this.router=r.router??new Nv({routers:[new Iv,new Av]})}},Tv=r=>{const e={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...r},n=(s=>typeof s=="string"?s==="*"?()=>s:o=>s===o?o:null:typeof s=="function"?s:o=>s.includes(o)?o:null)(e.origin),i=(s=>typeof s=="function"?s:Array.isArray(s)?()=>s:()=>[])(e.allowMethods);return async function(o,c){var u;function l(h,p){o.res.headers.set(h,p)}const d=await n(o.req.header("origin")||"",o);if(d&&l("Access-Control-Allow-Origin",d),e.credentials&&l("Access-Control-Allow-Credentials","true"),(u=e.exposeHeaders)!=null&&u.length&&l("Access-Control-Expose-Headers",e.exposeHeaders.join(",")),o.req.method==="OPTIONS"){e.origin!=="*"&&l("Vary","Origin"),e.maxAge!=null&&l("Access-Control-Max-Age",e.maxAge.toString());const h=await i(o.req.header("origin")||"",o);h.length&&l("Access-Control-Allow-Methods",h.join(","));let p=e.allowHeaders;if(!(p!=null&&p.length)){const f=o.req.header("Access-Control-Request-Headers");f&&(p=f.split(/\s*,\s*/))}return p!=null&&p.length&&(l("Access-Control-Allow-Headers",p.join(",")),o.res.headers.append("Vary","Access-Control-Request-Headers")),o.res.headers.delete("Content-Length"),o.res.headers.delete("Content-Type"),new Response(null,{headers:o.res.headers,status:204,statusText:"No Content"})}await c(),e.origin!=="*"&&o.header("Vary","Origin",{append:!0})}};/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */globalThis.Buffer=Uu;var Mf=function(r,t){return Mf=Object.setPrototypeOf||{__proto__:[]}instanceof Array&&function(e,n){e.__proto__=n}||function(e,n){for(var i in n)Object.prototype.hasOwnProperty.call(n,i)&&(e[i]=n[i])},Mf(r,t)};function xr(r,t){if(typeof t!="function"&&t!==null)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null");Mf(r,t);function e(){this.constructor=r}r.prototype=t===null?Object.create(t):(e.prototype=t.prototype,new e)}function Pv(r,t,e,n){function i(s){return s instanceof e?s:new e(function(o){o(s)})}return new(e||(e=Promise))(function(s,o){function c(u){try{d(n.next(u))}catch(h){o(h)}}function l(u){try{d(n.throw(u))}catch(h){o(h)}}function d(u){u.done?s(u.value):i(u.value).then(c,l)}d((n=n.apply(r,[])).next())})}function o0(r,t){var e={label:0,sent:function(){if(s[0]&1)throw s[1];return s[1]},trys:[],ops:[]},n,i,s,o;return o={next:c(0),throw:c(1),return:c(2)},typeof Symbol=="function"&&(o[Symbol.iterator]=function(){return this}),o;function c(d){return function(u){return l([d,u])}}function l(d){if(n)throw new TypeError("Generator is already executing.");for(;o&&(o=0,d[0]&&(e=0)),e;)try{if(n=1,i&&(s=d[0]&2?i.return:d[0]?i.throw||((s=i.return)&&s.call(i),0):i.next)&&!(s=s.call(i,d[1])).done)return s;switch(i=0,s&&(d=[d[0]&2,s.value]),d[0]){case 0:case 1:s=d;break;case 4:return e.label++,{value:d[1],done:!1};case 5:e.label++,i=d[1],d=[0];continue;case 7:d=e.ops.pop(),e.trys.pop();continue;default:if(s=e.trys,!(s=s.length>0&&s[s.length-1])&&(d[0]===6||d[0]===2)){e=0;continue}if(d[0]===3&&(!s||d[1]>s[0]&&d[1]<s[3])){e.label=d[1];break}if(d[0]===6&&e.label<s[1]){e.label=s[1],s=d;break}if(s&&e.label<s[2]){e.label=s[2],e.ops.push(d);break}s[2]&&e.ops.pop(),e.trys.pop();continue}d=t.call(r,e)}catch(u){d=[6,u],i=0}finally{n=s=0}if(d[0]&5)throw d[1];return{value:d[0]?d[1]:void 0,done:!0}}}function jo(r){var t=typeof Symbol=="function"&&Symbol.iterator,e=t&&r[t],n=0;if(e)return e.call(r);if(r&&typeof r.length=="number")return{next:function(){return r&&n>=r.length&&(r=void 0),{value:r&&r[n++],done:!r}}};throw new TypeError(t?"Object is not iterable.":"Symbol.iterator is not defined.")}function js(r,t){var e=typeof Symbol=="function"&&r[Symbol.iterator];if(!e)return r;var n=e.call(r),i,s=[],o;try{for(;(t===void 0||t-- >0)&&!(i=n.next()).done;)s.push(i.value)}catch(c){o={error:c}}finally{try{i&&!i.done&&(e=n.return)&&e.call(n)}finally{if(o)throw o.error}}return s}function Bo(r,t,e){if(arguments.length===2)for(var n=0,i=t.length,s;n<i;n++)(s||!(n in t))&&(s||(s=Array.prototype.slice.call(t,0,n)),s[n]=t[n]);return r.concat(s||Array.prototype.slice.call(t))}function ha(r){return this instanceof ha?(this.v=r,this):new ha(r)}function $v(r,t,e){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var n=e.apply(r,t||[]),i,s=[];return i={},o("next"),o("throw"),o("return"),i[Symbol.asyncIterator]=function(){return this},i;function o(p){n[p]&&(i[p]=function(f){return new Promise(function(y,w){s.push([p,f,y,w])>1||c(p,f)})})}function c(p,f){try{l(n[p](f))}catch(y){h(s[0][3],y)}}function l(p){p.value instanceof ha?Promise.resolve(p.value.v).then(d,u):h(s[0][2],p)}function d(p){c("next",p)}function u(p){c("throw",p)}function h(p,f){p(f),s.shift(),s.length&&c(s[0][0],s[0][1])}}function Rv(r){if(!Symbol.asyncIterator)throw new TypeError("Symbol.asyncIterator is not defined.");var t=r[Symbol.asyncIterator],e;return t?t.call(r):(r=typeof jo=="function"?jo(r):r[Symbol.iterator](),e={},n("next"),n("throw"),n("return"),e[Symbol.asyncIterator]=function(){return this},e);function n(s){e[s]=r[s]&&function(o){return new Promise(function(c,l){o=r[s](o),i(c,l,o.done,o.value)})}}function i(s,o,c,l){Promise.resolve(l).then(function(d){s({value:d,done:c})},o)}}function Re(r){return typeof r=="function"}function Gp(r){var t=function(n){Error.call(n),n.stack=new Error().stack},e=r(t);return e.prototype=Object.create(Error.prototype),e.prototype.constructor=e,e}var nf=Gp(function(r){return function(e){r(this),this.message=e?e.length+` errors occurred during unsubscription:
`+e.map(function(n,i){return i+1+") "+n.toString()}).join(`
  `):"",this.name="UnsubscriptionError",this.errors=e}});function Hu(r,t){if(r){var e=r.indexOf(t);0<=e&&r.splice(e,1)}}var Ud=(function(){function r(t){this.initialTeardown=t,this.closed=!1,this._parentage=null,this._finalizers=null}return r.prototype.unsubscribe=function(){var t,e,n,i,s;if(!this.closed){this.closed=!0;var o=this._parentage;if(o)if(this._parentage=null,Array.isArray(o))try{for(var c=jo(o),l=c.next();!l.done;l=c.next()){var d=l.value;d.remove(this)}}catch(w){t={error:w}}finally{try{l&&!l.done&&(e=c.return)&&e.call(c)}finally{if(t)throw t.error}}else o.remove(this);var u=this.initialTeardown;if(Re(u))try{u()}catch(w){s=w instanceof nf?w.errors:[w]}var h=this._finalizers;if(h){this._finalizers=null;try{for(var p=jo(h),f=p.next();!f.done;f=p.next()){var y=f.value;try{gg(y)}catch(w){s=s??[],w instanceof nf?s=Bo(Bo([],js(s)),js(w.errors)):s.push(w)}}}catch(w){n={error:w}}finally{try{f&&!f.done&&(i=p.return)&&i.call(p)}finally{if(n)throw n.error}}}if(s)throw new nf(s)}},r.prototype.add=function(t){var e;if(t&&t!==this)if(this.closed)gg(t);else{if(t instanceof r){if(t.closed||t._hasParent(this))return;t._addParent(this)}(this._finalizers=(e=this._finalizers)!==null&&e!==void 0?e:[]).push(t)}},r.prototype._hasParent=function(t){var e=this._parentage;return e===t||Array.isArray(e)&&e.includes(t)},r.prototype._addParent=function(t){var e=this._parentage;this._parentage=Array.isArray(e)?(e.push(t),e):e?[e,t]:t},r.prototype._removeParent=function(t){var e=this._parentage;e===t?this._parentage=null:Array.isArray(e)&&Hu(e,t)},r.prototype.remove=function(t){var e=this._finalizers;e&&Hu(e,t),t instanceof r&&t._removeParent(this)},r.EMPTY=(function(){var t=new r;return t.closed=!0,t})(),r})(),c0=Ud.EMPTY;function l0(r){return r instanceof Ud||r&&"closed"in r&&Re(r.remove)&&Re(r.add)&&Re(r.unsubscribe)}function gg(r){Re(r)?r():r.unsubscribe()}var Fv={Promise:void 0},Dv={setTimeout:function(r,t){for(var e=[],n=2;n<arguments.length;n++)e[n-2]=arguments[n];return setTimeout.apply(void 0,Bo([r,t],js(e)))},clearTimeout:function(r){return clearTimeout(r)},delegate:void 0};function d0(r){Dv.setTimeout(function(){throw r})}function Uo(){}function fu(r){r()}var Vp=(function(r){xr(t,r);function t(e){var n=r.call(this)||this;return n.isStopped=!1,e?(n.destination=e,l0(e)&&e.add(n)):n.destination=jv,n}return t.create=function(e,n,i){return new Wu(e,n,i)},t.prototype.next=function(e){this.isStopped||this._next(e)},t.prototype.error=function(e){this.isStopped||(this.isStopped=!0,this._error(e))},t.prototype.complete=function(){this.isStopped||(this.isStopped=!0,this._complete())},t.prototype.unsubscribe=function(){this.closed||(this.isStopped=!0,r.prototype.unsubscribe.call(this),this.destination=null)},t.prototype._next=function(e){this.destination.next(e)},t.prototype._error=function(e){try{this.destination.error(e)}finally{this.unsubscribe()}},t.prototype._complete=function(){try{this.destination.complete()}finally{this.unsubscribe()}},t})(Ud),Ov=(function(){function r(t){this.partialObserver=t}return r.prototype.next=function(t){var e=this.partialObserver;if(e.next)try{e.next(t)}catch(n){Gd(n)}},r.prototype.error=function(t){var e=this.partialObserver;if(e.error)try{e.error(t)}catch(n){Gd(n)}else Gd(t)},r.prototype.complete=function(){var t=this.partialObserver;if(t.complete)try{t.complete()}catch(e){Gd(e)}},r})(),Wu=(function(r){xr(t,r);function t(e,n,i){var s=r.call(this)||this,o;return Re(e)||!e?o={next:e??void 0,error:n??void 0,complete:i??void 0}:o=e,s.destination=new Ov(o),s}return t})(Vp);function Gd(r){d0(r)}function Lv(r){throw r}var jv={closed:!0,next:Uo,error:Lv,complete:Uo},Xp=(function(){return typeof Symbol=="function"&&Symbol.observable||"@@observable"})();function bi(r){return r}function Bv(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];return u0(r)}function u0(r){return r.length===0?bi:r.length===1?r[0]:function(e){return r.reduce(function(n,i){return i(n)},e)}}var ct=(function(){function r(t){t&&(this._subscribe=t)}return r.prototype.lift=function(t){var e=new r;return e.source=this,e.operator=t,e},r.prototype.subscribe=function(t,e,n){var i=this,s=zv(t)?t:new Wu(t,e,n);return fu(function(){var o=i,c=o.operator,l=o.source;s.add(c?c.call(s,l):l?i._subscribe(s):i._trySubscribe(s))}),s},r.prototype._trySubscribe=function(t){try{return this._subscribe(t)}catch(e){t.error(e)}},r.prototype.forEach=function(t,e){var n=this;return e=yg(e),new e(function(i,s){var o=new Wu({next:function(c){try{t(c)}catch(l){s(l),o.unsubscribe()}},error:s,complete:i});n.subscribe(o)})},r.prototype._subscribe=function(t){var e;return(e=this.source)===null||e===void 0?void 0:e.subscribe(t)},r.prototype[Xp]=function(){return this},r.prototype.pipe=function(){for(var t=[],e=0;e<arguments.length;e++)t[e]=arguments[e];return u0(t)(this)},r.prototype.toPromise=function(t){var e=this;return t=yg(t),new t(function(n,i){var s;e.subscribe(function(o){return s=o},function(o){return i(o)},function(){return n(s)})})},r.create=function(t){return new r(t)},r})();function yg(r){var t;return(t=r??Fv.Promise)!==null&&t!==void 0?t:Promise}function Uv(r){return r&&Re(r.next)&&Re(r.error)&&Re(r.complete)}function zv(r){return r&&r instanceof Vp||Uv(r)&&l0(r)}function Hv(r){return Re(r==null?void 0:r.lift)}function yt(r){return function(t){if(Hv(t))return t.lift(function(e){try{return r(e,this)}catch(n){this.error(n)}});throw new TypeError("Unable to lift unknown Observable type")}}function mt(r,t,e,n,i){return new Wv(r,t,e,n,i)}var Wv=(function(r){xr(t,r);function t(e,n,i,s,o,c){var l=r.call(this,e)||this;return l.onFinalize=o,l.shouldUnsubscribe=c,l._next=n?function(d){try{n(d)}catch(u){e.error(u)}}:r.prototype._next,l._error=s?function(d){try{s(d)}catch(u){e.error(u)}finally{this.unsubscribe()}}:r.prototype._error,l._complete=i?function(){try{i()}catch(d){e.error(d)}finally{this.unsubscribe()}}:r.prototype._complete,l}return t.prototype.unsubscribe=function(){var e;if(!this.shouldUnsubscribe||this.shouldUnsubscribe()){var n=this.closed;r.prototype.unsubscribe.call(this),!n&&((e=this.onFinalize)===null||e===void 0||e.call(this))}},t})(Vp),qv=Gp(function(r){return function(){r(this),this.name="ObjectUnsubscribedError",this.message="object unsubscribed"}}),h0=(function(r){xr(t,r);function t(){var e=r.call(this)||this;return e.closed=!1,e.currentObservers=null,e.observers=[],e.isStopped=!1,e.hasError=!1,e.thrownError=null,e}return t.prototype.lift=function(e){var n=new _g(this,this);return n.operator=e,n},t.prototype._throwIfClosed=function(){if(this.closed)throw new qv},t.prototype.next=function(e){var n=this;fu(function(){var i,s;if(n._throwIfClosed(),!n.isStopped){n.currentObservers||(n.currentObservers=Array.from(n.observers));try{for(var o=jo(n.currentObservers),c=o.next();!c.done;c=o.next()){var l=c.value;l.next(e)}}catch(d){i={error:d}}finally{try{c&&!c.done&&(s=o.return)&&s.call(o)}finally{if(i)throw i.error}}}})},t.prototype.error=function(e){var n=this;fu(function(){if(n._throwIfClosed(),!n.isStopped){n.hasError=n.isStopped=!0,n.thrownError=e;for(var i=n.observers;i.length;)i.shift().error(e)}})},t.prototype.complete=function(){var e=this;fu(function(){if(e._throwIfClosed(),!e.isStopped){e.isStopped=!0;for(var n=e.observers;n.length;)n.shift().complete()}})},t.prototype.unsubscribe=function(){this.isStopped=this.closed=!0,this.observers=this.currentObservers=null},Object.defineProperty(t.prototype,"observed",{get:function(){var e;return((e=this.observers)===null||e===void 0?void 0:e.length)>0},enumerable:!1,configurable:!0}),t.prototype._trySubscribe=function(e){return this._throwIfClosed(),r.prototype._trySubscribe.call(this,e)},t.prototype._subscribe=function(e){return this._throwIfClosed(),this._checkFinalizedStatuses(e),this._innerSubscribe(e)},t.prototype._innerSubscribe=function(e){var n=this,i=this,s=i.hasError,o=i.isStopped,c=i.observers;return s||o?c0:(this.currentObservers=null,c.push(e),new Ud(function(){n.currentObservers=null,Hu(c,e)}))},t.prototype._checkFinalizedStatuses=function(e){var n=this,i=n.hasError,s=n.thrownError,o=n.isStopped;i?e.error(s):o&&e.complete()},t.prototype.asObservable=function(){var e=new ct;return e.source=this,e},t.create=function(e,n){return new _g(e,n)},t})(ct),_g=(function(r){xr(t,r);function t(e,n){var i=r.call(this)||this;return i.destination=e,i.source=n,i}return t.prototype.next=function(e){var n,i;(i=(n=this.destination)===null||n===void 0?void 0:n.next)===null||i===void 0||i.call(n,e)},t.prototype.error=function(e){var n,i;(i=(n=this.destination)===null||n===void 0?void 0:n.error)===null||i===void 0||i.call(n,e)},t.prototype.complete=function(){var e,n;(n=(e=this.destination)===null||e===void 0?void 0:e.complete)===null||n===void 0||n.call(e)},t.prototype._subscribe=function(e){var n,i;return(i=(n=this.source)===null||n===void 0?void 0:n.subscribe(e))!==null&&i!==void 0?i:c0},t})(h0),Jp={now:function(){return(Jp.delegate||Date).now()},delegate:void 0},Kv=(function(r){xr(t,r);function t(e,n,i){e===void 0&&(e=1/0),n===void 0&&(n=1/0),i===void 0&&(i=Jp);var s=r.call(this)||this;return s._bufferSize=e,s._windowTime=n,s._timestampProvider=i,s._buffer=[],s._infiniteTimeWindow=!0,s._infiniteTimeWindow=n===1/0,s._bufferSize=Math.max(1,e),s._windowTime=Math.max(1,n),s}return t.prototype.next=function(e){var n=this,i=n.isStopped,s=n._buffer,o=n._infiniteTimeWindow,c=n._timestampProvider,l=n._windowTime;i||(s.push(e),!o&&s.push(c.now()+l)),this._trimBuffer(),r.prototype.next.call(this,e)},t.prototype._subscribe=function(e){this._throwIfClosed(),this._trimBuffer();for(var n=this._innerSubscribe(e),i=this,s=i._infiniteTimeWindow,o=i._buffer,c=o.slice(),l=0;l<c.length&&!e.closed;l+=s?1:2)e.next(c[l]);return this._checkFinalizedStatuses(e),n},t.prototype._trimBuffer=function(){var e=this,n=e._bufferSize,i=e._timestampProvider,s=e._buffer,o=e._infiniteTimeWindow,c=(o?1:2)*n;if(n<1/0&&c<s.length&&s.splice(0,s.length-c),!o){for(var l=i.now(),d=0,u=1;u<s.length&&s[u]<=l;u+=2)d=u;d&&s.splice(0,d+1)}},t})(h0),Gv=(function(r){xr(t,r);function t(e,n){return r.call(this)||this}return t.prototype.schedule=function(e,n){return this},t})(Ud),bg={setInterval:function(r,t){for(var e=[],n=2;n<arguments.length;n++)e[n-2]=arguments[n];return setInterval.apply(void 0,Bo([r,t],js(e)))},clearInterval:function(r){return clearInterval(r)},delegate:void 0},Vv=(function(r){xr(t,r);function t(e,n){var i=r.call(this,e,n)||this;return i.scheduler=e,i.work=n,i.pending=!1,i}return t.prototype.schedule=function(e,n){var i;if(n===void 0&&(n=0),this.closed)return this;this.state=e;var s=this.id,o=this.scheduler;return s!=null&&(this.id=this.recycleAsyncId(o,s,n)),this.pending=!0,this.delay=n,this.id=(i=this.id)!==null&&i!==void 0?i:this.requestAsyncId(o,this.id,n),this},t.prototype.requestAsyncId=function(e,n,i){return i===void 0&&(i=0),bg.setInterval(e.flush.bind(e,this),i)},t.prototype.recycleAsyncId=function(e,n,i){if(i===void 0&&(i=0),i!=null&&this.delay===i&&this.pending===!1)return n;n!=null&&bg.clearInterval(n)},t.prototype.execute=function(e,n){if(this.closed)return new Error("executing a cancelled action");this.pending=!1;var i=this._execute(e,n);if(i)return i;this.pending===!1&&this.id!=null&&(this.id=this.recycleAsyncId(this.scheduler,this.id,null))},t.prototype._execute=function(e,n){var i=!1,s;try{this.work(e)}catch(o){i=!0,s=o||new Error("Scheduled action threw falsy error")}if(i)return this.unsubscribe(),s},t.prototype.unsubscribe=function(){if(!this.closed){var e=this,n=e.id,i=e.scheduler,s=i.actions;this.work=this.state=this.scheduler=null,this.pending=!1,Hu(s,this),n!=null&&(this.id=this.recycleAsyncId(i,n,null)),this.delay=null,r.prototype.unsubscribe.call(this)}},t})(Gv),wg=(function(){function r(t,e){e===void 0&&(e=r.now),this.schedulerActionCtor=t,this.now=e}return r.prototype.schedule=function(t,e,n){return e===void 0&&(e=0),new this.schedulerActionCtor(this,t).schedule(n,e)},r.now=Jp.now,r})(),Xv=(function(r){xr(t,r);function t(e,n){n===void 0&&(n=wg.now);var i=r.call(this,e,n)||this;return i.actions=[],i._active=!1,i}return t.prototype.flush=function(e){var n=this.actions;if(this._active){n.push(e);return}var i;this._active=!0;do if(i=e.execute(e.state,e.delay))break;while(e=n.shift());if(this._active=!1,i){for(;e=n.shift();)e.unsubscribe();throw i}},t})(wg),Jv=new Xv(Vv),Qv=Jv,Ds=new ct(function(r){return r.complete()});function Yv(r){return r&&Re(r.schedule)}function f0(r){return r[r.length-1]}function Rh(r){return Yv(f0(r))?r.pop():void 0}function Zv(r,t){return typeof f0(r)=="number"?r.pop():t}var Qp=function(r){return r&&typeof r.length=="number"&&typeof r!="function"};function p0(r){return Re(r==null?void 0:r.then)}function m0(r){return Re(r[Xp])}function g0(r){return Symbol.asyncIterator&&Re(r==null?void 0:r[Symbol.asyncIterator])}function y0(r){return new TypeError("You provided "+(r!==null&&typeof r=="object"?"an invalid object":"'"+r+"'")+" where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.")}function e1(){return typeof Symbol!="function"||!Symbol.iterator?"@@iterator":Symbol.iterator}var _0=e1();function b0(r){return Re(r==null?void 0:r[_0])}function w0(r){return $v(this,arguments,function(){var e,n,i,s;return o0(this,function(o){switch(o.label){case 0:e=r.getReader(),o.label=1;case 1:o.trys.push([1,,9,10]),o.label=2;case 2:return[4,ha(e.read())];case 3:return n=o.sent(),i=n.value,s=n.done,s?[4,ha(void 0)]:[3,5];case 4:return[2,o.sent()];case 5:return[4,ha(i)];case 6:return[4,o.sent()];case 7:return o.sent(),[3,2];case 8:return[3,10];case 9:return e.releaseLock(),[7];case 10:return[2]}})})}function v0(r){return Re(r==null?void 0:r.getReader)}function Ot(r){if(r instanceof ct)return r;if(r!=null){if(m0(r))return t1(r);if(Qp(r))return n1(r);if(p0(r))return r1(r);if(g0(r))return x0(r);if(b0(r))return i1(r);if(v0(r))return s1(r)}throw y0(r)}function t1(r){return new ct(function(t){var e=r[Xp]();if(Re(e.subscribe))return e.subscribe(t);throw new TypeError("Provided object does not correctly implement Symbol.observable")})}function n1(r){return new ct(function(t){for(var e=0;e<r.length&&!t.closed;e++)t.next(r[e]);t.complete()})}function r1(r){return new ct(function(t){r.then(function(e){t.closed||(t.next(e),t.complete())},function(e){return t.error(e)}).then(null,d0)})}function i1(r){return new ct(function(t){var e,n;try{for(var i=jo(r),s=i.next();!s.done;s=i.next()){var o=s.value;if(t.next(o),t.closed)return}}catch(c){e={error:c}}finally{try{s&&!s.done&&(n=i.return)&&n.call(i)}finally{if(e)throw e.error}}t.complete()})}function x0(r){return new ct(function(t){a1(r,t).catch(function(e){return t.error(e)})})}function s1(r){return x0(w0(r))}function a1(r,t){var e,n,i,s;return Pv(this,void 0,void 0,function(){var o,c;return o0(this,function(l){switch(l.label){case 0:l.trys.push([0,5,6,11]),e=Rv(r),l.label=1;case 1:return[4,e.next()];case 2:if(n=l.sent(),!!n.done)return[3,4];if(o=n.value,t.next(o),t.closed)return[2];l.label=3;case 3:return[3,1];case 4:return[3,11];case 5:return c=l.sent(),i={error:c},[3,11];case 6:return l.trys.push([6,,9,10]),n&&!n.done&&(s=e.return)?[4,s.call(e)]:[3,8];case 7:l.sent(),l.label=8;case 8:return[3,10];case 9:if(i)throw i.error;return[7];case 10:return[7];case 11:return t.complete(),[2]}})})}function Os(r,t,e,n,i){n===void 0&&(n=0),i===void 0&&(i=!1);var s=t.schedule(function(){e(),i?r.add(this.schedule(null,n)):this.unsubscribe()},n);if(r.add(s),!i)return s}function S0(r,t){return t===void 0&&(t=0),yt(function(e,n){e.subscribe(mt(n,function(i){return Os(n,r,function(){return n.next(i)},t)},function(){return Os(n,r,function(){return n.complete()},t)},function(i){return Os(n,r,function(){return n.error(i)},t)}))})}function k0(r,t){return t===void 0&&(t=0),yt(function(e,n){n.add(r.schedule(function(){return e.subscribe(n)},t))})}function o1(r,t){return Ot(r).pipe(k0(t),S0(t))}function c1(r,t){return Ot(r).pipe(k0(t),S0(t))}function l1(r,t){return new ct(function(e){var n=0;return t.schedule(function(){n===r.length?e.complete():(e.next(r[n++]),e.closed||this.schedule())})})}function d1(r,t){return new ct(function(e){var n;return Os(e,t,function(){n=r[_0](),Os(e,t,function(){var i,s,o;try{i=n.next(),s=i.value,o=i.done}catch(c){e.error(c);return}o?e.complete():e.next(s)},0,!0)}),function(){return Re(n==null?void 0:n.return)&&n.return()}})}function C0(r,t){if(!r)throw new Error("Iterable cannot be null");return new ct(function(e){Os(e,t,function(){var n=r[Symbol.asyncIterator]();Os(e,t,function(){n.next().then(function(i){i.done?e.complete():e.next(i.value)})},0,!0)})})}function u1(r,t){return C0(w0(r),t)}function h1(r,t){if(r!=null){if(m0(r))return o1(r,t);if(Qp(r))return l1(r,t);if(p0(r))return c1(r,t);if(g0(r))return C0(r,t);if(b0(r))return d1(r,t);if(v0(r))return u1(r,t)}throw y0(r)}function Ie(r,t){return t?h1(r,t):Ot(r)}function vg(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];var e=Rh(r);return Ie(r,e)}var Yp=Gp(function(r){return function(){r(this),this.name="EmptyError",this.message="no elements in sequence"}});function Rt(r,t){return new Promise(function(e,n){var i=new Wu({next:function(s){e(s),i.unsubscribe()},error:n,complete:function(){n(new Yp)}});r.subscribe(i)})}function f1(r){return r instanceof Date&&!isNaN(r)}function Pt(r,t){return yt(function(e,n){var i=0;e.subscribe(mt(n,function(s){n.next(r.call(t,s,i++))}))})}var p1=Array.isArray;function m1(r,t){return p1(t)?r.apply(void 0,Bo([],js(t))):r(t)}function g1(r){return Pt(function(t){return m1(r,t)})}function E0(r,t,e,n,i,s,o,c){var l=[],d=0,u=0,h=!1,p=function(){h&&!l.length&&!d&&t.complete()},f=function(w){return d<n?y(w):l.push(w)},y=function(w){s&&t.next(w),d++;var b=!1;Ot(e(w,u++)).subscribe(mt(t,function(C){i==null||i(C),s?f(C):t.next(C)},function(){b=!0},void 0,function(){if(b)try{d--;for(var C=function(){var A=l.shift();o||y(A)};l.length&&d<n;)C();p()}catch(A){t.error(A)}}))};return r.subscribe(mt(t,f,function(){h=!0,p()})),function(){c==null||c()}}function ut(r,t,e){return e===void 0&&(e=1/0),Re(t)?ut(function(n,i){return Pt(function(s,o){return t(n,s,i,o)})(Ot(r(n,i)))},e):(typeof t=="number"&&(e=t),yt(function(n,i){return E0(n,i,r,e)}))}function I0(r){return r===void 0&&(r=1/0),ut(bi,r)}function y1(){return I0(1)}function Af(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];return y1()(Ie(r,Rh(r)))}function fa(r){return new ct(function(t){Ot(r()).subscribe(t)})}var _1=["addListener","removeListener"],b1=["addEventListener","removeEventListener"],w1=["on","off"];function Tf(r,t,e,n){if(Re(e)&&(n=e,e=void 0),n)return Tf(r,t,e).pipe(g1(n));var i=js(S1(r)?b1.map(function(c){return function(l){return r[c](t,l,e)}}):v1(r)?_1.map(xg(r,t)):x1(r)?w1.map(xg(r,t)):[],2),s=i[0],o=i[1];if(!s&&Qp(r))return ut(function(c){return Tf(c,t,e)})(Ot(r));if(!s)throw new TypeError("Invalid event target");return new ct(function(c){var l=function(){for(var d=[],u=0;u<arguments.length;u++)d[u]=arguments[u];return c.next(1<d.length?d:d[0])};return s(l),function(){return o(l)}})}function xg(r,t){return function(e){return function(n){return r[e](t,n)}}}function v1(r){return Re(r.addListener)&&Re(r.removeListener)}function x1(r){return Re(r.on)&&Re(r.off)}function S1(r){return Re(r.addEventListener)&&Re(r.removeEventListener)}function Zp(r,t,e){return r===void 0&&(r=0),e===void 0&&(e=Qv),new ct(function(n){var i=f1(r)?+r-e.now():r;i<0&&(i=0);var s=0;return e.schedule(function(){n.closed||(n.next(s++),n.complete())},i)})}function Nc(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];var e=Rh(r),n=Zv(r,1/0),i=r;return i.length?i.length===1?Ot(i[0]):I0(n)(Ie(i,e)):Ds}var N0=new ct(Uo),k1=Array.isArray;function C1(r){return r.length===1&&k1(r[0])?r[0]:r}function qo(r,t){return yt(function(e,n){var i=0;e.subscribe(mt(n,function(s){return r.call(t,s,i++)&&n.next(s)}))})}function E1(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];return r=C1(r),r.length===1?Ot(r[0]):new ct(M0(r))}function M0(r){return function(t){for(var e=[],n=function(s){e.push(Ot(r[s]).subscribe(mt(t,function(o){if(e){for(var c=0;c<e.length;c++)c!==s&&e[c].unsubscribe();e=null}t.next(o)})))},i=0;e&&!t.closed&&i<r.length;i++)n(i)}}function rc(r){return yt(function(t,e){var n=null,i=!1,s;n=t.subscribe(mt(e,void 0,void 0,function(o){s=Ot(r(o,rc(r)(t))),n?(n.unsubscribe(),n=null,s.subscribe(e)):i=!0})),i&&(n.unsubscribe(),n=null,s.subscribe(e))})}function A0(r){return yt(function(t,e){var n=!1;t.subscribe(mt(e,function(i){n=!0,e.next(i)},function(){n||e.next(r),e.complete()}))})}function T0(r){return r<=0?function(){return Ds}:yt(function(t,e){var n=0;t.subscribe(mt(e,function(i){++n<=r&&(e.next(i),r<=n&&e.complete())}))})}function pu(){return yt(function(r,t){r.subscribe(mt(t,Uo))})}function Fh(r){return r===void 0&&(r=I1),yt(function(t,e){var n=!1;t.subscribe(mt(e,function(i){n=!0,e.next(i)},function(){return n?e.complete():e.error(r())}))})}function I1(){return new Yp}function qu(r,t){var e=arguments.length>=2;return function(n){return n.pipe(r?qo(function(i,s){return r(i,s,n)}):bi,T0(1),e?A0(t):Fh(function(){return new Yp}))}}function N1(r,t,e){return e===void 0&&(e=1/0),yt(function(n,i){var s=t;return E0(n,i,function(o,c){return r(s,o,c)},e,function(o){s=o},!1,void 0,function(){return s=null})})}function zn(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];return r.length?yt(function(e,n){M0(Bo([e],js(r)))(n)}):bi}function mu(r){r===void 0&&(r=1/0);var t;r&&typeof r=="object"?t=r:t={count:r};var e=t.count,n=e===void 0?1/0:e,i=t.delay,s=t.resetOnSuccess,o=s===void 0?!1:s;return n<=0?bi:yt(function(c,l){var d=0,u,h=function(){var p=!1;u=c.subscribe(mt(l,function(f){o&&(d=0),l.next(f)},void 0,function(f){if(d++<n){var y=function(){u?(u.unsubscribe(),u=null,h()):p=!0};if(i!=null){var w=typeof i=="number"?Zp(i):Ot(i(f,d)),b=mt(l,function(){b.unsubscribe(),y()},function(){l.complete()});w.subscribe(b)}else y()}else l.error(f)})),p&&(u.unsubscribe(),u=null,h())};h()})}function M1(){for(var r=[],t=0;t<arguments.length;t++)r[t]=arguments[t];var e=Rh(r);return yt(function(n,i){(e?Af(r,n,e):Af(r,n)).subscribe(i)})}function A1(r,t){return yt(function(e,n){var i=null,s=0,o=!1,c=function(){return o&&!i&&n.complete()};e.subscribe(mt(n,function(l){i==null||i.unsubscribe();var d=0,u=s++;Ot(r(l,u)).subscribe(i=mt(n,function(h){return n.next(t?t(l,h,u,d++):h)},function(){i=null,c()}))},function(){o=!0,c()}))})}function T1(r){return yt(function(t,e){Ot(r).subscribe(mt(e,function(){return e.complete()},Uo)),!e.closed&&t.subscribe(e)})}function Vd(r,t,e){var n=Re(r)||t||e?{next:r,error:t,complete:e}:r;return n?yt(function(i,s){var o;(o=n.subscribe)===null||o===void 0||o.call(n);var c=!0;i.subscribe(mt(s,function(l){var d;(d=n.next)===null||d===void 0||d.call(n,l),s.next(l)},function(){var l;c=!1,(l=n.complete)===null||l===void 0||l.call(n),s.complete()},function(l){var d;c=!1,(d=n.error)===null||d===void 0||d.call(n,l),s.error(l)},function(){var l,d;c&&((l=n.unsubscribe)===null||l===void 0||l.call(n)),(d=n.finalize)===null||d===void 0||d.call(n)}))}):bi}const em="1.0.5";/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const X=(r,t)=>{if(!r)throw new Error(t)};/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const P0=!!(typeof process<"u"&&process.version);var P1={};let rf=null;async function $1(){return rf||(rf=(await Promise.resolve().then(()=>x3)).default),rf}const tm=r=>P0?async(...t)=>{const e=P1.DEBUG||"";(e==="*"||(e.endsWith("*")?r.startsWith(e):r===e))&&(await $1())(r)(t)}:(...t)=>{const e=globalThis.__PUPPETEER_DEBUG;!e||!(e==="*"||(e.endsWith("*")?r.startsWith(e):r===e))||console.log(`${r}:`,...t)};/**
 * @license
 * Copyright 2018 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class nm extends Error{constructor(t,e){super(t,e),this.name=this.constructor.name}get[Symbol.toStringTag](){return this.constructor.name}}class rm extends nm{}var Uc,zc;class Mc extends nm{constructor(){super(...arguments);m(this,Uc);m(this,zc,"")}set code(e){_(this,Uc,e)}get code(){return a(this,Uc)}set originalMessage(e){_(this,zc,e)}get originalMessage(){return a(this,zc)}}Uc=new WeakMap,zc=new WeakMap;class $0 extends nm{}class mi extends Mc{}/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const R1={letter:{width:8.5,height:11},legal:{width:8.5,height:14},tabloid:{width:11,height:17},ledger:{width:17,height:11},a0:{width:33.1,height:46.8},a1:{width:23.4,height:33.1},a2:{width:16.54,height:23.4},a3:{width:11.7,height:16.54},a4:{width:8.27,height:11.7},a5:{width:5.83,height:8.27},a6:{width:4.13,height:5.83}};/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const de=tm("puppeteer:error"),F1=Object.freeze({width:800,height:600}),Ku=Symbol("Source URL for Puppeteer evaluation scripts");var Fi,Di;const Ei=class Ei{constructor(){m(this,Fi);m(this,Di)}static fromCallSite(t,e){const n=new Ei;return _(n,Fi,t),_(n,Di,e.toString()),n}get functionName(){return a(this,Fi)}get siteString(){return a(this,Di)}toString(){return`pptr:${[a(this,Fi),encodeURIComponent(a(this,Di))].join(";")}`}};Fi=new WeakMap,Di=new WeakMap,L(Ei,"INTERNAL_URL","pptr:internal"),L(Ei,"parse",t=>{t=t.slice(5);const[e="",n=""]=t.split(";"),i=new Ei;return _(i,Fi,e),_(i,Di,decodeURIComponent(n)),i}),L(Ei,"isPuppeteerURL",t=>t.startsWith("pptr:"));let yr=Ei;const ot=(r,t)=>{if(Object.prototype.hasOwnProperty.call(t,Ku))return t;const e=Error.prepareStackTrace;Error.prepareStackTrace=(i,s)=>s[2];const n=new Error().stack;return Error.prepareStackTrace=e,Object.assign(t,{[Ku]:yr.fromCallSite(r,n)})},D1=r=>{if(Object.prototype.hasOwnProperty.call(r,Ku))return r[Ku]},Ws=r=>typeof r=="string"||r instanceof String,O1=r=>typeof r=="number"||r instanceof Number;function R0(r,...t){var i;if(Ws(r))return X(t.length===0,"Cannot evaluate a string with arguments"),r;function e(s){return Object.is(s,void 0)?"undefined":JSON.stringify(s)}const n=`(${r})(${t.map(e).join(",")})`;return((i=globalThis.navigator)==null?void 0:i.userAgent)==="Cloudflare-Workers"?`((__name => (${n}))(t => t))`:n}let sf=null;async function Sg(){if(!sf)try{sf=await import("fs/promises")}catch(r){throw r instanceof TypeError?new Error("Cannot write to a path outside of a Node-like environment. fs"):r}return sf}async function F0(r,t){const e=[],n=r.getReader();if(t)throw new Error("Cannot write to a path outside of a Node-like environment.");for(;;){const{done:i,value:s}=await n.read();if(i)break;e.push(s)}try{return Uu.concat(e)}catch(i){return de(i),null}}async function D0(r,t){return new ReadableStream({async pull(e){function n(c,l){return l?typeof Uu=="function"?Uu.from(c,"base64"):Uint8Array.from(atob(c),u=>u.codePointAt(0)):new TextEncoder().encode(c)}const{data:i,base64Encoded:s,eof:o}=await r.send("IO.read",{handle:t});e.enqueue(n(i,s??!1)),o&&(await r.send("IO.close",{handle:t}),e.close())}})}function L1(r){let t=null;return new Set(["alert","confirm","prompt","beforeunload"]).has(r)&&(t=r),X(t,`Unknown javascript dialog type: ${r}`),t}function Hn(r,t){return r===0?N0:Zp(r).pipe(Pt(()=>{throw new rm(`Timed out after waiting ${r}ms`,{cause:t})}))}const kg="__puppeteer_utility_world__"+em,Cg=/^[\040\t]*\/\/[@#] sourceURL=\s*(\S*?)\s*$/m;function j1(r){return`//# sourceURL=${r}`}const B1=500;function U1(r={},t="in"){var o,c,l,d;const e={scale:1,displayHeaderFooter:!1,headerTemplate:"",footerTemplate:"",printBackground:!1,landscape:!1,pageRanges:"",preferCSSPageSize:!1,omitBackground:!1,outline:!1,tagged:!0,waitForFonts:!0};let n=8.5,i=11;if(r.format){const u=R1[r.format.toLowerCase()];X(u,"Unknown paper format: "+r.format),n=u.width,i=u.height}else n=Js(r.width,t)??n,i=Js(r.height,t)??i;const s={top:Js((o=r.margin)==null?void 0:o.top,t)||0,left:Js((c=r.margin)==null?void 0:c.left,t)||0,bottom:Js((l=r.margin)==null?void 0:l.bottom,t)||0,right:Js((d=r.margin)==null?void 0:d.right,t)||0};return r.outline&&(r.tagged=!0),{...e,...r,width:n,height:i,margin:s}}const af={px:1,in:96,cm:37.8,mm:3.78};function Js(r,t="in"){if(typeof r>"u")return;let e;if(O1(r))e=r;else if(Ws(r)){const n=r;let i=n.substring(n.length-2).toLowerCase(),s="";i in af?s=n.substring(0,n.length-2):(i="px",s=n);const o=Number(s);X(!isNaN(o),"Failed to parse parameter value: "+n),e=o*af[i]}else throw new Error("page.pdf() Cannot handle parameter type: "+typeof r);return e/af[t]}function Ze(r,t){return new ct(e=>{const n=i=>{e.next(i)};return r.on(t,n),()=>{r.off(t,n)}})}function ic(r,t){return r?Tf(r,"abort").pipe(Pt(()=>{throw r.reason instanceof Error?(r.reason.cause=t,r.reason):new Error(r.reason,{cause:t})})):N0}function wc(r){return ut(t=>Ie(Promise.resolve(r(t))).pipe(qo(e=>e),Pt(()=>t)))}function z1(r){return{all:r=r||new Map,on:function(t,e){var n=r.get(t);n?n.push(e):r.set(t,[e])},off:function(t,e){var n=r.get(t);n&&(e?n.splice(n.indexOf(e)>>>0,1):r.set(t,[]))},emit:function(t,e){var n=r.get(t);n&&n.slice().map(function(i){i(e)}),(n=r.get("*"))&&n.slice().map(function(i){i(t,e)})}}}/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */Symbol.dispose??(Symbol.dispose=Symbol("dispose"));Symbol.asyncDispose??(Symbol.asyncDispose=Symbol("asyncDispose"));const Te=Symbol.dispose,vn=Symbol.asyncDispose;var By,Uy,Fr,er;Uy=Te,By=Symbol.toStringTag;const Am=class Am{constructor(){m(this,Fr,!1);m(this,er,[]);L(this,Uy,this.dispose);L(this,By,"DisposableStack")}get disposed(){return a(this,Fr)}dispose(){if(!a(this,Fr)){_(this,Fr,!0);for(const t of a(this,er).reverse())t[Te]()}}use(t){return t&&a(this,er).push(t),t}adopt(t,e){return a(this,er).push({[Te](){e(t)}}),t}defer(t){a(this,er).push({[Te](){t()}})}move(){if(a(this,Fr))throw new ReferenceError("a disposed stack can not use anything new");const t=new Am;return _(t,er,a(this,er)),_(this,Fr,!0),t}};Fr=new WeakMap,er=new WeakMap;let _r=Am;var zy,Hy,Dr,tr;Hy=vn,zy=Symbol.toStringTag;const Tm=class Tm{constructor(){m(this,Dr,!1);m(this,tr,[]);L(this,Hy,this.dispose);L(this,zy,"AsyncDisposableStack")}get disposed(){return a(this,Dr)}async dispose(){if(!a(this,Dr)){_(this,Dr,!0);for(const t of a(this,tr).reverse())await t[vn]()}}use(t){return t&&a(this,tr).push(t),t}adopt(t,e){return a(this,tr).push({[vn](){return e(t)}}),t}defer(t){a(this,tr).push({[vn](){return t()}})}move(){if(a(this,Dr))throw new ReferenceError("a disposed stack can not use anything new");const t=new Tm;return _(t,tr,a(this,tr)),_(this,Dr,!0),t}};Dr=new WeakMap,tr=new WeakMap;let Gu=Tm;/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var nr,Fn;class He{constructor(t=z1(new Map)){m(this,nr);m(this,Fn,new Map);_(this,nr,t)}on(t,e){const n=a(this,Fn).get(t);return n===void 0?a(this,Fn).set(t,[e]):n.push(e),a(this,nr).on(t,e),this}off(t,e){const n=a(this,Fn).get(t)??[];if(e===void 0){for(const s of n)a(this,nr).off(t,s);return a(this,Fn).delete(t),this}const i=n.lastIndexOf(e);return i>-1&&a(this,nr).off(t,...n.splice(i,1)),this}emit(t,e){return a(this,nr).emit(t,e),this.listenerCount(t)>0}once(t,e){const n=i=>{e(i),this.off(t,n)};return this.on(t,n)}listenerCount(t){var e;return((e=a(this,Fn).get(t))==null?void 0:e.length)||0}removeAllListeners(t){return t!==void 0?this.off(t):(this[Te](),this)}[Te](){for(const[t,e]of a(this,Fn))for(const n of e)a(this,nr).off(t,n);a(this,Fn).clear()}}nr=new WeakMap,Fn=new WeakMap;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const H1=new Map([["geolocation","geolocation"],["midi","midi"],["notifications","notifications"],["camera","videoCapture"],["microphone","audioCapture"],["background-sync","backgroundSync"],["ambient-light-sensor","sensors"],["accelerometer","sensors"],["gyroscope","sensors"],["magnetometer","sensors"],["accessibility-events","accessibilityEvents"],["clipboard-read","clipboardReadWrite"],["clipboard-write","clipboardReadWrite"],["clipboard-sanitized-write","clipboardSanitizedWrite"],["payment-handler","paymentHandler"],["persistent-storage","durableStorage"],["idle-detection","idleDetection"],["midi-sysex","midiSysex"]]);class W1 extends He{constructor(){super()}async waitForTarget(t,e={}){const{timeout:n=3e4}=e;return await Rt(Nc(Ze(this,"targetcreated"),Ze(this,"targetchanged"),Ie(this.targets())).pipe(wc(t),zn(Hn(n))))}async pages(){return(await Promise.all(this.browserContexts().map(e=>e.pages()))).reduce((e,n)=>e.concat(n),[])}isConnected(){return this.connected}[Te](){return this.process()?void this.close().catch(de):void this.disconnect().catch(de)}[vn](){return this.process()?this.close():this.disconnect()}sessionId(){throw new Error("Not implemented")}}var $e;(function(r){r.Disconnected=Symbol("CDPSession.Disconnected"),r.Swapped=Symbol("CDPSession.Swapped"),r.Ready=Symbol("CDPSession.Ready"),r.SessionAttached="sessionattached",r.SessionDetached="sessiondetached"})($e||($e={}));class gu extends He{constructor(){super()}parentSession(){}}/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Or,Lr,Oi,Hc,fh,Sa,Wc,qc,Pf,ka;const ph=class ph{constructor(t){m(this,qc);m(this,Or,!1);m(this,Lr,!1);m(this,Oi);m(this,Hc);m(this,fh,new Promise(t=>{_(this,Hc,t)}));m(this,Sa);m(this,Wc);m(this,ka);t&&t.timeout>0&&(_(this,Wc,new rm(t.message)),_(this,Sa,setTimeout(()=>{this.reject(a(this,Wc))},t.timeout)))}static create(t){return new ph(t)}static async race(t){const e=new Set;try{const n=t.map(i=>i instanceof ph?(a(i,Sa)&&e.add(i),i.valueOrThrow()):i);return await Promise.race(n)}finally{for(const n of e)n.reject(new Error("Timeout cleared"))}}resolve(t){a(this,Lr)||a(this,Or)||(_(this,Or,!0),I(this,qc,Pf).call(this,t))}reject(t){a(this,Lr)||a(this,Or)||(_(this,Lr,!0),I(this,qc,Pf).call(this,t))}resolved(){return a(this,Or)}finished(){return a(this,Or)||a(this,Lr)}value(){return a(this,Oi)}valueOrThrow(){return a(this,ka)||_(this,ka,(async()=>{if(await a(this,fh),a(this,Lr))throw a(this,Oi);return a(this,Oi)})()),a(this,ka)}};Or=new WeakMap,Lr=new WeakMap,Oi=new WeakMap,Hc=new WeakMap,fh=new WeakMap,Sa=new WeakMap,Wc=new WeakMap,qc=new WeakSet,Pf=function(t){clearTimeout(a(this,Sa)),_(this,Oi,t),a(this,Hc).call(this)},ka=new WeakMap;let Ae=ph;/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Kc,Gc,Wy,Ca,Vc;const Ec=class Ec{constructor(){m(this,Ca,!1);m(this,Vc,[])}async acquire(t){if(!a(this,Ca))return _(this,Ca,!0),new Ec.Guard(this);const e=Ae.create();return a(this,Vc).push(e.resolve.bind(e)),await e.valueOrThrow(),new Ec.Guard(this,t)}release(){const t=a(this,Vc).shift();if(!t){_(this,Ca,!1);return}t()}};Ca=new WeakMap,Vc=new WeakMap,L(Ec,"Guard",(Wy=class{constructor(e,n){m(this,Kc);m(this,Gc);_(this,Kc,e),_(this,Gc,n)}[Te](){var e;return(e=a(this,Gc))==null||e.call(this),a(this,Kc).release()}},Kc=new WeakMap,Gc=new WeakMap,Wy));let Ac=Ec;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Li,Ea;class q1 extends He{constructor(){super();m(this,Li);m(this,Ea,0)}startScreenshot(){const e=a(this,Li)||new Ac;return _(this,Li,e),Vs(this,Ea)._++,e.acquire(()=>{Vs(this,Ea)._--,a(this,Ea)===0&&_(this,Li,void 0)})}waitForScreenshotOperations(){var e;return(e=a(this,Li))==null?void 0:e.acquire()}async waitForTarget(e,n={}){const{timeout:i=3e4}=n;return await Rt(Nc(Ze(this,"targetcreated"),Ze(this,"targetchanged"),Ie(this.targets())).pipe(wc(e),zn(Hn(i))))}get closed(){return!this.browser().browserContexts().includes(this)}get id(){}[Te](){return void this.close().catch(de)}[vn](){return this.close()}}Li=new WeakMap,Ea=new WeakMap;/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var K1=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},G1=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n}),Ia,rr,hn;class of extends q1{constructor(e,n,i){super();m(this,Ia);m(this,rr);m(this,hn);_(this,Ia,e),_(this,rr,n),_(this,hn,i)}get id(){return a(this,hn)}targets(){return a(this,rr).targets().filter(e=>e.browserContext()===this)}async pages(){return(await Promise.all(this.targets().filter(n=>{var i;return n.type()==="page"||n.type()==="other"&&((i=a(this,rr)._getIsPageTargetCallback())==null?void 0:i(n))}).map(n=>n.page()))).filter(n=>!!n)}isIncognito(){return!!a(this,hn)}async overridePermissions(e,n){const i=n.map(s=>{const o=H1.get(s);if(!o)throw new Error("Unknown permission: "+s);return o});await a(this,Ia).send("Browser.grantPermissions",{origin:e,browserContextId:a(this,hn)||void 0,permissions:i})}async clearPermissionOverrides(){await a(this,Ia).send("Browser.resetPermissions",{browserContextId:a(this,hn)||void 0})}async newPage(){const e={stack:[],error:void 0,hasError:!1};try{const n=K1(e,await this.waitForScreenshotOperations(),!1);return await a(this,rr)._createPageInContext(a(this,hn))}catch(n){e.error=n,e.hasError=!0}finally{G1(e)}}browser(){return a(this,rr)}async close(){X(a(this,hn),"Non-incognito profiles cannot be closed!"),await a(this,rr)._disposeContext(a(this,hn))}}Ia=new WeakMap,rr=new WeakMap,hn=new WeakMap;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Jt;(function(r){r.PAGE="page",r.BACKGROUND_PAGE="background_page",r.SERVICE_WORKER="service_worker",r.SHARED_WORKER="shared_worker",r.BROWSER="browser",r.WEBVIEW="webview",r.OTHER="other",r.TAB="tab"})(Jt||(Jt={}));class V1{constructor(){}async worker(){return null}async page(){return null}}/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */function Kn(r){return typeof r=="object"&&r!==null&&"name"in r&&"message"in r}function O0(r,t,e){return r.message=t,r.originalMessage=e??r.originalMessage,r}function L0(r){let t=r.error.message;return r.error&&typeof r.error=="object"&&"data"in r.error&&(t+=` ${r.error.data}`),t}/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var fn,mh;class j0{constructor(){m(this,fn,new Map);m(this,mh,J1())}create(t,e,n){const i=new X1(a(this,mh).call(this),t,e);a(this,fn).set(i.id,i);try{n(i.id)}catch(s){throw i.promise.catch(de).finally(()=>{a(this,fn).delete(i.id)}),i.reject(s),s}return i.promise.finally(()=>{a(this,fn).delete(i.id)})}reject(t,e,n){const i=a(this,fn).get(t);i&&this._reject(i,e,n)}_reject(t,e,n){let i,s;e instanceof Mc?(i=e,i.cause=t.error,s=e.message):(i=t.error,s=e),t.reject(O0(i,`Protocol error (${t.label}): ${s}`,n))}resolve(t,e){const n=a(this,fn).get(t);n&&n.resolve(e)}clear(){for(const t of a(this,fn).values())this._reject(t,new mi("Target closed"));a(this,fn).clear()}getPendingProtocolErrors(){const t=[];for(const e of a(this,fn).values())t.push(new Error(`${e.label} timed out. Trace: ${e.error.stack}`));return t}}fn=new WeakMap,mh=new WeakMap;var Xc,Jc,ji,Na,Qc;class X1{constructor(t,e,n){m(this,Xc);m(this,Jc,new Mc);m(this,ji,Ae.create());m(this,Na);m(this,Qc);_(this,Xc,t),_(this,Qc,e),n&&_(this,Na,setTimeout(()=>{a(this,ji).reject(O0(a(this,Jc),`${e} timed out. Increase the 'protocolTimeout' setting in launch/connect calls for a higher timeout if needed.`))},n))}resolve(t){clearTimeout(a(this,Na)),a(this,ji).resolve(t)}reject(t){clearTimeout(a(this,Na)),a(this,ji).reject(t)}get id(){return a(this,Xc)}get promise(){return a(this,ji).valueOrThrow()}get error(){return a(this,Jc)}get label(){return a(this,Qc)}}Xc=new WeakMap,Jc=new WeakMap,ji=new WeakMap,Na=new WeakMap,Qc=new WeakMap;function J1(){let r=0;return()=>++r}/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Bi,Ma,jr,pn,Aa,Ta;class pa extends gu{constructor(e,n,i,s){super();m(this,Bi);m(this,Ma);m(this,jr,new j0);m(this,pn);m(this,Aa);m(this,Ta);_(this,pn,e),_(this,Ma,n),_(this,Bi,i),_(this,Aa,s)}_setTarget(e){_(this,Ta,e)}_target(){return X(a(this,Ta),"Target must exist"),a(this,Ta)}connection(){return a(this,pn)}parentSession(){var n;return a(this,Aa)?((n=a(this,pn))==null?void 0:n.session(a(this,Aa)))??void 0:this}send(e,n,i){return a(this,pn)?a(this,pn)._rawSend(a(this,jr),e,n,a(this,Bi),i):Promise.reject(new mi(`Protocol error (${e}): Session closed. Most likely the ${a(this,Ma)} has been closed.`))}_onMessage(e){e.id?e.error?a(this,jr).reject(e.id,L0(e),e.error.message):a(this,jr).resolve(e.id,e.result):(X(!e.id),this.emit(e.method,e.params))}async detach(){if(!a(this,pn))throw new Error(`Session already detached. Most likely the ${a(this,Ma)} has been closed.`);await a(this,pn).send("Target.detachFromTarget",{sessionId:a(this,Bi)})}_onClosed(){a(this,jr).clear(),_(this,pn,void 0),this.emit($e.Disconnected,void 0)}id(){return a(this,Bi)}getPendingProtocolErrors(){return a(this,jr).getPendingProtocolErrors()}}Bi=new WeakMap,Ma=new WeakMap,jr=new WeakMap,pn=new WeakMap,Aa=new WeakMap,Ta=new WeakMap;/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Eg=3e4;var ir,Ui;class im{constructor(){m(this,ir);m(this,Ui);_(this,ir,null),_(this,Ui,null)}setDefaultTimeout(t){_(this,ir,t)}setDefaultNavigationTimeout(t){_(this,Ui,t)}navigationTimeout(){return a(this,Ui)!==null?a(this,Ui):a(this,ir)!==null?a(this,ir):Eg}timeout(){return a(this,ir)!==null?a(this,ir):Eg}}ir=new WeakMap,Ui=new WeakMap;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Q1=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},Y1=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});const Yo=new WeakSet;function Z1(r,t){let e=!1;if(r.prototype[Te]){const n=r.prototype[Te];r.prototype[Te]=function(){if(Yo.has(this)){Yo.delete(this);return}return n.call(this)},e=!0}if(r.prototype[vn]){const n=r.prototype[vn];r.prototype[vn]=function(){if(Yo.has(this)){Yo.delete(this);return}return n.call(this)},e=!0}return e&&(r.prototype.move=function(){return Yo.add(this),this}),r}function ye(r=t=>`Attempted to use disposed ${t.constructor.name}.`){return(t,e)=>function(...n){if(this.disposed)throw new Error(r(this));return t.call(this,...n)}}function In(r,t){const e=new WeakMap;let n=-1;return function(...i){if(n===-1&&(n=i.length),n!==i.length)throw new Error("Memoized method was called with the wrong number of arguments");let s=!1,o=e;for(const c of i)o.has(c)||(s=!0,o.set(c,new WeakMap)),o=o.get(c);if(s)return r.call(this,...i)}}function ex(r=function(){return this}){return(t,e)=>{const n=new WeakMap;return async function(...i){const s={stack:[],error:void 0,hasError:!1};try{const o=r.call(this);let c=n.get(o);c||(c=new Ac,n.set(o,c));const l=Q1(s,await c.acquire(),!0);return await t.call(this,...i)}catch(o){s.error=o,s.hasError=!0}finally{const o=Y1(s);o&&await o}}}}var tx=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},nx=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n}),la;(function(r){r.Action="action"})(la||(la={}));var zi,Hi,Wi,Yc,qi,Ki,Gn,B0,U0,z0,H0;class Ko extends He{constructor(){super(...arguments);m(this,Gn);L(this,"visibility",null);L(this,"_timeout",3e4);m(this,zi,!0);m(this,Hi,!0);m(this,Wi,!0);L(this,"operators",{conditions:(e,n)=>ut(i=>Nc(...e.map(s=>s(i,n))).pipe(A0(i))),retryAndRaceWithSignalAndTimer:(e,n)=>{const i=[];return e&&i.push(ic(e,n)),i.push(Hn(this._timeout,n)),Bv(mu({delay:yu}),zn(...i))}});m(this,Yc,(e,n)=>a(this,Hi)?Ie(e.frame.waitForFunction(i=>i instanceof HTMLElement?!["BUTTON","INPUT","SELECT","TEXTAREA","OPTION","OPTGROUP"].includes(i.nodeName)||!i.hasAttribute("disabled"):!0,{timeout:this._timeout,signal:n},e)).pipe(pu()):Ds);m(this,qi,e=>a(this,Wi)?fa(()=>Ie(e.evaluate(n=>new Promise(i=>{window.requestAnimationFrame(()=>{const s=n.getBoundingClientRect();window.requestAnimationFrame(()=>{const o=n.getBoundingClientRect();i([{x:s.x,y:s.y,width:s.width,height:s.height},{x:o.x,y:o.y,width:o.width,height:o.height}])})})})))).pipe(qu(([n,i])=>n.x===i.x&&n.y===i.y&&n.width===i.width&&n.height===i.height),mu({delay:yu}),pu()):Ds);m(this,Ki,e=>a(this,zi)?Ie(e.isIntersectingViewport({threshold:0})).pipe(qo(n=>!n),ut(()=>Ie(e.scrollIntoView())),ut(()=>fa(()=>Ie(e.isIntersectingViewport({threshold:0}))).pipe(qu(bi),mu({delay:yu}),pu()))):Ds)}static race(e){return $f.create(e)}get timeout(){return this._timeout}setTimeout(e){const n=this._clone();return n._timeout=e,n}setVisibility(e){const n=this._clone();return n.visibility=e,n}setWaitForEnabled(e){const n=this._clone();return _(n,Hi,e),n}setEnsureElementIsInTheViewport(e){const n=this._clone();return _(n,zi,e),n}setWaitForStableBoundingBox(e){const n=this._clone();return _(n,Wi,e),n}copyOptions(e){return this._timeout=e._timeout,this.visibility=e.visibility,_(this,Hi,a(e,Hi)),_(this,zi,a(e,zi)),_(this,Wi,a(e,Wi)),this}clone(){return this._clone()}async waitHandle(e){const n=new Error("Locator.waitHandle");return await Rt(this._wait(e).pipe(this.operators.retryAndRaceWithSignalAndTimer(e==null?void 0:e.signal,n)))}async wait(e){const n={stack:[],error:void 0,hasError:!1};try{return await tx(n,await this.waitHandle(e),!1).jsonValue()}catch(i){n.error=i,n.hasError=!0}finally{nx(n)}}map(e){return new Ju(this._clone(),n=>n.evaluateHandle(e))}filter(e){return new Xu(this._clone(),async(n,i)=>(await n.frame.waitForFunction(e,{signal:i,timeout:this._timeout},n),!0))}filterHandle(e){return new Xu(this._clone(),e)}mapHandle(e){return new Ju(this._clone(),e)}click(e){return Rt(I(this,Gn,B0).call(this,e))}fill(e,n){return Rt(I(this,Gn,U0).call(this,e,n))}hover(e){return Rt(I(this,Gn,z0).call(this,e))}scroll(e){return Rt(I(this,Gn,H0).call(this,e))}}zi=new WeakMap,Hi=new WeakMap,Wi=new WeakMap,Yc=new WeakMap,qi=new WeakMap,Ki=new WeakMap,Gn=new WeakSet,B0=function(e){const n=e==null?void 0:e.signal,i=new Error("Locator.click");return this._wait(e).pipe(this.operators.conditions([a(this,Ki),a(this,qi),a(this,Yc)],n),Vd(()=>this.emit(la.Action,void 0)),ut(s=>Ie(s.click(e)).pipe(rc(o=>{throw s.dispose().catch(de),o}))),this.operators.retryAndRaceWithSignalAndTimer(n,i))},U0=function(e,n){const i=n==null?void 0:n.signal,s=new Error("Locator.fill");return this._wait(n).pipe(this.operators.conditions([a(this,Ki),a(this,qi),a(this,Yc)],i),Vd(()=>this.emit(la.Action,void 0)),ut(o=>Ie(o.evaluate(c=>c instanceof HTMLSelectElement?"select":c instanceof HTMLTextAreaElement?"typeable-input":c instanceof HTMLInputElement?new Set(["textarea","text","url","tel","search","password","number","email"]).has(c.type)?"typeable-input":"other-input":c.isContentEditable?"contenteditable":"unknown")).pipe(ut(c=>{switch(c){case"select":return Ie(o.select(e).then(Uo));case"contenteditable":case"typeable-input":return Ie(o.evaluate((l,d)=>{const u=l.isContentEditable?l.innerText:l.value;if(d.length<=u.length||!d.startsWith(l.value))return l.isContentEditable?l.innerText="":l.value="",d;const h=l.isContentEditable?l.innerText:l.value;return l.isContentEditable?(l.innerText="",l.innerText=h):(l.value="",l.value=h),d.substring(h.length)},e)).pipe(ut(l=>Ie(o.type(l))));case"other-input":return Ie(o.focus()).pipe(ut(()=>Ie(o.evaluate((l,d)=>{l.value=d,l.dispatchEvent(new Event("input",{bubbles:!0})),l.dispatchEvent(new Event("change",{bubbles:!0}))},e))));case"unknown":throw new Error("Element cannot be filled out.")}})).pipe(rc(c=>{throw o.dispose().catch(de),c}))),this.operators.retryAndRaceWithSignalAndTimer(i,s))},z0=function(e){const n=e==null?void 0:e.signal,i=new Error("Locator.hover");return this._wait(e).pipe(this.operators.conditions([a(this,Ki),a(this,qi)],n),Vd(()=>this.emit(la.Action,void 0)),ut(s=>Ie(s.hover()).pipe(rc(o=>{throw s.dispose().catch(de),o}))),this.operators.retryAndRaceWithSignalAndTimer(n,i))},H0=function(e){const n=e==null?void 0:e.signal,i=new Error("Locator.scroll");return this._wait(e).pipe(this.operators.conditions([a(this,Ki),a(this,qi)],n),Vd(()=>this.emit(la.Action,void 0)),ut(s=>Ie(s.evaluate((o,c,l)=>{c!==void 0&&(o.scrollTop=c),l!==void 0&&(o.scrollLeft=l)},e==null?void 0:e.scrollTop,e==null?void 0:e.scrollLeft)).pipe(rc(o=>{throw s.dispose().catch(de),o}))),this.operators.retryAndRaceWithSignalAndTimer(n,i))};var Pa,$a;const gh=class gh extends Ko{constructor(e,n){super();m(this,Pa);m(this,$a);_(this,Pa,e),_(this,$a,n)}static create(e,n){return new gh(e,n).setTimeout("getDefaultTimeout"in e?e.getDefaultTimeout():e.page().getDefaultTimeout())}_clone(){return new gh(a(this,Pa),a(this,$a))}_wait(e){const n=e==null?void 0:e.signal;return fa(()=>Ie(a(this,Pa).waitForFunction(a(this,$a),{timeout:this.timeout,signal:n}))).pipe(Fh())}};Pa=new WeakMap,$a=new WeakMap;let Vu=gh;var bt;class W0 extends Ko{constructor(e){super();m(this,bt);_(this,bt,e),this.copyOptions(a(this,bt))}get delegate(){return a(this,bt)}setTimeout(e){const n=super.setTimeout(e);return _(n,bt,a(this,bt).setTimeout(e)),n}setVisibility(e){const n=super.setVisibility(e);return _(n,bt,a(n,bt).setVisibility(e)),n}setWaitForEnabled(e){const n=super.setWaitForEnabled(e);return _(n,bt,a(this,bt).setWaitForEnabled(e)),n}setEnsureElementIsInTheViewport(e){const n=super.setEnsureElementIsInTheViewport(e);return _(n,bt,a(this,bt).setEnsureElementIsInTheViewport(e)),n}setWaitForStableBoundingBox(e){const n=super.setWaitForStableBoundingBox(e);return _(n,bt,a(this,bt).setWaitForStableBoundingBox(e)),n}}bt=new WeakMap;var Ra;const Pm=class Pm extends W0{constructor(e,n){super(e);m(this,Ra);_(this,Ra,n)}_clone(){return new Pm(this.delegate.clone(),a(this,Ra)).copyOptions(this)}_wait(e){return this.delegate._wait(e).pipe(ut(n=>Ie(Promise.resolve(a(this,Ra).call(this,n,e==null?void 0:e.signal))).pipe(qo(i=>i),Pt(()=>n))),Fh())}};Ra=new WeakMap;let Xu=Pm;var Fa;const $m=class $m extends W0{constructor(e,n){super(e);m(this,Fa);_(this,Fa,n)}_clone(){return new $m(this.delegate.clone(),a(this,Fa)).copyOptions(this)}_wait(e){return this.delegate._wait(e).pipe(ut(n=>Ie(Promise.resolve(a(this,Fa).call(this,n,e==null?void 0:e.signal)))))}};Fa=new WeakMap;let Ju=$m;var Da,Oa,yh;const _h=class _h extends Ko{constructor(e,n){super();m(this,Da);m(this,Oa);m(this,yh,e=>this.visibility?(()=>{switch(this.visibility){case"hidden":return fa(()=>Ie(e.isHidden()));case"visible":return fa(()=>Ie(e.isVisible()))}})().pipe(qu(bi),mu({delay:yu}),pu()):Ds);_(this,Da,e),_(this,Oa,n)}static create(e,n){return new _h(e,n).setTimeout("getDefaultTimeout"in e?e.getDefaultTimeout():e.page().getDefaultTimeout())}_clone(){return new _h(a(this,Da),a(this,Oa)).copyOptions(this)}_wait(e){const n=e==null?void 0:e.signal;return fa(()=>Ie(a(this,Da).waitForSelector(a(this,Oa),{visible:!1,timeout:this._timeout,signal:n}))).pipe(qo(i=>i!==null),Fh(),this.operators.conditions([a(this,yh)],n))}};Da=new WeakMap,Oa=new WeakMap,yh=new WeakMap;let Qu=_h;function rx(r){for(const t of r)if(!(t instanceof Ko))throw new Error("Unknown locator for race candidate");return r}var La;const bh=class bh extends Ko{constructor(e){super();m(this,La);_(this,La,e)}static create(e){const n=rx(e);return new bh(n)}_clone(){return new bh(a(this,La).map(e=>e.clone())).copyOptions(this)}_wait(e){return E1(...a(this,La).map(n=>n._wait(e)))}};La=new WeakMap;let $f=bh;const yu=100;var ix=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},sx=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0},Ig=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},ax=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});function ox(r){r.optimizeForSpeed??(r.optimizeForSpeed=!1),r.type??(r.type="png"),r.fromSurface??(r.fromSurface=!0),r.fullPage??(r.fullPage=!1),r.omitBackground??(r.omitBackground=!1),r.encoding??(r.encoding="binary"),r.captureBeyondViewport??(r.captureBeyondViewport=!0)}let cx=(()=>{var n,i,s,o,c;let r=He,t=[],e;return c=class extends r{constructor(){super();L(this,"_isDragging",(ix(this,t),!1));L(this,"_timeoutSettings",new im);m(this,n,new WeakMap);m(this,i,new Kv(1));m(this,s,0);m(this,o);Ze(this,"request").pipe(ut(u=>Af(vg(1),Nc(Ze(this,"requestfailed"),Ze(this,"requestfinished"),Ze(this,"response").pipe(Pt(h=>h.request()))).pipe(qo(h=>h.id===u.id),T0(1),Pt(()=>-1)))),N1((u,h)=>vg(u+h),0),T1(Ze(this,"close")),M1(0)).subscribe(a(this,i))}on(u,h){if(u!=="request")return super.on(u,h);let p=a(this,n).get(h);return p===void 0&&(p=f=>{f.enqueueInterceptAction(()=>h(f))},a(this,n).set(h,p)),super.on(u,p)}off(u,h){return u==="request"&&(h=a(this,n).get(h)||h),super.off(u,h)}get accessibility(){return this.mainFrame().accessibility}locator(u){return typeof u=="string"?Qu.create(this,u):Vu.create(this,u)}locatorRace(u){return Ko.race(u)}async $(u){return await this.mainFrame().$(u)}async $$(u,h){return await this.mainFrame().$$(u,h)}async evaluateHandle(u,...h){return u=ot(this.evaluateHandle.name,u),await this.mainFrame().evaluateHandle(u,...h)}async $eval(u,h,...p){return h=ot(this.$eval.name,h),await this.mainFrame().$eval(u,h,...p)}async $$eval(u,h,...p){return h=ot(this.$$eval.name,h),await this.mainFrame().$$eval(u,h,...p)}async addScriptTag(u){return await this.mainFrame().addScriptTag(u)}async addStyleTag(u){return await this.mainFrame().addStyleTag(u)}url(){return this.mainFrame().url()}async content(){return await this.mainFrame().content()}async setContent(u,h){await this.mainFrame().setContent(u,h)}async goto(u,h){return await this.mainFrame().goto(u,h)}async waitForNavigation(u={}){return await this.mainFrame().waitForNavigation(u)}waitForRequest(u,h={}){const{timeout:p=this._timeoutSettings.timeout(),signal:f}=h;if(typeof u=="string"){const w=u;u=b=>b.url()===w}const y=Ze(this,"request").pipe(wc(u),zn(Hn(p),ic(f),Ze(this,"close").pipe(Pt(()=>{throw new mi("Page closed!")}))));return Rt(y)}waitForResponse(u,h={}){const{timeout:p=this._timeoutSettings.timeout(),signal:f}=h;if(typeof u=="string"){const w=u;u=b=>b.url()===w}const y=Ze(this,"response").pipe(wc(u),zn(Hn(p),ic(f),Ze(this,"close").pipe(Pt(()=>{throw new mi("Page closed!")}))));return Rt(y)}waitForNetworkIdle(u={}){return Rt(this.waitForNetworkIdle$(u))}waitForNetworkIdle$(u={}){const{timeout:h=this._timeoutSettings.timeout(),idleTime:p=B1,concurrency:f=0,signal:y}=u;return a(this,i).pipe(A1(w=>w>f?Ds:Zp(p)),Pt(()=>{}),zn(Hn(h),ic(y),Ze(this,"close").pipe(Pt(()=>{throw new mi("Page closed!")}))))}async waitForFrame(u,h={}){const{timeout:p=this.getDefaultTimeout(),signal:f}=h;return Ws(u)&&(u=y=>u===y.url()),await Rt(Nc(Ze(this,"frameattached"),Ze(this,"framenavigated"),Ie(this.frames())).pipe(wc(u),qu(),zn(Hn(p),ic(f),Ze(this,"close").pipe(Pt(()=>{throw new mi("Page closed.")})))))}async emulate(u){await Promise.all([this.setUserAgent(u.userAgent),this.setViewport(u.viewport)])}async evaluate(u,...h){return u=ot(this.evaluate.name,u),await this.mainFrame().evaluate(u,...h)}async _maybeWriteBufferToFile(u,h){if(u)throw new Error("Cannot write to a path outside of a Node-like environment.")}async _startScreencast(){++Vs(this,s)._,a(this,o)||_(this,o,this.mainFrame().client.send("Page.startScreencast",{format:"png"}).then(()=>new Promise(u=>this.mainFrame().client.once("Page.screencastFrame",()=>u())))),await a(this,o)}async _stopScreencast(){--Vs(this,s)._,a(this,o)&&(_(this,o,void 0),a(this,s)===0&&await this.mainFrame().client.send("Page.stopScreencast"))}async screenshot(u={}){const h={stack:[],error:void 0,hasError:!1};try{const p=Ig(h,await this.browserContext().startScreenshot(),!1);await this.bringToFront();const f={...u,clip:u.clip?{...u.clip}:void 0};if(f.type===void 0&&f.path!==void 0){const C=f.path;switch(C.slice(C.lastIndexOf(".")+1).toLowerCase()){case"png":f.type="png";break;case"jpeg":case"jpg":f.type="jpeg";break;case"webp":f.type="webp";break}}if(f.quality!==void 0){if(f.quality<0||f.quality>100)throw new Error(`Expected 'quality' (${f.quality}) to be between 0 and 100, inclusive.`);if(f.type===void 0||!["jpeg","webp"].includes(f.type))throw new Error(`${f.type??"png"} screenshots do not support 'quality'.`)}if(f.clip){if(f.clip.width<=0)throw new Error("'width' in 'clip' must be positive.");if(f.clip.height<=0)throw new Error("'height' in 'clip' must be positive.")}ox(f);const y=Ig(h,new Gu,!0);if(f.clip){if(f.fullPage)throw new Error("'clip' and 'fullPage' are mutually exclusive");f.clip=dx(lx(f.clip))}else if(f.fullPage){if(!f.captureBeyondViewport){const C=await this.mainFrame().isolatedRealm().evaluate(()=>{const T=document.documentElement;return{width:T.scrollWidth,height:T.scrollHeight}}),A=this.viewport();await this.setViewport({...A,...C}),y.defer(async()=>{await this.setViewport(A).catch(de)})}}else f.captureBeyondViewport=!1;const w=await this._screenshot(f);if(f.encoding==="base64")return w;const b=Buffer.from(w,"base64");return await this._maybeWriteBufferToFile(f.path,b),b}catch(p){h.error=p,h.hasError=!0}finally{const p=ax(h);p&&await p}}async title(){return await this.mainFrame().title()}click(u,h){return this.mainFrame().click(u,h)}focus(u){return this.mainFrame().focus(u)}hover(u){return this.mainFrame().hover(u)}select(u,...h){return this.mainFrame().select(u,...h)}tap(u){return this.mainFrame().tap(u)}type(u,h,p){return this.mainFrame().type(u,h,p)}async waitForSelector(u,h={}){return await this.mainFrame().waitForSelector(u,h)}waitForFunction(u,h,...p){return this.mainFrame().waitForFunction(u,h,...p)}[(e=[ex(function(){return this.browser()})],Te)](){return void this.close().catch(de)}[vn](){return this.close()}},n=new WeakMap,i=new WeakMap,s=new WeakMap,o=new WeakMap,(()=>{const u=typeof Symbol=="function"&&Symbol.metadata?Object.create(r[Symbol.metadata]??null):void 0;sx(c,null,e,{kind:"method",name:"screenshot",static:!1,private:!1,access:{has:h=>"screenshot"in h,get:h=>h.screenshot},metadata:u},null,t),u&&Object.defineProperty(c,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:u})})(),c})();function lx(r){return{...r,...r.width<0?{x:r.x+r.width,width:-r.width}:{x:r.x,width:r.width},...r.height<0?{y:r.y+r.height,height:-r.height}:{y:r.y,height:r.height}}}function dx(r){const t=Math.round(r.x),e=Math.round(r.y),n=Math.round(r.width+r.x-t),i=Math.round(r.height+r.y-e);return{...r,x:t,y:e,width:n,height:i}}/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Zc,el,tl,ja;class Ng{constructor(t,e,n,i){m(this,Zc);m(this,el);m(this,tl);m(this,ja);_(this,Zc,t),_(this,el,e),_(this,tl,n),_(this,ja,i)}type(){return a(this,Zc)}text(){return a(this,el)}args(){return a(this,tl)}location(){return a(this,ja)[0]??{}}stackTrace(){return a(this,ja)}}Zc=new WeakMap,el=new WeakMap,tl=new WeakMap,ja=new WeakMap;/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Ba,nl,Gi;class ux{constructor(t,e){m(this,Ba);m(this,nl);m(this,Gi,!1);_(this,Ba,t),_(this,nl,e.mode!=="selectSingle")}isMultiple(){return a(this,nl)}async accept(t){X(!a(this,Gi),"Cannot accept FileChooser which is already handled!"),_(this,Gi,!0),await a(this,Ba).uploadFile(...t)}async cancel(){X(!a(this,Gi),"Cannot cancel FileChooser which is already handled!"),_(this,Gi,!0),await a(this,Ba).evaluate(t=>{t.dispatchEvent(new Event("cancel",{bubbles:!0}))})}}Ba=new WeakMap,nl=new WeakMap,Gi=new WeakMap;/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var st;(function(r){r.Request=Symbol("NetworkManager.Request"),r.RequestServedFromCache=Symbol("NetworkManager.RequestServedFromCache"),r.Response=Symbol("NetworkManager.Response"),r.RequestFailed=Symbol("NetworkManager.RequestFailed"),r.RequestFinished=Symbol("NetworkManager.RequestFinished")})(st||(st={}));/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Mg=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},cf=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0},hx=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},fx=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});let da=(()=>{var c;let r=[Z1],t,e=[],n,i=[],s,o;return c=class{constructor(){Mg(this,i)}async evaluate(d,...u){return d=ot(this.evaluate.name,d),await this.realm.evaluate(d,this,...u)}async evaluateHandle(d,...u){return d=ot(this.evaluateHandle.name,d),await this.realm.evaluateHandle(d,this,...u)}async getProperty(d){return await this.evaluateHandle((u,h)=>u[h],d)}async getProperties(){const d=await this.evaluate(p=>{var w;const f=[],y=Object.getOwnPropertyDescriptors(p);for(const b in y)(w=y[b])!=null&&w.enumerable&&f.push(b);return f}),u=new Map,h=await Promise.all(d.map(p=>this.getProperty(p)));for(const[p,f]of Object.entries(d)){const y={stack:[],error:void 0,hasError:!1};try{const w=hx(y,h[p],!1);w&&u.set(f,w.move())}catch(w){y.error=w,y.hasError=!0}finally{fx(y)}}return u}[(s=[ye()],o=[ye()],Te)](){return void this.dispose().catch(de)}[vn](){return this.dispose()}},n=c,(()=>{const d=typeof Symbol=="function"&&Symbol.metadata?Object.create(null):void 0;cf(c,null,s,{kind:"method",name:"getProperty",static:!1,private:!1,access:{has:u=>"getProperty"in u,get:u=>u.getProperty},metadata:d},null,i),cf(c,null,o,{kind:"method",name:"getProperties",static:!1,private:!1,access:{has:u=>"getProperties"in u,get:u=>u.getProperties},metadata:d},null,i),cf(null,t={value:n},r,{kind:"class",name:n.name,metadata:d},null,e),n=t.value,d&&Object.defineProperty(n,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:d}),Mg(n,e)})(),n})();var px=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},mx=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n}),sr,rl,il;class Yu{constructor(t,e,n){m(this,sr);m(this,rl);m(this,il);_(this,sr,t),_(this,rl,e),_(this,il,n)}get name(){return a(this,sr)}get initSource(){return a(this,il)}async run(t,e,n,i){const s=new _r;try{if(!i){const o={stack:[],error:void 0,hasError:!1};try{const l=await px(o,await t.evaluateHandle((d,u)=>globalThis[d].args.get(u),a(this,sr),e),!1).getProperties();for(const[d,u]of l)if(d in n)switch(u.remoteObject().subtype){case"node":n[+d]=u;break;default:s.use(u)}else s.use(u)}catch(c){o.error=c,o.hasError=!0}finally{mx(o)}}await t.evaluate((o,c,l)=>{const d=globalThis[o].callbacks;d.get(c).resolve(l),d.delete(c)},a(this,sr),e,await a(this,rl).call(this,...n));for(const o of n)o instanceof da&&s.use(o)}catch(o){Kn(o)?await t.evaluate((c,l,d,u)=>{const h=new Error(d);h.stack=u;const p=globalThis[c].callbacks;p.get(l).reject(h),p.delete(l)},a(this,sr),e,o.message,o.stack).catch(de):await t.evaluate((c,l,d)=>{const u=globalThis[c].callbacks;u.get(l).reject(d),u.delete(l)},a(this,sr),e,o).catch(de)}}}sr=new WeakMap,rl=new WeakMap,il=new WeakMap;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const gx=tm("puppeteer:protocol:SEND ►"),yx=tm("puppeteer:protocol:RECV ◀");var sl,Dn,Vi,Ua,Ct,Xi,za,Br,al,Rf;class q0 extends He{constructor(e,n,i=0,s){super();m(this,al);m(this,sl);m(this,Dn);m(this,Vi);m(this,Ua);m(this,Ct,new Map);m(this,Xi,!1);m(this,za,new Set);m(this,Br,new j0);_(this,sl,e),_(this,Vi,i),_(this,Ua,s??18e4),_(this,Dn,n),a(this,Dn).onmessage=this.onMessage.bind(this),a(this,Dn).onclose=I(this,al,Rf).bind(this)}static fromSession(e){return e.connection()}get delay(){return a(this,Vi)}get timeout(){return a(this,Ua)}get _closed(){return a(this,Xi)}get _sessions(){return a(this,Ct)}session(e){return a(this,Ct).get(e)||null}url(){return a(this,sl)}send(e,n,i){return this._rawSend(a(this,Br),e,n,void 0,i)}_rawSend(e,n,i,s,o){return a(this,Xi)?Promise.reject(new Error("Protocol error: Connection closed.")):e.create(n,(o==null?void 0:o.timeout)??a(this,Ua),c=>{const l=JSON.stringify({method:n,params:i,id:c,sessionId:s});gx(l),a(this,Dn).send(l)})}async closeBrowser(){await this.send("Browser.close")}async onMessage(e){a(this,Vi)&&await new Promise(i=>setTimeout(i,a(this,Vi))),yx(e);const n=JSON.parse(e);if(n.method==="Target.attachedToTarget"){const i=n.params.sessionId,s=new pa(this,n.params.targetInfo.type,i,n.sessionId);a(this,Ct).set(i,s),this.emit($e.SessionAttached,s);const o=a(this,Ct).get(n.sessionId);o&&o.emit($e.SessionAttached,s)}else if(n.method==="Target.detachedFromTarget"){const i=a(this,Ct).get(n.params.sessionId);if(i){i._onClosed(),a(this,Ct).delete(n.params.sessionId),this.emit($e.SessionDetached,i);const s=a(this,Ct).get(n.sessionId);s&&s.emit($e.SessionDetached,i)}}if(n.sessionId){const i=a(this,Ct).get(n.sessionId);i&&i._onMessage(n)}else n.id?n.error?a(this,Br).reject(n.id,L0(n),n.error.message):a(this,Br).resolve(n.id,n.result):this.emit(n.method,n.params)}dispose(){I(this,al,Rf).call(this),a(this,Dn).close()}isAutoAttached(e){return!a(this,za).has(e)}async _createSession(e,n=!0){n||a(this,za).add(e.targetId);const{sessionId:i}=await this.send("Target.attachToTarget",{targetId:e.targetId,flatten:!0});a(this,za).delete(e.targetId);const s=a(this,Ct).get(i);if(!s)throw new Error("CDPSession creation failed.");return s}async createSession(e){return await this._createSession(e,!1)}getPendingProtocolErrors(){const e=[];e.push(...a(this,Br).getPendingProtocolErrors());for(const n of a(this,Ct).values())e.push(...n.getPendingProtocolErrors());return e}}sl=new WeakMap,Dn=new WeakMap,Vi=new WeakMap,Ua=new WeakMap,Ct=new WeakMap,Xi=new WeakMap,za=new WeakMap,Br=new WeakMap,al=new WeakSet,Rf=function(){if(!a(this,Xi)){_(this,Xi,!0),a(this,Dn).onmessage=void 0,a(this,Dn).onclose=void 0,a(this,Br).clear();for(const e of a(this,Ct).values())e._onClosed();a(this,Ct).clear(),this.emit($e.Disconnected,void 0)}};function Ff(r){return r instanceof mi}/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Ji,Qi;class _x{constructor(t){m(this,Ji);m(this,Qi);_(this,Ji,new bx(t)),_(this,Qi,new wx(t))}updateClient(t){a(this,Ji).updateClient(t),a(this,Qi).updateClient(t)}async startJSCoverage(t={}){return await a(this,Ji).start(t)}async stopJSCoverage(){return await a(this,Ji).stop()}async startCSSCoverage(t={}){return await a(this,Qi).start(t)}async stopCSSCoverage(){return await a(this,Qi).stop()}}Ji=new WeakMap,Qi=new WeakMap;var Et,Yi,Zi,es,Ha,ol,Wa,qa,Ho,K0,G0;class bx{constructor(t){m(this,Ho);m(this,Et);m(this,Yi,!1);m(this,Zi,new Map);m(this,es,new Map);m(this,Ha);m(this,ol,!1);m(this,Wa,!1);m(this,qa,!1);_(this,Et,t)}updateClient(t){_(this,Et,t)}async start(t={}){X(!a(this,Yi),"JSCoverage is already enabled");const{resetOnNavigation:e=!0,reportAnonymousScripts:n=!1,includeRawScriptCoverage:i=!1,useBlockCoverage:s=!0}=t;_(this,ol,e),_(this,Wa,n),_(this,qa,i),_(this,Yi,!0),a(this,Zi).clear(),a(this,es).clear(),_(this,Ha,new _r);const o=a(this,Ha).use(new He(a(this,Et)));o.on("Debugger.scriptParsed",I(this,Ho,G0).bind(this)),o.on("Runtime.executionContextsCleared",I(this,Ho,K0).bind(this)),await Promise.all([a(this,Et).send("Profiler.enable"),a(this,Et).send("Profiler.startPreciseCoverage",{callCount:a(this,qa),detailed:s}),a(this,Et).send("Debugger.enable"),a(this,Et).send("Debugger.setSkipAllPauses",{skip:!0})])}async stop(){var i;X(a(this,Yi),"JSCoverage is not enabled"),_(this,Yi,!1);const t=await Promise.all([a(this,Et).send("Profiler.takePreciseCoverage"),a(this,Et).send("Profiler.stopPreciseCoverage"),a(this,Et).send("Profiler.disable"),a(this,Et).send("Debugger.disable")]);(i=a(this,Ha))==null||i.dispose();const e=[],n=t[0];for(const s of n.result){let o=a(this,Zi).get(s.scriptId);!o&&a(this,Wa)&&(o="debugger://VM"+s.scriptId);const c=a(this,es).get(s.scriptId);if(c===void 0||o===void 0)continue;const l=[];for(const u of s.functions)l.push(...u.ranges);const d=J0(l);a(this,qa)?e.push({url:o,ranges:d,text:c,rawScriptCoverage:s}):e.push({url:o,ranges:d,text:c})}return e}}Et=new WeakMap,Yi=new WeakMap,Zi=new WeakMap,es=new WeakMap,Ha=new WeakMap,ol=new WeakMap,Wa=new WeakMap,qa=new WeakMap,Ho=new WeakSet,K0=function(){a(this,ol)&&(a(this,Zi).clear(),a(this,es).clear())},G0=async function(t){if(!yr.isPuppeteerURL(t.url)&&!(!t.url&&!a(this,Wa)))try{const e=await a(this,Et).send("Debugger.getScriptSource",{scriptId:t.scriptId});a(this,Zi).set(t.scriptId,t.url),a(this,es).set(t.scriptId,e.scriptSource)}catch(e){de(e)}};var qt,ts,Ur,ns,Ka,cl,Wo,V0,X0;class wx{constructor(t){m(this,Wo);m(this,qt);m(this,ts,!1);m(this,Ur,new Map);m(this,ns,new Map);m(this,Ka);m(this,cl,!1);_(this,qt,t)}updateClient(t){_(this,qt,t)}async start(t={}){X(!a(this,ts),"CSSCoverage is already enabled");const{resetOnNavigation:e=!0}=t;_(this,cl,e),_(this,ts,!0),a(this,Ur).clear(),a(this,ns).clear(),_(this,Ka,new _r);const n=a(this,Ka).use(new He(a(this,qt)));n.on("CSS.styleSheetAdded",I(this,Wo,X0).bind(this)),n.on("Runtime.executionContextsCleared",I(this,Wo,V0).bind(this)),await Promise.all([a(this,qt).send("DOM.enable"),a(this,qt).send("CSS.enable"),a(this,qt).send("CSS.startRuleUsageTracking")])}async stop(){var i;X(a(this,ts),"CSSCoverage is not enabled"),_(this,ts,!1);const t=await a(this,qt).send("CSS.stopRuleUsageTracking");await Promise.all([a(this,qt).send("CSS.disable"),a(this,qt).send("DOM.disable")]),(i=a(this,Ka))==null||i.dispose();const e=new Map;for(const s of t.ruleUsage){let o=e.get(s.styleSheetId);o||(o=[],e.set(s.styleSheetId,o)),o.push({startOffset:s.startOffset,endOffset:s.endOffset,count:s.used?1:0})}const n=[];for(const s of a(this,Ur).keys()){const o=a(this,Ur).get(s);X(typeof o<"u",`Stylesheet URL is undefined (styleSheetId=${s})`);const c=a(this,ns).get(s);X(typeof c<"u",`Stylesheet text is undefined (styleSheetId=${s})`);const l=J0(e.get(s)||[]);n.push({url:o,ranges:l,text:c})}return n}}qt=new WeakMap,ts=new WeakMap,Ur=new WeakMap,ns=new WeakMap,Ka=new WeakMap,cl=new WeakMap,Wo=new WeakSet,V0=function(){a(this,cl)&&(a(this,Ur).clear(),a(this,ns).clear())},X0=async function(t){const e=t.header;if(e.sourceURL)try{const n=await a(this,qt).send("CSS.getStyleSheetText",{styleSheetId:e.styleSheetId});a(this,Ur).set(e.styleSheetId,e.sourceURL),a(this,ns).set(e.styleSheetId,n.text)}catch(n){de(n)}};function J0(r){const t=[];for(const s of r)t.push({offset:s.startOffset,type:0,range:s}),t.push({offset:s.endOffset,type:1,range:s});t.sort((s,o)=>{if(s.offset!==o.offset)return s.offset-o.offset;if(s.type!==o.type)return o.type-s.type;const c=s.range.endOffset-s.range.startOffset,l=o.range.endOffset-o.range.startOffset;return s.type===0?l-c:c-l});const e=[],n=[];let i=0;for(const s of t){if(e.length&&i<s.offset&&e[e.length-1]>0){const o=n[n.length-1];o&&o.end===i?o.end=s.offset:n.push({start:i,end:s.offset})}i=s.offset,s.type===0?e.push(s.range.count):e.pop()}return n.filter(s=>s.end-s.start>0)}/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var ll,dl,ul;class vx{constructor(t,e,n=""){m(this,ll);m(this,dl);m(this,ul);L(this,"handled",!1);_(this,ll,t),_(this,dl,e),_(this,ul,n)}type(){return a(this,ll)}message(){return a(this,dl)}defaultValue(){return a(this,ul)}async accept(t){X(!this.handled,"Cannot accept dialog which is already handled!"),this.handled=!0,await this.handle({accept:!0,text:t})}async dismiss(){X(!this.handled,"Cannot dismiss dialog which is already handled!"),this.handled=!0,await this.handle({accept:!1})}}ll=new WeakMap,dl=new WeakMap,ul=new WeakMap;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var hl;class xx extends vx{constructor(e,n,i,s=""){super(n,i,s);m(this,hl);_(this,hl,e)}async handle(e){await a(this,hl).send("Page.handleJavaScriptDialog",{accept:e.accept,promptText:e.text})}}hl=new WeakMap;var Sx=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},Nn=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0},Mn=function(r,t,e){return typeof t=="symbol"&&(t=t.description?"[".concat(t.description,"]"):""),Object.defineProperty(r,"name",{configurable:!0,value:e?"".concat(e," ",t):t})},rs,Ga,fl;class An{constructor(t,e,n){m(this,rs);m(this,Ga);m(this,fl);_(this,rs,t),_(this,Ga,e),_(this,fl,n),a(this,Ga).registerState(this)}async setState(t){_(this,rs,t),await this.sync()}get state(){return a(this,rs)}async sync(){await Promise.all(a(this,Ga).clients().map(t=>a(this,fl).call(this,t,a(this,rs))))}}rs=new WeakMap,Ga=new WeakMap,fl=new WeakMap;let kx=(()=>{var D,U,O,K,F,H,B,P,N,j,W,g,E,k,v,x,Df,Of,Lf,jf,Bf,Uf,zf,Hf,Wf,qf,me;let r=[],t,e,n,i,s,o,c,l,d,u,h,p,f,y,w,b,C,A,T,M;return me=class{constructor(J){m(this,x);m(this,D,Sx(this,r));m(this,U,!1);m(this,O,!1);m(this,K,[]);m(this,F,new An({active:!1},this,a(this,x,Df)));m(this,H,new An({active:!1},this,a(this,x,Of)));m(this,B,new An({active:!1},this,a(this,x,Lf)));m(this,P,new An({active:!1},this,a(this,x,jf)));m(this,N,new An({active:!1},this,a(this,x,Bf)));m(this,j,new An({active:!1},this,a(this,x,Uf)));m(this,W,new An({active:!1},this,a(this,x,zf)));m(this,g,new An({active:!1},this,a(this,x,Hf)));m(this,E,new An({active:!1},this,a(this,x,Wf)));m(this,k,new An({javaScriptEnabled:!0,active:!1},this,a(this,x,qf)));m(this,v,new Set);_(this,D,J)}updateClient(J){_(this,D,J),a(this,v).delete(J)}registerState(J){a(this,K).push(J)}clients(){return[a(this,D),...Array.from(a(this,v))]}async registerSpeculativeSession(J){a(this,v).add(J),J.once($e.Disconnected,()=>{a(this,v).delete(J)}),Promise.all(a(this,K).map(G=>G.sync().catch(de)))}get javascriptEnabled(){return a(this,k).state.javaScriptEnabled}async emulateViewport(J){const G=a(this,F).state;if(!J&&!G.active)return!1;await a(this,F).setState(J?{viewport:J,active:!0}:{active:!1});const z=(J==null?void 0:J.isMobile)||!1,ee=(J==null?void 0:J.hasTouch)||!1,ge=a(this,U)!==z||a(this,O)!==ee;return _(this,U,z),_(this,O,ee),ge}async emulateIdleState(J){await a(this,H).setState({active:!0,overrides:J})}async emulateTimezone(J){await a(this,B).setState({timezoneId:J,active:!0})}async emulateVisionDeficiency(J){X(!J||new Set(["none","achromatopsia","blurredVision","deuteranopia","protanopia","tritanopia"]).has(J),`Unsupported vision deficiency: ${J}`),await a(this,P).setState({active:!0,visionDeficiency:J})}async emulateCPUThrottling(J){X(J===null||J>=1,"Throttling rate should be greater or equal to 1"),await a(this,N).setState({active:!0,factor:J??void 0})}async emulateMediaFeatures(J){if(Array.isArray(J))for(const G of J){const z=G.name;X(/^(?:prefers-(?:color-scheme|reduced-motion)|color-gamut)$/.test(z),"Unsupported media feature: "+z)}await a(this,j).setState({active:!0,mediaFeatures:J})}async emulateMediaType(J){X(J==="screen"||J==="print"||(J??void 0)===void 0,"Unsupported media type: "+J),await a(this,W).setState({type:J,active:!0})}async setGeolocation(J){const{longitude:G,latitude:z,accuracy:ee=0}=J;if(G<-180||G>180)throw new Error(`Invalid longitude "${G}": precondition -180 <= LONGITUDE <= 180 failed.`);if(z<-90||z>90)throw new Error(`Invalid latitude "${z}": precondition -90 <= LATITUDE <= 90 failed.`);if(ee<0)throw new Error(`Invalid accuracy "${ee}": precondition 0 <= ACCURACY failed.`);await a(this,g).setState({active:!0,geoLocation:{longitude:G,latitude:z,accuracy:ee}})}async resetDefaultBackgroundColor(){await a(this,E).setState({active:!0,color:void 0})}async setTransparentBackgroundColor(){await a(this,E).setState({active:!0,color:{r:0,g:0,b:0,a:0}})}async setJavaScriptEnabled(J){await a(this,k).setState({active:!0,javaScriptEnabled:J})}},D=new WeakMap,U=new WeakMap,O=new WeakMap,K=new WeakMap,F=new WeakMap,H=new WeakMap,B=new WeakMap,P=new WeakMap,N=new WeakMap,j=new WeakMap,W=new WeakMap,g=new WeakMap,E=new WeakMap,k=new WeakMap,v=new WeakMap,x=new WeakSet,Df=function(){return e.value},Of=function(){return i.value},Lf=function(){return o.value},jf=function(){return l.value},Bf=function(){return u.value},Uf=function(){return p.value},zf=function(){return y.value},Hf=function(){return b.value},Wf=function(){return A.value},qf=function(){return M.value},(()=>{const J=typeof Symbol=="function"&&Symbol.metadata?Object.create(null):void 0;t=[In],n=[In],s=[In],c=[In],d=[In],h=[In],f=[In],w=[In],C=[In],T=[In],Nn(me,e={value:Mn(async function(G,z){if(!z.viewport){await Promise.all([G.send("Emulation.clearDeviceMetricsOverride"),G.send("Emulation.setTouchEmulationEnabled",{enabled:!1})]).catch(de);return}const{viewport:ee}=z,ge=ee.isMobile||!1,De=ee.width,he=ee.height,jt=ee.deviceScaleFactor??1,Sn=ee.isLandscape?{angle:90,type:"landscapePrimary"}:{angle:0,type:"portraitPrimary"},rn=ee.hasTouch||!1;await Promise.all([G.send("Emulation.setDeviceMetricsOverride",{mobile:ge,width:De,height:he,deviceScaleFactor:jt,screenOrientation:Sn}).catch(je=>{if(je.message.includes("Target does not support metrics override")){de(je);return}throw je}),G.send("Emulation.setTouchEmulationEnabled",{enabled:rn})])},"#applyViewport")},t,{kind:"method",name:"#applyViewport",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Df)},metadata:J},null,r),Nn(me,i={value:Mn(async function(G,z){z.active&&(z.overrides?await G.send("Emulation.setIdleOverride",{isUserActive:z.overrides.isUserActive,isScreenUnlocked:z.overrides.isScreenUnlocked}):await G.send("Emulation.clearIdleOverride"))},"#emulateIdleState")},n,{kind:"method",name:"#emulateIdleState",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Of)},metadata:J},null,r),Nn(me,o={value:Mn(async function(G,z){if(z.active)try{await G.send("Emulation.setTimezoneOverride",{timezoneId:z.timezoneId||""})}catch(ee){throw Kn(ee)&&ee.message.includes("Invalid timezone")?new Error(`Invalid timezone ID: ${z.timezoneId}`):ee}},"#emulateTimezone")},s,{kind:"method",name:"#emulateTimezone",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Lf)},metadata:J},null,r),Nn(me,l={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setEmulatedVisionDeficiency",{type:z.visionDeficiency||"none"})},"#emulateVisionDeficiency")},c,{kind:"method",name:"#emulateVisionDeficiency",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,jf)},metadata:J},null,r),Nn(me,u={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setCPUThrottlingRate",{rate:z.factor??1})},"#emulateCpuThrottling")},d,{kind:"method",name:"#emulateCpuThrottling",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Bf)},metadata:J},null,r),Nn(me,p={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setEmulatedMedia",{features:z.mediaFeatures})},"#emulateMediaFeatures")},h,{kind:"method",name:"#emulateMediaFeatures",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Uf)},metadata:J},null,r),Nn(me,y={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setEmulatedMedia",{media:z.type||""})},"#emulateMediaType")},f,{kind:"method",name:"#emulateMediaType",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,zf)},metadata:J},null,r),Nn(me,b={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setGeolocationOverride",z.geoLocation?{longitude:z.geoLocation.longitude,latitude:z.geoLocation.latitude,accuracy:z.geoLocation.accuracy}:void 0)},"#setGeolocation")},w,{kind:"method",name:"#setGeolocation",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Hf)},metadata:J},null,r),Nn(me,A={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setDefaultBackgroundColorOverride",{color:z.color})},"#setDefaultBackgroundColor")},C,{kind:"method",name:"#setDefaultBackgroundColor",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,Wf)},metadata:J},null,r),Nn(me,M={value:Mn(async function(G,z){z.active&&await G.send("Emulation.setScriptExecutionDisabled",{value:!z.javaScriptEnabled})},"#setJavaScriptEnabled")},T,{kind:"method",name:"#setJavaScriptEnabled",static:!1,private:!0,access:{has:G=>Qt(x,G),get:G=>a(G,x,qf)},metadata:J},null,r),J&&Object.defineProperty(me,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:J})})(),me})();/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Zt,is,On,pl,Va,Xa,zr,ml,Ja,wh,gl,yl,vh,ss,sc;class Q0 extends He{constructor(e,n,i){super();m(this,ss);m(this,Zt);m(this,is,new Map);m(this,On,new Map);m(this,pl,new Map);m(this,Va);m(this,Xa);m(this,zr,new WeakMap);m(this,ml,Ae.create());m(this,Ja,new Set);m(this,wh,e=>{this.removeSessionListeners(e),a(this,pl).delete(e.id())});m(this,gl,async e=>{if(a(this,is).has(e.targetInfo.targetId))return;if(a(this,is).set(e.targetInfo.targetId,e.targetInfo),e.targetInfo.type==="browser"&&e.targetInfo.attached){const i=a(this,Xa).call(this,e.targetInfo,void 0);i._initialize(),a(this,On).set(e.targetInfo.targetId,i),I(this,ss,sc).call(this,i._targetId);return}const n=a(this,Xa).call(this,e.targetInfo,void 0);if(a(this,Va)&&!a(this,Va).call(this,n)){I(this,ss,sc).call(this,e.targetInfo.targetId);return}n._initialize(),a(this,On).set(e.targetInfo.targetId,n),this.emit("targetAvailable",n),I(this,ss,sc).call(this,n._targetId)});m(this,yl,e=>{a(this,is).delete(e.targetId),I(this,ss,sc).call(this,e.targetId);const n=a(this,On).get(e.targetId);n&&(this.emit("targetGone",n),a(this,On).delete(e.targetId))});m(this,vh,async(e,n)=>{const i=n.targetInfo,s=a(this,Zt).session(n.sessionId);if(!s)throw new Error(`Session ${n.sessionId} was not created.`);const o=a(this,On).get(i.targetId);X(o,`Target ${i.targetId} is missing`),s._setTarget(o),this.setupAttachmentListeners(s),a(this,pl).set(s.id(),a(this,On).get(i.targetId)),e.emit($e.Ready,s)});_(this,Zt,e),_(this,Va,i),_(this,Xa,n),a(this,Zt).on("Target.targetCreated",a(this,gl)),a(this,Zt).on("Target.targetDestroyed",a(this,yl)),a(this,Zt).on($e.SessionDetached,a(this,wh)),this.setupAttachmentListeners(a(this,Zt))}setupAttachmentListeners(e){const n=i=>a(this,vh).call(this,e,i);X(!a(this,zr).has(e)),a(this,zr).set(e,n),e.on("Target.attachedToTarget",n)}removeSessionListeners(e){a(this,zr).has(e)&&(e.off("Target.attachedToTarget",a(this,zr).get(e)),a(this,zr).delete(e))}getAvailableTargets(){return a(this,On)}getChildTargets(e){return new Set}dispose(){a(this,Zt).off("Target.targetCreated",a(this,gl)),a(this,Zt).off("Target.targetDestroyed",a(this,yl))}async initialize(){await a(this,Zt).send("Target.setDiscoverTargets",{discover:!0,filter:[{}]}),_(this,Ja,new Set(a(this,is).keys())),await a(this,ml).valueOrThrow()}}Zt=new WeakMap,is=new WeakMap,On=new WeakMap,pl=new WeakMap,Va=new WeakMap,Xa=new WeakMap,zr=new WeakMap,ml=new WeakMap,Ja=new WeakMap,wh=new WeakMap,gl=new WeakMap,yl=new WeakMap,vh=new WeakMap,ss=new WeakSet,sc=function(e){a(this,Ja).delete(e),a(this,Ja).size===0&&a(this,ml).resolve()};/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const _u=Symbol("_isElementHandle");/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Ag=new Map,Cx=r=>{let t=Ag.get(r);return t||(t=new Function(`return ${r}`)(),Ag.set(r,t),t)};function yi(r){var e;let t;return typeof r=="function"&&((e=globalThis.navigator)==null?void 0:e.userAgent)==="Cloudflare-Workers"?t=`((__name => (${r}))(t => t))`:t=r.toString(),t}const vc=(r,t)=>{let e=yi(r);for(const[n,i]of Object.entries(t))e=e.replace(new RegExp(`PLACEHOLDER\\(\\s*(?:'${n}'|"${n}")\\s*\\)`,"g"),`(${i})`);return Cx(e)};/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var bu=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},Kf=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});const Ex=20;async function*Ix(r,t){const e={stack:[],error:void 0,hasError:!1};try{const i=await bu(e,await r.evaluateHandle(async(c,l)=>{const d=[];for(;d.length<l;){const u=await c.next();if(u.done)break;d.push(u.value)}return d},t),!1).getProperties(),s=i.values();return bu(e,new _r,!1).defer(()=>{for(const c of s){const l={stack:[],error:void 0,hasError:!1};try{bu(l,c,!1)[Te]()}catch(d){l.error=d,l.hasError=!0}finally{Kf(l)}}}),yield*s,i.size===0}catch(n){e.error=n,e.hasError=!0}finally{Kf(e)}}async function*Nx(r){let t=Ex;for(;!(yield*Ix(r,t));)t<<=1}async function*Y0(r){const t={stack:[],error:void 0,hasError:!1};try{const e=bu(t,await r.evaluateHandle(n=>(async function*(){yield*n})()),!1);yield*Nx(e)}catch(e){t.error=e,t.hasError=!0}finally{Kf(t)}}/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var _l;const xh=class xh{constructor(t){m(this,_l);_(this,_l,t)}async get(t){return await a(this,_l).call(this,t)}};_l=new WeakMap,L(xh,"create",t=>new xh(t));let qn=xh;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Xd=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},Jd=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});class br{static get _querySelector(){if(this.querySelector)return this.querySelector;if(!this.querySelectorAll)throw new Error("Cannot create default `querySelector`.");return this.querySelector=vc(async(t,e,n)=>{const s=PLACEHOLDER("querySelectorAll")(t,e,n);for await(const o of s)return o;return null},{querySelectorAll:yi(this.querySelectorAll)})}static get _querySelectorAll(){if(this.querySelectorAll)return this.querySelectorAll;if(!this.querySelector)throw new Error("Cannot create default `querySelectorAll`.");return this.querySelectorAll=vc(async function*(t,e,n){const s=await PLACEHOLDER("querySelector")(t,e,n);s&&(yield s)},{querySelector:yi(this.querySelector)})}static async*queryAll(t,e){const n={stack:[],error:void 0,hasError:!1};try{const i=Xd(n,await t.evaluateHandle(this._querySelectorAll,e,qn.create(s=>s.puppeteerUtil)),!1);yield*Y0(i)}catch(i){n.error=i,n.hasError=!0}finally{Jd(n)}}static async queryOne(t,e){const n={stack:[],error:void 0,hasError:!1};try{const i=Xd(n,await t.evaluateHandle(this._querySelector,e,qn.create(s=>s.puppeteerUtil)),!1);return _u in i?i.move():null}catch(i){n.error=i,n.hasError=!0}finally{Jd(n)}}static async waitFor(t,e,n){const i={stack:[],error:void 0,hasError:!1};try{let s;const o=Xd(i,await(async()=>{if(!(_u in t)){s=t;return}return s=t.frame,await s.isolatedRealm().adoptHandle(t)})(),!1),{visible:c=!1,hidden:l=!1,timeout:d,signal:u}=n,h=n.polling??(c||l?"raf":"mutation");try{const p={stack:[],error:void 0,hasError:!1};try{u==null||u.throwIfAborted();const f=Xd(p,await s.isolatedRealm().waitForFunction(async(y,w,b,C,A)=>{const M=await y.createFunction(w)(C??document,b,y);return y.checkVisibility(M,A)},{polling:h,root:o,timeout:d,signal:u},qn.create(y=>y.puppeteerUtil),yi(this._querySelector),e,o,c?!0:l?!1:void 0),!1);if(u!=null&&u.aborted)throw u.reason;return _u in f?await s.mainRealm().transferHandle(f):null}catch(f){p.error=f,p.hasError=!0}finally{Jd(p)}}catch(p){throw!Kn(p)||p.name==="AbortError"||(p.message=`Waiting for selector \`${e}\` failed: ${p.message}`),p}}catch(s){i.error=s,i.hasError=!0}finally{Jd(i)}}}L(br,"querySelectorAll"),L(br,"querySelector");class Dh{static async*map(t,e){for await(const n of t)yield await e(n)}static async*flatMap(t,e){for await(const n of t)yield*e(n)}static async collect(t){const e=[];for await(const n of t)e.push(n);return e}static async first(t){for await(const e of t)return e}}/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Mx=r=>["name","role"].includes(r),Tg=r=>r.replace(/ +/g," ").trim(),Ax=/\[\s*(?<attribute>\w+)\s*=\s*(?<quote>"|')(?<value>\\.|.*?(?=\k<quote>))\k<quote>\s*\]/g,Tx=r=>{const t={},e=r.replace(Ax,(n,i,s,o)=>(i=i.trim(),X(Mx(i),`Unknown aria attribute "${i}" in selector`),t[i]=Tg(o),""));return e&&!t.name&&(t.name=Tg(e)),t},Ic=class Ic extends br{static async*queryAll(t,e){const{name:n,role:i}=Tx(e);yield*t.queryAXTree(n,i)}};L(Ic,"querySelector",async(t,e,{ariaQuerySelector:n})=>await n(t,e)),L(Ic,"queryOne",async(t,e)=>await Dh.first(Ic.queryAll(t,e))??null);let Tc=Ic;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class Zu extends br{}L(Zu,"querySelector",(t,e,{cssQuerySelector:n})=>n(t,e)),L(Zu,"querySelectorAll",(t,e,{cssQuerySelectorAll:n})=>n(t,e));const Px='"use strict";var g=Object.defineProperty;var X=Object.getOwnPropertyDescriptor;var B=Object.getOwnPropertyNames;var Y=Object.prototype.hasOwnProperty;var l=(t,e)=>{for(var r in e)g(t,r,{get:e[r],enumerable:!0})},G=(t,e,r,o)=>{if(e&&typeof e=="object"||typeof e=="function")for(let n of B(e))!Y.call(t,n)&&n!==r&&g(t,n,{get:()=>e[n],enumerable:!(o=X(e,n))||o.enumerable});return t};var J=t=>G(g({},"__esModule",{value:!0}),t);var pe={};l(pe,{default:()=>he});module.exports=J(pe);var N=class extends Error{constructor(e,r){super(e,r),this.name=this.constructor.name}get[Symbol.toStringTag](){return this.constructor.name}},p=class extends N{};var c=class t{static create(e){return new t(e)}static async race(e){let r=new Set;try{let o=e.map(n=>n instanceof t?(n.#n&&r.add(n),n.valueOrThrow()):n);return await Promise.race(o)}finally{for(let o of r)o.reject(new Error("Timeout cleared"))}}#e=!1;#r=!1;#o;#t;#a=new Promise(e=>{this.#t=e});#n;#i;constructor(e){e&&e.timeout>0&&(this.#i=new p(e.message),this.#n=setTimeout(()=>{this.reject(this.#i)},e.timeout))}#l(e){clearTimeout(this.#n),this.#o=e,this.#t()}resolve(e){this.#r||this.#e||(this.#e=!0,this.#l(e))}reject(e){this.#r||this.#e||(this.#r=!0,this.#l(e))}resolved(){return this.#e}finished(){return this.#e||this.#r}value(){return this.#o}#s;valueOrThrow(){return this.#s||(this.#s=(async()=>{if(await this.#a,this.#r)throw this.#o;return this.#o})()),this.#s}};var L=new Map,F=t=>{let e=L.get(t);return e||(e=new Function(`return ${t}`)(),L.set(t,e),e)};var x={};l(x,{ariaQuerySelector:()=>z,ariaQuerySelectorAll:()=>b});var z=(t,e)=>globalThis.__ariaQuerySelector(t,e),b=async function*(t,e){yield*await globalThis.__ariaQuerySelectorAll(t,e)};var E={};l(E,{cssQuerySelector:()=>K,cssQuerySelectorAll:()=>Z});var K=(t,e)=>t.querySelector(e),Z=function(t,e){return t.querySelectorAll(e)};var A={};l(A,{customQuerySelectors:()=>P});var v=class{#e=new Map;register(e,r){if(!r.queryOne&&r.queryAll){let o=r.queryAll;r.queryOne=(n,i)=>{for(let s of o(n,i))return s;return null}}else if(r.queryOne&&!r.queryAll){let o=r.queryOne;r.queryAll=(n,i)=>{let s=o(n,i);return s?[s]:[]}}else if(!r.queryOne||!r.queryAll)throw new Error("At least one query method must be defined.");this.#e.set(e,{querySelector:r.queryOne,querySelectorAll:r.queryAll})}unregister(e){this.#e.delete(e)}get(e){return this.#e.get(e)}clear(){this.#e.clear()}},P=new v;var R={};l(R,{pierceQuerySelector:()=>ee,pierceQuerySelectorAll:()=>te});var ee=(t,e)=>{let r=null,o=n=>{let i=document.createTreeWalker(n,NodeFilter.SHOW_ELEMENT);do{let s=i.currentNode;s.shadowRoot&&o(s.shadowRoot),!(s instanceof ShadowRoot)&&s!==n&&!r&&s.matches(e)&&(r=s)}while(!r&&i.nextNode())};return t instanceof Document&&(t=t.documentElement),o(t),r},te=(t,e)=>{let r=[],o=n=>{let i=document.createTreeWalker(n,NodeFilter.SHOW_ELEMENT);do{let s=i.currentNode;s.shadowRoot&&o(s.shadowRoot),!(s instanceof ShadowRoot)&&s!==n&&s.matches(e)&&r.push(s)}while(i.nextNode())};return t instanceof Document&&(t=t.documentElement),o(t),r};var u=(t,e)=>{if(!t)throw new Error(e)};var y=class{#e;#r;#o;#t;constructor(e,r){this.#e=e,this.#r=r}async start(){let e=this.#t=c.create(),r=await this.#e();if(r){e.resolve(r);return}this.#o=new MutationObserver(async()=>{let o=await this.#e();o&&(e.resolve(o),await this.stop())}),this.#o.observe(this.#r,{childList:!0,subtree:!0,attributes:!0})}async stop(){u(this.#t,"Polling never started."),this.#t.finished()||this.#t.reject(new Error("Polling stopped")),this.#o&&(this.#o.disconnect(),this.#o=void 0)}result(){return u(this.#t,"Polling never started."),this.#t.valueOrThrow()}},w=class{#e;#r;constructor(e){this.#e=e}async start(){let e=this.#r=c.create(),r=await this.#e();if(r){e.resolve(r);return}let o=async()=>{if(e.finished())return;let n=await this.#e();if(!n){window.requestAnimationFrame(o);return}e.resolve(n),await this.stop()};window.requestAnimationFrame(o)}async stop(){u(this.#r,"Polling never started."),this.#r.finished()||this.#r.reject(new Error("Polling stopped"))}result(){return u(this.#r,"Polling never started."),this.#r.valueOrThrow()}},T=class{#e;#r;#o;#t;constructor(e,r){this.#e=e,this.#r=r}async start(){let e=this.#t=c.create(),r=await this.#e();if(r){e.resolve(r);return}this.#o=setInterval(async()=>{let o=await this.#e();o&&(e.resolve(o),await this.stop())},this.#r)}async stop(){u(this.#t,"Polling never started."),this.#t.finished()||this.#t.reject(new Error("Polling stopped")),this.#o&&(clearInterval(this.#o),this.#o=void 0)}result(){return u(this.#t,"Polling never started."),this.#t.valueOrThrow()}};var _={};l(_,{PCombinator:()=>H,pQuerySelector:()=>fe,pQuerySelectorAll:()=>$});var a=class{static async*map(e,r){for await(let o of e)yield await r(o)}static async*flatMap(e,r){for await(let o of e)yield*r(o)}static async collect(e){let r=[];for await(let o of e)r.push(o);return r}static async first(e){for await(let r of e)return r}};var C={};l(C,{textQuerySelectorAll:()=>m});var re=new Set(["checkbox","image","radio"]),oe=t=>t instanceof HTMLSelectElement||t instanceof HTMLTextAreaElement||t instanceof HTMLInputElement&&!re.has(t.type),ne=new Set(["SCRIPT","STYLE"]),f=t=>!ne.has(t.nodeName)&&!document.head?.contains(t),I=new WeakMap,j=t=>{for(;t;)I.delete(t),t instanceof ShadowRoot?t=t.host:t=t.parentNode},W=new WeakSet,se=new MutationObserver(t=>{for(let e of t)j(e.target)}),d=t=>{let e=I.get(t);if(e||(e={full:"",immediate:[]},!f(t)))return e;let r="";if(oe(t))e.full=t.value,e.immediate.push(t.value),t.addEventListener("input",o=>{j(o.target)},{once:!0,capture:!0});else{for(let o=t.firstChild;o;o=o.nextSibling){if(o.nodeType===Node.TEXT_NODE){e.full+=o.nodeValue??"",r+=o.nodeValue??"";continue}r&&e.immediate.push(r),r="",o.nodeType===Node.ELEMENT_NODE&&(e.full+=d(o).full)}r&&e.immediate.push(r),t instanceof Element&&t.shadowRoot&&(e.full+=d(t.shadowRoot).full),W.has(t)||(se.observe(t,{childList:!0,characterData:!0,subtree:!0}),W.add(t))}return I.set(t,e),e};var m=function*(t,e){let r=!1;for(let o of t.childNodes)if(o instanceof Element&&f(o)){let n;o.shadowRoot?n=m(o.shadowRoot,e):n=m(o,e);for(let i of n)yield i,r=!0}r||t instanceof Element&&f(t)&&d(t).full.includes(e)&&(yield t)};var O={};l(O,{checkVisibility:()=>le,pierce:()=>S,pierceAll:()=>k});var ie=["hidden","collapse"],le=(t,e)=>{if(!t)return e===!1;if(e===void 0)return t;let r=t.nodeType===Node.TEXT_NODE?t.parentElement:t,o=window.getComputedStyle(r),n=o&&!ie.includes(o.visibility)&&!ae(r);return e===n?t:!1};function ae(t){let e=t.getBoundingClientRect();return e.width===0||e.height===0}var ce=t=>"shadowRoot"in t&&t.shadowRoot instanceof ShadowRoot;function*S(t){ce(t)?yield t.shadowRoot:yield t}function*k(t){t=S(t).next().value,yield t;let e=[document.createTreeWalker(t,NodeFilter.SHOW_ELEMENT)];for(let r of e){let o;for(;o=r.nextNode();)o.shadowRoot&&(yield o.shadowRoot,e.push(document.createTreeWalker(o.shadowRoot,NodeFilter.SHOW_ELEMENT)))}}var Q={};l(Q,{xpathQuerySelectorAll:()=>q});var q=function*(t,e,r=-1){let n=(t.ownerDocument||document).evaluate(e,t,null,XPathResult.ORDERED_NODE_ITERATOR_TYPE),i=[],s;for(;(s=n.iterateNext())&&(i.push(s),!(r&&i.length===r)););for(let h=0;h<i.length;h++)s=i[h],yield s,delete i[h]};var ue=/[-\\w\\P{ASCII}*]/,H=(r=>(r.Descendent=">>>",r.Child=">>>>",r))(H||{}),V=t=>"querySelectorAll"in t,M=class{#e;#r=[];#o=void 0;elements;constructor(e,r){this.elements=[e],this.#e=r,this.#t()}async run(){if(typeof this.#o=="string")switch(this.#o.trimStart()){case":scope":this.#t();break}for(;this.#o!==void 0;this.#t()){let e=this.#o;typeof e=="string"?e[0]&&ue.test(e[0])?this.elements=a.flatMap(this.elements,async function*(r){V(r)&&(yield*r.querySelectorAll(e))}):this.elements=a.flatMap(this.elements,async function*(r){if(!r.parentElement){if(!V(r))return;yield*r.querySelectorAll(e);return}let o=0;for(let n of r.parentElement.children)if(++o,n===r)break;yield*r.parentElement.querySelectorAll(`:scope>:nth-child(${o})${e}`)}):this.elements=a.flatMap(this.elements,async function*(r){switch(e.name){case"text":yield*m(r,e.value);break;case"xpath":yield*q(r,e.value);break;case"aria":yield*b(r,e.value);break;default:let o=P.get(e.name);if(!o)throw new Error(`Unknown selector type: ${e.name}`);yield*o.querySelectorAll(r,e.value)}})}}#t(){if(this.#r.length!==0){this.#o=this.#r.shift();return}if(this.#e.length===0){this.#o=void 0;return}let e=this.#e.shift();switch(e){case">>>>":{this.elements=a.flatMap(this.elements,S),this.#t();break}case">>>":{this.elements=a.flatMap(this.elements,k),this.#t();break}default:this.#r=e,this.#t();break}}},D=class{#e=new WeakMap;calculate(e,r=[]){if(e===null)return r;e instanceof ShadowRoot&&(e=e.host);let o=this.#e.get(e);if(o)return[...o,...r];let n=0;for(let s=e.previousSibling;s;s=s.previousSibling)++n;let i=this.calculate(e.parentNode,[n]);return this.#e.set(e,i),[...i,...r]}},U=(t,e)=>{if(t.length+e.length===0)return 0;let[r=-1,...o]=t,[n=-1,...i]=e;return r===n?U(o,i):r<n?-1:1},de=async function*(t){let e=new Set;for await(let o of t)e.add(o);let r=new D;yield*[...e.values()].map(o=>[o,r.calculate(o)]).sort(([,o],[,n])=>U(o,n)).map(([o])=>o)},$=function(t,e){let r=JSON.parse(e);if(r.some(o=>{let n=0;return o.some(i=>(typeof i=="string"?++n:n=0,n>1))}))throw new Error("Multiple deep combinators found in sequence.");return de(a.flatMap(r,o=>{let n=new M(t,o);return n.run(),n.elements}))},fe=async function(t,e){for await(let r of $(t,e))return r;return null};var me=Object.freeze({...x,...A,...R,..._,...C,...O,...Q,...E,Deferred:c,createFunction:F,createTextContent:d,IntervalPoller:T,isSuitableNodeForTextMatching:f,MutationPoller:y,RAFPoller:w}),he=me;\n';/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Qa,Ya,zs,Gf,Z0;class $x{constructor(){m(this,zs);m(this,Qa,!1);m(this,Ya,new Set)}append(t){I(this,zs,Gf).call(this,()=>{a(this,Ya).add(t)})}pop(t){I(this,zs,Gf).call(this,()=>{a(this,Ya).delete(t)})}inject(t,e=!1){(a(this,Qa)||e)&&t(I(this,zs,Z0).call(this)),_(this,Qa,!1)}}Qa=new WeakMap,Ya=new WeakMap,zs=new WeakSet,Gf=function(t){t(),_(this,Qa,!0)},Z0=function(){return`(() => {
      const module = {};
      ${Px}
      ${[...a(this,Ya)].map(t=>`(${t})(module.exports.default);`).join("")}
      return module.exports.default;
    })()`};const wu=new $x;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var mn;class Rx{constructor(){m(this,mn,new Map)}get(t){const e=a(this,mn).get(t);return e?e[1]:void 0}register(t,e){var s;X(!a(this,mn).has(t),`Cannot register over existing handler: ${t}`),X(/^[a-zA-Z]+$/.test(t),"Custom query handler names may only contain [a-zA-Z]"),X(e.queryAll||e.queryOne,"At least one query method must be implemented.");const n=(s=class extends br{},L(s,"querySelectorAll",vc((o,c,l)=>l.customQuerySelectors.get(PLACEHOLDER("name")).querySelectorAll(o,c),{name:JSON.stringify(t)})),L(s,"querySelector",vc((o,c,l)=>l.customQuerySelectors.get(PLACEHOLDER("name")).querySelector(o,c),{name:JSON.stringify(t)})),s),i=vc(o=>{o.customQuerySelectors.register(PLACEHOLDER("name"),{queryAll:PLACEHOLDER("queryAll"),queryOne:PLACEHOLDER("queryOne")})},{name:JSON.stringify(t),queryAll:e.queryAll?yi(e.queryAll):String(void 0),queryOne:e.queryOne?yi(e.queryOne):String(void 0)}).toString();a(this,mn).set(t,[i,n]),wu.append(i)}unregister(t){const e=a(this,mn).get(t);if(!e)throw new Error(`Cannot unregister unknown handler: ${t}`);wu.pop(e[0]),a(this,mn).delete(t)}names(){return[...a(this,mn).keys()]}clear(){for(const[t]of a(this,mn))wu.pop(t);a(this,mn).clear()}}mn=new WeakMap;const Vf=new Rx;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class Xf extends br{}L(Xf,"querySelector",(t,e,{pierceQuerySelector:n})=>n(t,e)),L(Xf,"querySelectorAll",(t,e,{pierceQuerySelectorAll:n})=>n(t,e));/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class Jf extends br{}L(Jf,"querySelectorAll",(t,e,{pQuerySelectorAll:n})=>n(t,e)),L(Jf,"querySelector",(t,e,{pQuerySelector:n})=>n(t,e));var zo={attribute:/\[\s*(?:(?<namespace>\*|[-\w\P{ASCII}]*)\|)?(?<name>[-\w\P{ASCII}]+)\s*(?:(?<operator>\W?=)\s*(?<value>.+?)\s*(\s(?<caseSensitive>[iIsS]))?\s*)?\]/gu,id:/#(?<name>[-\w\P{ASCII}]+)/gu,class:/\.(?<name>[-\w\P{ASCII}]+)/gu,comma:/\s*,\s*/g,combinator:/\s*[\s>+~]\s*/g,"pseudo-element":/::(?<name>[-\w\P{ASCII}]+)(?:\((?<argument>¶*)\))?/gu,"pseudo-class":/:(?<name>[-\w\P{ASCII}]+)(?:\((?<argument>¶*)\))?/gu,universal:/(?:(?<namespace>\*|[-\w\P{ASCII}]*)\|)?\*/gu,type:/(?:(?<namespace>\*|[-\w\P{ASCII}]*)\|)?(?<name>[-\w\P{ASCII}]+)/gu},Fx=new Set(["combinator","comma"]),Dx=r=>{switch(r){case"pseudo-element":case"pseudo-class":return new RegExp(zo[r].source.replace("(?<argument>¶*)","(?<argument>.*)"),"gu");default:return zo[r]}};function Ox(r,t){let e=0,n="";for(;t<r.length;t++){const i=r[t];switch(i){case"(":++e;break;case")":--e;break}if(n+=i,e===0)return n}return n}function Lx(r,t=zo){if(!r)return[];const e=[r];for(const[i,s]of Object.entries(t))for(let o=0;o<e.length;o++){const c=e[o];if(typeof c!="string")continue;s.lastIndex=0;const l=s.exec(c);if(!l)continue;const d=l.index-1,u=[],h=l[0],p=c.slice(0,d+1);p&&u.push(p),u.push({...l.groups,type:i,content:h});const f=c.slice(d+h.length+1);f&&u.push(f),e.splice(o,1,...u)}let n=0;for(const i of e)switch(typeof i){case"string":throw new Error(`Unexpected sequence ${i} found at index ${n}`);case"object":n+=i.content.length,i.pos=[n-i.content.length,n],Fx.has(i.type)&&(i.content=i.content.trim()||" ");break}return e}var jx=/(['"])([^\\\n]+?)\1/g,Bx=/\\./g;function Ux(r,t=zo){if(r=r.trim(),r==="")return[];const e=[];r=r.replace(Bx,(s,o)=>(e.push({value:s,offset:o}),"".repeat(s.length))),r=r.replace(jx,(s,o,c,l)=>(e.push({value:s,offset:l}),`${o}${"".repeat(c.length)}${o}`));{let s=0,o;for(;(o=r.indexOf("(",s))>-1;){const c=Ox(r,o);e.push({value:c,offset:o}),r=`${r.substring(0,o)}(${"¶".repeat(c.length-2)})${r.substring(o+c.length)}`,s=o+c.length}}const n=Lx(r,t),i=new Set;for(const s of e.reverse())for(const o of n){const{offset:c,value:l}=s;if(!(o.pos[0]<=c&&c+l.length<=o.pos[1]))continue;const{content:d}=o,u=c-o.pos[0];o.content=d.slice(0,u)+l+d.slice(u+l.length),o.content!==d&&i.add(o)}for(const s of i){const o=Dx(s.type);if(!o)throw new Error(`Unknown token type: ${s.type}`);o.lastIndex=0;const c=o.exec(s.content);if(!c)throw new Error(`Unable to parse content for ${s.type}: ${s.content}`);Object.assign(s,c.groups)}return n}function*vu(r,t){switch(r.type){case"list":for(let e of r.list)yield*vu(e,r);break;case"complex":yield*vu(r.left,r),yield*vu(r.right,r);break;case"compound":yield*r.list.map(e=>[e,r]);break;default:yield[r,t]}}function Zo(r){let t;return Array.isArray(r)?t=r:t=[...vu(r)].map(([e])=>e),t.map(e=>e.content).join("")}/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */zo.nesting=/&/g;zo.combinator=/\s*(>>>>?|[\s>+~])\s*/g;const zx=/\\[\s\S]/g,Hx=r=>r.length<=1?r:((r[0]==='"'||r[0]==="'")&&r.endsWith(r[0])&&(r=r.slice(1,-1)),r.replace(zx,t=>t[1]));function Wx(r){let t=!0,e=!1,n=!1;const i=Ux(r);if(i.length===0)return[[],t,n,!1];let s=[],o=[s];const c=[o],l=[];for(const d of i){switch(d.type){case"combinator":switch(d.content){case">>>":t=!1,l.length&&(s.push(Zo(l)),l.splice(0)),s=[],o.push(">>>"),o.push(s);continue;case">>>>":t=!1,l.length&&(s.push(Zo(l)),l.splice(0)),s=[],o.push(">>>>"),o.push(s);continue}break;case"pseudo-element":if(!d.name.startsWith("-p-"))break;t=!1,l.length&&(s.push(Zo(l)),l.splice(0));const u=d.name.slice(3);u==="aria"&&(e=!0),s.push({name:u,value:Hx(d.argument??"")});continue;case"pseudo-class":n=!0;break;case"comma":l.length&&(s.push(Zo(l)),l.splice(0)),s=[],o=[s],c.push(o);continue}l.push(d)}return l.length&&s.push(Zo(l)),[c,t,n,e]}/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class e_ extends br{}L(e_,"querySelectorAll",(t,e,{textQuerySelectorAll:n})=>n(t,e));/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class Qf extends br{}L(Qf,"querySelectorAll",(t,e,{xpathQuerySelectorAll:n})=>n(t,e)),L(Qf,"querySelector",(t,e,{xpathQuerySelectorAll:n})=>{for(const i of n(t,e,1))return i;return null});/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const qx={aria:Tc,pierce:Xf,xpath:Qf,text:e_},Kx=["=","/"];function xu(r){for(const t of[Vf.names().map(e=>[e,Vf.get(e)]),Object.entries(qx)])for(const[e,n]of t)for(const i of Kx){const s=`${e}${i}`;if(r.startsWith(s))return r=r.slice(s.length),{updatedSelector:r,polling:e==="aria"?"raf":"mutation",QueryHandler:n}}try{const[t,e,n,i]=Wx(r);return e?{updatedSelector:r,polling:n?"raf":"mutation",QueryHandler:Zu}:{updatedSelector:JSON.stringify(t),polling:i?"raf":"mutation",QueryHandler:Jf}}catch{return{updatedSelector:r,polling:"mutation",QueryHandler:Zu}}}/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Gx=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},Ge=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0},kr=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},Cr=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n}),ft;(function(r){r.FrameNavigated=Symbol("Frame.FrameNavigated"),r.FrameSwapped=Symbol("Frame.FrameSwapped"),r.LifecycleEvent=Symbol("Frame.LifecycleEvent"),r.FrameNavigatedWithinDocument=Symbol("Frame.FrameNavigatedWithinDocument"),r.FrameDetached=Symbol("Frame.FrameDetached"),r.FrameSwappedByActivation=Symbol("Frame.FrameSwappedByActivation")})(ft||(ft={}));const Pe=ye(r=>`Attempted to use detached Frame '${r._id}'.`);let Vx=(()=>{var U,O,ac,F;let r=He,t=[],e,n,i,s,o,c,l,d,u,h,p,f,y,w,b,C,A,T,M,D;return F=class extends r{constructor(){super();m(this,O);L(this,"_id",Gx(this,t));L(this,"_parentId");L(this,"_name");L(this,"_hasStartedLoading",!1);m(this,U)}clearDocumentHandle(){_(this,U,void 0)}async frameElement(){const P={stack:[],error:void 0,hasError:!1};try{const N=this.parentFrame();if(!N)return null;const j=kr(P,await N.isolatedRealm().evaluateHandle(()=>document.querySelectorAll("iframe,frame")),!1);for await(const W of Y0(j)){const g={stack:[],error:void 0,hasError:!1};try{const E=kr(g,W,!1),k=await E.contentFrame();if((k==null?void 0:k._id)===this._id)return E.move()}catch(E){g.error=E,g.hasError=!0}finally{Cr(g)}}return null}catch(N){P.error=N,P.hasError=!0}finally{Cr(P)}}async evaluateHandle(P,...N){return P=ot(this.evaluateHandle.name,P),await this.mainRealm().evaluateHandle(P,...N)}async evaluate(P,...N){return P=ot(this.evaluate.name,P),await this.mainRealm().evaluate(P,...N)}locator(P){return typeof P=="string"?Qu.create(this,P):Vu.create(this,P)}async $(P){return await(await I(this,O,ac).call(this)).$(P)}async $$(P,N){return await(await I(this,O,ac).call(this)).$$(P,N)}async $eval(P,N,...j){return N=ot(this.$eval.name,N),await(await I(this,O,ac).call(this)).$eval(P,N,...j)}async $$eval(P,N,...j){return N=ot(this.$$eval.name,N),await(await I(this,O,ac).call(this)).$$eval(P,N,...j)}async waitForSelector(P,N={}){const{updatedSelector:j,QueryHandler:W,polling:g}=xu(P);return await W.waitFor(this,j,{polling:g,...N})}async waitForFunction(P,N={},...j){return await this.mainRealm().waitForFunction(P,N,...j)}async content(){return await this.evaluate(()=>{let P="";for(const N of document.childNodes)switch(N){case document.documentElement:P+=document.documentElement.outerHTML;break;default:P+=new XMLSerializer().serializeToString(N);break}return P})}async setFrameContent(P){return await this.evaluate(N=>{document.open(),document.write(N),document.close()},P)}name(){return this._name||""}isDetached(){return this.detached}get disposed(){return this.detached}async addScriptTag(P){let{content:N="",type:j}=P;const{path:W}=P;if(+!!P.url+ +!!W+ +!!N!=1)throw new Error("Exactly one of `url`, `path`, or `content` must be specified.");return W&&(N=await(await Sg()).readFile(W,"utf8"),N+=`//# sourceURL=${W.replace(/\n/g,"")}`),j=j??"text/javascript",await this.mainRealm().transferHandle(await this.isolatedRealm().evaluateHandle(async({url:g,id:E,type:k,content:v})=>await new Promise((x,V)=>{const re=document.createElement("script");re.type=k,re.text=v,re.addEventListener("error",oe=>{V(new Error(oe.message??"Could not load script"))},{once:!0}),E&&(re.id=E),g?(re.src=g,re.addEventListener("load",()=>{x(re)},{once:!0}),document.head.appendChild(re)):(document.head.appendChild(re),x(re))}),{...P,type:j,content:N}))}async addStyleTag(P){let{content:N=""}=P;const{path:j}=P;if(+!!P.url+ +!!j+ +!!N!=1)throw new Error("Exactly one of `url`, `path`, or `content` must be specified.");return j&&(N=await(await Sg()).readFile(j,"utf8"),N+="/*# sourceURL="+j.replace(/\n/g,"")+"*/",P.content=N),await this.mainRealm().transferHandle(await this.isolatedRealm().evaluateHandle(async({url:W,content:g})=>await new Promise((E,k)=>{let v;if(!W)v=document.createElement("style"),v.appendChild(document.createTextNode(g));else{const x=document.createElement("link");x.rel="stylesheet",x.href=W,v=x}return v.addEventListener("load",()=>{E(v)},{once:!0}),v.addEventListener("error",x=>{k(new Error(x.message??"Could not load style"))},{once:!0}),document.head.appendChild(v),v}),P))}async click(P,N={}){const j={stack:[],error:void 0,hasError:!1};try{const W=kr(j,await this.$(P),!1);X(W,`No element found for selector: ${P}`),await W.click(N),await W.dispose()}catch(W){j.error=W,j.hasError=!0}finally{Cr(j)}}async focus(P){const N={stack:[],error:void 0,hasError:!1};try{const j=kr(N,await this.$(P),!1);X(j,`No element found for selector: ${P}`),await j.focus()}catch(j){N.error=j,N.hasError=!0}finally{Cr(N)}}async hover(P){const N={stack:[],error:void 0,hasError:!1};try{const j=kr(N,await this.$(P),!1);X(j,`No element found for selector: ${P}`),await j.hover()}catch(j){N.error=j,N.hasError=!0}finally{Cr(N)}}async select(P,...N){const j={stack:[],error:void 0,hasError:!1};try{const W=kr(j,await this.$(P),!1);return X(W,`No element found for selector: ${P}`),await W.select(...N)}catch(W){j.error=W,j.hasError=!0}finally{Cr(j)}}async tap(P){const N={stack:[],error:void 0,hasError:!1};try{const j=kr(N,await this.$(P),!1);X(j,`No element found for selector: ${P}`),await j.tap()}catch(j){N.error=j,N.hasError=!0}finally{Cr(N)}}async type(P,N,j){const W={stack:[],error:void 0,hasError:!1};try{const g=kr(W,await this.$(P),!1);X(g,`No element found for selector: ${P}`),await g.type(N,j)}catch(g){W.error=g,W.hasError=!0}finally{Cr(W)}}async title(){return await this.isolatedRealm().evaluate(()=>document.title)}},U=new WeakMap,O=new WeakSet,ac=function(){return a(this,U)||_(this,U,this.mainRealm().evaluateHandle(()=>document)),a(this,U)},(()=>{const P=typeof Symbol=="function"&&Symbol.metadata?Object.create(r[Symbol.metadata]??null):void 0;e=[Pe],n=[Pe],i=[Pe],s=[Pe],o=[Pe],c=[Pe],l=[Pe],d=[Pe],u=[Pe],h=[Pe],p=[Pe],f=[Pe],y=[Pe],w=[Pe],b=[Pe],C=[Pe],A=[Pe],T=[Pe],M=[Pe],D=[Pe],Ge(F,null,e,{kind:"method",name:"frameElement",static:!1,private:!1,access:{has:N=>"frameElement"in N,get:N=>N.frameElement},metadata:P},null,t),Ge(F,null,n,{kind:"method",name:"evaluateHandle",static:!1,private:!1,access:{has:N=>"evaluateHandle"in N,get:N=>N.evaluateHandle},metadata:P},null,t),Ge(F,null,i,{kind:"method",name:"evaluate",static:!1,private:!1,access:{has:N=>"evaluate"in N,get:N=>N.evaluate},metadata:P},null,t),Ge(F,null,s,{kind:"method",name:"locator",static:!1,private:!1,access:{has:N=>"locator"in N,get:N=>N.locator},metadata:P},null,t),Ge(F,null,o,{kind:"method",name:"$",static:!1,private:!1,access:{has:N=>"$"in N,get:N=>N.$},metadata:P},null,t),Ge(F,null,c,{kind:"method",name:"$$",static:!1,private:!1,access:{has:N=>"$$"in N,get:N=>N.$$},metadata:P},null,t),Ge(F,null,l,{kind:"method",name:"$eval",static:!1,private:!1,access:{has:N=>"$eval"in N,get:N=>N.$eval},metadata:P},null,t),Ge(F,null,d,{kind:"method",name:"$$eval",static:!1,private:!1,access:{has:N=>"$$eval"in N,get:N=>N.$$eval},metadata:P},null,t),Ge(F,null,u,{kind:"method",name:"waitForSelector",static:!1,private:!1,access:{has:N=>"waitForSelector"in N,get:N=>N.waitForSelector},metadata:P},null,t),Ge(F,null,h,{kind:"method",name:"waitForFunction",static:!1,private:!1,access:{has:N=>"waitForFunction"in N,get:N=>N.waitForFunction},metadata:P},null,t),Ge(F,null,p,{kind:"method",name:"content",static:!1,private:!1,access:{has:N=>"content"in N,get:N=>N.content},metadata:P},null,t),Ge(F,null,f,{kind:"method",name:"addScriptTag",static:!1,private:!1,access:{has:N=>"addScriptTag"in N,get:N=>N.addScriptTag},metadata:P},null,t),Ge(F,null,y,{kind:"method",name:"addStyleTag",static:!1,private:!1,access:{has:N=>"addStyleTag"in N,get:N=>N.addStyleTag},metadata:P},null,t),Ge(F,null,w,{kind:"method",name:"click",static:!1,private:!1,access:{has:N=>"click"in N,get:N=>N.click},metadata:P},null,t),Ge(F,null,b,{kind:"method",name:"focus",static:!1,private:!1,access:{has:N=>"focus"in N,get:N=>N.focus},metadata:P},null,t),Ge(F,null,C,{kind:"method",name:"hover",static:!1,private:!1,access:{has:N=>"hover"in N,get:N=>N.hover},metadata:P},null,t),Ge(F,null,A,{kind:"method",name:"select",static:!1,private:!1,access:{has:N=>"select"in N,get:N=>N.select},metadata:P},null,t),Ge(F,null,T,{kind:"method",name:"tap",static:!1,private:!1,access:{has:N=>"tap"in N,get:N=>N.tap},metadata:P},null,t),Ge(F,null,M,{kind:"method",name:"type",static:!1,private:!1,access:{has:N=>"type"in N,get:N=>N.type},metadata:P},null,t),Ge(F,null,D,{kind:"method",name:"title",static:!1,private:!1,access:{has:N=>"title"in N,get:N=>N.title},metadata:P},null,t),P&&Object.defineProperty(F,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:P})})(),F})();/**
 * @license
 * Copyright 2024 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var bl,wl,Za;class Xx{constructor(t,e,n){m(this,bl);m(this,wl);m(this,Za,new WeakMap);_(this,bl,e),_(this,wl,n),a(this,Za).set(t,e)}get id(){return a(this,bl)}get source(){return a(this,wl)}getIdForFrame(t){return a(this,Za).get(t)}setIdForFrame(t,e){a(this,Za).set(t,e)}}bl=new WeakMap,wl=new WeakMap,Za=new WeakMap;/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class Jx{constructor(t,e){L(this,"id");L(this,"name");this.id=t,this.name=e}}var Kt,vl,as,os,eo,to,xl,Yf;class Qx{constructor(t,e,n){m(this,xl);m(this,Kt);m(this,vl);m(this,as);m(this,os,!1);m(this,eo,I(this,xl,Yf).bind(this));m(this,to,new Set);L(this,"devices",[]);_(this,Kt,t),_(this,vl,e),_(this,as,n.id),a(this,Kt).on("DeviceAccess.deviceRequestPrompted",a(this,eo)),a(this,Kt).on("Target.detachedFromTarget",()=>{_(this,Kt,null)}),I(this,xl,Yf).call(this,n)}async waitForDevice(t,e={}){for(const o of this.devices)if(t(o))return o;const{timeout:n=a(this,vl).timeout()}=e,i=Ae.create({message:`Waiting for \`DeviceRequestPromptDevice\` failed: ${n}ms exceeded`,timeout:n}),s={filter:t,promise:i};a(this,to).add(s);try{return await i.valueOrThrow()}finally{a(this,to).delete(s)}}async select(t){return X(a(this,Kt)!==null,"Cannot select device through detached session!"),X(this.devices.includes(t),"Cannot select unknown device!"),X(!a(this,os),"Cannot select DeviceRequestPrompt which is already handled!"),a(this,Kt).off("DeviceAccess.deviceRequestPrompted",a(this,eo)),_(this,os,!0),await a(this,Kt).send("DeviceAccess.selectPrompt",{id:a(this,as),deviceId:t.id})}async cancel(){return X(a(this,Kt)!==null,"Cannot cancel prompt through detached session!"),X(!a(this,os),"Cannot cancel DeviceRequestPrompt which is already handled!"),a(this,Kt).off("DeviceAccess.deviceRequestPrompted",a(this,eo)),_(this,os,!0),await a(this,Kt).send("DeviceAccess.cancelPrompt",{id:a(this,as)})}}Kt=new WeakMap,vl=new WeakMap,as=new WeakMap,os=new WeakMap,eo=new WeakMap,to=new WeakMap,xl=new WeakSet,Yf=function(t){if(t.id===a(this,as))for(const e of t.devices){if(this.devices.some(i=>i.id===e.id))continue;const n=new Jx(e.id,e.name);this.devices.push(n);for(const i of a(this,to))i.filter(n)&&i.promise.resolve(n)}};var gn,no,ar,Sh,t_;class Yx{constructor(t,e){m(this,Sh);m(this,gn);m(this,no);m(this,ar,new Set);_(this,gn,t),_(this,no,e),a(this,gn).on("DeviceAccess.deviceRequestPrompted",n=>{I(this,Sh,t_).call(this,n)}),a(this,gn).on("Target.detachedFromTarget",()=>{_(this,gn,null)})}async waitForDevicePrompt(t={}){X(a(this,gn)!==null,"Cannot wait for device prompt through detached session!");const e=a(this,ar).size===0;let n;e&&(n=a(this,gn).send("DeviceAccess.enable"));const{timeout:i=a(this,no).timeout()}=t,s=Ae.create({message:`Waiting for \`DeviceRequestPrompt\` failed: ${i}ms exceeded`,timeout:i});a(this,ar).add(s);try{const[o]=await Promise.all([s.valueOrThrow(),n]);return o}finally{a(this,ar).delete(s)}}}gn=new WeakMap,no=new WeakMap,ar=new WeakMap,Sh=new WeakSet,t_=function(t){if(!a(this,ar).size)return;X(a(this,gn)!==null);const e=new Qx(a(this,gn),a(this,no),t);for(const n of a(this,ar))n.resolve(e);a(this,ar).clear()};/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Zx=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},ke=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0},ec=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},tc=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n}),eS=function(r,t,e){return typeof t=="symbol"&&(t=t.description?"[".concat(t.description,"]"):""),Object.defineProperty(r,"name",{configurable:!0,value:e?"".concat(e," ",t):t})};let lf=(()=>{var Se,Zf,ep,tp,n_,np,rp,r_,i_,s_,Q;var r,t,e,n,i,s,o,c,l,d,u,h,p,f,y,w,b,C,A,T,M,D,U,O,K,F,H,B,P,N;let j=da,W=[],g,E,k,v,x,V,re,oe,ve,ce,Ee,Le,Fe,We,Sr,me,Lt,J,G,z,ee,ge,De,he,jt,Sn,rn,je,sn,kn,Cn,Nt;return Q=class extends j{constructor($){super();m(this,Se);L(this,"isolatedHandle",Zx(this,W));L(this,"handle");this.handle=$,this[_u]=!0}static bindIsolatedHandle($,S){return async function(...ne){if(this.realm===this.frame.isolatedRealm())return await $.call(this,...ne);let Z;this.isolatedHandle?Z=this.isolatedHandle:this.isolatedHandle=Z=await this.frame.isolatedRealm().adoptHandle(this);const ie=await $.call(Z,...ne);return ie===Z?this:ie instanceof da?await this.realm.transferHandle(ie):(Array.isArray(ie)&&await Promise.all(ie.map(async(ue,we,qe)=>{ue instanceof da&&(qe[we]=await this.realm.transferHandle(ue))})),ie instanceof Map&&await Promise.all([...ie.entries()].map(async([ue,we])=>{we instanceof da&&ie.set(ue,await this.realm.transferHandle(we))})),ie)}}get id(){return this.handle.id}get disposed(){return this.handle.disposed}async getProperty($){return await this.handle.getProperty($)}async getProperties(){return await this.handle.getProperties()}async evaluate($,...S){return $=ot(this.evaluate.name,$),await this.handle.evaluate($,...S)}async evaluateHandle($,...S){return $=ot(this.evaluateHandle.name,$),await this.handle.evaluateHandle($,...S)}async jsonValue(){return await this.handle.jsonValue()}toString(){return this.handle.toString()}remoteObject(){return this.handle.remoteObject()}dispose(){return this.handle.dispose()}asElement(){return this}async $($){const{updatedSelector:S,QueryHandler:ne}=xu($);return await ne.queryOne(this,S)}async $$($,S){return(S==null?void 0:S.isolate)===!1?await I(this,Se,ep).call(this,$):await a(this,Se,Zf).call(this,$)}async $eval($,S,...ne){const Z={stack:[],error:void 0,hasError:!1};try{S=ot(this.$eval.name,S);const ie=ec(Z,await this.$($),!1);if(!ie)throw new Error(`Error: failed to find element matching selector "${$}"`);return await ie.evaluate(S,...ne)}catch(ie){Z.error=ie,Z.hasError=!0}finally{tc(Z)}}async $$eval($,S,...ne){const Z={stack:[],error:void 0,hasError:!1};try{S=ot(this.$$eval.name,S);const ie=await this.$$($),ue=ec(Z,await this.evaluateHandle((qe,...Ke)=>Ke,...ie),!1),[we]=await Promise.all([ue.evaluate(S,...ne),...ie.map(qe=>qe.dispose())]);return we}catch(ie){Z.error=ie,Z.hasError=!0}finally{tc(Z)}}async waitForSelector($,S={}){const{updatedSelector:ne,QueryHandler:Z,polling:ie}=xu($);return await Z.waitFor(this,ne,{polling:ie,...S})}async isVisible(){return await I(this,Se,tp).call(this,!0)}async isHidden(){return await I(this,Se,tp).call(this,!1)}async toElement($){if(!await this.evaluate((ne,Z)=>ne.nodeName===Z.toUpperCase(),$))throw new Error(`Element is not a(n) \`${$}\` element`);return this}async clickablePoint($){const S=await I(this,Se,n_).call(this);if(!S)throw new Error("Node is either not clickable or not an Element");return $!==void 0?{x:S.x+$.x,y:S.y+$.y}:{x:S.x+S.width/2,y:S.y+S.height/2}}async hover(){await this.scrollIntoViewIfNeeded();const{x:$,y:S}=await this.clickablePoint();await this.frame.page().mouse.move($,S)}async click($={}){await this.scrollIntoViewIfNeeded();const{x:S,y:ne}=await this.clickablePoint($.offset);await this.frame.page().mouse.click(S,ne,$)}async drag($){await this.scrollIntoViewIfNeeded();const S=this.frame.page();if(S.isDragInterceptionEnabled()){const ne=await this.clickablePoint();return $ instanceof Q&&($=await $.clickablePoint()),await S.mouse.drag(ne,$)}try{S._isDragging||(S._isDragging=!0,await this.hover(),await S.mouse.down()),$ instanceof Q?await $.hover():await S.mouse.move($.x,$.y)}catch(ne){throw S._isDragging=!1,ne}}async dragEnter($={items:[],dragOperationsMask:1}){const S=this.frame.page();await this.scrollIntoViewIfNeeded();const ne=await this.clickablePoint();await S.mouse.dragEnter(ne,$)}async dragOver($={items:[],dragOperationsMask:1}){const S=this.frame.page();await this.scrollIntoViewIfNeeded();const ne=await this.clickablePoint();await S.mouse.dragOver(ne,$)}async drop($={items:[],dragOperationsMask:1}){const S=this.frame.page();if("items"in $){await this.scrollIntoViewIfNeeded();const ne=await this.clickablePoint();await S.mouse.drop(ne,$)}else await $.drag(this),S._isDragging=!1,await S.mouse.up()}async dragAndDrop($,S){const ne=this.frame.page();X(ne.isDragInterceptionEnabled(),"Drag Interception is not enabled!"),await this.scrollIntoViewIfNeeded();const Z=await this.clickablePoint(),ie=await $.clickablePoint();await ne.mouse.dragAndDrop(Z,ie,S)}async select(...$){for(const S of $)X(Ws(S),'Values must be strings. Found value "'+S+'" of type "'+typeof S+'"');return await this.evaluate((S,ne)=>{const Z=new Set(ne);if(!(S instanceof HTMLSelectElement))throw new Error("Element is not a <select> element.");const ie=new Set;if(S.multiple)for(const ue of S.options)ue.selected=Z.has(ue.value),ue.selected&&ie.add(ue.value);else{for(const ue of S.options)ue.selected=!1;for(const ue of S.options)if(Z.has(ue.value)){ue.selected=!0,ie.add(ue.value);break}}return S.dispatchEvent(new Event("input",{bubbles:!0})),S.dispatchEvent(new Event("change",{bubbles:!0})),[...ie.values()]},$)}async tap(){await this.scrollIntoViewIfNeeded();const{x:$,y:S}=await this.clickablePoint();await this.frame.page().touchscreen.tap($,S)}async touchStart(){await this.scrollIntoViewIfNeeded();const{x:$,y:S}=await this.clickablePoint();await this.frame.page().touchscreen.touchStart($,S)}async touchMove(){await this.scrollIntoViewIfNeeded();const{x:$,y:S}=await this.clickablePoint();await this.frame.page().touchscreen.touchMove($,S)}async touchEnd(){await this.scrollIntoViewIfNeeded(),await this.frame.page().touchscreen.touchEnd()}async focus(){await this.evaluate($=>{if(!($ instanceof HTMLElement))throw new Error("Cannot focus non-HTMLElement");return $.focus()})}async type($,S){await this.focus(),await this.frame.page().keyboard.type($,S)}async press($,S){await this.focus(),await this.frame.page().keyboard.press($,S)}async boundingBox(){const $=await this.evaluate(ne=>{if(!(ne instanceof Element)||ne.getClientRects().length===0)return null;const Z=ne.getBoundingClientRect();return{x:Z.x,y:Z.y,width:Z.width,height:Z.height}});if(!$)return null;const S=await I(this,Se,rp).call(this);return S?{x:$.x+S.x,y:$.y+S.y,height:$.height,width:$.width}:null}async boxModel(){const $=await this.evaluate(ne=>{if(!(ne instanceof Element)||ne.getClientRects().length===0)return null;const Z=ne.getBoundingClientRect(),ie=window.getComputedStyle(ne),ue={padding:{left:parseInt(ie.paddingLeft,10),top:parseInt(ie.paddingTop,10),right:parseInt(ie.paddingRight,10),bottom:parseInt(ie.paddingBottom,10)},margin:{left:-parseInt(ie.marginLeft,10),top:-parseInt(ie.marginTop,10),right:-parseInt(ie.marginRight,10),bottom:-parseInt(ie.marginBottom,10)},border:{left:parseInt(ie.borderLeft,10),top:parseInt(ie.borderTop,10),right:parseInt(ie.borderRight,10),bottom:parseInt(ie.borderBottom,10)}},we=[{x:Z.left,y:Z.top},{x:Z.left+Z.width,y:Z.top},{x:Z.left+Z.width,y:Z.top+Z.bottom},{x:Z.left,y:Z.top+Z.bottom}],qe=Bt(we,ue.border),Ke=Bt(qe,ue.padding),En=Bt(we,ue.margin);return{content:Ke,padding:qe,border:we,margin:En,width:Z.width,height:Z.height};function Bt(an,on){return[{x:an[0].x+on.left,y:an[0].y+on.top},{x:an[1].x-on.right,y:an[1].y+on.top},{x:an[2].x-on.right,y:an[2].y-on.bottom},{x:an[3].x+on.left,y:an[3].y-on.bottom}]}});if(!$)return null;const S=await I(this,Se,rp).call(this);if(!S)return null;for(const ne of["content","padding","border","margin"])for(const Z of $[ne])Z.x+=S.x,Z.y+=S.y;return $}async screenshot($={}){const{scrollIntoView:S=!0,clip:ne}=$,Z=this.frame.page();S&&await this.scrollIntoViewIfNeeded();const ie=await I(this,Se,r_).call(this),[ue,we]=await this.evaluate(()=>{if(!window.visualViewport)throw new Error("window.visualViewport is not supported.");return[window.visualViewport.pageLeft,window.visualViewport.pageTop]});return ie.x+=ue,ie.y+=we,ne&&(ie.x+=ne.x,ie.y+=ne.y,ie.height=ne.height,ie.width=ne.width),await Z.screenshot({...$,clip:ie})}async assertConnectedElement(){const $=await this.evaluate(async S=>{if(!S.isConnected)return"Node is detached from document";if(S.nodeType!==Node.ELEMENT_NODE)return"Node is not of type HTMLElement"});if($)throw new Error($)}async scrollIntoViewIfNeeded(){await this.isIntersectingViewport({threshold:1})||await this.scrollIntoView()}async isIntersectingViewport($={}){var ne;const S={stack:[],error:void 0,hasError:!1};try{await this.assertConnectedElement();const Z=await I(this,Se,i_).call(this);return await(ec(S,Z&&await I(ne=Z,Se,s_).call(ne),!1)??this).evaluate(async(ue,we)=>{const qe=await new Promise(Ke=>{const En=new IntersectionObserver(Bt=>{Ke(Bt[0].intersectionRatio),En.disconnect()});En.observe(ue)});return we===1?qe===1:qe>we},$.threshold??0)}catch(Z){S.error=Z,S.hasError=!0}finally{tc(S)}}async scrollIntoView(){await this.assertConnectedElement(),await this.evaluate(async $=>{$.scrollIntoView({block:"center",inline:"center",behavior:"instant"})})}},Se=new WeakSet,Zf=function(){return re.value},ep=async function($){const{updatedSelector:S,QueryHandler:ne}=xu($);return await Dh.collect(ne.queryAll(this,S))},tp=async function($){return await this.evaluate(async(S,ne,Z)=>!!ne.checkVisibility(S,Z),qn.create(S=>S.puppeteerUtil),$)},n_=async function(){var ie;const $=await this.evaluate(ue=>ue instanceof Element?[...ue.getClientRects()].map(we=>({x:we.x,y:we.y,width:we.width,height:we.height})):null);if(!($!=null&&$.length))return null;await I(this,Se,np).call(this,$);let S=this.frame,ne;for(;ne=S==null?void 0:S.parentFrame();){const ue={stack:[],error:void 0,hasError:!1};try{const we=ec(ue,await S.frameElement(),!1);if(!we)throw new Error("Unsupported frame type");const qe=await we.evaluate(Ke=>{if(Ke.getClientRects().length===0)return null;const En=Ke.getBoundingClientRect(),Bt=window.getComputedStyle(Ke);return{left:En.left+parseInt(Bt.paddingLeft,10)+parseInt(Bt.borderLeftWidth,10),top:En.top+parseInt(Bt.paddingTop,10)+parseInt(Bt.borderTopWidth,10)}});if(!qe)return null;for(const Ke of $)Ke.x+=qe.left,Ke.y+=qe.top;await I(ie=we,Se,np).call(ie,$),S=ne}catch(we){ue.error=we,ue.hasError=!0}finally{tc(ue)}}const Z=$.find(ue=>ue.width>=1&&ue.height>=1);return Z?{x:Z.x,y:Z.y,height:Z.height,width:Z.width}:null},np=async function($){const{documentWidth:S,documentHeight:ne}=await this.frame.isolatedRealm().evaluate(()=>({documentWidth:document.documentElement.clientWidth,documentHeight:document.documentElement.clientHeight}));for(const Z of $)tS(Z,S,ne)},rp=async function(){const $={x:0,y:0};let S=this.frame,ne;for(;ne=S==null?void 0:S.parentFrame();){const Z={stack:[],error:void 0,hasError:!1};try{const ie=ec(Z,await S.frameElement(),!1);if(!ie)throw new Error("Unsupported frame type");const ue=await ie.evaluate(we=>{if(we.getClientRects().length===0)return null;const qe=we.getBoundingClientRect(),Ke=window.getComputedStyle(we);return{left:qe.left+parseInt(Ke.paddingLeft,10)+parseInt(Ke.borderLeftWidth,10),top:qe.top+parseInt(Ke.paddingTop,10)+parseInt(Ke.borderTopWidth,10)}});if(!ue)return null;$.x+=ue.left,$.y+=ue.top,S=ne}catch(ie){Z.error=ie,Z.hasError=!0}finally{tc(Z)}}return $},r_=async function(){const $=await this.boundingBox();return X($,"Node is either not visible or not an HTMLElement"),X($.width!==0,"Node has 0 width."),X($.height!==0,"Node has 0 height."),$},i_=async function(){return await this.evaluate($=>$ instanceof SVGElement)?this:null},s_=async function(){return await this.evaluateHandle($=>$ instanceof SVGSVGElement?$:$.ownerSVGElement)},(()=>{const $=typeof Symbol=="function"&&Symbol.metadata?Object.create(j[Symbol.metadata]??null):void 0;g=[ye(),(r=Q).bindIsolatedHandle.bind(r)],E=[ye(),(t=Q).bindIsolatedHandle.bind(t)],k=[ye(),(e=Q).bindIsolatedHandle.bind(e)],v=[ye(),(n=Q).bindIsolatedHandle.bind(n)],x=[ye()],V=[(i=Q).bindIsolatedHandle.bind(i)],oe=[ye(),(s=Q).bindIsolatedHandle.bind(s)],ve=[ye(),(o=Q).bindIsolatedHandle.bind(o)],ce=[ye(),(c=Q).bindIsolatedHandle.bind(c)],Ee=[ye(),(l=Q).bindIsolatedHandle.bind(l)],Le=[ye(),(d=Q).bindIsolatedHandle.bind(d)],Fe=[ye(),(u=Q).bindIsolatedHandle.bind(u)],We=[ye(),(h=Q).bindIsolatedHandle.bind(h)],Sr=[ye(),(p=Q).bindIsolatedHandle.bind(p)],me=[ye(),(f=Q).bindIsolatedHandle.bind(f)],Lt=[ye(),(y=Q).bindIsolatedHandle.bind(y)],J=[ye(),(w=Q).bindIsolatedHandle.bind(w)],G=[ye(),(b=Q).bindIsolatedHandle.bind(b)],z=[ye(),(C=Q).bindIsolatedHandle.bind(C)],ee=[ye(),(A=Q).bindIsolatedHandle.bind(A)],ge=[ye(),(T=Q).bindIsolatedHandle.bind(T)],De=[ye(),(M=Q).bindIsolatedHandle.bind(M)],he=[ye(),(D=Q).bindIsolatedHandle.bind(D)],jt=[ye(),(U=Q).bindIsolatedHandle.bind(U)],Sn=[ye(),(O=Q).bindIsolatedHandle.bind(O)],rn=[ye(),(K=Q).bindIsolatedHandle.bind(K)],je=[ye(),(F=Q).bindIsolatedHandle.bind(F)],sn=[ye(),(H=Q).bindIsolatedHandle.bind(H)],kn=[ye(),(B=Q).bindIsolatedHandle.bind(B)],Cn=[ye(),(P=Q).bindIsolatedHandle.bind(P)],Nt=[ye(),(N=Q).bindIsolatedHandle.bind(N)],ke(Q,null,g,{kind:"method",name:"getProperty",static:!1,private:!1,access:{has:S=>"getProperty"in S,get:S=>S.getProperty},metadata:$},null,W),ke(Q,null,E,{kind:"method",name:"getProperties",static:!1,private:!1,access:{has:S=>"getProperties"in S,get:S=>S.getProperties},metadata:$},null,W),ke(Q,null,k,{kind:"method",name:"jsonValue",static:!1,private:!1,access:{has:S=>"jsonValue"in S,get:S=>S.jsonValue},metadata:$},null,W),ke(Q,null,v,{kind:"method",name:"$",static:!1,private:!1,access:{has:S=>"$"in S,get:S=>S.$},metadata:$},null,W),ke(Q,null,x,{kind:"method",name:"$$",static:!1,private:!1,access:{has:S=>"$$"in S,get:S=>S.$$},metadata:$},null,W),ke(Q,re={value:eS(async function(S){return await I(this,Se,ep).call(this,S)},"#$$")},V,{kind:"method",name:"#$$",static:!1,private:!0,access:{has:S=>Qt(Se,S),get:S=>a(S,Se,Zf)},metadata:$},null,W),ke(Q,null,oe,{kind:"method",name:"waitForSelector",static:!1,private:!1,access:{has:S=>"waitForSelector"in S,get:S=>S.waitForSelector},metadata:$},null,W),ke(Q,null,ve,{kind:"method",name:"isVisible",static:!1,private:!1,access:{has:S=>"isVisible"in S,get:S=>S.isVisible},metadata:$},null,W),ke(Q,null,ce,{kind:"method",name:"isHidden",static:!1,private:!1,access:{has:S=>"isHidden"in S,get:S=>S.isHidden},metadata:$},null,W),ke(Q,null,Ee,{kind:"method",name:"toElement",static:!1,private:!1,access:{has:S=>"toElement"in S,get:S=>S.toElement},metadata:$},null,W),ke(Q,null,Le,{kind:"method",name:"clickablePoint",static:!1,private:!1,access:{has:S=>"clickablePoint"in S,get:S=>S.clickablePoint},metadata:$},null,W),ke(Q,null,Fe,{kind:"method",name:"hover",static:!1,private:!1,access:{has:S=>"hover"in S,get:S=>S.hover},metadata:$},null,W),ke(Q,null,We,{kind:"method",name:"click",static:!1,private:!1,access:{has:S=>"click"in S,get:S=>S.click},metadata:$},null,W),ke(Q,null,Sr,{kind:"method",name:"drag",static:!1,private:!1,access:{has:S=>"drag"in S,get:S=>S.drag},metadata:$},null,W),ke(Q,null,me,{kind:"method",name:"dragEnter",static:!1,private:!1,access:{has:S=>"dragEnter"in S,get:S=>S.dragEnter},metadata:$},null,W),ke(Q,null,Lt,{kind:"method",name:"dragOver",static:!1,private:!1,access:{has:S=>"dragOver"in S,get:S=>S.dragOver},metadata:$},null,W),ke(Q,null,J,{kind:"method",name:"drop",static:!1,private:!1,access:{has:S=>"drop"in S,get:S=>S.drop},metadata:$},null,W),ke(Q,null,G,{kind:"method",name:"dragAndDrop",static:!1,private:!1,access:{has:S=>"dragAndDrop"in S,get:S=>S.dragAndDrop},metadata:$},null,W),ke(Q,null,z,{kind:"method",name:"select",static:!1,private:!1,access:{has:S=>"select"in S,get:S=>S.select},metadata:$},null,W),ke(Q,null,ee,{kind:"method",name:"tap",static:!1,private:!1,access:{has:S=>"tap"in S,get:S=>S.tap},metadata:$},null,W),ke(Q,null,ge,{kind:"method",name:"touchStart",static:!1,private:!1,access:{has:S=>"touchStart"in S,get:S=>S.touchStart},metadata:$},null,W),ke(Q,null,De,{kind:"method",name:"touchMove",static:!1,private:!1,access:{has:S=>"touchMove"in S,get:S=>S.touchMove},metadata:$},null,W),ke(Q,null,he,{kind:"method",name:"touchEnd",static:!1,private:!1,access:{has:S=>"touchEnd"in S,get:S=>S.touchEnd},metadata:$},null,W),ke(Q,null,jt,{kind:"method",name:"focus",static:!1,private:!1,access:{has:S=>"focus"in S,get:S=>S.focus},metadata:$},null,W),ke(Q,null,Sn,{kind:"method",name:"type",static:!1,private:!1,access:{has:S=>"type"in S,get:S=>S.type},metadata:$},null,W),ke(Q,null,rn,{kind:"method",name:"press",static:!1,private:!1,access:{has:S=>"press"in S,get:S=>S.press},metadata:$},null,W),ke(Q,null,je,{kind:"method",name:"boundingBox",static:!1,private:!1,access:{has:S=>"boundingBox"in S,get:S=>S.boundingBox},metadata:$},null,W),ke(Q,null,sn,{kind:"method",name:"boxModel",static:!1,private:!1,access:{has:S=>"boxModel"in S,get:S=>S.boxModel},metadata:$},null,W),ke(Q,null,kn,{kind:"method",name:"screenshot",static:!1,private:!1,access:{has:S=>"screenshot"in S,get:S=>S.screenshot},metadata:$},null,W),ke(Q,null,Cn,{kind:"method",name:"isIntersectingViewport",static:!1,private:!1,access:{has:S=>"isIntersectingViewport"in S,get:S=>S.isIntersectingViewport},metadata:$},null,W),ke(Q,null,Nt,{kind:"method",name:"scrollIntoView",static:!1,private:!1,access:{has:S=>"scrollIntoView"in S,get:S=>S.scrollIntoView},metadata:$},null,W),$&&Object.defineProperty(Q,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:$})})(),Q})();function tS(r,t,e){r.width=Math.max(r.x>=0?Math.min(t-r.x,r.width):Math.min(t,r.width+r.x),0),r.height=Math.max(r.y>=0?Math.min(e-r.y,r.height):Math.min(e,r.height+r.y),0)}/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */function Pg(r){let t,e;if(!r.exception)t="Error",e=r.text;else{if((r.exception.type!=="object"||r.exception.subtype!=="error")&&!r.exception.objectId)return Bs(r.exception);{const c=a_(r);t=c.name,e=c.message}}const n=e.split(`
`).length,i=new Error(e);i.name=t;const s=i.stack.split(`
`),o=s.splice(0,n);if(s.shift(),r.stackTrace&&s.length<Error.stackTraceLimit)for(const c of r.stackTrace.callFrames.reverse()){if(yr.isPuppeteerURL(c.url)&&c.url!==yr.INTERNAL_URL){const l=yr.parse(c.url);s.unshift(`    at ${c.functionName||l.functionName} (${l.functionName} at ${l.siteString}, <anonymous>:${c.lineNumber}:${c.columnNumber})`)}else s.push(`    at ${c.functionName||"<anonymous>"} (${c.url}:${c.lineNumber}:${c.columnNumber})`);if(s.length>=Error.stackTraceLimit)break}return i.stack=[...o,...s].join(`
`),i}const a_=r=>{var s,o,c,l;let t="",e;const n=((o=(s=r.exception)==null?void 0:s.description)==null?void 0:o.split(`
    at `))??[],i=Math.min(((c=r.stackTrace)==null?void 0:c.callFrames.length)??0,n.length-1);return n.splice(-i,i),(l=r.exception)!=null&&l.className&&(t=r.exception.className),e=n.join(`
`),t&&e.startsWith(`${t}: `)&&(e=e.slice(t.length+2)),{message:e,name:t}};function nS(r){let t,e;if(!r.exception)t="Error",e=r.text;else{if((r.exception.type!=="object"||r.exception.subtype!=="error")&&!r.exception.objectId)return Bs(r.exception);{const c=a_(r);t=c.name,e=c.message}}const n=new Error(e);n.name=t;const i=n.message.split(`
`).length,s=n.stack.split(`
`).splice(0,i),o=[];if(r.stackTrace){for(const c of r.stackTrace.callFrames)if(o.push(`    at ${c.functionName||"<anonymous>"} (${c.url}:${c.lineNumber+1}:${c.columnNumber+1})`),o.length>=Error.stackTraceLimit)break}return n.stack=[...s,...o].join(`
`),n}function Bs(r){if(X(!r.objectId,"Cannot extract value when objectId is given"),r.unserializableValue){if(r.type==="bigint")return BigInt(r.unserializableValue.replace("n",""));switch(r.unserializableValue){case"-0":return-0;case"NaN":return NaN;case"Infinity":return 1/0;case"-Infinity":return-1/0;default:throw new Error("Unsupported unserializable value: "+r.unserializableValue)}}return r.value}function o_(r,t,e){globalThis[t]||Object.assign(globalThis,{[t](...n){const i=globalThis[t];i.args??(i.args=new Map),i.callbacks??(i.callbacks=new Map);const s=(i.lastSeq??0)+1;return i.lastSeq=s,i.args.set(s,n),globalThis[e+t](JSON.stringify({type:r,name:t,seq:s,args:n,isTrivial:!n.some(o=>o instanceof Node)})),new Promise((o,c)=>{i.callbacks.set(s,{resolve(l){i.args.delete(s),o(l)},reject(l){i.args.delete(s),c(l)}})})}})}const ma="puppeteer_";function rS(r,t){return R0(o_,r,t,ma)}/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var ro,Tt,io;class Oh extends da{constructor(e,n){super();m(this,ro,!1);m(this,Tt);m(this,io);_(this,io,e),_(this,Tt,n)}get disposed(){return a(this,ro)}get realm(){return a(this,io)}get client(){return this.realm.environment.client}async jsonValue(){if(!a(this,Tt).objectId)return Bs(a(this,Tt));const e=await this.evaluate(n=>n);if(e===void 0)throw new Error("Could not serialize referenced object");return e}asElement(){return null}async dispose(){a(this,ro)||(_(this,ro,!0),await c_(this.client,a(this,Tt)))}toString(){return a(this,Tt).objectId?"JSHandle@"+(a(this,Tt).subtype||a(this,Tt).type):"JSHandle:"+Bs(a(this,Tt))}get id(){return a(this,Tt).objectId}remoteObject(){return a(this,Tt)}async getProperties(){const e=await this.client.send("Runtime.getProperties",{objectId:a(this,Tt).objectId,ownProperties:!0}),n=new Map;for(const i of e.result)!i.enumerable||!i.value||n.set(i.name,a(this,io).createCdpHandle(i.value));return n}}ro=new WeakMap,Tt=new WeakMap,io=new WeakMap;async function c_(r,t){t.objectId&&await r.send("Runtime.releaseObject",{objectId:t.objectId}).catch(e=>{de(e)})}/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var iS=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},Qd=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0};const sS=new Set(["StaticText","InlineTextBox"]);let l_=(()=>{var l,d_,u;var r,t;let e=lf,n=[],i,s,o,c;return u=class extends e{constructor(f,y){super(new Oh(f,y));m(this,l);iS(this,n)}get realm(){return this.handle.realm}get client(){return this.handle.client}remoteObject(){return this.handle.remoteObject()}get frame(){return this.realm.environment}async contentFrame(){const f=await this.client.send("DOM.describeNode",{objectId:this.id});return typeof f.node.frameId!="string"?null:a(this,l,d_).frame(f.node.frameId)}async scrollIntoView(){await this.assertConnectedElement();try{await this.client.send("DOM.scrollIntoViewIfNeeded",{objectId:this.id})}catch(f){de(f),await super.scrollIntoView()}}async uploadFile(...f){const y=await this.evaluate(A=>A.multiple);X(f.length<=1||y,"Multiple file uploads only work with <input type=file multiple>");let w;try{w=await import("path")}catch(A){throw A instanceof TypeError?new Error("JSHandle#uploadFile can only be used in Node-like environments."):A}const b=f.map(A=>w.win32.isAbsolute(A)||w.posix.isAbsolute(A)?A:w.resolve(A));if(b.length===0){await this.evaluate(A=>{A.files=new DataTransfer().files,A.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),A.dispatchEvent(new Event("change",{bubbles:!0}))});return}const{node:{backendNodeId:C}}=await this.client.send("DOM.describeNode",{objectId:this.id});await this.client.send("DOM.setFileInputFiles",{objectId:this.id,files:b,backendNodeId:C})}async autofill(f){const w=(await this.client.send("DOM.describeNode",{objectId:this.handle.id})).node.backendNodeId,b=this.frame._id;await this.client.send("Autofill.trigger",{fieldId:w,frameId:b,card:f.creditCard})}async*queryAXTree(f,y){const{nodes:w}=await this.client.send("Accessibility.queryAXTree",{objectId:this.id,accessibleName:f,role:y}),b=w.filter(C=>!(C.ignored||!C.role||sS.has(C.role.value)));return yield*Dh.map(b,C=>this.realm.adoptBackendNode(C.backendDOMNodeId))}},l=new WeakSet,d_=function(){return this.frame._frameManager},(()=>{const f=typeof Symbol=="function"&&Symbol.metadata?Object.create(e[Symbol.metadata]??null):void 0;i=[ye()],s=[ye(),(r=lf).bindIsolatedHandle.bind(r)],o=[ye(),(t=lf).bindIsolatedHandle.bind(t)],c=[ye()],Qd(u,null,i,{kind:"method",name:"contentFrame",static:!1,private:!1,access:{has:y=>"contentFrame"in y,get:y=>y.contentFrame},metadata:f},null,n),Qd(u,null,s,{kind:"method",name:"scrollIntoView",static:!1,private:!1,access:{has:y=>"scrollIntoView"in y,get:y=>y.scrollIntoView},metadata:f},null,n),Qd(u,null,o,{kind:"method",name:"uploadFile",static:!1,private:!1,access:{has:y=>"uploadFile"in y,get:y=>y.uploadFile},metadata:f},null,n),Qd(u,null,c,{kind:"method",name:"autofill",static:!1,private:!1,access:{has:y=>"autofill"in y,get:y=>y.autofill},metadata:f},null,n),f&&Object.defineProperty(u,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:f})})(),u})();/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var aS=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},oS=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});const cS=new Yu("__ariaQuerySelector",Tc.queryOne,""),lS=new Yu("__ariaQuerySelectorAll",(async(r,t)=>{const e=Tc.queryAll(r,t);return await r.realm.evaluateHandle((...n)=>n,...await Dh.collect(e))}),"");var Hr,cs,yn,so,Sl,ls,kh,Dt,h_,f_,p_,kl,Wr,ip,sp;class u_ extends He{constructor(e,n,i){super();m(this,Dt);m(this,Hr);m(this,cs);m(this,yn);m(this,so);m(this,Sl,new _r);m(this,ls,new Map);m(this,kh,new Ac);m(this,kl,!1);m(this,Wr);_(this,Hr,e),_(this,cs,i),_(this,yn,n.id),n.name&&_(this,so,n.name);const s=a(this,Sl).use(new He(a(this,Hr)));s.on("Runtime.bindingCalled",I(this,Dt,f_).bind(this)),s.on("Runtime.executionContextDestroyed",async o=>{o.executionContextId===a(this,yn)&&this[Te]()}),s.on("Runtime.executionContextsCleared",async()=>{this[Te]()}),s.on("Runtime.consoleAPICalled",I(this,Dt,p_).bind(this)),s.on($e.Disconnected,()=>{this[Te]()})}get id(){return a(this,yn)}get puppeteerUtil(){let e=Promise.resolve();return a(this,kl)||(e=Promise.all([I(this,Dt,ip).call(this,cS),I(this,Dt,ip).call(this,lS)]),_(this,kl,!0)),wu.inject(n=>{a(this,Wr)&&a(this,Wr).then(i=>{i.dispose()}),_(this,Wr,e.then(()=>this.evaluateHandle(n)))},!a(this,Wr)),a(this,Wr)}async evaluate(e,...n){return await I(this,Dt,sp).call(this,!0,e,...n)}async evaluateHandle(e,...n){return await I(this,Dt,sp).call(this,!1,e,...n)}[Te](){a(this,Sl).dispose(),this.emit("disposed",void 0)}}Hr=new WeakMap,cs=new WeakMap,yn=new WeakMap,so=new WeakMap,Sl=new WeakMap,ls=new WeakMap,kh=new WeakMap,Dt=new WeakSet,h_=async function(e){const n={stack:[],error:void 0,hasError:!1};try{if(a(this,ls).has(e.name))return;const i=aS(n,await a(this,kh).acquire(),!1);try{await a(this,Hr).send("Runtime.addBinding",a(this,so)?{name:ma+e.name,executionContextName:a(this,so)}:{name:ma+e.name,executionContextId:a(this,yn)}),await this.evaluate(o_,"internal",e.name,ma),a(this,ls).set(e.name,e)}catch(s){if(s instanceof Error&&(s.message.includes("Execution context was destroyed")||s.message.includes("Cannot find context with specified id")))return;de(s)}}catch(i){n.error=i,n.hasError=!0}finally{oS(n)}},f_=async function(e){if(e.executionContextId!==a(this,yn))return;let n;try{n=JSON.parse(e.payload)}catch{return}const{type:i,name:s,seq:o,args:c,isTrivial:l}=n;if(i!=="internal"){this.emit("bindingcalled",e);return}if(!a(this,ls).has(s)){this.emit("bindingcalled",e);return}try{const d=a(this,ls).get(s);await(d==null?void 0:d.run(this,o,c,l))}catch(d){de(d)}},p_=function(e){e.executionContextId===a(this,yn)&&this.emit("consoleapicalled",e)},kl=new WeakMap,Wr=new WeakMap,ip=async function(e){try{await I(this,Dt,h_).call(this,e)}catch(n){de(n)}},sp=async function(e,n,...i){var p;const s=j1(((p=D1(n))==null?void 0:p.toString())??yr.INTERNAL_URL);if(Ws(n)){const f=a(this,yn),y=n,w=Cg.test(y)?y:`${y}
${s}
`,{exceptionDetails:b,result:C}=await a(this,Hr).send("Runtime.evaluate",{expression:w,contextId:f,returnByValue:e,awaitPromise:!0,userGesture:!0}).catch($g);if(b)throw Pg(b);return e?Bs(C):a(this,cs).createCdpHandle(C)}const o=yi(n),c=Cg.test(o)?o:`${o}
${s}
`;let l;try{l=a(this,Hr).send("Runtime.callFunctionOn",{functionDeclaration:c,executionContextId:a(this,yn),arguments:i.length?await Promise.all(i.map(h.bind(this))):[],returnByValue:e,awaitPromise:!0,userGesture:!0})}catch(f){throw f instanceof TypeError&&f.message.startsWith("Converting circular structure to JSON")&&(f.message+=" Recursive objects are not allowed."),f}const{exceptionDetails:d,result:u}=await l.catch($g);if(d)throw Pg(d);return e?Bs(u):a(this,cs).createCdpHandle(u);async function h(f){if(f instanceof qn&&(f=await f.get(this)),typeof f=="bigint")return{unserializableValue:`${f.toString()}n`};if(Object.is(f,-0))return{unserializableValue:"-0"};if(Object.is(f,1/0))return{unserializableValue:"Infinity"};if(Object.is(f,-1/0))return{unserializableValue:"-Infinity"};if(Object.is(f,NaN))return{unserializableValue:"NaN"};const y=f&&(f instanceof Oh||f instanceof l_)?f:null;if(y){if(y.realm!==a(this,cs))throw new Error("JSHandles can be evaluated only in the context they were created!");if(y.disposed)throw new Error("JSHandle is disposed!");return y.remoteObject().unserializableValue?{unserializableValue:y.remoteObject().unserializableValue}:y.remoteObject().objectId?{objectId:y.remoteObject().objectId}:{value:y.remoteObject().value}}return{value:f}}};const $g=r=>{if(r.message.includes("Object reference chain is too long"))return{result:{type:"undefined"}};if(r.message.includes("Object couldn't be returned by value"))return{result:{type:"undefined"}};throw r.message.endsWith("Cannot find context with specified id")||r.message.endsWith("Inspected target navigated or closed")?new Error("Execution context was destroyed, most likely because of a navigation."):r};/**
 * @license
 * Copyright 2018 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var ds;class dS{constructor(t){m(this,ds);_(this,ds,t)}async snapshot(t={}){const{interestingOnly:e=!0,root:n=null}=t,{nodes:i}=await a(this,ds).environment.client.send("Accessibility.getFullAXTree");let s;if(n){const{node:d}=await a(this,ds).environment.client.send("DOM.describeNode",{objectId:n.id});s=d.backendNodeId}const o=ap.createTree(a(this,ds),i);let c=o;if(s&&(c=o.find(d=>d.payload.backendDOMNodeId===s),!c))return null;if(!e)return this.serializeTree(c)[0]??null;const l=new Set;return this.collectInterestingNodes(l,o,!1),l.has(c)?this.serializeTree(c,l)[0]??null:null}serializeTree(t,e){const n=[];for(const s of t.children)n.push(...this.serializeTree(s,e));if(e&&!e.has(t))return n;const i=t.serialize();return n.length&&(i.children=n),[i]}collectInterestingNodes(t,e,n){if(e.isInteresting(n)&&t.add(e),!e.isLeafNode()){n=n||e.isControl();for(const i of e.children)this.collectInterestingNodes(t,i,n)}}}ds=new WeakMap;var ao,Cl,us,El,hs,Gt,Il,fs,Nl,vr,m_,g_,op;const Rm=class Rm{constructor(t,e){m(this,vr);L(this,"payload");L(this,"children",[]);m(this,ao,!1);m(this,Cl,!1);m(this,us,!1);m(this,El,!1);m(this,hs);m(this,Gt);m(this,Il);m(this,fs);m(this,Nl);this.payload=e,_(this,hs,this.payload.name?this.payload.name.value:""),_(this,Gt,this.payload.role?this.payload.role.value:"Unknown"),_(this,Il,this.payload.ignored),_(this,Nl,t);for(const n of this.payload.properties||[])n.name==="editable"&&(_(this,ao,n.value.value==="richtext"),_(this,Cl,!0)),n.name==="focusable"&&_(this,us,n.value.value),n.name==="hidden"&&_(this,El,n.value.value)}find(t){if(t(this))return this;for(const e of this.children){const n=e.find(t);if(n)return n}return null}isLeafNode(){if(!this.children.length||I(this,vr,m_).call(this)||I(this,vr,g_).call(this))return!0;switch(a(this,Gt)){case"doc-cover":case"graphics-symbol":case"img":case"image":case"Meter":case"scrollbar":case"slider":case"separator":case"progressbar":return!0}return I(this,vr,op).call(this)?!1:!!(a(this,us)&&a(this,hs)||a(this,Gt)==="heading"&&a(this,hs))}isControl(){switch(a(this,Gt)){case"button":case"checkbox":case"ColorWell":case"combobox":case"DisclosureTriangle":case"listbox":case"menu":case"menubar":case"menuitem":case"menuitemcheckbox":case"menuitemradio":case"radio":case"scrollbar":case"searchbox":case"slider":case"spinbutton":case"switch":case"tab":case"textbox":case"tree":case"treeitem":return!0;default:return!1}}isInteresting(t){return a(this,Gt)==="Ignored"||a(this,El)||a(this,Il)?!1:a(this,us)||a(this,ao)||this.isControl()?!0:t?!1:this.isLeafNode()&&!!a(this,hs)}serialize(){const t=new Map;for(const p of this.payload.properties||[])t.set(p.name.toLowerCase(),p.value.value);this.payload.name&&t.set("name",this.payload.name.value),this.payload.value&&t.set("value",this.payload.value.value),this.payload.description&&t.set("description",this.payload.description.value);const e={role:a(this,Gt),elementHandle:async()=>this.payload.backendDOMNodeId?await a(this,Nl).adoptBackendNode(this.payload.backendDOMNodeId):null},n=["name","value","description","keyshortcuts","roledescription","valuetext"],i=p=>t.get(p);for(const p of n)t.has(p)&&(e[p]=i(p));const s=["disabled","expanded","focused","modal","multiline","multiselectable","readonly","required","selected"],o=p=>t.get(p);for(const p of s)p==="focused"&&a(this,Gt)==="RootWebArea"||!o(p)||(e[p]=o(p));const c=["checked","pressed"];for(const p of c){if(!t.has(p))continue;const f=t.get(p);e[p]=f==="mixed"?"mixed":f==="true"}const l=["level","valuemax","valuemin"],d=p=>t.get(p);for(const p of l)t.has(p)&&(e[p]=d(p));const u=["autocomplete","haspopup","invalid","orientation"],h=p=>t.get(p);for(const p of u){const f=h(p);!f||f==="false"||(e[p]=h(p))}return e}static createTree(t,e){const n=new Map;for(const i of e)n.set(i.nodeId,new Rm(t,i));for(const i of n.values())for(const s of i.payload.childIds||[]){const o=n.get(s);o&&i.children.push(o)}return n.values().next().value}};ao=new WeakMap,Cl=new WeakMap,us=new WeakMap,El=new WeakMap,hs=new WeakMap,Gt=new WeakMap,Il=new WeakMap,fs=new WeakMap,Nl=new WeakMap,vr=new WeakSet,m_=function(){return a(this,ao)?!1:a(this,Cl)?!0:a(this,Gt)==="textbox"||a(this,Gt)==="searchbox"},g_=function(){const t=a(this,Gt);return t==="LineBreak"||t==="text"||t==="InlineTextBox"||t==="StaticText"},op=function(){var t;if(a(this,fs)===void 0){_(this,fs,!1);for(const e of this.children)if(a(e,us)||I(t=e,vr,op).call(t)){_(this,fs,!0);break}}return a(this,fs)};let ap=Rm;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var at;(function(r){r.FrameAttached=Symbol("FrameManager.FrameAttached"),r.FrameNavigated=Symbol("FrameManager.FrameNavigated"),r.FrameDetached=Symbol("FrameManager.FrameDetached"),r.FrameSwapped=Symbol("FrameManager.FrameSwapped"),r.LifecycleEvent=Symbol("FrameManager.LifecycleEvent"),r.FrameNavigatedWithinDocument=Symbol("FrameManager.FrameNavigatedWithinDocument"),r.ConsoleApiCalled=Symbol("FrameManager.ConsoleApiCalled"),r.BindingCalled=Symbol("FrameManager.BindingCalled")})(at||(at={}));/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var or,oo,Ml,qr,ps,Al,Tl,ms,Vt,co,lo;class uS{constructor(t,e,n,...i){m(this,or);m(this,oo);m(this,Ml);m(this,qr);m(this,ps);m(this,Al);m(this,Tl);m(this,ms,Ae.create());m(this,Vt);m(this,co);m(this,lo,[]);var s;switch(_(this,or,t),_(this,oo,e.polling),_(this,Ml,e.root),_(this,co,e.signal),(s=a(this,co))==null||s.addEventListener("abort",()=>{var o;this.terminate((o=a(this,co))==null?void 0:o.reason)},{once:!0}),typeof n){case"string":_(this,qr,`() => {return (${n});}`);break;default:_(this,qr,yi(n));break}_(this,ps,i),a(this,or).taskManager.add(this),e.timeout&&(_(this,Tl,new rm(`Waiting failed: ${e.timeout}ms exceeded`)),_(this,Al,setTimeout(()=>{this.terminate(a(this,Tl))},e.timeout))),this.rerun()}get result(){return a(this,ms).valueOrThrow()}async rerun(){for(const e of a(this,lo))e.abort();a(this,lo).length=0;const t=new AbortController;a(this,lo).push(t);try{switch(a(this,oo)){case"raf":_(this,Vt,await a(this,or).evaluateHandle(({RAFPoller:n,createFunction:i},s,...o)=>{const c=i(s);return new n(()=>c(...o))},qn.create(n=>n.puppeteerUtil),a(this,qr),...a(this,ps)));break;case"mutation":_(this,Vt,await a(this,or).evaluateHandle(({MutationPoller:n,createFunction:i},s,o,...c)=>{const l=i(o);return new n(()=>l(...c),s||document)},qn.create(n=>n.puppeteerUtil),a(this,Ml),a(this,qr),...a(this,ps)));break;default:_(this,Vt,await a(this,or).evaluateHandle(({IntervalPoller:n,createFunction:i},s,o,...c)=>{const l=i(o);return new n(()=>l(...c),s)},qn.create(n=>n.puppeteerUtil),a(this,oo),a(this,qr),...a(this,ps)));break}await a(this,Vt).evaluate(n=>{n.start()});const e=await a(this,Vt).evaluateHandle(n=>n.result());a(this,ms).resolve(e),await this.terminate()}catch(e){if(t.signal.aborted)return;const n=this.getBadError(e);n&&await this.terminate(n)}}async terminate(t){if(a(this,or).taskManager.delete(this),clearTimeout(a(this,Al)),t&&!a(this,ms).finished()&&a(this,ms).reject(t),a(this,Vt))try{await a(this,Vt).evaluateHandle(async e=>{await e.stop()}),a(this,Vt)&&(await a(this,Vt).dispose(),_(this,Vt,void 0))}catch{}}getBadError(t){return Kn(t)?t.message.includes("Execution context is not available in detached frame")?new Error("Waiting failed: Frame detached"):t.message.includes("Execution context was destroyed")||t.message.includes("Cannot find context with specified id")||t.message.includes("AbortError: Actor 'MessageHandlerFrame' destroyed")?void 0:t:new Error("WaitTask failed with an error",{cause:t})}}or=new WeakMap,oo=new WeakMap,Ml=new WeakMap,qr=new WeakMap,ps=new WeakMap,Al=new WeakMap,Tl=new WeakMap,ms=new WeakMap,Vt=new WeakMap,co=new WeakMap,lo=new WeakMap;var Kr;class hS{constructor(){m(this,Kr,new Set)}add(t){a(this,Kr).add(t)}delete(t){a(this,Kr).delete(t)}terminateAll(t){for(const e of a(this,Kr))e.terminate(t);a(this,Kr).clear()}async rerunAll(){await Promise.all([...a(this,Kr)].map(t=>t.rerun()))}}Kr=new WeakMap;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Pl;class fS{constructor(t){L(this,"timeoutSettings");L(this,"taskManager",new hS);m(this,Pl,!1);this.timeoutSettings=t}async waitForFunction(t,e={},...n){const{polling:i="raf",timeout:s=this.timeoutSettings.timeout(),root:o,signal:c}=e;if(typeof i=="number"&&i<0)throw new Error("Cannot poll with non-positive interval");return await new uS(this,{polling:i,root:o,timeout:s,signal:c},t,...n).result}get disposed(){return a(this,Pl)}dispose(){_(this,Pl,!0),this.taskManager.terminateAll(new Error("waitForFunction failed: frame got detached."))}[Te](){this.dispose()}}Pl=new WeakMap;/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Ln,_n,Gr,vt,y_,__,b_,Su,ku;class cp extends fS{constructor(e,n){super(n);m(this,vt);m(this,Ln);m(this,_n,new He);m(this,Gr);_(this,Gr,e)}get environment(){return a(this,Gr)}get client(){return a(this,Gr).client}get emitter(){return a(this,_n)}setContext(e){var n;(n=a(this,Ln))==null||n[Te](),e.once("disposed",I(this,vt,y_).bind(this)),e.on("consoleapicalled",I(this,vt,__).bind(this)),e.on("bindingcalled",I(this,vt,b_).bind(this)),_(this,Ln,e),a(this,_n).emit("context",e),this.taskManager.rerunAll()}hasContext(){return!!a(this,Ln)}get context(){return a(this,Ln)}async evaluateHandle(e,...n){e=ot(this.evaluateHandle.name,e);let i=I(this,vt,Su).call(this);return i||(i=await I(this,vt,ku).call(this)),await i.evaluateHandle(e,...n)}async evaluate(e,...n){e=ot(this.evaluate.name,e);let i=I(this,vt,Su).call(this);return i||(i=await I(this,vt,ku).call(this)),await i.evaluate(e,...n)}async adoptBackendNode(e){let n=I(this,vt,Su).call(this);n||(n=await I(this,vt,ku).call(this));const{object:i}=await this.client.send("DOM.resolveNode",{backendNodeId:e,executionContextId:n.id});return this.createCdpHandle(i)}async adoptHandle(e){if(e.realm===this)return await e.evaluateHandle(i=>i);const n=await this.client.send("DOM.describeNode",{objectId:e.id});return await this.adoptBackendNode(n.node.backendNodeId)}async transferHandle(e){if(e.realm===this||e.remoteObject().objectId===void 0)return e;const n=await this.client.send("DOM.describeNode",{objectId:e.remoteObject().objectId}),i=await this.adoptBackendNode(n.node.backendNodeId);return await e.dispose(),i}createCdpHandle(e){return e.subtype==="node"?new l_(this,e):new Oh(this,e)}[Te](){var e;(e=a(this,Ln))==null||e[Te](),a(this,_n).emit("disposed",void 0),super[Te](),a(this,_n).removeAllListeners()}}Ln=new WeakMap,_n=new WeakMap,Gr=new WeakMap,vt=new WeakSet,y_=function(){_(this,Ln,void 0),"clearDocumentHandle"in a(this,Gr)&&a(this,Gr).clearDocumentHandle()},__=function(e){a(this,_n).emit("consoleapicalled",e)},b_=function(e){a(this,_n).emit("bindingcalled",e)},Su=function(){if(this.disposed)throw new Error(`Execution context is not available in detached frame or worker "${this.environment.url()}" (are you trying to evaluate?)`);return a(this,Ln)},ku=async function(){return await Rt(Ze(a(this,_n),"context").pipe(zn(Ze(a(this,_n),"disposed").pipe(Pt(()=>{throw new Error("Execution context was destroyed")})),Hn(this.timeoutSettings.timeout()))))};/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Pn=Symbol("mainWorld"),Cu=Symbol("puppeteerWorld");/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const pS=new Map([["load","load"],["domcontentloaded","DOMContentLoaded"],["networkidle0","networkIdle"],["networkidle2","networkAlmostIdle"]]);var $l,Vr,uo,Xr,gs,Rl,ys,Fl,Dl,Ol,Ll,jl,cr,Oe,w_,v_,x_,S_,k_,C_,Eu,Si;class df{constructor(t,e,n,i){m(this,Oe);m(this,$l);m(this,Vr);m(this,uo);m(this,Xr,null);m(this,gs,new _r);m(this,Rl);m(this,ys);m(this,Fl,Ae.create());m(this,Dl,Ae.create());m(this,Ol,Ae.create());m(this,Ll);m(this,jl);m(this,cr);Array.isArray(n)?n=n.slice():typeof n=="string"&&(n=[n]),_(this,Rl,e._loaderId),_(this,$l,n.map(l=>{const d=pS.get(l);return X(d,"Unknown value for options.waitUntil: "+l),d})),_(this,Vr,e),_(this,uo,i),a(this,gs).use(new He(e._frameManager)).on(at.LifecycleEvent,I(this,Oe,Si).bind(this));const o=a(this,gs).use(new He(e));o.on(ft.FrameNavigatedWithinDocument,I(this,Oe,k_).bind(this)),o.on(ft.FrameNavigated,I(this,Oe,C_).bind(this)),o.on(ft.FrameSwapped,I(this,Oe,Eu).bind(this)),o.on(ft.FrameSwappedByActivation,I(this,Oe,Eu).bind(this)),o.on(ft.FrameDetached,I(this,Oe,S_).bind(this));const c=a(this,gs).use(new He(t));c.on(st.Request,I(this,Oe,w_).bind(this)),c.on(st.Response,I(this,Oe,x_).bind(this)),c.on(st.RequestFailed,I(this,Oe,v_).bind(this)),_(this,ys,Ae.create({timeout:a(this,uo),message:`Navigation timeout of ${a(this,uo)} ms exceeded`})),I(this,Oe,Si).call(this)}async navigationResponse(){var t;return await((t=a(this,cr))==null?void 0:t.valueOrThrow()),a(this,Xr)?a(this,Xr).response():null}sameDocumentNavigationPromise(){return a(this,Fl).valueOrThrow()}newDocumentNavigationPromise(){return a(this,Ol).valueOrThrow()}lifecyclePromise(){return a(this,Dl).valueOrThrow()}terminationPromise(){return a(this,ys).valueOrThrow()}dispose(){a(this,gs).dispose(),a(this,ys).resolve(new Error("LifecycleWatcher disposed"))}}$l=new WeakMap,Vr=new WeakMap,uo=new WeakMap,Xr=new WeakMap,gs=new WeakMap,Rl=new WeakMap,ys=new WeakMap,Fl=new WeakMap,Dl=new WeakMap,Ol=new WeakMap,Ll=new WeakMap,jl=new WeakMap,cr=new WeakMap,Oe=new WeakSet,w_=function(t){var e,n;t.frame()!==a(this,Vr)||!t.isNavigationRequest()||(_(this,Xr,t),(e=a(this,cr))==null||e.resolve(),_(this,cr,Ae.create()),t.response()!==null&&((n=a(this,cr))==null||n.resolve()))},v_=function(t){var e,n;((e=a(this,Xr))==null?void 0:e.id)===t.id&&((n=a(this,cr))==null||n.resolve())},x_=function(t){var e,n;((e=a(this,Xr))==null?void 0:e.id)===t.request().id&&((n=a(this,cr))==null||n.resolve())},S_=function(t){if(a(this,Vr)===t){a(this,ys).resolve(new Error("Navigating frame was detached"));return}I(this,Oe,Si).call(this)},k_=function(){_(this,Ll,!0),I(this,Oe,Si).call(this)},C_=function(t){if(t==="BackForwardCacheRestore")return I(this,Oe,Eu).call(this);I(this,Oe,Si).call(this)},Eu=function(){_(this,jl,!0),I(this,Oe,Si).call(this)},Si=function(){if(!t(a(this,Vr),a(this,$l)))return;a(this,Dl).resolve(),a(this,Ll)&&a(this,Fl).resolve(void 0),(a(this,jl)||a(this,Vr)._loaderId!==a(this,Rl))&&a(this,Ol).resolve(void 0);function t(e,n){for(const i of n)if(!e._lifecycleEvents.has(i))return!1;for(const i of e.childFrames())if(i._hasStartedLoading&&!t(i,n))return!1;return!0}};/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var mS=function(r,t,e){for(var n=arguments.length>2,i=0;i<t.length;i++)e=n?t[i].call(r,e):t[i].call(r);return n?e:void 0},wi=function(r,t,e,n,i,s){function o(C){if(C!==void 0&&typeof C!="function")throw new TypeError("Function expected");return C}for(var c=n.kind,l=c==="getter"?"get":c==="setter"?"set":"value",d=!t&&r?n.static?r:r.prototype:null,u=t||(d?Object.getOwnPropertyDescriptor(d,n.name):{}),h,p=!1,f=e.length-1;f>=0;f--){var y={};for(var w in n)y[w]=w==="access"?{}:n[w];for(var w in n.access)y.access[w]=n.access[w];y.addInitializer=function(C){if(p)throw new TypeError("Cannot add initializers after decoration has completed");s.push(o(C||null))};var b=(0,e[f])(c==="accessor"?{get:u.get,set:u.set}:u[l],y);if(c==="accessor"){if(b===void 0)continue;if(b===null||typeof b!="object")throw new TypeError("Object expected");(h=o(b.get))&&(u.get=h),(h=o(b.set))&&(u.set=h),(h=o(b.init))&&i.unshift(h)}else(h=o(b))&&(c==="field"?i.unshift(h):u[l]=h)}d&&Object.defineProperty(d,n.name,u),p=!0};let Rg=(()=>{var d,u,h,p,E_,I_,N_,b;let r=Vx,t=[],e,n,i,s,o,c,l;return b=class extends r{constructor(T,M,D,U){super();m(this,p);m(this,d,(mS(this,t),""));m(this,u,!1);m(this,h);L(this,"_frameManager");L(this,"_loaderId","");L(this,"_lifecycleEvents",new Set);L(this,"_id");L(this,"_parentId");L(this,"accessibility");L(this,"worlds");this._frameManager=T,_(this,d,""),this._id=M,this._parentId=D,_(this,u,!1),_(this,h,U),this._loaderId="",this.worlds={[Pn]:new cp(this,this._frameManager.timeoutSettings),[Cu]:new cp(this,this._frameManager.timeoutSettings)},this.accessibility=new dS(this.worlds[Pn]),this.on(ft.FrameSwappedByActivation,()=>{this._onLoadingStarted(),this._onLoadingStopped()}),this.worlds[Pn].emitter.on("consoleapicalled",I(this,p,E_).bind(this)),this.worlds[Pn].emitter.on("bindingcalled",I(this,p,I_).bind(this))}_client(){return a(this,h)}updateId(T){this._id=T}updateClient(T){_(this,h,T)}page(){return this._frameManager.page()}isOOPFrame(){return a(this,h)!==this._frameManager.client}async goto(T,M={}){const{referer:D=this._frameManager.networkManager.extraHTTPHeaders().referer,referrerPolicy:U=this._frameManager.networkManager.extraHTTPHeaders()["referer-policy"],waitUntil:O=["load"],timeout:K=this._frameManager.timeoutSettings.navigationTimeout()}=M;let F=!1;const H=new df(this._frameManager.networkManager,this,O,K);let B=await Ae.race([P(a(this,h),T,D,U,this._id),H.terminationPromise()]);B||(B=await Ae.race([H.terminationPromise(),F?H.newDocumentNavigationPromise():H.sameDocumentNavigationPromise()]));try{if(B)throw B;return await H.navigationResponse()}finally{H.dispose()}async function P(N,j,W,g,E){try{const k=await N.send("Page.navigate",{url:j,referrer:W,frameId:E,referrerPolicy:g});return F=!!k.loaderId,k.errorText==="net::ERR_HTTP_RESPONSE_CODE_FAILURE"?null:k.errorText?new Error(`${k.errorText} at ${j}`):null}catch(k){if(Kn(k))return k;throw k}}}async waitForNavigation(T={}){const{waitUntil:M=["load"],timeout:D=this._frameManager.timeoutSettings.navigationTimeout()}=T,U=new df(this._frameManager.networkManager,this,M,D),O=await Ae.race([U.terminationPromise(),...T.ignoreSameDocumentNavigation?[]:[U.sameDocumentNavigationPromise()],U.newDocumentNavigationPromise()]);try{if(O)throw O;const K=await Ae.race([U.terminationPromise(),U.navigationResponse()]);if(K instanceof Error)throw O;return K||null}finally{U.dispose()}}get client(){return a(this,h)}mainRealm(){return this.worlds[Pn]}isolatedRealm(){return this.worlds[Cu]}async setContent(T,M={}){const{waitUntil:D=["load"],timeout:U=this._frameManager.timeoutSettings.navigationTimeout()}=M;await this.setFrameContent(T);const O=new df(this._frameManager.networkManager,this,D,U),K=await Ae.race([O.terminationPromise(),O.lifecyclePromise()]);if(O.dispose(),K)throw K}url(){return a(this,d)}parentFrame(){return this._frameManager._frameTree.parentFrame(this._id)||null}childFrames(){return this._frameManager._frameTree.childFrames(this._id)}async addPreloadScript(T){if(!this.isOOPFrame()&&this!==this._frameManager.mainFrame()||T.getIdForFrame(this))return;const{identifier:M}=await a(this,h).send("Page.addScriptToEvaluateOnNewDocument",{source:T.source});T.setIdForFrame(this,M)}async addExposedFunctionBinding(T){this!==this._frameManager.mainFrame()&&!this._hasStartedLoading||await Promise.all([a(this,h).send("Runtime.addBinding",{name:ma+T.name}),this.evaluate(T.initSource).catch(de)])}async removeExposedFunctionBinding(T){this!==this._frameManager.mainFrame()&&!this._hasStartedLoading||await Promise.all([a(this,h).send("Runtime.removeBinding",{name:ma+T.name}),this.evaluate(M=>{globalThis[M]=void 0},T.name).catch(de)])}async waitForDevicePrompt(T={}){return await I(this,p,N_).call(this).waitForDevicePrompt(T)}_navigated(T){this._name=T.name,_(this,d,`${T.url}${T.urlFragment||""}`)}_navigatedWithinDocument(T){_(this,d,T)}_onLifecycleEvent(T,M){M==="init"&&(this._loaderId=T,this._lifecycleEvents.clear()),this._lifecycleEvents.add(M)}_onLoadingStopped(){this._lifecycleEvents.add("DOMContentLoaded"),this._lifecycleEvents.add("load")}_onLoadingStarted(){this._hasStartedLoading=!0}get detached(){return a(this,u)}[(e=[Pe],n=[Pe],i=[Pe],s=[Pe],o=[Pe],c=[Pe],l=[Pe],Te)](){a(this,u)||(_(this,u,!0),this.worlds[Pn][Te](),this.worlds[Cu][Te]())}exposeFunction(){throw new $0}},d=new WeakMap,u=new WeakMap,h=new WeakMap,p=new WeakSet,E_=function(T){this._frameManager.emit(at.ConsoleApiCalled,[this.worlds[Pn],T])},I_=function(T){this._frameManager.emit(at.BindingCalled,[this.worlds[Pn],T])},N_=function(){const T=this.page().mainFrame();return this.isOOPFrame()||T===null?this._frameManager._deviceRequestPromptManager(a(this,h)):T._frameManager._deviceRequestPromptManager(a(this,h))},(()=>{const T=typeof Symbol=="function"&&Symbol.metadata?Object.create(r[Symbol.metadata]??null):void 0;wi(b,null,e,{kind:"method",name:"goto",static:!1,private:!1,access:{has:M=>"goto"in M,get:M=>M.goto},metadata:T},null,t),wi(b,null,n,{kind:"method",name:"waitForNavigation",static:!1,private:!1,access:{has:M=>"waitForNavigation"in M,get:M=>M.waitForNavigation},metadata:T},null,t),wi(b,null,i,{kind:"method",name:"setContent",static:!1,private:!1,access:{has:M=>"setContent"in M,get:M=>M.setContent},metadata:T},null,t),wi(b,null,s,{kind:"method",name:"addPreloadScript",static:!1,private:!1,access:{has:M=>"addPreloadScript"in M,get:M=>M.addPreloadScript},metadata:T},null,t),wi(b,null,o,{kind:"method",name:"addExposedFunctionBinding",static:!1,private:!1,access:{has:M=>"addExposedFunctionBinding"in M,get:M=>M.addExposedFunctionBinding},metadata:T},null,t),wi(b,null,c,{kind:"method",name:"removeExposedFunctionBinding",static:!1,private:!1,access:{has:M=>"removeExposedFunctionBinding"in M,get:M=>M.removeExposedFunctionBinding},metadata:T},null,t),wi(b,null,l,{kind:"method",name:"waitForDevicePrompt",static:!1,private:!1,access:{has:M=>"waitForDevicePrompt"in M,get:M=>M.waitForDevicePrompt},metadata:T},null,t),T&&Object.defineProperty(b,Symbol.metadata,{enumerable:!0,configurable:!0,writable:!0,value:T})})(),b})();/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var _s,ho,Jr,fo,po,Bl;class gS{constructor(){m(this,_s,new Map);m(this,ho,new Map);m(this,Jr,new Map);m(this,fo);m(this,po,!1);m(this,Bl,new Map)}getMainFrame(){return a(this,fo)}getById(t){return a(this,_s).get(t)}waitForFrame(t){const e=this.getById(t);if(e)return Promise.resolve(e);const n=Ae.create();return(a(this,Bl).get(t)||new Set).add(n),n.valueOrThrow()}frames(){return Array.from(a(this,_s).values())}addFrame(t){var e;a(this,_s).set(t._id,t),t._parentId?(a(this,ho).set(t._id,t._parentId),a(this,Jr).has(t._parentId)||a(this,Jr).set(t._parentId,new Set),a(this,Jr).get(t._parentId).add(t._id)):(!a(this,fo)||a(this,po))&&(_(this,fo,t),_(this,po,!1)),(e=a(this,Bl).get(t._id))==null||e.forEach(n=>n.resolve(t))}removeFrame(t){var e;a(this,_s).delete(t._id),a(this,ho).delete(t._id),t._parentId?(e=a(this,Jr).get(t._parentId))==null||e.delete(t._id):_(this,po,!0)}childFrames(t){const e=a(this,Jr).get(t);return e?Array.from(e).map(n=>this.getById(n)).filter(n=>n!==void 0):[]}parentFrame(t){const e=a(this,ho).get(t);return e?this.getById(e):void 0}}_s=new WeakMap,ho=new WeakMap,Jr=new WeakMap,fo=new WeakMap,po=new WeakMap,Bl=new WeakMap;class Fg{constructor(){L(this,"_interceptionId");L(this,"_failureText",null);L(this,"_response",null);L(this,"_fromMemoryCache",!1);L(this,"_redirectChain",[]);L(this,"interception",{enabled:!1,handled:!1,handlers:[],resolutionState:{action:$n.None},requestOverrides:{},response:null,abortReason:null})}continueRequestOverrides(){return X(this.interception.enabled,"Request Interception is not enabled!"),this.interception.requestOverrides}responseForRequest(){return X(this.interception.enabled,"Request Interception is not enabled!"),this.interception.response}abortErrorReason(){return X(this.interception.enabled,"Request Interception is not enabled!"),this.interception.abortReason}interceptResolutionState(){return this.interception.enabled?this.interception.handled?{action:$n.AlreadyHandled}:{...this.interception.resolutionState}:{action:$n.Disabled}}isInterceptResolutionHandled(){return this.interception.handled}enqueueInterceptAction(t){this.interception.handlers.push(t)}async finalizeInterceptions(){await this.interception.handlers.reduce((e,n)=>e.then(n),Promise.resolve()),this.interception.handlers=[];const{action:t}=this.interceptResolutionState();switch(t){case"abort":return await this._abort(this.interception.abortReason);case"respond":if(this.interception.response===null)throw new Error("Response is missing for the interception");return await this._respond(this.interception.response);case"continue":return await this._continue(this.interception.requestOverrides)}}async continue(t={},e){if(!this.url().startsWith("data:")){if(X(this.interception.enabled,"Request Interception is not enabled!"),X(!this.interception.handled,"Request is already handled!"),e===void 0)return await this._continue(t);if(this.interception.requestOverrides=t,this.interception.resolutionState.priority===void 0||e>this.interception.resolutionState.priority){this.interception.resolutionState={action:$n.Continue,priority:e};return}if(e===this.interception.resolutionState.priority){if(this.interception.resolutionState.action==="abort"||this.interception.resolutionState.action==="respond")return;this.interception.resolutionState.action=$n.Continue}}}async respond(t,e){if(!this.url().startsWith("data:")){if(X(this.interception.enabled,"Request Interception is not enabled!"),X(!this.interception.handled,"Request is already handled!"),e===void 0)return await this._respond(t);if(this.interception.response=t,this.interception.resolutionState.priority===void 0||e>this.interception.resolutionState.priority){this.interception.resolutionState={action:$n.Respond,priority:e};return}if(e===this.interception.resolutionState.priority){if(this.interception.resolutionState.action==="abort")return;this.interception.resolutionState.action=$n.Respond}}}async abort(t="failed",e){if(this.url().startsWith("data:"))return;const n=_S[t];if(X(n,"Unknown error code: "+t),X(this.interception.enabled,"Request Interception is not enabled!"),X(!this.interception.handled,"Request is already handled!"),e===void 0)return await this._abort(n);if(this.interception.abortReason=n,this.interception.resolutionState.priority===void 0||e>=this.interception.resolutionState.priority){this.interception.resolutionState={action:$n.Abort,priority:e};return}}static getResponse(t){const e=Ws(t)?new TextEncoder().encode(t):t,n=[];for(const i of e)n.push(String.fromCharCode(i));return{contentLength:e.byteLength,base64:btoa(n.join(""))}}}var $n;(function(r){r.Abort="abort",r.Respond="respond",r.Continue="continue",r.Disabled="disabled",r.None="none",r.AlreadyHandled="already-handled"})($n||($n={}));function Dg(r){const t=[];for(const e in r){const n=r[e];if(!Object.is(n,void 0)){const i=Array.isArray(n)?n:[n];t.push(...i.map(s=>({name:e,value:s+""})))}}return t}const yS={100:"Continue",101:"Switching Protocols",102:"Processing",103:"Early Hints",200:"OK",201:"Created",202:"Accepted",203:"Non-Authoritative Information",204:"No Content",205:"Reset Content",206:"Partial Content",207:"Multi-Status",208:"Already Reported",226:"IM Used",300:"Multiple Choices",301:"Moved Permanently",302:"Found",303:"See Other",304:"Not Modified",305:"Use Proxy",306:"Switch Proxy",307:"Temporary Redirect",308:"Permanent Redirect",400:"Bad Request",401:"Unauthorized",402:"Payment Required",403:"Forbidden",404:"Not Found",405:"Method Not Allowed",406:"Not Acceptable",407:"Proxy Authentication Required",408:"Request Timeout",409:"Conflict",410:"Gone",411:"Length Required",412:"Precondition Failed",413:"Payload Too Large",414:"URI Too Long",415:"Unsupported Media Type",416:"Range Not Satisfiable",417:"Expectation Failed",418:"I'm a teapot",421:"Misdirected Request",422:"Unprocessable Entity",423:"Locked",424:"Failed Dependency",425:"Too Early",426:"Upgrade Required",428:"Precondition Required",429:"Too Many Requests",431:"Request Header Fields Too Large",451:"Unavailable For Legal Reasons",500:"Internal Server Error",501:"Not Implemented",502:"Bad Gateway",503:"Service Unavailable",504:"Gateway Timeout",505:"HTTP Version Not Supported",506:"Variant Also Negotiates",507:"Insufficient Storage",508:"Loop Detected",510:"Not Extended",511:"Network Authentication Required"},_S={aborted:"Aborted",accessdenied:"AccessDenied",addressunreachable:"AddressUnreachable",blockedbyclient:"BlockedByClient",blockedbyresponse:"BlockedByResponse",connectionaborted:"ConnectionAborted",connectionclosed:"ConnectionClosed",connectionfailed:"ConnectionFailed",connectionrefused:"ConnectionRefused",connectionreset:"ConnectionReset",internetdisconnected:"InternetDisconnected",namenotresolved:"NameNotResolved",timedout:"TimedOut",failed:"Failed"};function uf(r){if(r.originalMessage.includes("Invalid header")||r.originalMessage.includes('Expected "header"')||r.originalMessage.includes("invalid argument"))throw r;de(r)}var lr,Ul,zl,Hl,Wl,ql,Kl,Gl,Vl,Xl;class Og extends Fg{constructor(e,n,i,s,o,c){super();L(this,"id");m(this,lr);m(this,Ul);m(this,zl);m(this,Hl);m(this,Wl);m(this,ql,!1);m(this,Kl);m(this,Gl,{});m(this,Vl);m(this,Xl);_(this,lr,e),this.id=o.requestId,_(this,Ul,o.requestId===o.loaderId&&o.type==="Document"),this._interceptionId=i,_(this,zl,o.request.url),_(this,Hl,(o.type||"other").toLowerCase()),_(this,Wl,o.request.method),_(this,Kl,o.request.postData),_(this,ql,o.request.hasPostData??!1),_(this,Vl,n),this._redirectChain=c,_(this,Xl,o.initiator),this.interception.enabled=s;for(const[l,d]of Object.entries(o.request.headers))a(this,Gl)[l.toLowerCase()]=d}get client(){return a(this,lr)}url(){return a(this,zl)}resourceType(){return a(this,Hl)}method(){return a(this,Wl)}postData(){return a(this,Kl)}hasPostData(){return a(this,ql)}async fetchPostData(){try{return(await a(this,lr).send("Network.getRequestPostData",{requestId:this.id})).postData}catch(e){de(e);return}}headers(){return a(this,Gl)}response(){return this._response}frame(){return a(this,Vl)}isNavigationRequest(){return a(this,Ul)}initiator(){return a(this,Xl)}redirectChain(){return this._redirectChain.slice()}failure(){return this._failureText?{errorText:this._failureText}:null}async _continue(e={}){const{url:n,method:i,postData:s,headers:o}=e;this.interception.handled=!0;const c=s?btoa(s):void 0;if(this._interceptionId===void 0)throw new Error("HTTPRequest is missing _interceptionId needed for Fetch.continueRequest");await a(this,lr).send("Fetch.continueRequest",{requestId:this._interceptionId,url:n,method:i,postData:c,headers:o?Dg(o):void 0}).catch(l=>(this.interception.handled=!1,uf(l)))}async _respond(e){this.interception.handled=!0;let n;e.body&&(n=Fg.getResponse(e.body));const i={};if(e.headers)for(const o of Object.keys(e.headers)){const c=e.headers[o];i[o.toLowerCase()]=Array.isArray(c)?c.map(l=>String(l)):String(c)}e.contentType&&(i["content-type"]=e.contentType),n!=null&&n.contentLength&&!("content-length"in i)&&(i["content-length"]=String(n.contentLength));const s=e.status||200;if(this._interceptionId===void 0)throw new Error("HTTPRequest is missing _interceptionId needed for Fetch.fulfillRequest");await a(this,lr).send("Fetch.fulfillRequest",{requestId:this._interceptionId,responseCode:s,responsePhrase:yS[s],responseHeaders:Dg(i),body:n==null?void 0:n.base64}).catch(o=>(this.interception.handled=!1,uf(o)))}async _abort(e){if(this.interception.handled=!0,this._interceptionId===void 0)throw new Error("HTTPRequest is missing _interceptionId needed for Fetch.failRequest");await a(this,lr).send("Fetch.failRequest",{requestId:this._interceptionId,errorReason:e||"Failed"}).catch(uf)}}lr=new WeakMap,Ul=new WeakMap,zl=new WeakMap,Hl=new WeakMap,Wl=new WeakMap,ql=new WeakMap,Kl=new WeakMap,Gl=new WeakMap,Vl=new WeakMap,Xl=new WeakMap;/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class bS{constructor(){}ok(){const t=this.status();return t===0||t>=200&&t<=299}async text(){return(await this.buffer()).toString("utf8")}async json(){const t=await this.text();return JSON.parse(t)}}/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Jl,Ql,Yl,Zl,ed,td;class wS{constructor(t){m(this,Jl);m(this,Ql);m(this,Yl);m(this,Zl);m(this,ed);m(this,td);_(this,Jl,t.subjectName),_(this,Ql,t.issuer),_(this,Yl,t.validFrom),_(this,Zl,t.validTo),_(this,ed,t.protocol),_(this,td,t.sanList)}issuer(){return a(this,Ql)}validFrom(){return a(this,Yl)}validTo(){return a(this,Zl)}protocol(){return a(this,ed)}subjectName(){return a(this,Jl)}subjectAlternativeNames(){return a(this,td)}}Jl=new WeakMap,Ql=new WeakMap,Yl=new WeakMap,Zl=new WeakMap,ed=new WeakMap,td=new WeakMap;/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var nd,Qr,mo,go,rd,id,sd,ad,od,cd,ld,dd,ud,Ch,M_;class Lg extends bS{constructor(e,n,i,s){super();m(this,Ch);m(this,nd);m(this,Qr);m(this,mo,null);m(this,go,Ae.create());m(this,rd);m(this,id);m(this,sd);m(this,ad);m(this,od);m(this,cd);m(this,ld,{});m(this,dd);m(this,ud);_(this,nd,e),_(this,Qr,n),_(this,rd,{ip:i.remoteIPAddress,port:i.remotePort}),_(this,sd,I(this,Ch,M_).call(this,s)||i.statusText),_(this,ad,n.url()),_(this,od,!!i.fromDiskCache),_(this,cd,!!i.fromServiceWorker),_(this,id,s?s.statusCode:i.status);const o=s?s.headers:i.headers;for(const[c,l]of Object.entries(o))a(this,ld)[c.toLowerCase()]=l;_(this,dd,i.securityDetails?new wS(i.securityDetails):null),_(this,ud,i.timing||null)}_resolveBody(e){return e?a(this,go).reject(e):a(this,go).resolve()}remoteAddress(){return a(this,rd)}url(){return a(this,ad)}status(){return a(this,id)}statusText(){return a(this,sd)}headers(){return a(this,ld)}securityDetails(){return a(this,dd)}timing(){return a(this,ud)}buffer(){return a(this,mo)||_(this,mo,a(this,go).valueOrThrow().then(async()=>{try{const e=await a(this,nd).send("Network.getResponseBody",{requestId:a(this,Qr).id});return Buffer.from(e.body,e.base64Encoded?"base64":"utf8")}catch(e){throw e instanceof Mc&&e.originalMessage==="No resource with given identifier found"?new Mc("Could not load body for this request. This might happen if the request is a preflight request."):e}})),a(this,mo)}request(){return a(this,Qr)}fromCache(){return a(this,od)||a(this,Qr)._fromMemoryCache}fromServiceWorker(){return a(this,cd)}frame(){return a(this,Qr).frame()}}nd=new WeakMap,Qr=new WeakMap,mo=new WeakMap,go=new WeakMap,rd=new WeakMap,id=new WeakMap,sd=new WeakMap,ad=new WeakMap,od=new WeakMap,cd=new WeakMap,ld=new WeakMap,dd=new WeakMap,ud=new WeakMap,Ch=new WeakSet,M_=function(e){if(!e||!e.headersText)return;const n=e.headersText.split("\r",1)[0];if(!n)return;const i=n.match(/[^ ]* [^ ]* (.*)/);if(!i)return;const s=i[1];if(s)return s};/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var bs,ws,vs,xs,Ss,ks;class vS{constructor(){m(this,bs,new Map);m(this,ws,new Map);m(this,vs,new Map);m(this,xs,new Map);m(this,Ss,new Map);m(this,ks,new Map)}forget(t){a(this,bs).delete(t),a(this,ws).delete(t),a(this,ks).delete(t),a(this,Ss).delete(t),a(this,xs).delete(t)}responseExtraInfo(t){return a(this,xs).has(t)||a(this,xs).set(t,[]),a(this,xs).get(t)}queuedRedirectInfo(t){return a(this,Ss).has(t)||a(this,Ss).set(t,[]),a(this,Ss).get(t)}queueRedirectInfo(t,e){this.queuedRedirectInfo(t).push(e)}takeQueuedRedirectInfo(t){return this.queuedRedirectInfo(t).shift()}inFlightRequestsCount(){let t=0;for(const e of a(this,vs).values())e.response()||t++;return t}storeRequestWillBeSent(t,e){a(this,bs).set(t,e)}getRequestWillBeSent(t){return a(this,bs).get(t)}forgetRequestWillBeSent(t){a(this,bs).delete(t)}getRequestPaused(t){return a(this,ws).get(t)}forgetRequestPaused(t){a(this,ws).delete(t)}storeRequestPaused(t,e){a(this,ws).set(t,e)}getRequest(t){return a(this,vs).get(t)}storeRequest(t,e){a(this,vs).set(t,e)}forgetRequest(t){a(this,vs).delete(t)}getQueuedEventGroup(t){return a(this,ks).get(t)}queueEventGroup(t,e){a(this,ks).set(t,e)}forgetQueuedEventGroup(t){a(this,ks).delete(t)}}bs=new WeakMap,ws=new WeakMap,vs=new WeakMap,xs=new WeakMap,Ss=new WeakMap,ks=new WeakMap;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var yo,Ce,Cs,Yr,_o,jn,dr,Zr,wt,bo,hd,Eh,ei,Y,A_,lp,Nr,Iu,dp,Nu,oc,T_,P_,$_,up,R_,cc,F_,D_,hp,O_,L_,Mu,j_,fp,B_,pp;class xS extends He{constructor(e){super();m(this,Y);m(this,yo);m(this,Ce,new vS);m(this,Cs);m(this,Yr,null);m(this,_o,new Set);m(this,jn,!1);m(this,dr,!1);m(this,Zr);m(this,wt);m(this,bo);m(this,hd);m(this,Eh,[["Fetch.requestPaused",I(this,Y,$_)],["Fetch.authRequired",I(this,Y,P_)],["Network.requestWillBeSent",I(this,Y,T_)],["Network.requestServedFromCache",I(this,Y,F_)],["Network.responseReceived",I(this,Y,O_)],["Network.loadingFinished",I(this,Y,j_)],["Network.loadingFailed",I(this,Y,B_)],["Network.responseReceivedExtraInfo",I(this,Y,L_)],[$e.Disconnected,I(this,Y,A_)]]);m(this,ei,new Map);_(this,yo,e)}async addClient(e){if(a(this,ei).has(e))return;const n=new _r;a(this,ei).set(e,n);const i=n.use(new He(e));for(const[s,o]of a(this,Eh))i.on(s,c=>o.bind(this)(e,c));await Promise.all([e.send("Network.enable"),I(this,Y,lp).call(this,e),I(this,Y,Iu).call(this,e),I(this,Y,oc).call(this,e),I(this,Y,Nu).call(this,e),I(this,Y,dp).call(this,e)])}async authenticate(e){_(this,Yr,e);const n=a(this,jn)||!!a(this,Yr);n!==a(this,dr)&&(_(this,dr,n),await I(this,Y,Nr).call(this,I(this,Y,Nu).bind(this)))}async setExtraHTTPHeaders(e){const n={};for(const[i,s]of Object.entries(e))X(Ws(s),`Expected value of header "${i}" to be String, but "${typeof s}" is found.`),n[i.toLowerCase()]=s;_(this,Cs,n),await I(this,Y,Nr).call(this,I(this,Y,lp).bind(this))}extraHTTPHeaders(){return Object.assign({},a(this,Cs))}inFlightRequestsCount(){return a(this,Ce).inFlightRequestsCount()}async setOfflineMode(e){a(this,wt)||_(this,wt,{offline:!1,upload:-1,download:-1,latency:0}),a(this,wt).offline=e,await I(this,Y,Nr).call(this,I(this,Y,Iu).bind(this))}async emulateNetworkConditions(e){a(this,wt)||_(this,wt,{offline:!1,upload:-1,download:-1,latency:0}),a(this,wt).upload=e?e.upload:-1,a(this,wt).download=e?e.download:-1,a(this,wt).latency=e?e.latency:0,await I(this,Y,Nr).call(this,I(this,Y,Iu).bind(this))}async setUserAgent(e,n){_(this,bo,e),_(this,hd,n),await I(this,Y,Nr).call(this,I(this,Y,dp).bind(this))}async setCacheEnabled(e){_(this,Zr,!e),await I(this,Y,Nr).call(this,I(this,Y,oc).bind(this))}async setRequestInterception(e){_(this,jn,e);const n=a(this,jn)||!!a(this,Yr);n!==a(this,dr)&&(_(this,dr,n),await I(this,Y,Nr).call(this,I(this,Y,Nu).bind(this)))}}yo=new WeakMap,Ce=new WeakMap,Cs=new WeakMap,Yr=new WeakMap,_o=new WeakMap,jn=new WeakMap,dr=new WeakMap,Zr=new WeakMap,wt=new WeakMap,bo=new WeakMap,hd=new WeakMap,Eh=new WeakMap,ei=new WeakMap,Y=new WeakSet,A_=async function(e){var n;(n=a(this,ei).get(e))==null||n.dispose(),a(this,ei).delete(e)},lp=async function(e){a(this,Cs)!==void 0&&await e.send("Network.setExtraHTTPHeaders",{headers:a(this,Cs)})},Nr=async function(e){await Promise.all(Array.from(a(this,ei).keys()).map(n=>e(n)))},Iu=async function(e){a(this,wt)!==void 0&&await e.send("Network.emulateNetworkConditions",{offline:a(this,wt).offline,latency:a(this,wt).latency,uploadThroughput:a(this,wt).upload,downloadThroughput:a(this,wt).download})},dp=async function(e){a(this,bo)!==void 0&&await e.send("Network.setUserAgentOverride",{userAgent:a(this,bo),userAgentMetadata:a(this,hd)})},Nu=async function(e){a(this,Zr)===void 0&&_(this,Zr,!1),a(this,dr)?await Promise.all([I(this,Y,oc).call(this,e),e.send("Fetch.enable",{handleAuthRequests:!0,patterns:[{urlPattern:"*"}]})]):await Promise.all([I(this,Y,oc).call(this,e),e.send("Fetch.disable")])},oc=async function(e){a(this,Zr)!==void 0&&await e.send("Network.setCacheDisabled",{cacheDisabled:a(this,Zr)})},T_=function(e,n){if(a(this,jn)&&!n.request.url.startsWith("data:")){const{requestId:i}=n;a(this,Ce).storeRequestWillBeSent(i,n);const s=a(this,Ce).getRequestPaused(i);if(s){const{requestId:o}=s;I(this,Y,up).call(this,n,s),I(this,Y,cc).call(this,e,n,o),a(this,Ce).forgetRequestPaused(i)}return}I(this,Y,cc).call(this,e,n,void 0)},P_=function(e,n){let i="Default";a(this,_o).has(n.requestId)?i="CancelAuth":a(this,Yr)&&(i="ProvideCredentials",a(this,_o).add(n.requestId));const{username:s,password:o}=a(this,Yr)||{username:void 0,password:void 0};e.send("Fetch.continueWithAuth",{requestId:n.requestId,authChallengeResponse:{response:i,username:s,password:o}}).catch(de)},$_=function(e,n){!a(this,jn)&&a(this,dr)&&e.send("Fetch.continueRequest",{requestId:n.requestId}).catch(de);const{networkId:i,requestId:s}=n;if(!i){I(this,Y,R_).call(this,e,n);return}const o=(()=>{const c=a(this,Ce).getRequestWillBeSent(i);if(c&&(c.request.url!==n.request.url||c.request.method!==n.request.method)){a(this,Ce).forgetRequestWillBeSent(i);return}return c})();o?(I(this,Y,up).call(this,o,n),I(this,Y,cc).call(this,e,o,s)):a(this,Ce).storeRequestPaused(i,n)},up=function(e,n){e.request.headers={...e.request.headers,...n.request.headers}},R_=function(e,n){const i=n.frameId?a(this,yo).frame(n.frameId):null,s=new Og(e,i,n.requestId,a(this,jn),n,[]);this.emit(st.Request,s),s.finalizeInterceptions()},cc=function(e,n,i){let s=[];if(n.redirectResponse){let l=null;if(n.redirectHasExtraInfo&&(l=a(this,Ce).responseExtraInfo(n.requestId).shift(),!l)){a(this,Ce).queueRedirectInfo(n.requestId,{event:n,fetchRequestId:i});return}const d=a(this,Ce).getRequest(n.requestId);d&&(I(this,Y,D_).call(this,e,d,n.redirectResponse,l),s=d._redirectChain)}const o=n.frameId?a(this,yo).frame(n.frameId):null,c=new Og(e,o,i,a(this,jn),n,s);a(this,Ce).storeRequest(n.requestId,c),this.emit(st.Request,c),c.finalizeInterceptions()},F_=function(e,n){const i=a(this,Ce).getRequest(n.requestId);i&&(i._fromMemoryCache=!0),this.emit(st.RequestServedFromCache,i)},D_=function(e,n,i,s){const o=new Lg(e,n,i,s);n._response=o,n._redirectChain.push(n),o._resolveBody(new Error("Response body is unavailable for redirect responses")),I(this,Y,Mu).call(this,n,!1),this.emit(st.Response,o),this.emit(st.RequestFinished,n)},hp=function(e,n,i){const s=a(this,Ce).getRequest(n.requestId);if(!s)return;a(this,Ce).responseExtraInfo(n.requestId).length&&de(new Error("Unexpected extraInfo events for request "+n.requestId)),n.response.fromDiskCache&&(i=null);const c=new Lg(e,s,n.response,i);s._response=c,this.emit(st.Response,c)},O_=function(e,n){const i=a(this,Ce).getRequest(n.requestId);let s=null;if(i&&!i._fromMemoryCache&&n.hasExtraInfo&&(s=a(this,Ce).responseExtraInfo(n.requestId).shift(),!s)){a(this,Ce).queueEventGroup(n.requestId,{responseReceivedEvent:n});return}I(this,Y,hp).call(this,e,n,s)},L_=function(e,n){const i=a(this,Ce).takeQueuedRedirectInfo(n.requestId);if(i){a(this,Ce).responseExtraInfo(n.requestId).push(n),I(this,Y,cc).call(this,e,i.event,i.fetchRequestId);return}const s=a(this,Ce).getQueuedEventGroup(n.requestId);if(s){a(this,Ce).forgetQueuedEventGroup(n.requestId),I(this,Y,hp).call(this,e,s.responseReceivedEvent,n),s.loadingFinishedEvent&&I(this,Y,fp).call(this,s.loadingFinishedEvent),s.loadingFailedEvent&&I(this,Y,pp).call(this,s.loadingFailedEvent);return}a(this,Ce).responseExtraInfo(n.requestId).push(n)},Mu=function(e,n){const i=e.id,s=e._interceptionId;a(this,Ce).forgetRequest(i),s!==void 0&&a(this,_o).delete(s),n&&a(this,Ce).forget(i)},j_=function(e,n){const i=a(this,Ce).getQueuedEventGroup(n.requestId);i?i.loadingFinishedEvent=n:I(this,Y,fp).call(this,n)},fp=function(e){var i;const n=a(this,Ce).getRequest(e.requestId);n&&(n.response()&&((i=n.response())==null||i._resolveBody()),I(this,Y,Mu).call(this,n,!0),this.emit(st.RequestFinished,n))},B_=function(e,n){const i=a(this,Ce).getQueuedEventGroup(n.requestId);i?i.loadingFailedEvent=n:I(this,Y,pp).call(this,n)},pp=function(e){const n=a(this,Ce).getRequest(e.requestId);if(!n)return;n._failureText=e.errorText;const i=n.response();i&&i._resolveBody(),I(this,Y,Mu).call(this,n,!0),this.emit(st.RequestFailed,n)};/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const SS=100;var fd,ti,wo,pd,en,Es,vo,Is,md,It,be,mp,U_,z_,H_,gp,yp,_p,W_,q_,K_,G_,ia;class kS extends He{constructor(e,n,i){super();m(this,be);m(this,fd);m(this,ti);m(this,wo);m(this,pd,new Set);m(this,en);m(this,Es,new Map);m(this,vo,new Set);L(this,"_frameTree",new gS);m(this,Is,new Set);m(this,md,new WeakMap);m(this,It);_(this,en,e),_(this,fd,n),_(this,ti,new xS(this)),_(this,wo,i),this.setupEventListeners(a(this,en)),e.once($e.Disconnected,()=>{I(this,be,mp).call(this).catch(de)})}get timeoutSettings(){return a(this,wo)}get networkManager(){return a(this,ti)}get client(){return a(this,en)}async swapFrameTree(e){_(this,en,e),X(a(this,en)instanceof pa,"CDPSession is not an instance of CDPSessionImpl.");const n=this._frameTree.getMainFrame();n&&(a(this,Is).add(a(this,en)._target()._targetId),this._frameTree.removeFrame(n),n.updateId(a(this,en)._target()._targetId),this._frameTree.addFrame(n),n.updateClient(e)),this.setupEventListeners(e),e.once($e.Disconnected,()=>{I(this,be,mp).call(this).catch(de)}),await this.initialize(e,n),await a(this,ti).addClient(e),n&&n.emit(ft.FrameSwappedByActivation,void 0)}async registerSpeculativeSession(e){await a(this,ti).addClient(e)}setupEventListeners(e){e.on("Page.frameAttached",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,yp).call(this,e,n.frameId,n.parentFrameId)}),e.on("Page.frameNavigated",async n=>{var i;a(this,Is).add(n.frame.id),await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,_p).call(this,n.frame,n.type)}),e.on("Page.navigatedWithinDocument",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,q_).call(this,n.frameId,n.url)}),e.on("Page.frameDetached",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,K_).call(this,n.frameId,n.reason)}),e.on("Page.frameStartedLoading",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,z_).call(this,n.frameId)}),e.on("Page.frameStoppedLoading",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,H_).call(this,n.frameId)}),e.on("Runtime.executionContextCreated",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,G_).call(this,n.context,e)}),e.on("Page.lifecycleEvent",async n=>{var i;await((i=a(this,It))==null?void 0:i.valueOrThrow()),I(this,be,U_).call(this,n)})}async initialize(e,n){var i,s;try{(i=a(this,It))==null||i.resolve(),_(this,It,Ae.create()),await Promise.all([a(this,ti).addClient(e),e.send("Page.enable"),e.send("Page.getFrameTree").then(({frameTree:o})=>{var c;I(this,be,gp).call(this,e,o),(c=a(this,It))==null||c.resolve()}),e.send("Page.setLifecycleEventsEnabled",{enabled:!0}),e.send("Runtime.enable").then(()=>I(this,be,W_).call(this,e,kg)),...(n?Array.from(a(this,Es).values()):[]).map(o=>n==null?void 0:n.addPreloadScript(o)),...(n?Array.from(a(this,vo).values()):[]).map(o=>n==null?void 0:n.addExposedFunctionBinding(o))])}catch(o){if((s=a(this,It))==null||s.resolve(),Kn(o)&&Ff(o))return;throw o}}page(){return a(this,fd)}mainFrame(){const e=this._frameTree.getMainFrame();return X(e,"Requesting main frame too early!"),e}frames(){return Array.from(this._frameTree.frames())}frame(e){return this._frameTree.getById(e)||null}async addExposedFunctionBinding(e){a(this,vo).add(e),await Promise.all(this.frames().map(async n=>await n.addExposedFunctionBinding(e)))}async removeExposedFunctionBinding(e){a(this,vo).delete(e),await Promise.all(this.frames().map(async n=>await n.removeExposedFunctionBinding(e)))}async evaluateOnNewDocument(e){const{identifier:n}=await this.mainFrame()._client().send("Page.addScriptToEvaluateOnNewDocument",{source:e}),i=new Xx(this.mainFrame(),n,e);return a(this,Es).set(n,i),await Promise.all(this.frames().map(async s=>await s.addPreloadScript(i))),{identifier:n}}async removeScriptToEvaluateOnNewDocument(e){const n=a(this,Es).get(e);if(!n)throw new Error(`Script to evaluate on new document with id ${e} not found`);a(this,Es).delete(e),await Promise.all(this.frames().map(i=>{const s=n.getIdForFrame(i);if(s)return i._client().send("Page.removeScriptToEvaluateOnNewDocument",{identifier:s}).catch(de)}))}onAttachedToTarget(e){if(e._getTargetInfo().type!=="iframe")return;const n=this.frame(e._getTargetInfo().targetId);n&&n.updateClient(e._session()),this.setupEventListeners(e._session()),this.initialize(e._session(),n)}_deviceRequestPromptManager(e){let n=a(this,md).get(e);return n===void 0&&(n=new Yx(e,a(this,wo)),a(this,md).set(e,n)),n}}fd=new WeakMap,ti=new WeakMap,wo=new WeakMap,pd=new WeakMap,en=new WeakMap,Es=new WeakMap,vo=new WeakMap,Is=new WeakMap,md=new WeakMap,It=new WeakMap,be=new WeakSet,mp=async function(){const e=this._frameTree.getMainFrame();if(!e)return;for(const i of e.childFrames())I(this,be,ia).call(this,i);const n=Ae.create({timeout:SS,message:"Frame was not swapped"});e.once(ft.FrameSwappedByActivation,()=>{n.resolve()});try{await n.valueOrThrow()}catch{I(this,be,ia).call(this,e)}},U_=function(e){const n=this.frame(e.frameId);n&&(n._onLifecycleEvent(e.loaderId,e.name),this.emit(at.LifecycleEvent,n),n.emit(ft.LifecycleEvent,void 0))},z_=function(e){const n=this.frame(e);n&&n._onLoadingStarted()},H_=function(e){const n=this.frame(e);n&&(n._onLoadingStopped(),this.emit(at.LifecycleEvent,n),n.emit(ft.LifecycleEvent,void 0))},gp=function(e,n){if(n.frame.parentId&&I(this,be,yp).call(this,e,n.frame.id,n.frame.parentId),a(this,Is).has(n.frame.id)?a(this,Is).delete(n.frame.id):I(this,be,_p).call(this,n.frame,"Navigation"),!!n.childFrames)for(const i of n.childFrames)I(this,be,gp).call(this,e,i)},yp=function(e,n,i){let s=this.frame(n);if(s){e&&s.isOOPFrame()&&s.updateClient(e);return}s=new Rg(this,n,i,e),this._frameTree.addFrame(s),this.emit(at.FrameAttached,s)},_p=async function(e,n){const i=e.id,s=!e.parentId;let o=this._frameTree.getById(i);if(o)for(const c of o.childFrames())I(this,be,ia).call(this,c);s&&(o?(this._frameTree.removeFrame(o),o._id=i):o=new Rg(this,i,void 0,a(this,en)),this._frameTree.addFrame(o)),o=await this._frameTree.waitForFrame(i),o._navigated(e),this.emit(at.FrameNavigated,o),o.emit(ft.FrameNavigated,n)},W_=async function(e,n){const i=`${e.id()}:${n}`;a(this,pd).has(i)||(await e.send("Page.addScriptToEvaluateOnNewDocument",{source:`//# sourceURL=${yr.INTERNAL_URL}`,worldName:n}),await Promise.all(this.frames().filter(s=>s.client===e).map(s=>e.send("Page.createIsolatedWorld",{frameId:s._id,worldName:n,grantUniveralAccess:!0}).catch(de))),a(this,pd).add(i))},q_=function(e,n){const i=this.frame(e);i&&(i._navigatedWithinDocument(n),this.emit(at.FrameNavigatedWithinDocument,i),i.emit(ft.FrameNavigatedWithinDocument,void 0),this.emit(at.FrameNavigated,i),i.emit(ft.FrameNavigated,"Navigation"))},K_=function(e,n){const i=this.frame(e);if(i)switch(n){case"remove":I(this,be,ia).call(this,i);break;case"swap":this.emit(at.FrameSwapped,i),i.emit(ft.FrameSwapped,void 0);break}},G_=function(e,n){const i=e.auxData,s=i&&i.frameId,o=typeof s=="string"?this.frame(s):void 0;let c;if(o){if(o.client!==n)return;e.auxData&&e.auxData.isDefault?c=o.worlds[Pn]:e.name===kg&&(c=o.worlds[Cu])}if(!c)return;const l=new u_((o==null?void 0:o.client)||a(this,en),e,c);c.setContext(l)},ia=function(e){for(const n of e.childFrames())I(this,be,ia).call(this,n);e[Te](),this._frameTree.removeFrame(e),this.emit(at.FrameDetached,e),e.emit(ft.FrameDetached,e)};/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class CS{constructor(){}}const pt=Object.freeze({Left:"left",Right:"right",Middle:"middle",Back:"back",Forward:"forward"});class ES{constructor(){}}class IS{constructor(){}async tap(t,e){await this.touchStart(t,e),await this.touchEnd()}}/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const jg={0:{keyCode:48,key:"0",code:"Digit0"},1:{keyCode:49,key:"1",code:"Digit1"},2:{keyCode:50,key:"2",code:"Digit2"},3:{keyCode:51,key:"3",code:"Digit3"},4:{keyCode:52,key:"4",code:"Digit4"},5:{keyCode:53,key:"5",code:"Digit5"},6:{keyCode:54,key:"6",code:"Digit6"},7:{keyCode:55,key:"7",code:"Digit7"},8:{keyCode:56,key:"8",code:"Digit8"},9:{keyCode:57,key:"9",code:"Digit9"},Power:{key:"Power",code:"Power"},Eject:{key:"Eject",code:"Eject"},Abort:{keyCode:3,code:"Abort",key:"Cancel"},Help:{keyCode:6,code:"Help",key:"Help"},Backspace:{keyCode:8,code:"Backspace",key:"Backspace"},Tab:{keyCode:9,code:"Tab",key:"Tab"},Numpad5:{keyCode:12,shiftKeyCode:101,key:"Clear",code:"Numpad5",shiftKey:"5",location:3},NumpadEnter:{keyCode:13,code:"NumpadEnter",key:"Enter",text:"\r",location:3},Enter:{keyCode:13,code:"Enter",key:"Enter",text:"\r"},"\r":{keyCode:13,code:"Enter",key:"Enter",text:"\r"},"\n":{keyCode:13,code:"Enter",key:"Enter",text:"\r"},ShiftLeft:{keyCode:16,code:"ShiftLeft",key:"Shift",location:1},ShiftRight:{keyCode:16,code:"ShiftRight",key:"Shift",location:2},ControlLeft:{keyCode:17,code:"ControlLeft",key:"Control",location:1},ControlRight:{keyCode:17,code:"ControlRight",key:"Control",location:2},AltLeft:{keyCode:18,code:"AltLeft",key:"Alt",location:1},AltRight:{keyCode:18,code:"AltRight",key:"Alt",location:2},Pause:{keyCode:19,code:"Pause",key:"Pause"},CapsLock:{keyCode:20,code:"CapsLock",key:"CapsLock"},Escape:{keyCode:27,code:"Escape",key:"Escape"},Convert:{keyCode:28,code:"Convert",key:"Convert"},NonConvert:{keyCode:29,code:"NonConvert",key:"NonConvert"},Space:{keyCode:32,code:"Space",key:" "},Numpad9:{keyCode:33,shiftKeyCode:105,key:"PageUp",code:"Numpad9",shiftKey:"9",location:3},PageUp:{keyCode:33,code:"PageUp",key:"PageUp"},Numpad3:{keyCode:34,shiftKeyCode:99,key:"PageDown",code:"Numpad3",shiftKey:"3",location:3},PageDown:{keyCode:34,code:"PageDown",key:"PageDown"},End:{keyCode:35,code:"End",key:"End"},Numpad1:{keyCode:35,shiftKeyCode:97,key:"End",code:"Numpad1",shiftKey:"1",location:3},Home:{keyCode:36,code:"Home",key:"Home"},Numpad7:{keyCode:36,shiftKeyCode:103,key:"Home",code:"Numpad7",shiftKey:"7",location:3},ArrowLeft:{keyCode:37,code:"ArrowLeft",key:"ArrowLeft"},Numpad4:{keyCode:37,shiftKeyCode:100,key:"ArrowLeft",code:"Numpad4",shiftKey:"4",location:3},Numpad8:{keyCode:38,shiftKeyCode:104,key:"ArrowUp",code:"Numpad8",shiftKey:"8",location:3},ArrowUp:{keyCode:38,code:"ArrowUp",key:"ArrowUp"},ArrowRight:{keyCode:39,code:"ArrowRight",key:"ArrowRight"},Numpad6:{keyCode:39,shiftKeyCode:102,key:"ArrowRight",code:"Numpad6",shiftKey:"6",location:3},Numpad2:{keyCode:40,shiftKeyCode:98,key:"ArrowDown",code:"Numpad2",shiftKey:"2",location:3},ArrowDown:{keyCode:40,code:"ArrowDown",key:"ArrowDown"},Select:{keyCode:41,code:"Select",key:"Select"},Open:{keyCode:43,code:"Open",key:"Execute"},PrintScreen:{keyCode:44,code:"PrintScreen",key:"PrintScreen"},Insert:{keyCode:45,code:"Insert",key:"Insert"},Numpad0:{keyCode:45,shiftKeyCode:96,key:"Insert",code:"Numpad0",shiftKey:"0",location:3},Delete:{keyCode:46,code:"Delete",key:"Delete"},NumpadDecimal:{keyCode:46,shiftKeyCode:110,code:"NumpadDecimal",key:"\0",shiftKey:".",location:3},Digit0:{keyCode:48,code:"Digit0",shiftKey:")",key:"0"},Digit1:{keyCode:49,code:"Digit1",shiftKey:"!",key:"1"},Digit2:{keyCode:50,code:"Digit2",shiftKey:"@",key:"2"},Digit3:{keyCode:51,code:"Digit3",shiftKey:"#",key:"3"},Digit4:{keyCode:52,code:"Digit4",shiftKey:"$",key:"4"},Digit5:{keyCode:53,code:"Digit5",shiftKey:"%",key:"5"},Digit6:{keyCode:54,code:"Digit6",shiftKey:"^",key:"6"},Digit7:{keyCode:55,code:"Digit7",shiftKey:"&",key:"7"},Digit8:{keyCode:56,code:"Digit8",shiftKey:"*",key:"8"},Digit9:{keyCode:57,code:"Digit9",shiftKey:"(",key:"9"},KeyA:{keyCode:65,code:"KeyA",shiftKey:"A",key:"a"},KeyB:{keyCode:66,code:"KeyB",shiftKey:"B",key:"b"},KeyC:{keyCode:67,code:"KeyC",shiftKey:"C",key:"c"},KeyD:{keyCode:68,code:"KeyD",shiftKey:"D",key:"d"},KeyE:{keyCode:69,code:"KeyE",shiftKey:"E",key:"e"},KeyF:{keyCode:70,code:"KeyF",shiftKey:"F",key:"f"},KeyG:{keyCode:71,code:"KeyG",shiftKey:"G",key:"g"},KeyH:{keyCode:72,code:"KeyH",shiftKey:"H",key:"h"},KeyI:{keyCode:73,code:"KeyI",shiftKey:"I",key:"i"},KeyJ:{keyCode:74,code:"KeyJ",shiftKey:"J",key:"j"},KeyK:{keyCode:75,code:"KeyK",shiftKey:"K",key:"k"},KeyL:{keyCode:76,code:"KeyL",shiftKey:"L",key:"l"},KeyM:{keyCode:77,code:"KeyM",shiftKey:"M",key:"m"},KeyN:{keyCode:78,code:"KeyN",shiftKey:"N",key:"n"},KeyO:{keyCode:79,code:"KeyO",shiftKey:"O",key:"o"},KeyP:{keyCode:80,code:"KeyP",shiftKey:"P",key:"p"},KeyQ:{keyCode:81,code:"KeyQ",shiftKey:"Q",key:"q"},KeyR:{keyCode:82,code:"KeyR",shiftKey:"R",key:"r"},KeyS:{keyCode:83,code:"KeyS",shiftKey:"S",key:"s"},KeyT:{keyCode:84,code:"KeyT",shiftKey:"T",key:"t"},KeyU:{keyCode:85,code:"KeyU",shiftKey:"U",key:"u"},KeyV:{keyCode:86,code:"KeyV",shiftKey:"V",key:"v"},KeyW:{keyCode:87,code:"KeyW",shiftKey:"W",key:"w"},KeyX:{keyCode:88,code:"KeyX",shiftKey:"X",key:"x"},KeyY:{keyCode:89,code:"KeyY",shiftKey:"Y",key:"y"},KeyZ:{keyCode:90,code:"KeyZ",shiftKey:"Z",key:"z"},MetaLeft:{keyCode:91,code:"MetaLeft",key:"Meta",location:1},MetaRight:{keyCode:92,code:"MetaRight",key:"Meta",location:2},ContextMenu:{keyCode:93,code:"ContextMenu",key:"ContextMenu"},NumpadMultiply:{keyCode:106,code:"NumpadMultiply",key:"*",location:3},NumpadAdd:{keyCode:107,code:"NumpadAdd",key:"+",location:3},NumpadSubtract:{keyCode:109,code:"NumpadSubtract",key:"-",location:3},NumpadDivide:{keyCode:111,code:"NumpadDivide",key:"/",location:3},F1:{keyCode:112,code:"F1",key:"F1"},F2:{keyCode:113,code:"F2",key:"F2"},F3:{keyCode:114,code:"F3",key:"F3"},F4:{keyCode:115,code:"F4",key:"F4"},F5:{keyCode:116,code:"F5",key:"F5"},F6:{keyCode:117,code:"F6",key:"F6"},F7:{keyCode:118,code:"F7",key:"F7"},F8:{keyCode:119,code:"F8",key:"F8"},F9:{keyCode:120,code:"F9",key:"F9"},F10:{keyCode:121,code:"F10",key:"F10"},F11:{keyCode:122,code:"F11",key:"F11"},F12:{keyCode:123,code:"F12",key:"F12"},F13:{keyCode:124,code:"F13",key:"F13"},F14:{keyCode:125,code:"F14",key:"F14"},F15:{keyCode:126,code:"F15",key:"F15"},F16:{keyCode:127,code:"F16",key:"F16"},F17:{keyCode:128,code:"F17",key:"F17"},F18:{keyCode:129,code:"F18",key:"F18"},F19:{keyCode:130,code:"F19",key:"F19"},F20:{keyCode:131,code:"F20",key:"F20"},F21:{keyCode:132,code:"F21",key:"F21"},F22:{keyCode:133,code:"F22",key:"F22"},F23:{keyCode:134,code:"F23",key:"F23"},F24:{keyCode:135,code:"F24",key:"F24"},NumLock:{keyCode:144,code:"NumLock",key:"NumLock"},ScrollLock:{keyCode:145,code:"ScrollLock",key:"ScrollLock"},AudioVolumeMute:{keyCode:173,code:"AudioVolumeMute",key:"AudioVolumeMute"},AudioVolumeDown:{keyCode:174,code:"AudioVolumeDown",key:"AudioVolumeDown"},AudioVolumeUp:{keyCode:175,code:"AudioVolumeUp",key:"AudioVolumeUp"},MediaTrackNext:{keyCode:176,code:"MediaTrackNext",key:"MediaTrackNext"},MediaTrackPrevious:{keyCode:177,code:"MediaTrackPrevious",key:"MediaTrackPrevious"},MediaStop:{keyCode:178,code:"MediaStop",key:"MediaStop"},MediaPlayPause:{keyCode:179,code:"MediaPlayPause",key:"MediaPlayPause"},Semicolon:{keyCode:186,code:"Semicolon",shiftKey:":",key:";"},Equal:{keyCode:187,code:"Equal",shiftKey:"+",key:"="},NumpadEqual:{keyCode:187,code:"NumpadEqual",key:"=",location:3},Comma:{keyCode:188,code:"Comma",shiftKey:"<",key:","},Minus:{keyCode:189,code:"Minus",shiftKey:"_",key:"-"},Period:{keyCode:190,code:"Period",shiftKey:">",key:"."},Slash:{keyCode:191,code:"Slash",shiftKey:"?",key:"/"},Backquote:{keyCode:192,code:"Backquote",shiftKey:"~",key:"`"},BracketLeft:{keyCode:219,code:"BracketLeft",shiftKey:"{",key:"["},Backslash:{keyCode:220,code:"Backslash",shiftKey:"|",key:"\\"},BracketRight:{keyCode:221,code:"BracketRight",shiftKey:"}",key:"]"},Quote:{keyCode:222,code:"Quote",shiftKey:'"',key:"'"},AltGraph:{keyCode:225,code:"AltGraph",key:"AltGraph"},Props:{keyCode:247,code:"Props",key:"CrSel"},Cancel:{keyCode:3,key:"Cancel",code:"Abort"},Clear:{keyCode:12,key:"Clear",code:"Numpad5",location:3},Shift:{keyCode:16,key:"Shift",code:"ShiftLeft",location:1},Control:{keyCode:17,key:"Control",code:"ControlLeft",location:1},Alt:{keyCode:18,key:"Alt",code:"AltLeft",location:1},Accept:{keyCode:30,key:"Accept"},ModeChange:{keyCode:31,key:"ModeChange"}," ":{keyCode:32,key:" ",code:"Space"},Print:{keyCode:42,key:"Print"},Execute:{keyCode:43,key:"Execute",code:"Open"},"\0":{keyCode:46,key:"\0",code:"NumpadDecimal",location:3},a:{keyCode:65,key:"a",code:"KeyA"},b:{keyCode:66,key:"b",code:"KeyB"},c:{keyCode:67,key:"c",code:"KeyC"},d:{keyCode:68,key:"d",code:"KeyD"},e:{keyCode:69,key:"e",code:"KeyE"},f:{keyCode:70,key:"f",code:"KeyF"},g:{keyCode:71,key:"g",code:"KeyG"},h:{keyCode:72,key:"h",code:"KeyH"},i:{keyCode:73,key:"i",code:"KeyI"},j:{keyCode:74,key:"j",code:"KeyJ"},k:{keyCode:75,key:"k",code:"KeyK"},l:{keyCode:76,key:"l",code:"KeyL"},m:{keyCode:77,key:"m",code:"KeyM"},n:{keyCode:78,key:"n",code:"KeyN"},o:{keyCode:79,key:"o",code:"KeyO"},p:{keyCode:80,key:"p",code:"KeyP"},q:{keyCode:81,key:"q",code:"KeyQ"},r:{keyCode:82,key:"r",code:"KeyR"},s:{keyCode:83,key:"s",code:"KeyS"},t:{keyCode:84,key:"t",code:"KeyT"},u:{keyCode:85,key:"u",code:"KeyU"},v:{keyCode:86,key:"v",code:"KeyV"},w:{keyCode:87,key:"w",code:"KeyW"},x:{keyCode:88,key:"x",code:"KeyX"},y:{keyCode:89,key:"y",code:"KeyY"},z:{keyCode:90,key:"z",code:"KeyZ"},Meta:{keyCode:91,key:"Meta",code:"MetaLeft",location:1},"*":{keyCode:106,key:"*",code:"NumpadMultiply",location:3},"+":{keyCode:107,key:"+",code:"NumpadAdd",location:3},"-":{keyCode:109,key:"-",code:"NumpadSubtract",location:3},"/":{keyCode:111,key:"/",code:"NumpadDivide",location:3},";":{keyCode:186,key:";",code:"Semicolon"},"=":{keyCode:187,key:"=",code:"Equal"},",":{keyCode:188,key:",",code:"Comma"},".":{keyCode:190,key:".",code:"Period"},"`":{keyCode:192,key:"`",code:"Backquote"},"[":{keyCode:219,key:"[",code:"BracketLeft"},"\\":{keyCode:220,key:"\\",code:"Backslash"},"]":{keyCode:221,key:"]",code:"BracketRight"},"'":{keyCode:222,key:"'",code:"Quote"},Attn:{keyCode:246,key:"Attn"},CrSel:{keyCode:247,key:"CrSel",code:"Props"},ExSel:{keyCode:248,key:"ExSel"},EraseEof:{keyCode:249,key:"EraseEof"},Play:{keyCode:250,key:"Play"},ZoomOut:{keyCode:251,key:"ZoomOut"},")":{keyCode:48,key:")",code:"Digit0"},"!":{keyCode:49,key:"!",code:"Digit1"},"@":{keyCode:50,key:"@",code:"Digit2"},"#":{keyCode:51,key:"#",code:"Digit3"},$:{keyCode:52,key:"$",code:"Digit4"},"%":{keyCode:53,key:"%",code:"Digit5"},"^":{keyCode:54,key:"^",code:"Digit6"},"&":{keyCode:55,key:"&",code:"Digit7"},"(":{keyCode:57,key:"(",code:"Digit9"},A:{keyCode:65,key:"A",code:"KeyA"},B:{keyCode:66,key:"B",code:"KeyB"},C:{keyCode:67,key:"C",code:"KeyC"},D:{keyCode:68,key:"D",code:"KeyD"},E:{keyCode:69,key:"E",code:"KeyE"},F:{keyCode:70,key:"F",code:"KeyF"},G:{keyCode:71,key:"G",code:"KeyG"},H:{keyCode:72,key:"H",code:"KeyH"},I:{keyCode:73,key:"I",code:"KeyI"},J:{keyCode:74,key:"J",code:"KeyJ"},K:{keyCode:75,key:"K",code:"KeyK"},L:{keyCode:76,key:"L",code:"KeyL"},M:{keyCode:77,key:"M",code:"KeyM"},N:{keyCode:78,key:"N",code:"KeyN"},O:{keyCode:79,key:"O",code:"KeyO"},P:{keyCode:80,key:"P",code:"KeyP"},Q:{keyCode:81,key:"Q",code:"KeyQ"},R:{keyCode:82,key:"R",code:"KeyR"},S:{keyCode:83,key:"S",code:"KeyS"},T:{keyCode:84,key:"T",code:"KeyT"},U:{keyCode:85,key:"U",code:"KeyU"},V:{keyCode:86,key:"V",code:"KeyV"},W:{keyCode:87,key:"W",code:"KeyW"},X:{keyCode:88,key:"X",code:"KeyX"},Y:{keyCode:89,key:"Y",code:"KeyY"},Z:{keyCode:90,key:"Z",code:"KeyZ"},":":{keyCode:186,key:":",code:"Semicolon"},"<":{keyCode:188,key:"<",code:"Comma"},_:{keyCode:189,key:"_",code:"Minus"},">":{keyCode:190,key:">",code:"Period"},"?":{keyCode:191,key:"?",code:"Slash"},"~":{keyCode:192,key:"~",code:"Backquote"},"{":{keyCode:219,key:"{",code:"BracketLeft"},"|":{keyCode:220,key:"|",code:"Backslash"},"}":{keyCode:221,key:"}",code:"BracketRight"},'"':{keyCode:222,key:'"',code:"Quote"},SoftLeft:{key:"SoftLeft",code:"SoftLeft",location:4},SoftRight:{key:"SoftRight",code:"SoftRight",location:4},Camera:{keyCode:44,key:"Camera",code:"Camera",location:4},Call:{key:"Call",code:"Call",location:4},EndCall:{keyCode:95,key:"EndCall",code:"EndCall",location:4},VolumeDown:{keyCode:182,key:"VolumeDown",code:"VolumeDown",location:4},VolumeUp:{keyCode:183,key:"VolumeUp",code:"VolumeUp",location:4}};/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var ni,xo,_i,bp,wp;class NS extends CS{constructor(e){super();m(this,_i);m(this,ni);m(this,xo,new Set);L(this,"_modifiers",0);_(this,ni,e)}updateClient(e){_(this,ni,e)}async down(e,n={text:void 0,commands:[]}){const i=I(this,_i,wp).call(this,e),s=a(this,xo).has(i.code);a(this,xo).add(i.code),this._modifiers|=I(this,_i,bp).call(this,i.key);const o=n.text===void 0?i.text:n.text;await a(this,ni).send("Input.dispatchKeyEvent",{type:o?"keyDown":"rawKeyDown",modifiers:this._modifiers,windowsVirtualKeyCode:i.keyCode,code:i.code,key:i.key,text:o,unmodifiedText:o,autoRepeat:s,location:i.location,isKeypad:i.location===3,commands:n.commands})}async up(e){const n=I(this,_i,wp).call(this,e);this._modifiers&=~I(this,_i,bp).call(this,n.key),a(this,xo).delete(n.code),await a(this,ni).send("Input.dispatchKeyEvent",{type:"keyUp",modifiers:this._modifiers,key:n.key,windowsVirtualKeyCode:n.keyCode,code:n.code,location:n.location})}async sendCharacter(e){await a(this,ni).send("Input.insertText",{text:e})}charIsKey(e){return!!jg[e]}async type(e,n={}){const i=n.delay||void 0;for(const s of e)this.charIsKey(s)?await this.press(s,{delay:i}):(i&&await new Promise(o=>setTimeout(o,i)),await this.sendCharacter(s))}async press(e,n={}){const{delay:i=null}=n;await this.down(e,n),i&&await new Promise(s=>setTimeout(s,n.delay)),await this.up(e)}}ni=new WeakMap,xo=new WeakMap,_i=new WeakSet,bp=function(e){return e==="Alt"?1:e==="Control"?2:e==="Meta"?4:e==="Shift"?8:0},wp=function(e){const n=this._modifiers&8,i={key:"",keyCode:0,code:"",text:"",location:0},s=jg[e];return X(s,`Unknown key: "${e}"`),s.key&&(i.key=s.key),n&&s.shiftKey&&(i.key=s.shiftKey),s.keyCode&&(i.keyCode=s.keyCode),n&&s.shiftKeyCode&&(i.keyCode=s.shiftKeyCode),s.code&&(i.code=s.code),s.location&&(i.location=s.location),i.key.length===1&&(i.text=i.key),s.text&&(i.text=s.text),n&&s.shiftText&&(i.text=s.shiftText),this._modifiers&-9&&(i.text=""),i};const Bg=r=>{switch(r){case pt.Left:return 1;case pt.Right:return 2;case pt.Middle:return 4;case pt.Back:return 8;case pt.Forward:return 16}},MS=r=>r&1?pt.Left:r&2?pt.Right:r&4?pt.Middle:r&8?pt.Back:r&16?pt.Forward:"none";var Xt,bn,So,ze,Ut,Ns,V_,Au;class AS extends ES{constructor(e,n){super();m(this,ze);m(this,Xt);m(this,bn);m(this,So,{position:{x:0,y:0},buttons:0});m(this,Ns,[]);_(this,Xt,e),_(this,bn,n)}updateClient(e){_(this,Xt,e)}async reset(){const e=[];for(const[n,i]of[[1,pt.Left],[4,pt.Middle],[2,pt.Right],[16,pt.Forward],[8,pt.Back]])a(this,ze,Ut).buttons&n&&e.push(this.up({button:i}));(a(this,ze,Ut).position.x!==0||a(this,ze,Ut).position.y!==0)&&e.push(this.move(0,0)),await Promise.all(e)}async move(e,n,i={}){const{steps:s=1}=i,o=a(this,ze,Ut).position,c={x:e,y:n};for(let l=1;l<=s;l++)await I(this,ze,Au).call(this,d=>{d({position:{x:o.x+(c.x-o.x)*(l/s),y:o.y+(c.y-o.y)*(l/s)}});const{buttons:u,position:h}=a(this,ze,Ut);return a(this,Xt).send("Input.dispatchMouseEvent",{type:"mouseMoved",modifiers:a(this,bn)._modifiers,buttons:u,button:MS(u),...h})})}async down(e={}){const{button:n=pt.Left,clickCount:i=1}=e,s=Bg(n);if(!s)throw new Error(`Unsupported mouse button: ${n}`);if(a(this,ze,Ut).buttons&s)throw new Error(`'${n}' is already pressed.`);await I(this,ze,Au).call(this,o=>{o({buttons:a(this,ze,Ut).buttons|s});const{buttons:c,position:l}=a(this,ze,Ut);return a(this,Xt).send("Input.dispatchMouseEvent",{type:"mousePressed",modifiers:a(this,bn)._modifiers,clickCount:i,buttons:c,button:n,...l})})}async up(e={}){const{button:n=pt.Left,clickCount:i=1}=e,s=Bg(n);if(!s)throw new Error(`Unsupported mouse button: ${n}`);if(!(a(this,ze,Ut).buttons&s))throw new Error(`'${n}' is not pressed.`);await I(this,ze,Au).call(this,o=>{o({buttons:a(this,ze,Ut).buttons&~s});const{buttons:c,position:l}=a(this,ze,Ut);return a(this,Xt).send("Input.dispatchMouseEvent",{type:"mouseReleased",modifiers:a(this,bn)._modifiers,clickCount:i,buttons:c,button:n,...l})})}async click(e,n,i={}){const{delay:s,count:o=1,clickCount:c=o}=i;if(o<1)throw new Error("Click must occur a positive number of times.");const l=[this.move(e,n)];if(c===o)for(let d=1;d<o;++d)l.push(this.down({...i,clickCount:d}),this.up({...i,clickCount:d}));l.push(this.down({...i,clickCount:c})),typeof s=="number"&&(await Promise.all(l),l.length=0,await new Promise(d=>{setTimeout(d,s)})),l.push(this.up({...i,clickCount:c})),await Promise.all(l)}async wheel(e={}){const{deltaX:n=0,deltaY:i=0}=e,{position:s,buttons:o}=a(this,ze,Ut);await a(this,Xt).send("Input.dispatchMouseEvent",{type:"mouseWheel",pointerType:"mouse",modifiers:a(this,bn)._modifiers,deltaY:i,deltaX:n,buttons:o,...s})}async drag(e,n){const i=new Promise(s=>{a(this,Xt).once("Input.dragIntercepted",o=>s(o.data))});return await this.move(e.x,e.y),await this.down(),await this.move(n.x,n.y),await i}async dragEnter(e,n){await a(this,Xt).send("Input.dispatchDragEvent",{type:"dragEnter",x:e.x,y:e.y,modifiers:a(this,bn)._modifiers,data:n})}async dragOver(e,n){await a(this,Xt).send("Input.dispatchDragEvent",{type:"dragOver",x:e.x,y:e.y,modifiers:a(this,bn)._modifiers,data:n})}async drop(e,n){await a(this,Xt).send("Input.dispatchDragEvent",{type:"drop",x:e.x,y:e.y,modifiers:a(this,bn)._modifiers,data:n})}async dragAndDrop(e,n,i={}){const{delay:s=null}=i,o=await this.drag(e,n);await this.dragEnter(n,o),await this.dragOver(n,o),s&&await new Promise(c=>setTimeout(c,s)),await this.drop(n,o),await this.up()}}Xt=new WeakMap,bn=new WeakMap,So=new WeakMap,ze=new WeakSet,Ut=function(){return Object.assign({...a(this,So)},...a(this,Ns))},Ns=new WeakMap,V_=function(){const e={};a(this,Ns).push(e);const n=()=>{a(this,Ns).splice(a(this,Ns).indexOf(e),1)};return{update:i=>{Object.assign(e,i)},commit:()=>{_(this,So,{...a(this,So),...e}),n()},rollback:n}},Au=async function(e){const{update:n,commit:i,rollback:s}=I(this,ze,V_).call(this);try{await e(n),i()}catch(o){throw s(),o}};var ri,Ms;class TS extends IS{constructor(e,n){super();m(this,ri);m(this,Ms);_(this,ri,e),_(this,Ms,n)}updateClient(e){_(this,ri,e)}async touchStart(e,n){await a(this,ri).send("Input.dispatchTouchEvent",{type:"touchStart",touchPoints:[{x:Math.round(e),y:Math.round(n),radiusX:.5,radiusY:.5,force:.5}],modifiers:a(this,Ms)._modifiers})}async touchMove(e,n){await a(this,ri).send("Input.dispatchTouchEvent",{type:"touchMove",touchPoints:[{x:Math.round(e),y:Math.round(n),radiusX:.5,radiusY:.5,force:.5}],modifiers:a(this,Ms)._modifiers})}async touchEnd(){await a(this,ri).send("Input.dispatchTouchEvent",{type:"touchEnd",touchPoints:[],modifiers:a(this,Ms)._modifiers})}}ri=new WeakMap,Ms=new WeakMap;var ur,ko,gd;class PS{constructor(t){m(this,ur);m(this,ko,!1);m(this,gd);_(this,ur,t)}updateClient(t){_(this,ur,t)}async start(t={}){X(!a(this,ko),"Cannot start recording trace while already recording trace.");const e=["-*","devtools.timeline","v8.execute","disabled-by-default-devtools.timeline","disabled-by-default-devtools.timeline.frame","toplevel","blink.console","blink.user_timing","latencyInfo","disabled-by-default-devtools.timeline.stack","disabled-by-default-v8.cpu_profiler"],{path:n,screenshots:i=!1,categories:s=e}=t;i&&s.push("disabled-by-default-devtools.screenshot");const o=s.filter(l=>l.startsWith("-")).map(l=>l.slice(1)),c=s.filter(l=>!l.startsWith("-"));_(this,gd,n),_(this,ko,!0),await a(this,ur).send("Tracing.start",{transferMode:"ReturnAsStream",traceConfig:{excludedCategories:o,includedCategories:c}})}async stop(){const t=Ae.create();return a(this,ur).once("Tracing.tracingComplete",async e=>{try{X(e.stream,'Missing "stream"');const n=await D0(a(this,ur),e.stream),i=await F0(n,a(this,gd));t.resolve(i??void 0)}catch(n){Kn(n)?t.reject(n):t.reject(new Error(`Unknown error: ${n}`))}}),await a(this,ur).send("Tracing.end"),_(this,ko,!1),await t.valueOrThrow()}}ur=new WeakMap,ko=new WeakMap,gd=new WeakMap;/**
 * @license
 * Copyright 2018 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var yd;class $S extends He{constructor(e){super();L(this,"timeoutSettings",new im);m(this,yd);_(this,yd,e)}url(){return a(this,yd)}async evaluate(e,...n){return e=ot(this.evaluate.name,e),await this.mainRealm().evaluate(e,...n)}async evaluateHandle(e,...n){return e=ot(this.evaluateHandle.name,e),await this.mainRealm().evaluateHandle(e,...n)}async close(){throw new $0("WebWorker.close() is not supported")}}yd=new WeakMap;var Bn,hr,_d,bd;class X_ extends $S{constructor(e,n,i,s,o,c){super(n);m(this,Bn);m(this,hr);m(this,_d);m(this,bd);_(this,_d,i),_(this,hr,e),_(this,bd,s),_(this,Bn,new cp(this,new im)),a(this,hr).once("Runtime.executionContextCreated",async l=>{a(this,Bn).setContext(new u_(e,l.context,a(this,Bn)))}),a(this,Bn).emitter.on("consoleapicalled",async l=>{try{return o(l.type,l.args.map(d=>new Oh(a(this,Bn),d)),l.stackTrace)}catch(d){de(d)}}),a(this,hr).on("Runtime.exceptionThrown",c),a(this,hr).once($e.Disconnected,()=>{a(this,Bn).dispose()}),a(this,hr).send("Runtime.enable").catch(de)}mainRealm(){return a(this,Bn)}get client(){return a(this,hr)}async close(){var e,n;switch(a(this,bd)){case Jt.SERVICE_WORKER:case Jt.SHARED_WORKER:{await((e=this.client.connection())==null?void 0:e.send("Target.closeTarget",{targetId:a(this,_d)})),await((n=this.client.connection())==null?void 0:n.send("Target.detachFromTarget",{sessionId:this.client.id()}));break}default:await this.evaluate(()=>{self.close()})}}}Bn=new WeakMap,hr=new WeakMap,_d=new WeakMap,bd=new WeakMap;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var hf=function(r,t,e){if(t!=null){if(typeof t!="object"&&typeof t!="function")throw new TypeError("Object expected.");var n;if(e){if(!Symbol.asyncDispose)throw new TypeError("Symbol.asyncDispose is not defined.");n=t[Symbol.asyncDispose]}if(n===void 0){if(!Symbol.dispose)throw new TypeError("Symbol.dispose is not defined.");n=t[Symbol.dispose]}if(typeof n!="function")throw new TypeError("Object not disposable.");r.stack.push({value:t,dispose:n,async:e})}else e&&r.stack.push({async:!0});return t},ff=(function(r){return function(t){function e(i){t.error=t.hasError?new r(i,t.error,"An error was suppressed during disposal."):i,t.hasError=!0}function n(){for(;t.stack.length;){var i=t.stack.pop();try{var s=i.dispose&&i.dispose.call(i.value);if(i.async)return Promise.resolve(s).then(n,function(o){return e(o),n()})}catch(o){e(o)}}if(t.hasError)throw t.error}return n()}})(typeof SuppressedError=="function"?SuppressedError:function(r,t,e){var n=new Error(e);return n.name="SuppressedError",n.error=r,n.suppressed=t,n});function pf(r){switch(r){case"warning":return"warn";default:return r}}var wd,ii,xe,wn,si,As,ai,Co,Eo,Me,Ve,Io,oi,No,Mo,Ao,Ts,fr,Ih,vd,xd,Nh,Mh,Ah,pe,J_,Q_,Y_,vp,Sd,To,Z_,eb,tb,nb,rb,xp,Sp,ib,sb,kp,ab,Cp;const Fm=class Fm extends cx{constructor(e,n){super();m(this,pe);m(this,wd,!1);m(this,ii);m(this,xe);m(this,wn);m(this,si);m(this,As);m(this,ai);m(this,Co);m(this,Eo);m(this,Me);m(this,Ve);m(this,Io);m(this,oi,new Map);m(this,No,new Map);m(this,Mo);m(this,Ao);m(this,Ts,new Map);m(this,fr,new Set);m(this,Ih,Ae.create());m(this,vd,!1);m(this,xd,!1);m(this,Nh,[[at.FrameAttached,e=>{this.emit("frameattached",e)}],[at.FrameDetached,e=>{this.emit("framedetached",e)}],[at.FrameNavigated,e=>{this.emit("framenavigated",e)}]]);m(this,Mh,[[st.Request,e=>{this.emit("request",e)}],[st.RequestServedFromCache,e=>{this.emit("requestservedfromcache",e)}],[st.Response,e=>{this.emit("response",e)}],[st.RequestFailed,e=>{this.emit("requestfailed",e)}],[st.RequestFinished,e=>{this.emit("requestfinished",e)}]]);m(this,Ah,[[$e.Disconnected,()=>{a(this,Ih).reject(new mi("Target closed"))}],["Page.domContentEventFired",()=>this.emit("domcontentloaded",void 0)],["Page.loadEventFired",()=>this.emit("load",void 0)],["Page.javascriptDialogOpening",I(this,pe,ab).bind(this)],["Runtime.exceptionThrown",I(this,pe,Sp).bind(this)],["Inspector.targetCrashed",I(this,pe,tb).bind(this)],["Performance.metrics",I(this,pe,rb).bind(this)],["Log.entryAdded",I(this,pe,nb).bind(this)],["Page.fileChooserOpened",I(this,pe,eb).bind(this)]]);m(this,Sd,e=>{var s;const n=(s=e._session())==null?void 0:s.id(),i=a(this,Ts).get(n);i&&(a(this,Ts).delete(n),this.emit("workerdestroyed",i))});m(this,To,e=>{if(X(e instanceof pa),a(this,Me).onAttachedToTarget(e._target()),e._target()._getTargetInfo().type==="worker"){const n=new X_(e,e._target().url(),e._target()._targetId,e._target().type(),I(this,pe,kp).bind(this),I(this,pe,Sp).bind(this));a(this,Ts).set(e.id(),n),this.emit("workercreated",n)}e.on($e.Ready,a(this,To))});_(this,xe,e),_(this,si,e.parentSession()),X(a(this,si),"Tab target session is not defined."),_(this,As,a(this,si)._target()),X(a(this,As),"Tab target is not defined."),_(this,wn,n),_(this,ii,n._targetManager()),_(this,ai,new NS(e)),_(this,Co,new AS(e,a(this,ai))),_(this,Eo,new TS(e,a(this,ai))),_(this,Me,new kS(e,this,this._timeoutSettings)),_(this,Ve,new kx(e)),_(this,Io,new PS(e)),_(this,Mo,new _x(e)),_(this,Ao,null);for(const[i,s]of a(this,Nh))a(this,Me).on(i,s);a(this,Me).on(at.ConsoleApiCalled,([i,s])=>{I(this,pe,ib).call(this,i,s)}),a(this,Me).on(at.BindingCalled,([i,s])=>{I(this,pe,sb).call(this,i,s)});for(const[i,s]of a(this,Mh))a(this,Me).networkManager.on(i,s);a(this,si).on($e.Swapped,I(this,pe,Q_).bind(this)),a(this,si).on($e.Ready,I(this,pe,Y_).bind(this)),a(this,ii).on("targetGone",a(this,Sd)),a(this,As)._isClosedDeferred.valueOrThrow().then(()=>{a(this,ii).off("targetGone",a(this,Sd)),this.emit("close",void 0),_(this,wd,!0)}).catch(de),I(this,pe,vp).call(this),I(this,pe,J_).call(this)}static async _create(e,n,i){var o;const s=new Fm(e,n);if(await I(o=s,pe,Z_).call(o),i)try{await s.setViewport(i)}catch(c){if(Kn(c)&&Ff(c))de(c);else throw c}return s}_client(){return a(this,xe)}isServiceWorkerBypassed(){return a(this,vd)}isDragInterceptionEnabled(){return a(this,xd)}isJavaScriptEnabled(){return a(this,Ve).javascriptEnabled}async waitForFileChooser(e={}){const n=a(this,fr).size===0,{timeout:i=this._timeoutSettings.timeout()}=e,s=Ae.create({message:`Waiting for \`FileChooser\` failed: ${i}ms exceeded`,timeout:i});a(this,fr).add(s);let o;n&&(o=a(this,xe).send("Page.setInterceptFileChooserDialog",{enabled:!0}));try{const[c]=await Promise.all([s.valueOrThrow(),o]);return c}catch(c){throw a(this,fr).delete(s),c}}async setGeolocation(e){return await a(this,Ve).setGeolocation(e)}target(){return a(this,wn)}browser(){return a(this,wn).browser()}browserContext(){return a(this,wn).browserContext()}mainFrame(){return a(this,Me).mainFrame()}get keyboard(){return a(this,ai)}get touchscreen(){return a(this,Eo)}get coverage(){return a(this,Mo)}get tracing(){return a(this,Io)}frames(){return a(this,Me).frames()}workers(){return Array.from(a(this,Ts).values())}async setRequestInterception(e){return await a(this,Me).networkManager.setRequestInterception(e)}async setBypassServiceWorker(e){return _(this,vd,e),await a(this,xe).send("Network.setBypassServiceWorker",{bypass:e})}async setDragInterception(e){return _(this,xd,e),await a(this,xe).send("Input.setInterceptDrags",{enabled:e})}async setOfflineMode(e){return await a(this,Me).networkManager.setOfflineMode(e)}async emulateNetworkConditions(e){return await a(this,Me).networkManager.emulateNetworkConditions(e)}setDefaultNavigationTimeout(e){this._timeoutSettings.setDefaultNavigationTimeout(e)}setDefaultTimeout(e){this._timeoutSettings.setDefaultTimeout(e)}getDefaultTimeout(){return this._timeoutSettings.timeout()}async queryObjects(e){X(!e.disposed,"Prototype JSHandle is disposed!"),X(e.id,"Prototype JSHandle must not be referencing primitive value");const n=await this.mainFrame().client.send("Runtime.queryObjects",{prototypeObjectId:e.id});return this.mainFrame().mainRealm().createCdpHandle(n.objects)}async cookies(...e){const n=(await a(this,xe).send("Network.getCookies",{urls:e.length?e:[this.url()]})).cookies,i=["sourcePort"],s=o=>{for(const c of i)delete o[c];return o};return n.map(s)}async deleteCookie(...e){const n=this.url();for(const i of e){const s=Object.assign({},i);!i.url&&n.startsWith("http")&&(s.url=n),await a(this,xe).send("Network.deleteCookies",s)}}async setCookie(...e){const n=this.url(),i=n.startsWith("http"),s=e.map(o=>{const c=Object.assign({},o);return!c.url&&i&&(c.url=n),X(c.url!=="about:blank",`Blank page can not have cookie "${c.name}"`),X(!String.prototype.startsWith.call(c.url||"","data:"),`Data URL page can not have cookie "${c.name}"`),c});await this.deleteCookie(...s),s.length&&await a(this,xe).send("Network.setCookies",{cookies:s})}async exposeFunction(e,n){if(a(this,oi).has(e))throw new Error(`Failed to add page binding with name ${e}: window['${e}'] already exists!`);const i=rS("exposedFun",e);let s;switch(typeof n){case"function":s=new Yu(e,n,i);break;default:s=new Yu(e,n.default,i);break}a(this,oi).set(e,s);const[{identifier:o}]=await Promise.all([a(this,Me).evaluateOnNewDocument(i),a(this,Me).addExposedFunctionBinding(s)]);a(this,No).set(e,o)}async removeExposedFunction(e){const n=a(this,No).get(e);if(!n)throw new Error(`Function with name "${e}" does not exist`);const i=a(this,oi).get(e);a(this,No).delete(e),a(this,oi).delete(e),await Promise.all([a(this,Me).removeScriptToEvaluateOnNewDocument(n),a(this,Me).removeExposedFunctionBinding(i)])}async authenticate(e){return await a(this,Me).networkManager.authenticate(e)}async setExtraHTTPHeaders(e){return await a(this,Me).networkManager.setExtraHTTPHeaders(e)}async setUserAgent(e,n){return await a(this,Me).networkManager.setUserAgent(e,n)}async metrics(){const e=await a(this,xe).send("Performance.getMetrics");return I(this,pe,xp).call(this,e.metrics)}async reload(e){const[n]=await Promise.all([this.waitForNavigation({...e,ignoreSameDocumentNavigation:!0}),a(this,xe).send("Page.reload")]);return n}async createCDPSession(){return await this.target().createCDPSession()}async goBack(e={}){return await I(this,pe,Cp).call(this,-1,e)}async goForward(e={}){return await I(this,pe,Cp).call(this,1,e)}async bringToFront(){await a(this,xe).send("Page.bringToFront")}async setJavaScriptEnabled(e){return await a(this,Ve).setJavaScriptEnabled(e)}async setBypassCSP(e){await a(this,xe).send("Page.setBypassCSP",{enabled:e})}async emulateMediaType(e){return await a(this,Ve).emulateMediaType(e)}async emulateCPUThrottling(e){return await a(this,Ve).emulateCPUThrottling(e)}async emulateMediaFeatures(e){return await a(this,Ve).emulateMediaFeatures(e)}async emulateTimezone(e){return await a(this,Ve).emulateTimezone(e)}async emulateIdleState(e){return await a(this,Ve).emulateIdleState(e)}async emulateVisionDeficiency(e){return await a(this,Ve).emulateVisionDeficiency(e)}async setViewport(e){const n=await a(this,Ve).emulateViewport(e);_(this,Ao,e),n&&await this.reload()}viewport(){return a(this,Ao)}async evaluateOnNewDocument(e,...n){const i=R0(e,...n);return await a(this,Me).evaluateOnNewDocument(i)}async removeScriptToEvaluateOnNewDocument(e){return await a(this,Me).removeScriptToEvaluateOnNewDocument(e)}async setCacheEnabled(e=!0){await a(this,Me).networkManager.setCacheEnabled(e)}async _screenshot(e){const n={stack:[],error:void 0,hasError:!1};try{const{fromSurface:i,omitBackground:s,optimizeForSpeed:o,quality:c,clip:l,type:d,captureBeyondViewport:u}=e,h=this.target()._targetManager()instanceof Q0,p=hf(n,new Gu,!0);!h&&s&&(d==="png"||d==="webp")&&(await a(this,Ve).setTransparentBackgroundColor(),p.defer(async()=>{await a(this,Ve).resetDefaultBackgroundColor().catch(de)}));let f=l;if(f&&!u){const w=await this.mainFrame().isolatedRealm().evaluate(()=>{const{height:b,pageLeft:C,pageTop:A,width:T}=window.visualViewport;return{x:C,y:A,height:b,width:T}});f=FS(f,w)}const{data:y}=await a(this,xe).send("Page.captureScreenshot",{format:d,...o?{optimizeForSpeed:o}:{},...c!==void 0?{quality:Math.round(c)}:{},...f?{clip:{...f,scale:f.scale??1}}:{},...i?{}:{fromSurface:i},captureBeyondViewport:u});return y}catch(i){n.error=i,n.hasError=!0}finally{const i=ff(n);i&&await i}}async createPDFStream(e={}){const{timeout:n=this._timeoutSettings.timeout()}=e,{landscape:i,displayHeaderFooter:s,headerTemplate:o,footerTemplate:c,printBackground:l,scale:d,width:u,height:h,margin:p,pageRanges:f,preferCSSPageSize:y,omitBackground:w,tagged:b,outline:C,waitForFonts:A}=U1(e);w&&await a(this,Ve).setTransparentBackgroundColor(),A&&await Rt(Ie(this.mainFrame().isolatedRealm().evaluate(()=>document.fonts.ready)).pipe(zn(Hn(n))));const T=a(this,xe).send("Page.printToPDF",{transferMode:"ReturnAsStream",landscape:i,displayHeaderFooter:s,headerTemplate:o,footerTemplate:c,printBackground:l,scale:d,paperWidth:u,paperHeight:h,marginTop:p.top,marginBottom:p.bottom,marginLeft:p.left,marginRight:p.right,pageRanges:f,preferCSSPageSize:y,generateTaggedPDF:b,generateDocumentOutline:C}),M=await Rt(Ie(T).pipe(zn(Hn(n))));return w&&await a(this,Ve).resetDefaultBackgroundColor(),X(M.stream,"`stream` is missing from `Page.printToPDF"),await D0(a(this,xe),M.stream)}async pdf(e={}){const{path:n=void 0}=e,i=await this.createPDFStream(e),s=await F0(i,n);return X(s,"Could not create buffer"),s}async close(e={runBeforeUnload:void 0}){const n={stack:[],error:void 0,hasError:!1};try{const i=hf(n,await this.browserContext().waitForScreenshotOperations(),!1),s=a(this,xe).connection();X(s,"Protocol error: Connection closed. Most likely the page has been closed."),!!e.runBeforeUnload?await a(this,xe).send("Page.close"):(await s.send("Target.closeTarget",{targetId:a(this,wn)._targetId}),await a(this,As)._isClosedDeferred.valueOrThrow())}catch(i){n.error=i,n.hasError=!0}finally{ff(n)}}isClosed(){return a(this,wd)}get mouse(){return a(this,Co)}async waitForDevicePrompt(e={}){return await this.mainFrame().waitForDevicePrompt(e)}};wd=new WeakMap,ii=new WeakMap,xe=new WeakMap,wn=new WeakMap,si=new WeakMap,As=new WeakMap,ai=new WeakMap,Co=new WeakMap,Eo=new WeakMap,Me=new WeakMap,Ve=new WeakMap,Io=new WeakMap,oi=new WeakMap,No=new WeakMap,Mo=new WeakMap,Ao=new WeakMap,Ts=new WeakMap,fr=new WeakMap,Ih=new WeakMap,vd=new WeakMap,xd=new WeakMap,Nh=new WeakMap,Mh=new WeakMap,Ah=new WeakMap,pe=new WeakSet,J_=function(){const e=[];for(const i of a(this,ii).getChildTargets(a(this,wn)))e.push(i);let n=0;for(;n<e.length;){const i=e[n];n++;const s=i._session();s&&a(this,To).call(this,s);for(const o of a(this,ii).getChildTargets(i))e.push(o)}},Q_=async function(e){_(this,xe,e),X(a(this,xe)instanceof pa,"CDPSession is not instance of CDPSessionImpl"),_(this,wn,a(this,xe)._target()),X(a(this,wn),"Missing target on swap"),a(this,ai).updateClient(e),a(this,Co).updateClient(e),a(this,Eo).updateClient(e),a(this,Ve).updateClient(e),a(this,Io).updateClient(e),a(this,Mo).updateClient(e),await a(this,Me).swapFrameTree(e),I(this,pe,vp).call(this)},Y_=async function(e){X(e instanceof pa),e._target()._subtype()==="prerender"&&(a(this,Me).registerSpeculativeSession(e).catch(de),a(this,Ve).registerSpeculativeSession(e).catch(de))},vp=function(){a(this,xe).on($e.Ready,a(this,To));for(const[e,n]of a(this,Ah))a(this,xe).on(e,n)},Sd=new WeakMap,To=new WeakMap,Z_=async function(){try{await Promise.all([a(this,Me).initialize(a(this,xe)),a(this,xe).send("Performance.enable"),a(this,xe).send("Log.enable")])}catch(e){if(Kn(e)&&Ff(e))de(e);else throw e}},eb=async function(e){const n={stack:[],error:void 0,hasError:!1};try{if(!a(this,fr).size)return;const i=a(this,Me).frame(e.frameId);X(i,"This should never happen.");const s=hf(n,await i.worlds[Pn].adoptBackendNode(e.backendNodeId),!1),o=new ux(s.move(),e);for(const c of a(this,fr))c.resolve(o);a(this,fr).clear()}catch(i){n.error=i,n.hasError=!0}finally{ff(n)}},tb=function(){this.emit("error",new Error("Page crashed!"))},nb=function(e){const{level:n,text:i,args:s,source:o,url:c,lineNumber:l}=e.entry;s&&s.map(d=>{c_(a(this,xe),d)}),o!=="worker"&&this.emit("console",new Ng(pf(n),i,[],[{url:c,lineNumber:l}]))},rb=function(e){this.emit("metrics",{title:e.title,metrics:I(this,pe,xp).call(this,e.metrics)})},xp=function(e){const n={};for(const i of e||[])RS.has(i.name)&&(n[i.name]=i.value);return n},Sp=function(e){this.emit("pageerror",nS(e.exceptionDetails))},ib=function(e,n){const i=n.args.map(s=>e.createCdpHandle(s));I(this,pe,kp).call(this,pf(n.type),i,n.stackTrace)},sb=async function(e,n){let i;try{i=JSON.parse(n.payload)}catch{return}const{type:s,name:o,seq:c,args:l,isTrivial:d}=i;if(s!=="exposedFun")return;const u=e.context;if(!u)return;const h=a(this,oi).get(o);await(h==null?void 0:h.run(u,c,l,d))},kp=function(e,n,i){if(!this.listenerCount("console")){n.forEach(l=>l.dispose());return}const s=[];for(const l of n){const d=l.remoteObject();d.objectId?s.push(l.toString()):s.push(Bs(d))}const o=[];if(i)for(const l of i.callFrames)o.push({url:l.url,lineNumber:l.lineNumber,columnNumber:l.columnNumber});const c=new Ng(pf(e),s.join(" "),n,o);this.emit("console",c)},ab=function(e){const n=L1(e.type),i=new xx(a(this,xe),n,e.message,e.defaultPrompt);this.emit("dialog",i)},Cp=async function(e,n){const i=await a(this,xe).send("Page.getNavigationHistory"),s=i.entries[i.currentIndex+e];return s?(await Promise.all([this.waitForNavigation(n),a(this,xe).send("Page.navigateToHistoryEntry",{entryId:s.id})]))[0]:null};let Pc=Fm;const RS=new Set(["Timestamp","Documents","Frames","JSEventListeners","Nodes","LayoutCount","RecalcStyleCount","LayoutDuration","RecalcStyleDuration","ScriptDuration","TaskDuration","JSHeapUsedSize","JSHeapTotalSize"]);function FS(r,t){const e=Math.max(r.x,t.x),n=Math.max(r.y,t.y);return{x:e,y:n,width:Math.max(Math.min(r.x+r.width,t.x+t.width)-e,0),height:Math.max(Math.min(r.y+r.height,t.y+t.height)-n,0)}}/**
 * @license
 * Copyright 2019 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var tn;(function(r){r.SUCCESS="success",r.ABORTED="aborted"})(tn||(tn={}));var ci,li,Un,Po,di,$o;class Lh extends V1{constructor(e,n,i,s,o){super();m(this,ci);m(this,li);m(this,Un);m(this,Po);m(this,di);m(this,$o,new Set);L(this,"_initializedDeferred",Ae.create());L(this,"_isClosedDeferred",Ae.create());L(this,"_targetId");_(this,li,n),_(this,Po,s),_(this,Un,e),_(this,ci,i),this._targetId=e.targetId,_(this,di,o),a(this,li)&&a(this,li)instanceof pa&&a(this,li)._setTarget(this)}async asPage(){const e=this._session();return e?await Pc._create(e,this,null):await this.createCDPSession().then(n=>Pc._create(n,this,null))}_subtype(){return a(this,Un).subtype}_session(){return a(this,li)}_addChildTarget(e){a(this,$o).add(e)}_removeChildTarget(e){a(this,$o).delete(e)}_childTargets(){return a(this,$o)}_sessionFactory(){if(!a(this,di))throw new Error("sessionFactory is not initialized");return a(this,di)}createCDPSession(){if(!a(this,di))throw new Error("sessionFactory is not initialized");return a(this,di).call(this,!1).then(e=>(e._setTarget(this),e))}url(){return a(this,Un).url}type(){switch(a(this,Un).type){case"page":return Jt.PAGE;case"background_page":return Jt.BACKGROUND_PAGE;case"service_worker":return Jt.SERVICE_WORKER;case"shared_worker":return Jt.SHARED_WORKER;case"browser":return Jt.BROWSER;case"webview":return Jt.WEBVIEW;case"tab":return Jt.TAB;default:return Jt.OTHER}}_targetManager(){if(!a(this,Po))throw new Error("targetManager is not initialized");return a(this,Po)}_getTargetInfo(){return a(this,Un)}browser(){if(!a(this,ci))throw new Error("browserContext is not initialized");return a(this,ci).browser()}browserContext(){if(!a(this,ci))throw new Error("browserContext is not initialized");return a(this,ci)}opener(){const{openerId:e}=a(this,Un);if(e)return this.browser().targets().find(n=>n._targetId===e)}_targetInfoChanged(e){_(this,Un,e),this._checkIfInitialized()}_initialize(){this._initializedDeferred.resolve(tn.SUCCESS)}_isTargetExposed(){return this.type()!==Jt.TAB&&!this._subtype()}_checkIfInitialized(){this._initializedDeferred.resolved()||this._initializedDeferred.resolve(tn.SUCCESS)}}ci=new WeakMap,li=new WeakMap,Un=new WeakMap,Po=new WeakMap,di=new WeakMap,$o=new WeakMap;var kd;const Dm=class Dm extends Lh{constructor(e,n,i,s,o,c){super(e,n,i,s,o);m(this,kd);L(this,"pagePromise");_(this,kd,c??void 0)}_initialize(){this._initializedDeferred.valueOrThrow().then(async e=>{if(e===tn.ABORTED)return;const n=this.opener();if(!(n instanceof Dm))return;if(!n||!n.pagePromise||this.type()!=="page")return!0;const i=await n.pagePromise;if(!i.listenerCount("popup"))return!0;const s=await this.page();return i.emit("popup",s),!0}).catch(de),this._checkIfInitialized()}async page(){if(!this.pagePromise){const e=this._session();this.pagePromise=(e?Promise.resolve(e):this._sessionFactory()(!1)).then(n=>Pc._create(n,this,a(this,kd)??null))}return await this.pagePromise??null}_checkIfInitialized(){this._initializedDeferred.resolved()||this._getTargetInfo().url!==""&&this._initializedDeferred.resolve(tn.SUCCESS)}};kd=new WeakMap;let eh=Dm;class DS extends eh{}var Ro;class OS extends Lh{constructor(){super(...arguments);m(this,Ro)}async worker(){if(!a(this,Ro)){const e=this._session();_(this,Ro,(e?Promise.resolve(e):this._sessionFactory()(!1)).then(n=>new X_(n,this._getTargetInfo().url,this._targetId,this.type(),()=>{},()=>{})))}return await a(this,Ro)}}Ro=new WeakMap;class LS extends Lh{}/**
 * @license
 * Copyright 2022 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */function jS(r,t){return!!r._subtype()&&!t.subtype}var nt,ui,rt,Ps,Cd,hi,$s,Rs,fi,Ed,Fs,Id,Fo,Th,Ft,Ep,Ip,Nd,Md,Ad,Td,Ph,sa,$h;class BS extends He{constructor(e,n,i,s=!0){super();m(this,Ft);m(this,nt);m(this,ui,new Map);m(this,rt,new Map);m(this,Ps,new Map);m(this,Cd,new Set);m(this,hi);m(this,$s);m(this,Rs,new WeakMap);m(this,fi,new WeakMap);m(this,Ed,Ae.create());m(this,Fs,new Set);m(this,Id,!0);m(this,Fo,[{}]);m(this,Th,()=>{if(a(this,Id))for(const[e,n]of a(this,ui).entries()){const i=new Lh(n,void 0,void 0,this,void 0),s=n.type==="browser"||n.url.startsWith("chrome-extension://");(!a(this,hi)||a(this,hi).call(this,i))&&!s&&a(this,Fs).add(e)}});m(this,Nd,e=>{I(this,Ft,Ip).call(this,e)});m(this,Md,async e=>{if(a(this,ui).set(e.targetInfo.targetId,e.targetInfo),this.emit("targetDiscovered",e.targetInfo),e.targetInfo.type==="browser"&&e.targetInfo.attached){if(a(this,rt).has(e.targetInfo.targetId))return;const n=a(this,$s).call(this,e.targetInfo,void 0);n._initialize(),a(this,rt).set(e.targetInfo.targetId,n)}});m(this,Ad,e=>{const n=a(this,ui).get(e.targetId);if(a(this,ui).delete(e.targetId),I(this,Ft,sa).call(this,e.targetId),(n==null?void 0:n.type)==="service_worker"&&a(this,rt).has(e.targetId)){const i=a(this,rt).get(e.targetId);i&&(this.emit("targetGone",i),a(this,rt).delete(e.targetId))}});m(this,Td,e=>{var o;if(a(this,ui).set(e.targetInfo.targetId,e.targetInfo),a(this,Cd).has(e.targetInfo.targetId)||!a(this,rt).has(e.targetInfo.targetId)||!e.targetInfo.attached)return;const n=a(this,rt).get(e.targetInfo.targetId);if(!n)return;const i=n.url(),s=n._initializedDeferred.value()===tn.SUCCESS;if(jS(n,e.targetInfo)){const c=n==null?void 0:n._session();X(c,"Target that is being activated is missing a CDPSession."),(o=c.parentSession())==null||o.emit($e.Swapped,c)}n._targetInfoChanged(e.targetInfo),s&&i!==n.url()&&this.emit("targetChanged",{target:n,wasInitialized:s,previousURL:i})});m(this,Ph,async(e,n)=>{const i=n.targetInfo,s=a(this,nt).session(n.sessionId);if(!s)throw new Error(`Session ${n.sessionId} was not created.`);const o=async()=>{await s.send("Runtime.runIfWaitingForDebugger").catch(de),await e.send("Target.detachFromTarget",{sessionId:s.id()}).catch(de)};if(!a(this,nt).isAutoAttached(i.targetId))return;if(i.type==="service_worker"){if(I(this,Ft,sa).call(this,i.targetId),await o(),a(this,rt).has(i.targetId))return;const u=a(this,$s).call(this,i);u._initialize(),a(this,rt).set(i.targetId,u),this.emit("targetAvailable",u);return}const c=a(this,rt).has(i.targetId),l=c?a(this,rt).get(i.targetId):a(this,$s).call(this,i,s,e instanceof gu?e:void 0);if(a(this,hi)&&!a(this,hi).call(this,l)){a(this,Cd).add(i.targetId),I(this,Ft,sa).call(this,i.targetId),await o();return}I(this,Ft,Ep).call(this,s),c?(s._setTarget(l),a(this,Ps).set(s.id(),a(this,rt).get(i.targetId))):(l._initialize(),a(this,rt).set(i.targetId,l),a(this,Ps).set(s.id(),l));const d=e instanceof gu?e._target():null;d==null||d._addChildTarget(l),e.emit($e.Ready,s),a(this,Fs).delete(l._targetId),c||this.emit("targetAvailable",l),I(this,Ft,sa).call(this),await Promise.all([s.send("Target.setAutoAttach",{waitForDebuggerOnStart:!0,flatten:!0,autoAttach:!0,filter:a(this,Fo)}),s.send("Runtime.runIfWaitingForDebugger")]).catch(de)});m(this,$h,(e,n)=>{const i=a(this,Ps).get(n.sessionId);a(this,Ps).delete(n.sessionId),i&&(e instanceof gu&&e._target()._removeChildTarget(i),a(this,rt).delete(i._targetId),this.emit("targetGone",i))});_(this,nt,e),_(this,hi,i),_(this,$s,n),_(this,Id,s),a(this,nt).on("Target.targetCreated",a(this,Md)),a(this,nt).on("Target.targetDestroyed",a(this,Ad)),a(this,nt).on("Target.targetInfoChanged",a(this,Td)),a(this,nt).on($e.SessionDetached,a(this,Nd)),I(this,Ft,Ep).call(this,a(this,nt))}async initialize(){await a(this,nt).send("Target.setDiscoverTargets",{discover:!0,filter:a(this,Fo)}),a(this,Th).call(this),await a(this,nt).send("Target.setAutoAttach",{waitForDebuggerOnStart:!0,flatten:!0,autoAttach:!0,filter:[{type:"page",exclude:!0},...a(this,Fo)]}),I(this,Ft,sa).call(this),await a(this,Ed).valueOrThrow()}getChildTargets(e){return e._childTargets()}dispose(){a(this,nt).off("Target.targetCreated",a(this,Md)),a(this,nt).off("Target.targetDestroyed",a(this,Ad)),a(this,nt).off("Target.targetInfoChanged",a(this,Td)),a(this,nt).off($e.SessionDetached,a(this,Nd)),I(this,Ft,Ip).call(this,a(this,nt))}getAvailableTargets(){return a(this,rt)}}nt=new WeakMap,ui=new WeakMap,rt=new WeakMap,Ps=new WeakMap,Cd=new WeakMap,hi=new WeakMap,$s=new WeakMap,Rs=new WeakMap,fi=new WeakMap,Ed=new WeakMap,Fs=new WeakMap,Id=new WeakMap,Fo=new WeakMap,Th=new WeakMap,Ft=new WeakSet,Ep=function(e){const n=s=>{a(this,Ph).call(this,e,s)};X(!a(this,Rs).has(e)),a(this,Rs).set(e,n),e.on("Target.attachedToTarget",n);const i=s=>a(this,$h).call(this,e,s);X(!a(this,fi).has(e)),a(this,fi).set(e,i),e.on("Target.detachedFromTarget",i)},Ip=function(e){const n=a(this,Rs).get(e);n&&(e.off("Target.attachedToTarget",n),a(this,Rs).delete(e)),a(this,fi).has(e)&&(e.off("Target.detachedFromTarget",a(this,fi).get(e)),a(this,fi).delete(e))},Nd=new WeakMap,Md=new WeakMap,Ad=new WeakMap,Td=new WeakMap,Ph=new WeakMap,sa=function(e){e!==void 0&&a(this,Fs).delete(e),a(this,Fs).size===0&&a(this,Ed).resolve()},$h=new WeakMap;/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var Do,Pd,it,$d,Oo,Lo,pi,pr,Ue,Rd,Fd,Hs,ob,Dd,Od,Ld,jd,Bd,Np;const Om=class Om extends W1{constructor(e,n,i,s,o,c,l,d,u=!0,h){super();m(this,Hs);L(this,"protocol","cdp");m(this,Do);m(this,Pd);m(this,it);m(this,$d);m(this,Oo);m(this,Lo);m(this,pi);m(this,pr,new Map);m(this,Ue);m(this,Rd);m(this,Fd,()=>{this.emit("disconnected",void 0)});m(this,Dd,(e,n)=>{var l;const{browserContextId:i}=e,s=i&&a(this,pr).has(i)?a(this,pr).get(i):a(this,pi);if(!s)throw new Error("Missing browser context");const o=d=>a(this,it)._createSession(e,d),c=new LS(e,n,s,a(this,Ue),o);return(l=e.url)!=null&&l.startsWith("devtools://")?new DS(e,n,s,a(this,Ue),o,a(this,Do)??null):a(this,Lo).call(this,c)?new eh(e,n,s,a(this,Ue),o,a(this,Do)??null):e.type==="service_worker"||e.type==="shared_worker"?new OS(e,n,s,a(this,Ue),o):c});m(this,Od,async e=>{e._isTargetExposed()&&await e._initializedDeferred.valueOrThrow()===tn.SUCCESS&&(this.emit("targetcreated",e),e.browserContext().emit("targetcreated",e))});m(this,Ld,async e=>{e._initializedDeferred.resolve(tn.ABORTED),e._isClosedDeferred.resolve(),e._isTargetExposed()&&await e._initializedDeferred.valueOrThrow()===tn.SUCCESS&&(this.emit("targetdestroyed",e),e.browserContext().emit("targetdestroyed",e))});m(this,jd,({target:e})=>{this.emit("targetchanged",e),e.browserContext().emit("targetchanged",e)});m(this,Bd,e=>{this.emit("targetdiscovered",e)});e=e||"chrome",_(this,Do,s),_(this,Pd,o),_(this,it,n),_(this,$d,c||(()=>{})),_(this,Oo,l||(()=>!0)),I(this,Hs,ob).call(this,d),e==="firefox"?_(this,Ue,new Q0(n,a(this,Dd),a(this,Oo))):_(this,Ue,new BS(n,a(this,Dd),a(this,Oo),u)),_(this,pi,new of(a(this,it),this));for(const p of i)a(this,pr).set(p,new of(a(this,it),this,p));_(this,Rd,h||"unknown")}static async _create(e,n,i,s,o,c,l,d,u,h=!0,p){const f=new Om(e,n,i,o,c,l,d,u,h,p);return s&&await n.send("Security.setIgnoreCertificateErrors",{ignore:!0}),await f._attach(),f}async _attach(){a(this,it).on($e.Disconnected,a(this,Fd)),a(this,Ue).on("targetAvailable",a(this,Od)),a(this,Ue).on("targetGone",a(this,Ld)),a(this,Ue).on("targetChanged",a(this,jd)),a(this,Ue).on("targetDiscovered",a(this,Bd)),await a(this,Ue).initialize()}_detach(){a(this,it).off($e.Disconnected,a(this,Fd)),a(this,Ue).off("targetAvailable",a(this,Od)),a(this,Ue).off("targetGone",a(this,Ld)),a(this,Ue).off("targetChanged",a(this,jd)),a(this,Ue).off("targetDiscovered",a(this,Bd))}process(){return a(this,Pd)??null}_targetManager(){return a(this,Ue)}_getIsPageTargetCallback(){return a(this,Lo)}async createBrowserContext(e={}){const{proxyServer:n,proxyBypassList:i}=e,{browserContextId:s}=await a(this,it).send("Target.createBrowserContext",{proxyServer:n,proxyBypassList:i&&i.join(",")}),o=new of(a(this,it),this,s);return a(this,pr).set(s,o),o}browserContexts(){return[a(this,pi),...Array.from(a(this,pr).values())]}defaultBrowserContext(){return a(this,pi)}async _disposeContext(e){e&&(await a(this,it).send("Target.disposeBrowserContext",{browserContextId:e}),a(this,pr).delete(e))}wsEndpoint(){return a(this,it).url()}async newPage(){return await a(this,pi).newPage()}async _createPageInContext(e){const{targetId:n}=await a(this,it).send("Target.createTarget",{url:"about:blank",browserContextId:e||void 0}),i=await this.waitForTarget(c=>c._targetId===n);if(!i)throw new Error(`Missing target for page (id = ${n})`);if(!(await i._initializedDeferred.valueOrThrow()===tn.SUCCESS))throw new Error(`Failed to create target for page (id = ${n})`);const o=await i.page();if(!o)throw new Error(`Failed to create a page for context (id = ${e})`);return o}targets(){return Array.from(a(this,Ue).getAvailableTargets().values()).filter(e=>e._isTargetExposed()&&e._initializedDeferred.value()===tn.SUCCESS)}target(){const e=this.targets().find(n=>n.type()==="browser");if(!e)throw new Error("Browser target is not found");return e}async version(){return(await I(this,Hs,Np).call(this)).product}async userAgent(){return(await I(this,Hs,Np).call(this)).userAgent}async close(){await a(this,$d).call(null),await this.disconnect()}disconnect(){return a(this,Ue).dispose(),a(this,it).dispose(),this._detach(),Promise.resolve()}get connected(){return!a(this,it)._closed}get debugInfo(){return{pendingProtocolErrors:a(this,it).getPendingProtocolErrors()}}sessionId(){return a(this,Rd)}};Do=new WeakMap,Pd=new WeakMap,it=new WeakMap,$d=new WeakMap,Oo=new WeakMap,Lo=new WeakMap,pi=new WeakMap,pr=new WeakMap,Ue=new WeakMap,Rd=new WeakMap,Fd=new WeakMap,Hs=new WeakSet,ob=function(e){_(this,Lo,e||(n=>n.type()==="page"||n.type()==="background_page"||n.type()==="webview"))},Dd=new WeakMap,Od=new WeakMap,Ld=new WeakMap,jd=new WeakMap,Bd=new WeakMap,Np=function(){return a(this,it).send("Browser.getVersion")};let th=Om;/**
 * @license
 * Copyright 2020 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */async function US(r,t,e){const{ignoreHTTPSErrors:n=!1,defaultViewport:i=F1,targetFilter:s,_isPageTarget:o,slowMo:c=0,protocolTimeout:l}=e,d=new q0(t,r,c,l),h=(await d.send("Browser.getVersion")).product.toLowerCase().includes("firefox")?"firefox":"chrome",{browserContextIds:p}=await d.send("Target.getBrowserContexts");return await th._create(h,d,p,n,i,void 0,()=>d.send("Browser.close").catch(de),s,o)}/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Ug=async()=>P0?(await Promise.resolve().then(()=>E3)).NodeWebSocketTransport:(await Promise.resolve().then(()=>QS)).BrowserWebSocketTransport;async function zS(r){const{connectionTransport:t,endpointUrl:e}=await HS(r);return await US(t,e,r)}async function HS(r){const{browserWSEndpoint:t,browserURL:e,transport:n,headers:i={}}=r;if(X(+!!t+ +!!e+ +!!n==1,"Exactly one of browserWSEndpoint, browserURL or transport must be passed to puppeteer.connect"),n)return{connectionTransport:n,endpointUrl:""};if(t)return{connectionTransport:await(await Ug()).create(t,i),endpointUrl:t};if(e){const s=await WS(e);return{connectionTransport:await(await Ug()).create(s),endpointUrl:s}}throw new Error("Invalid connection options")}async function WS(r){const t=new URL("/json/version",r);try{const e=await globalThis.fetch(t.toString(),{method:"GET"});if(!e.ok)throw new Error(`HTTP ${e.statusText}`);return(await e.json()).webSocketDebuggerUrl}catch(e){throw Kn(e)&&(e.message=`Failed to fetch browser webSocket URL from ${t}: `+e.message),e}}/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */class cb{constructor(t){L(this,"_isPuppeteerCore");L(this,"_changedProduct",!1);this._isPuppeteerCore=t.isPuppeteerCore,this.connect=this.connect.bind(this)}static registerCustomQueryHandler(t,e){return this.customQueryHandlers.register(t,e)}static unregisterCustomQueryHandler(t){return this.customQueryHandlers.unregister(t)}static customQueryHandlerNames(){return this.customQueryHandlers.names()}static clearCustomQueryHandlers(){return this.customQueryHandlers.clear()}connect(t){return zS(t)}}L(cb,"customQueryHandlers",Vf);/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const qS=Object.freeze({width:800,height:600});async function KS(r,t){const{ignoreHTTPSErrors:e=!1,defaultViewport:n=qS,targetFilter:i,_isPageTarget:s,slowMo:o=0,protocolTimeout:c,sessionId:l="unknown"}=t,d=new q0("",r,o,c),h=(await d.send("Browser.getVersion")).product.toLowerCase().includes("firefox")?"firefox":"chrome",{browserContextIds:p}=await d.send("Target.getBrowserContexts");return await th._create(h,d,p,e,n,void 0,()=>d.send("Browser.close").catch(console.log),i,s,!0,l)}/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const $c=4,Tu=1048575,zg=Tu-$c,GS=r=>{const e=new TextEncoder().encode(r),n=new Uint8Array(Math.min(Tu,$c+e.length));new DataView(n.buffer).setUint32(0,e.length,!0),n.set(e.slice(0,zg),$c);const s=[n];for(let o=zg;o<r.length;o+=Tu)s.push(e.slice(o,o+Tu));return s},VS=(r,t)=>{if(r.length===0)return null;const e=new Uint8Array(0),n=r[0]||e,s=new DataView(n.buffer).getUint32(0,!0);let o=-$c;for(let c=0;c<r.length;++c){const l=r[c]||e;if(o+=l.length,o>s)throw new Error(`Should have gotten the exact number of bytes but we got more.  SessionID: ${t}`);if(o===s){const d=r.splice(0,c+1);d[0]=n.subarray($c);const u=new Uint8Array(s);let h=0;for(let y=0;y<=c;++y){const w=d[y]||e;u.set(w,h),h+=w.length}return new TextDecoder().decode(u)}}return null},XS="https://fake.host";class sm{constructor(t,e){L(this,"ws");L(this,"pingInterval");L(this,"chunks",[]);L(this,"onmessage");L(this,"onclose");L(this,"sessionId");this.pingInterval=setInterval(()=>this.ws.send("ping"),1e3),this.ws=t,this.sessionId=e,this.ws.addEventListener("message",n=>{this.chunks.push(new Uint8Array(n.data));const i=VS(this.chunks,e);i&&this.onmessage&&this.onmessage(i)}),this.ws.addEventListener("close",()=>{clearInterval(this.pingInterval),this.onclose&&this.onclose()}),this.ws.addEventListener("error",n=>{console.error(`Websocket error: SessionID: ${e}`,n),clearInterval(this.pingInterval)})}static async create(t,e){const n=`${XS}/v1/connectDevtools?browser_session=${e}`,i=await t.fetch(n,{headers:{Upgrade:"websocket","cf-brapi-client":`@cloudflare/puppeteer@${em}`}});return i.webSocket.accept(),new sm(i.webSocket,e)}send(t){for(const e of GS(t))this.ws.send(e)}close(){clearInterval(this.pingInterval),this.ws.close()}toString(){return this.sessionId}}/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Yd="https://fake.host";class JS extends cb{constructor(){super({isPuppeteerCore:!1}),this.acquire=this.acquire.bind(this),this.connect=this.connect.bind(this),this.launch=this.launch.bind(this),this.sessions=this.sessions.bind(this),this.history=this.history.bind(this),this.limits=this.limits.bind(this)}async launch(t,e){const n=await this.acquire(t,e);return await this.connect(t,n.sessionId)}async sessions(t){const e=await t.fetch(`${Yd}/v1/sessions`),n=e.status,i=await e.text();if(n!==200)throw new Error(`Unable to fetch new sessions: code: ${n}: message: ${i}`);return JSON.parse(i).sessions}async history(t){const e=await t.fetch(`${Yd}/v1/history`),n=e.status,i=await e.text();if(n!==200)throw new Error(`Unable to fetch account history: code: ${n}: message: ${i}`);return JSON.parse(i).history}async limits(t){const e=await t.fetch(`${Yd}/v1/limits`),n=e.status,i=await e.text();if(n!==200)throw new Error(`Unable to fetch account limits: code: ${n}: message: ${i}`);return JSON.parse(i)}async connect(t,e){try{if(!e)return await super.connect(t);const n=await sm.create(t,e);return await KS(n,{sessionId:e})}catch(n){throw new Error(`Unable to connect to existing session ${e} (it may still be in use or not ready yet) - retry or launch a new browser: ${n}`)}}async acquire(t,e){const n=new URLSearchParams;e!=null&&e.keep_alive&&n.set("keep_alive",`${e.keep_alive}`),e!=null&&e.location&&n.set("location",e.location);const i=`${Yd}/v1/acquire?${n.toString()}`,s=await t.fetch(i),o=s.status,c=await s.text();if(o!==200)throw new Error(`Unable to create new browser: code: ${o}: message: ${c}`);return JSON.parse(c)}}var mr;const Lm=class Lm{constructor(t){m(this,mr);L(this,"onmessage");L(this,"onclose");_(this,mr,t),a(this,mr).addEventListener("message",e=>{this.onmessage&&this.onmessage.call(null,e.data)}),a(this,mr).addEventListener("close",()=>{this.onclose&&this.onclose.call(null)}),a(this,mr).addEventListener("error",()=>{})}static create(t){return new Promise((e,n)=>{const i=new WebSocket(t);i.addEventListener("open",()=>e(new Lm(i))),i.addEventListener("error",n)})}send(t){a(this,mr).send(t)}close(){a(this,mr).close()}};mr=new WeakMap;let Mp=Lm;const QS=Object.freeze(Object.defineProperty({__proto__:null,BrowserWebSocketTransport:Mp},Symbol.toStringTag,{value:"Module"}));/**
 * @license
 * Copyright 2017 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const YS=[{name:"Blackberry PlayBook",userAgent:"Mozilla/5.0 (PlayBook; U; RIM Tablet OS 2.1.0; en-US) AppleWebKit/536.2+ (KHTML like Gecko) Version/7.2.1.0 Safari/536.2+",viewport:{width:600,height:1024,deviceScaleFactor:1,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Blackberry PlayBook landscape",userAgent:"Mozilla/5.0 (PlayBook; U; RIM Tablet OS 2.1.0; en-US) AppleWebKit/536.2+ (KHTML like Gecko) Version/7.2.1.0 Safari/536.2+",viewport:{width:1024,height:600,deviceScaleFactor:1,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"BlackBerry Z30",userAgent:"Mozilla/5.0 (BB10; Touch) AppleWebKit/537.10+ (KHTML, like Gecko) Version/10.0.9.2372 Mobile Safari/537.10+",viewport:{width:360,height:640,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"BlackBerry Z30 landscape",userAgent:"Mozilla/5.0 (BB10; Touch) AppleWebKit/537.10+ (KHTML, like Gecko) Version/10.0.9.2372 Mobile Safari/537.10+",viewport:{width:640,height:360,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy Note 3",userAgent:"Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",viewport:{width:360,height:640,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy Note 3 landscape",userAgent:"Mozilla/5.0 (Linux; U; Android 4.3; en-us; SM-N900T Build/JSS15J) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",viewport:{width:640,height:360,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy Note II",userAgent:"Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",viewport:{width:360,height:640,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy Note II landscape",userAgent:"Mozilla/5.0 (Linux; U; Android 4.1; en-us; GT-N7100 Build/JRO03C) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",viewport:{width:640,height:360,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy S III",userAgent:"Mozilla/5.0 (Linux; U; Android 4.0; en-us; GT-I9300 Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",viewport:{width:360,height:640,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy S III landscape",userAgent:"Mozilla/5.0 (Linux; U; Android 4.0; en-us; GT-I9300 Build/IMM76D) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30",viewport:{width:640,height:360,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy S5",userAgent:"Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:360,height:640,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy S5 landscape",userAgent:"Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:640,height:360,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy S8",userAgent:"Mozilla/5.0 (Linux; Android 7.0; SM-G950U Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36",viewport:{width:360,height:740,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy S8 landscape",userAgent:"Mozilla/5.0 (Linux; Android 7.0; SM-G950U Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36",viewport:{width:740,height:360,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy S9+",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; SM-G965U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36",viewport:{width:320,height:658,deviceScaleFactor:4.5,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy S9+ landscape",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; SM-G965U Build/R16NW) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.111 Mobile Safari/537.36",viewport:{width:658,height:320,deviceScaleFactor:4.5,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Galaxy Tab S4",userAgent:"Mozilla/5.0 (Linux; Android 8.1.0; SM-T837A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Safari/537.36",viewport:{width:712,height:1138,deviceScaleFactor:2.25,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Galaxy Tab S4 landscape",userAgent:"Mozilla/5.0 (Linux; Android 8.1.0; SM-T837A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.80 Safari/537.36",viewport:{width:1138,height:712,deviceScaleFactor:2.25,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPad",userAgent:"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",viewport:{width:768,height:1024,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPad landscape",userAgent:"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",viewport:{width:1024,height:768,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPad (gen 6)",userAgent:"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:768,height:1024,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPad (gen 6) landscape",userAgent:"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:1024,height:768,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPad (gen 7)",userAgent:"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:810,height:1080,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPad (gen 7) landscape",userAgent:"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:1080,height:810,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPad Mini",userAgent:"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",viewport:{width:768,height:1024,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPad Mini landscape",userAgent:"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",viewport:{width:1024,height:768,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPad Pro",userAgent:"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",viewport:{width:1024,height:1366,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPad Pro landscape",userAgent:"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko) Version/11.0 Mobile/15A5341f Safari/604.1",viewport:{width:1366,height:1024,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPad Pro 11",userAgent:"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:834,height:1194,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPad Pro 11 landscape",userAgent:"Mozilla/5.0 (iPad; CPU OS 12_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:1194,height:834,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 4",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53",viewport:{width:320,height:480,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 4 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 7_1_2 like Mac OS X) AppleWebKit/537.51.2 (KHTML, like Gecko) Version/7.0 Mobile/11D257 Safari/9537.53",viewport:{width:480,height:320,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 5",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1",viewport:{width:320,height:568,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 5 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1",viewport:{width:568,height:320,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 6",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:375,height:667,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 6 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:667,height:375,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 6 Plus",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:414,height:736,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 6 Plus landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:736,height:414,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 7",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:375,height:667,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 7 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:667,height:375,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 7 Plus",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:414,height:736,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 7 Plus landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:736,height:414,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 8",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:375,height:667,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 8 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:667,height:375,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 8 Plus",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:414,height:736,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 8 Plus landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:736,height:414,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone SE",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1",viewport:{width:320,height:568,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone SE landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1",viewport:{width:568,height:320,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone X",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:375,height:812,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone X landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",viewport:{width:812,height:375,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone XR",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Mobile/15E148 Safari/604.1",viewport:{width:414,height:896,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone XR landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 12_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/12.0 Mobile/15E148 Safari/604.1",viewport:{width:896,height:414,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 11",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",viewport:{width:414,height:828,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 11 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",viewport:{width:828,height:414,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 11 Pro",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",viewport:{width:375,height:812,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 11 Pro landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",viewport:{width:812,height:375,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 11 Pro Max",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",viewport:{width:414,height:896,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 11 Pro Max landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 13_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",viewport:{width:896,height:414,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 12",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:390,height:844,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 12 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:844,height:390,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 12 Pro",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:390,height:844,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 12 Pro landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:844,height:390,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 12 Pro Max",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:428,height:926,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 12 Pro Max landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:926,height:428,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 12 Mini",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:375,height:812,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 12 Mini landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:812,height:375,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 13",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:390,height:844,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 13 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:844,height:390,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 13 Pro",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:390,height:844,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 13 Pro landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:844,height:390,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 13 Pro Max",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:428,height:926,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 13 Pro Max landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:926,height:428,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 13 Mini",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:375,height:812,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 13 Mini landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",viewport:{width:812,height:375,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 14",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:390,height:663,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 14 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:750,height:340,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 14 Plus",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:428,height:745,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 14 Plus landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:832,height:378,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 14 Pro",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:393,height:659,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 14 Pro landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:734,height:343,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 14 Pro Max",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:430,height:739,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 14 Pro Max landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",viewport:{width:814,height:380,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 15",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:393,height:659,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 15 landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:734,height:343,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 15 Plus",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:430,height:739,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 15 Plus landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:814,height:380,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 15 Pro",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:393,height:659,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 15 Pro landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:734,height:343,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"iPhone 15 Pro Max",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:430,height:739,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"iPhone 15 Pro Max landscape",userAgent:"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",viewport:{width:814,height:380,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"JioPhone 2",userAgent:"Mozilla/5.0 (Mobile; LYF/F300B/LYF-F300B-001-01-15-130718-i;Android; rv:48.0) Gecko/48.0 Firefox/48.0 KAIOS/2.5",viewport:{width:240,height:320,deviceScaleFactor:1,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"JioPhone 2 landscape",userAgent:"Mozilla/5.0 (Mobile; LYF/F300B/LYF-F300B-001-01-15-130718-i;Android; rv:48.0) Gecko/48.0 Firefox/48.0 KAIOS/2.5",viewport:{width:320,height:240,deviceScaleFactor:1,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Kindle Fire HDX",userAgent:"Mozilla/5.0 (Linux; U; en-us; KFAPWI Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Silk/3.13 Safari/535.19 Silk-Accelerated=true",viewport:{width:800,height:1280,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Kindle Fire HDX landscape",userAgent:"Mozilla/5.0 (Linux; U; en-us; KFAPWI Build/JDQ39) AppleWebKit/535.19 (KHTML, like Gecko) Silk/3.13 Safari/535.19 Silk-Accelerated=true",viewport:{width:1280,height:800,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"LG Optimus L70",userAgent:"Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; LGMS323 Build/KOT49I.MS32310c) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:384,height:640,deviceScaleFactor:1.25,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"LG Optimus L70 landscape",userAgent:"Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; LGMS323 Build/KOT49I.MS32310c) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:640,height:384,deviceScaleFactor:1.25,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Microsoft Lumia 550",userAgent:"Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 550) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/14.14263",viewport:{width:640,height:360,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Microsoft Lumia 950",userAgent:"Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 950) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/14.14263",viewport:{width:360,height:640,deviceScaleFactor:4,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Microsoft Lumia 950 landscape",userAgent:"Mozilla/5.0 (Windows Phone 10.0; Android 4.2.1; Microsoft; Lumia 950) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Mobile Safari/537.36 Edge/14.14263",viewport:{width:640,height:360,deviceScaleFactor:4,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 10",userAgent:"Mozilla/5.0 (Linux; Android 6.0.1; Nexus 10 Build/MOB31T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Safari/537.36",viewport:{width:800,height:1280,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 10 landscape",userAgent:"Mozilla/5.0 (Linux; Android 6.0.1; Nexus 10 Build/MOB31T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Safari/537.36",viewport:{width:1280,height:800,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 4",userAgent:"Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:384,height:640,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 4 landscape",userAgent:"Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:640,height:384,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 5",userAgent:"Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:360,height:640,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 5 landscape",userAgent:"Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:640,height:360,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 5X",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:412,height:732,deviceScaleFactor:2.625,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 5X landscape",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; Nexus 5X Build/OPR4.170623.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:732,height:412,deviceScaleFactor:2.625,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 6",userAgent:"Mozilla/5.0 (Linux; Android 7.1.1; Nexus 6 Build/N6F26U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:412,height:732,deviceScaleFactor:3.5,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 6 landscape",userAgent:"Mozilla/5.0 (Linux; Android 7.1.1; Nexus 6 Build/N6F26U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:732,height:412,deviceScaleFactor:3.5,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 6P",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; Nexus 6P Build/OPP3.170518.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:412,height:732,deviceScaleFactor:3.5,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 6P landscape",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; Nexus 6P Build/OPP3.170518.006) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:732,height:412,deviceScaleFactor:3.5,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nexus 7",userAgent:"Mozilla/5.0 (Linux; Android 6.0.1; Nexus 7 Build/MOB30X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Safari/537.36",viewport:{width:600,height:960,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nexus 7 landscape",userAgent:"Mozilla/5.0 (Linux; Android 6.0.1; Nexus 7 Build/MOB30X) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Safari/537.36",viewport:{width:960,height:600,deviceScaleFactor:2,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nokia Lumia 520",userAgent:"Mozilla/5.0 (compatible; MSIE 10.0; Windows Phone 8.0; Trident/6.0; IEMobile/10.0; ARM; Touch; NOKIA; Lumia 520)",viewport:{width:320,height:533,deviceScaleFactor:1.5,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nokia Lumia 520 landscape",userAgent:"Mozilla/5.0 (compatible; MSIE 10.0; Windows Phone 8.0; Trident/6.0; IEMobile/10.0; ARM; Touch; NOKIA; Lumia 520)",viewport:{width:533,height:320,deviceScaleFactor:1.5,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Nokia N9",userAgent:"Mozilla/5.0 (MeeGo; NokiaN9) AppleWebKit/534.13 (KHTML, like Gecko) NokiaBrowser/8.5.0 Mobile Safari/534.13",viewport:{width:480,height:854,deviceScaleFactor:1,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Nokia N9 landscape",userAgent:"Mozilla/5.0 (MeeGo; NokiaN9) AppleWebKit/534.13 (KHTML, like Gecko) NokiaBrowser/8.5.0 Mobile Safari/534.13",viewport:{width:854,height:480,deviceScaleFactor:1,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Pixel 2",userAgent:"Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:411,height:731,deviceScaleFactor:2.625,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Pixel 2 landscape",userAgent:"Mozilla/5.0 (Linux; Android 8.0; Pixel 2 Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:731,height:411,deviceScaleFactor:2.625,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Pixel 2 XL",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 XL Build/OPD1.170816.004) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:411,height:823,deviceScaleFactor:3.5,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Pixel 2 XL landscape",userAgent:"Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 XL Build/OPD1.170816.004) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3765.0 Mobile Safari/537.36",viewport:{width:823,height:411,deviceScaleFactor:3.5,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Pixel 3",userAgent:"Mozilla/5.0 (Linux; Android 9; Pixel 3 Build/PQ1A.181105.017.A1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36",viewport:{width:393,height:786,deviceScaleFactor:2.75,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Pixel 3 landscape",userAgent:"Mozilla/5.0 (Linux; Android 9; Pixel 3 Build/PQ1A.181105.017.A1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.158 Mobile Safari/537.36",viewport:{width:786,height:393,deviceScaleFactor:2.75,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Pixel 4",userAgent:"Mozilla/5.0 (Linux; Android 10; Pixel 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36",viewport:{width:353,height:745,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Pixel 4 landscape",userAgent:"Mozilla/5.0 (Linux; Android 10; Pixel 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36",viewport:{width:745,height:353,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Pixel 4a (5G)",userAgent:"Mozilla/5.0 (Linux; Android 11; Pixel 4a (5G)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4812.0 Mobile Safari/537.36",viewport:{width:353,height:745,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Pixel 4a (5G) landscape",userAgent:"Mozilla/5.0 (Linux; Android 11; Pixel 4a (5G)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4812.0 Mobile Safari/537.36",viewport:{width:745,height:353,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Pixel 5",userAgent:"Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4812.0 Mobile Safari/537.36",viewport:{width:393,height:851,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Pixel 5 landscape",userAgent:"Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4812.0 Mobile Safari/537.36",viewport:{width:851,height:393,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}},{name:"Moto G4",userAgent:"Mozilla/5.0 (Linux; Android 7.0; Moto G (4)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4812.0 Mobile Safari/537.36",viewport:{width:360,height:640,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!1}},{name:"Moto G4 landscape",userAgent:"Mozilla/5.0 (Linux; Android 7.0; Moto G (4)) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4812.0 Mobile Safari/537.36",viewport:{width:640,height:360,deviceScaleFactor:3,isMobile:!0,hasTouch:!0,isLandscape:!0}}],lb={};for(const r of YS)lb[r.name]=r;Object.freeze(lb);/**
 * @license
 * Copyright 2025 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */const Ap=new JS,{connect:A3,history:T3,launch:P3,limits:$3,sessions:R3,acquire:F3}=Ap;function Ii(r,t,e){const n=ZS(r),i=ek(r,e),s=ik(r),o=ak(r,n),c=hk(r,s.paragraphCount),l=gk(r),d=wk(r),u=vk(r,t),h=xk(r),p=Ak(r),f=uk(r);return{url:t,html:r,navigation:n,accessibility:i,content:s,forms:o,visuals:c,realWorldMatch:l,userControlFreedom:d,navigationFreedom:u,languageConsistency:h,webStandardsCompliance:p,helpDocumentation:f}}function ZS(r){const t=r.match(/<nav[^>]*>/gi)||[],e=r.match(/<a\s+[^>]*href/gi)||[],n=/breadcrumb/i.test(r)||/location[_-]?wrap/i.test(r)||/현재[\s]*위치/i.test(r)||/navi[_-]?home/i.test(r)||/(class|id)\s*=\s*["'][^"']*path[^"']*["']/i.test(r)||/(class|id)\s*=\s*["'][^"']*location[^"']*["']/i.test(r)||/>\s*Home\s*<.*?>\s*[>›▶]\s*</i.test(r),i=/type\s*=\s*["']search["']/i.test(r)||/role\s*=\s*["']search["']/i.test(r)||/name\s*=\s*["'](search|query|keyword|searchWord|q|kwd)[^"']*["']/i.test(r)||/(class|id)\s*=\s*["'][^"']*search[^"']*["']/i.test(r)||/placeholder\s*=\s*["'][^"']*검색[^"']*["']/i.test(r)||/placeholder\s*=\s*["'][^"']*search[^"']*["']/i.test(r)||/<button[^>]*>[^<]*검색[^<]*<\/button>/i.test(r)||/<button[^>]*>[^<]*search[^<]*<\/button>/i.test(r)||/<a[^>]*href\s*=\s*["'][^"']*(search|\/search\.)[^"']*["'][^>]*>[^<]*검색[^<]*<\/a>/i.test(r)||/<input[^>]*[^>]*>[\s\S]{0,100}검색/i.test(r),o=(r.match(/<ul[^>]*>[\s\S]*?<li[^>]*>[\s\S]*?<ul/gi)||[]).length>0?2:1;return{menuCount:t.length,linkCount:e.length,breadcrumbExists:n,searchExists:i,depthLevel:o}}function ek(r,t){const e=r.match(/<img[^>]*>/gi)||[],n=r.match(/<img[^>]*alt\s*=/gi)||[],i=r.match(/aria-label\s*=/gi)||[],s=r.match(/<h[1-6][^>]*>/gi)||[],o=/<html[^>]*lang\s*=/i.test(r),c=/skip[\s-]*(to[\s-]*)?content|skip[\s-]*navigation/i.test(r),l=tk(r),d=db(r);t&&(l.dynamicDetection=t,t.loadingScreenFound&&(l.score+=3,l.score=Math.min(l.score,10),l.hasLoadingUI=!0,l.details.push(`동적 분석: 로딩 UI 발견 (지속시간: ${t.loadingDuration}ms)`),l.details.push(...t.loadingElements.map(f=>`동적 요소: ${f}`))));const u=l.hasLoadingUI,h=e.length>0?n.length/e.length:1,p=s.length>0;return{altTextRatio:h,ariaLabelCount:i.length,headingStructure:p,langAttribute:o,skipLinkExists:c,loadingIndicatorExists:u,loadingUI:l,actionFeedback:d}}function tk(r){const t=[],e={ariaAttributes:0,progressTags:0,loadingClasses:0,loadingText:0,spinAnimations:0,loadingIcons:0};/aria-busy\s*=\s*["']true["']/i.test(r)&&(e.ariaAttributes++,t.push('aria-busy="true" 발견')),/role\s*=\s*["']status["']/i.test(r)&&(e.ariaAttributes++,t.push('role="status" 발견')),/role\s*=\s*["']progressbar["']/i.test(r)&&(e.ariaAttributes++,t.push('role="progressbar" 발견')),/aria-live\s*=\s*["'](polite|assertive)["']/i.test(r)&&(e.ariaAttributes++,t.push("aria-live 발견"));const n=r.match(/<progress[^>]*>/gi)||[],i=r.match(/<meter[^>]*>/gi)||[];e.progressTags=n.length+i.length,n.length>0&&t.push(`<progress> 태그 ${n.length}개 발견`),i.length>0&&t.push(`<meter> 태그 ${i.length}개 발견`),[{pattern:/class\s*=\s*["'][^"']*\bloading\b[^"']*["']/i,name:"loading 클래스"},{pattern:/class\s*=\s*["'][^"']*\bloader\b[^"']*["']/i,name:"loader 클래스"},{pattern:/class\s*=\s*["'][^"']*\bspinner\b[^"']*["']/i,name:"spinner 클래스"},{pattern:/class\s*=\s*["'][^"']*\bskeleton\b[^"']*["']/i,name:"skeleton 클래스"},{pattern:/class\s*=\s*["'][^"']*\bplaceholder\b[^"']*["']/i,name:"placeholder 클래스"}].forEach(({pattern:u,name:h})=>{u.test(r)&&(e.loadingClasses++,t.push(`${h} 발견`))}),[{pattern:/로딩\s*(중|...)/i,name:'한글 "로딩 중"'},{pattern:/처리\s*(중|...)/i,name:'한글 "처리 중"'},{pattern:/잠시만\s*기다려/i,name:'한글 "잠시만 기다려"'},{pattern:/불러오는\s*중/i,name:'한글 "불러오는 중"'},{pattern:/loading/i,name:'영문 "loading"'},{pattern:/please\s+wait/i,name:'영문 "please wait"'},{pattern:/processing/i,name:'영문 "processing"'}].forEach(({pattern:u,name:h})=>{u.test(r)&&(e.loadingText++,t.push(`${h} 텍스트 발견`))}),/@keyframes\s+(spin|rotate|loading|pulse)/i.test(r)&&(e.spinAnimations++,t.push("CSS 애니메이션 키프레임 발견")),/animation\s*:\s*[^;]*(spin|rotate|loading|pulse)/i.test(r)&&(e.spinAnimations++,t.push("CSS 애니메이션 속성 발견")),[{pattern:/fa-spinner|fa-circle-notch|fa-sync|fa-cog/i,name:"Font Awesome 로딩 아이콘"},{pattern:/material-icons[^>]*>\s*(hourglass|sync|autorenew|loop|cached)/i,name:"Material Icons 로딩 아이콘"}].forEach(({pattern:u,name:h})=>{u.test(r)&&(e.loadingIcons++,t.push(`${h} 발견`))});let l=0;l+=Math.min(e.ariaAttributes*1,4),l+=Math.min(e.progressTags*1.5,3),l+=Math.min(e.loadingClasses*.5,2.5),l+=Math.min(e.loadingText*.3,2),l+=Math.min(e.spinAnimations*.5,1),l+=Math.min(e.loadingIcons*1,1),l=Math.min(l,10);const d=l>=2;return{score:l,hasLoadingUI:d,staticPatterns:e,details:t}}function db(r){const t=[],n=[/:hover/gi,/\.hover|--hover|_hover/gi,/class\s*=\s*["'][^"']*hover[^"']*["']/gi].reduce((g,E)=>{const k=r.match(E)||[];return g+k.length},0),s=[/:focus(-visible|-within)?/gi,/\.focus|--focus|_focus/gi,/class\s*=\s*["'][^"']*focus[^"']*["']/gi].reduce((g,E)=>{const k=r.match(E)||[];return g+k.length},0),c=[/:active/gi,/\.active|--active|_active/gi,/class\s*=\s*["'][^"']*active[^"']*["']/gi].reduce((g,E)=>{const k=r.match(E)||[];return g+k.length},0),d=[/transition\s*:/gi,/transform\s*:/gi,/animation\s*:/gi,/@keyframes/gi].reduce((g,E)=>{const k=r.match(E)||[];return g+k.length},0),u=Math.min(n*.3+s*.4+c*.2+d*.1,3);n>0&&t.push(`✓ 호버 효과: ${n}개`),s>0&&t.push(`✓ 포커스 효과: ${s}개`),c>0&&t.push(`✓ 클릭 액티브 효과: ${c}개`),d>0&&t.push(`✓ CSS 트랜지션/애니메이션: ${d}개`);const h=(r.match(/aria-expanded\s*=\s*["'](true|false)["']/gi)||[]).length,p=(r.match(/aria-pressed\s*=\s*["'](true|false|mixed)["']/gi)||[]).length,f=(r.match(/aria-selected\s*=\s*["'](true|false)["']/gi)||[]).length,y=(r.match(/aria-checked\s*=\s*["'](true|false|mixed)["']/gi)||[]).length,w=(r.match(/<details[^>]*>/gi)||[]).length,b=(r.match(/<dialog[^>]*>/gi)||[]).length,C=Math.min(h*.5+p*.4+f*.4+y*.3+w*.6+b*.8,4);h>0&&t.push(`✓ 접기/펼치기 (aria-expanded): ${h}개`),p>0&&t.push(`✓ 토글 버튼 (aria-pressed): ${p}개`),f>0&&t.push(`✓ 선택 가능 요소 (aria-selected): ${f}개`),y>0&&t.push(`✓ 체크 상태 (aria-checked): ${y}개`),w>0&&t.push(`✓ <details> 요소: ${w}개`),b>0&&t.push(`✓ <dialog> 모달: ${b}개`);const A=(r.match(/autocomplete\s*=\s*["'][^"']+["']/gi)||[]).length,T=(r.match(/inputmode\s*=\s*["'][^"']+["']/gi)||[]).length,M=(r.match(/<input[^>]*list\s*=\s*["'][^"']+["']/gi)||[]).length,D=(r.match(/role\s*=\s*["']combobox["']/gi)||[]).length,U=(r.match(/aria-live\s*=\s*["'](polite|assertive|off)["']/gi)||[]).length,O=(r.match(/role\s*=\s*["'](alert|status)["']/gi)||[]).length,K=(r.match(/aria-busy\s*=\s*["']true["']/gi)||[]).length,F=(r.match(/role\s*=\s*["']progressbar["']/gi)||[]).length,H=Math.min(A*.3+T*.2+M*.5+D*.6+U*.4+O*.3+K*.5+F*.6,3);A>0&&t.push(`✓ 자동완성 (autocomplete): ${A}개`),T>0&&t.push(`✓ 모바일 키패드 최적화 (inputmode): ${T}개`),M>0&&t.push(`✓ 데이터리스트 (datalist): ${M}개`),D>0&&t.push(`✓ 콤보박스 (role=combobox): ${D}개`),U>0&&t.push(`✓ 실시간 알림 (aria-live): ${U}개`),O>0&&t.push(`✓ 경고/상태 (role=alert/status): ${O}개`),K>0&&t.push(`✓ 로딩 상태 (aria-busy): ${K}개`),F>0&&t.push(`✓ 진행 상태 (role=progressbar): ${F}개`);const B=[...r.matchAll(/<(button|a)[^>]*>/gi),...r.matchAll(/<input[^>]*type\s*=\s*["'](button|submit|reset)["']/gi),...r.matchAll(/role\s*=\s*["']button["']/gi)].length,P=n+s+c+h+p+f,N=B>0?Math.round(P/B*100)/100:0,j=Math.min(u+C+H,10),W=j>=2;return{score:j,hasActionFeedback:W,immediateFeedback:{hoverEffects:n,focusEffects:s,activeEffects:c,transitions:d,microInteractions:Math.round(u*10)/10},stateManagement:{ariaExpanded:h,ariaPressed:p,ariaSelected:f,ariaChecked:y,detailsElements:w,dialogElements:b,stateInteractionScore:Math.round(C*10)/10},userAssistance:{autocomplete:A,inputmode:T,datalist:M,combobox:D,ariaLive:U,roleAlert:O,ariaBusy:K,progressbar:F,assistanceScore:Math.round(H*10)/10},interactionDensity:N,details:t}}function nk(r){return db(r).hasActionFeedback}function rk(r,t,e){const n=r.replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim(),i=n.split(/\s+/).filter(U=>U.length>0),s=i.length;if(s<50)return{score:0,grade:"N/A",density:{wordsPerParagraph:0,totalWords:s,rating:"insufficient"},conciseness:{avgSentenceLength:0,rating:"insufficient"},redundancy:{repetitivePatterns:0,duplicateCount:0,rating:"insufficient"},essentialRatio:{headingToContentRatio:0,rating:"insufficient"},issues:[{type:"INSUFFICIENT_CONTENT",severity:"HIGH",message:`텍스트가 ${s}단어로 너무 적어 자동 판단 불가 (최소 50단어 필요) → UI/UX 전문가가 직접 확인 필요`}],strengths:[]};let o=100;const c=[],l=[],u=(n.match(/[.!?。！？]+/g)||[]).length||1,h=t>0?s/t:0;let p="optimal";h>=50&&h<=150?(p="optimal",l.push("적절한 정보 밀도 (50-150 단어/문단)")):h<50&&h>0?(p="sparse",o-=15,c.push({type:"SPARSE_CONTENT",severity:"MEDIUM",message:`평균 ${Math.round(h)}단어/문단 → 정보 부족, 50단어 이상 권장`})):h>150&&(p="dense",o-=10,c.push({type:"DENSE_CONTENT",severity:"LOW",message:`평균 ${Math.round(h)}단어/문단 → 너무 빽빽, 150단어 이하 권장`}));const f=s/u;let y="moderate";f>=15&&f<=25?(y="concise",l.push("간결한 문장 (15-25 단어/문장)")):f<15?(y="concise",l.push("매우 간결한 문장 (15 단어 미만)")):f>25&&(y="verbose",o-=15,c.push({type:"VERBOSE_SENTENCES",severity:"MEDIUM",message:`평균 ${Math.round(f)}단어/문장 → 장황함, 25단어 이하 권장`}));const w={};i.forEach(U=>{const O=U.toLowerCase().replace(/[^a-z가-힣0-9]/g,"");O.length>=5&&(w[O]=(w[O]||0)+1)});const b=Object.values(w).filter(U=>U>3).length,C=Object.values(w).reduce((U,O)=>U+(O>3?O-3:0),0);let A="low";b===0?(A="low",l.push("중복 내용 없음 → 핵심 정보 집중")):b<=3?A="medium":(A="high",o-=20,c.push({type:"HIGH_REDUNDANCY",severity:"HIGH",message:`반복 단어 ${b}개 발견 (총 ${C}회 중복) → 중복 제거 필요`}));const T=e>0?t/e:t;let M="balanced";T>=2&&T<=5?(M="balanced",l.push("균형잡힌 구조 (헤딩 1개당 2-5 문단)")):T<2&&e>0?(M="heading-heavy",o-=10,c.push({type:"HEADING_HEAVY",severity:"LOW",message:`헤딩이 많고 내용 적음 (헤딩 1개당 ${T.toFixed(1)} 문단)`})):(T>5||e===0)&&(M="content-heavy",o-=10,c.push({type:"CONTENT_HEAVY",severity:"LOW",message:`헤딩 부족, 내용 과다 (헤딩 1개당 ${T.toFixed(1)} 문단) → 헤딩 추가 권장`})),o=Math.max(0,Math.min(100,o));let D;return o>=85?D="A":o>=70?D="B":o>=55?D="C":D="D",{score:o,grade:D,density:{wordsPerParagraph:Math.round(h*10)/10,totalWords:s,rating:p},conciseness:{avgSentenceLength:Math.round(f*10)/10,rating:y},redundancy:{repetitivePatterns:b,duplicateCount:C,rating:A},essentialRatio:{headingToContentRatio:Math.round(T*10)/10,rating:M},issues:c,strengths:l}}function ik(r){const t=(r.match(/<h[1-6][^>]*>/gi)||[]).length,e=(r.match(/<p[^>]*>/gi)||[]).length,n=(r.match(/<ul[^>]*>|<ol[^>]*>/gi)||[]).length,i=(r.match(/<table[^>]*>/gi)||[]).length;let s;const c=r.replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim().split(/\s+/).filter(l=>l.length>0);console.log(`[DEBUG] N8.1 텍스트 추출: ${c.length}단어, 문단 ${e}개`);try{const l=e>0?e:Math.max(1,Math.floor(c.length/100));s=rk(r,l,t),console.log(`[DEBUG] N8.1 textQuality 분석 완료: score=${s==null?void 0:s.score}, grade=${s==null?void 0:s.grade}`)}catch(l){console.error("[N8.1 TextQuality] Analysis failed:",l)}return{headingCount:t,paragraphCount:e,listCount:n,tableCount:i,textQuality:s}}function sk(r){const t=/<form[^>]*>[\s\S]*?<\/form>/gi,e=r.match(t)||[];if(e.length===0)return{totalForms:0,formsWithValidation:0,validationRatio:100,features:{hasAriaInvalid:0,hasErrorMessages:0,hasLiveRegion:0,hasBrowserValidation:0},score:30,quality:"none"};let n=0;const i={hasAriaInvalid:0,hasErrorMessages:0,hasLiveRegion:0,hasBrowserValidation:0};e.forEach(l=>{let d=!1;/novalidate/i.test(l)||(d=!0,i.hasBrowserValidation++),/aria-invalid\s*=/i.test(l)&&(d=!0,i.hasAriaInvalid++),/role\s*=\s*["']alert["']|class\s*=\s*["'][^"']*error[^"']*["']|id\s*=\s*["'][^"']*error[^"']*["']|aria-describedby\s*=\s*["'][^"']*error[^"']*["']/i.test(l)&&(d=!0,i.hasErrorMessages++),/aria-live\s*=\s*["'](polite|assertive)["']/i.test(l)&&(d=!0,i.hasLiveRegion++),d&&n++});const s=n/e.length*100;let o=Math.round(s/100*30),c;return s===0?c="none":s<40?c="minimal":s<60?c="basic":s<85?c="good":c="excellent",{totalForms:e.length,formsWithValidation:n,validationRatio:Math.round(s),features:i,score:o,quality:c}}function ak(r,t){const e=r.match(/<form[^>]*>/gi)||[],n=r.match(/<input[^>]*>/gi)||[],i=r.match(/<label[^>]*>/gi)||[],s=/required|pattern|minlength|maxlength/i.test(r),o=nk(r),c=sk(r),l=n.length>0?i.length/n.length:1,d=ok(r),u=ck(r,t),h=lk(r),p=dk(r);return{formCount:e.length,inputCount:n.length,labelRatio:l,validationExists:s,interactiveFeedbackExists:o,realtimeValidation:c,constraintQuality:d,memoryLoadSupport:u,flexibilityEfficiency:h,errorRecovery:p}}function ok(r){const t=r.match(/<input[^>]*>/gi)||[],e=r.match(/<textarea[^>]*>/gi)||[],n=r.match(/<select[^>]*>/gi)||[],i=t.length+e.length+n.length;if(i===0)return{totalInputs:0,hasExplicitRules:0,hasExamples:0,hasRequiredMarker:0,quality:"none",score:0,details:["입력 필드가 없어 제약조건 평가가 불가능합니다."]};const s=[],o=[/\d+자\s*이상/gi,/\d+자\s*이하/gi,/영문/gi,/숫자/gi,/특수문자/gi,/형식/gi,/필수/gi,/조건/gi,/입력\s*방법/gi,/\d+글자/gi,/[a-zA-Z가-힣]+\s*포함/gi];let c=0;o.forEach(C=>{const A=r.match(C);A&&(c+=A.length,s.push(`명시적 규칙 발견: ${C.source} (${A.length}개)`))});const l=[/placeholder\s*=\s*["'][^"']{3,}["']/gi,/aria-describedby/gi,/예:/gi,/example:/gi,/e\.g\./gi,/예시/gi,/\(예:\s*/gi,/ex\)/gi];let d=0;l.forEach(C=>{const A=r.match(C);A&&(d+=A.length,s.push(`예시 제공 발견: ${C.source} (${A.length}개)`))});const u=[/\*/g,/required/gi,/aria-required\s*=\s*["']true["']/gi,/필수\s*항목/gi,/필수\s*입력/gi,/<span[^>]*class\s*=\s*["'][^"']*required[^"']*["']/gi];let h=0;u.forEach(C=>{const A=r.match(C);A&&(h+=A.length,s.push(`필수 표시 발견: ${C.source} (${A.length}개)`))});const p=Math.min(35,c/i*35),f=Math.min(30,d/i*30),y=Math.min(35,h/i*35),w=Math.round(p+f+y);let b;return w>=90?b="excellent":w>=75?b="good":w>=60?b="basic":w>=40?b="minimal":b="poor",s.unshift(`총 입력 필드: ${i}개, 명시적 규칙: ${c}개, 예시: ${d}개, 필수 표시: ${h}개`),{totalInputs:i,hasExplicitRules:c,hasExamples:d,hasRequiredMarker:h,quality:b,score:w,details:s}}function ck(r,t){const e=[],n=t.breadcrumbExists;n&&e.push("✅ Breadcrumb 존재: 현재 위치 파악 용이");const i=[/autocomplete\s*=\s*["'](?:on|name|email|username|tel|address-line1|postal-code|cc-number|cc-exp|cc-csc|bday|sex|url|photo)["']/gi];let s=0;i.forEach(C=>{const A=r.match(C);A&&(s+=A.length,e.push(`✅ autocomplete 속성 발견: ${A.length}개 (예: email, name, tel 등)`))});const o=[/<input[^>]*\svalue\s*=\s*["'][^"']+["'][^>]*>/gi,/<option[^>]*\sselected[^>]*>/gi,/<input[^>]*type\s*=\s*["'](?:checkbox|radio)["'][^>]*\schecked[^>]*>/gi];let c=0;o.forEach((C,A)=>{const T=r.match(C);if(T){c+=T.length;const M=A===0?"input value":A===1?"selected option":"checked";e.push(`✅ 기본값 설정 발견: ${M} ${T.length}개`)}});const l=/<datalist[^>]*>/gi,d=r.match(l),u=d?d.length:0;u>0&&e.push(`✅ datalist 자동완성 제안: ${u}개`);const h=n?40:0,p=Math.min(30,s/3*30),f=Math.min(20,c/2*20),y=Math.min(10,u*10),w=Math.round(h+p+f+y);let b;return w>=80?b="excellent":w>=60?b="good":w>=40?b="basic":w>=20?b="minimal":b="none",e.unshift(`총점: ${w}/100 (Breadcrumb ${h}점 + autocomplete ${Math.round(p)}점 + 기본값 ${Math.round(f)}점 + datalist ${y}점)`),{hasBreadcrumb:n,autocompleteCount:s,defaultValueCount:c,datalistCount:u,score:w,quality:b,details:e}}function lk(r){const t=[];let e=0;[/accesskey\s*=\s*["'][^"']+["']/gi,/\b(?:ctrl|alt|shift)\s*\+\s*[a-z0-9]/gi,/단축키|shortcut|keyboard/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(e=15,t.push(`✅ 키보드 단축키: ${P.length}개 발견`))}),e===0&&t.push("❌ 키보드 단축키 미제공 (정부 90% 미제공)");let i=0;[/즐겨찾기|favorite|bookmark/gi,/자주\s*찾는|빠른\s*메뉴|quick\s*menu/gi,/마이\s*메뉴|my\s*menu/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(i=12,t.push("✅ 빠른 메뉴/즐겨찾기: 발견"))}),i===0&&t.push("❌ 빠른 메뉴/즐겨찾기 미제공");let o=0;[/최근\s*(?:본|이용|방문|검색)/gi,/recent(?:ly)?\s*(?:viewed|visited|searched)/gi,/history/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(o=8,t.push("✅ 최근 이용 기록: 발견"))}),o===0&&t.push("❌ 최근 이용 기록 미제공 (정부 62% 미제공, 재탐색 불만)");let l=0;[/<a[^>]*href\s*=\s*["']#(?:content|main|skip)["'][^>]*>/gi,/본문\s*바로가기|skip\s*to\s*(?:content|main)/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(l=5,t.push("✅ Skip Navigation: 발견"))}),l===0&&t.push("⚠️ Skip Navigation 미제공");const u=e+i+o+l;let h=0;[/설정|환경설정|내\s*정보|마이페이지/gi,/settings?|preferences|my\s*page|profile/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(h=15,t.push("✅ 설정 개인화: 발견"))}),h===0&&t.push("❌ 설정 개인화 미제공 (정부 85% 미제공)");let f=0;[/글자\s*크기|font\s*size/gi,/\b(?:text|font)-(?:size|scale|zoom)/gi,/확대|축소|zoom/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(f=10,t.push("✅ 글자 크기 조절: 발견"))}),f===0&&t.push("❌ 글자 크기 조절 미제공 (정부 70% 미제공, 고령층 불편)");let w=0;[/다크\s*모드|dark\s*mode/gi,/테마|theme/gi,/\bmode\s*=\s*["'](?:dark|light)["']/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(w=5,t.push("✅ 다크모드/테마: 발견"))}),w===0&&t.push("⚠️ 다크모드/테마 미제공");let C=0;[/<select[^>]*>(?:[^<]*<option[^>]*>)*[^<]*(?:한국어|english|日本語|中文)[^<]*<\/option>/gi,/언어\s*선택|language\s*select/gi,/\blang\s*=\s*["'](?:ko|en|ja|zh)["']/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(C=5,t.push("✅ 언어 선택: 발견"))}),C===0&&t.push("ℹ️ 언어 선택 미제공 (필요 시 다국어 지원)");const T=h+f+w+C;let M=0;[/전체\s*선택|select\s*all/gi,/<input[^>]*type\s*=\s*["']checkbox["'][^>]*(?:id|name)\s*=\s*["'](?:selectAll|checkAll)["']/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(M=15,t.push("✅ 전체 선택 기능: 발견"))}),M===0&&t.push("❌ 전체 선택 기능 미제공 (정부 78% 미제공)");let U=0;[/일괄|batch|bulk/gi,/선택\s*(?:삭제|수정|다운로드)/gi].forEach(B=>{const P=r.match(B);P&&P.length>0&&(U=10,t.push("✅ 일괄 작업 버튼: 발견"))}),U===0&&t.push("❌ 일괄 작업 버튼 미제공");const K=M+U,F=u+T+K;let H;return F>=85?H="excellent":F>=70?H="good":F>=50?H="basic":F>=30?H="minimal":F>0?H="poor":H="none",t.unshift(`총점: ${F}/100 (가속장치 ${u}점 + 개인화 ${T}점 + 일괄처리 ${K}점)`),{accelerators:{keyboardShortcuts:e,quickMenu:i,recentItems:o,skipNavigation:l,score:u},personalization:{settings:h,fontSize:f,theme:w,language:C,score:T},batchOperations:{selectAll:M,bulkActions:U,score:K},score:F,quality:H,details:t}}function dk(r){const t=[],e=[...Array.from(r.matchAll(/<[^>]+(?:role\s*=\s*["']alert["']|class\s*=\s*["'][^"']*\b(?:error|invalid|danger)[^"']*["']|aria-invalid\s*=\s*["']true["'])[^>]*>/gi))],n=[];if((r.match(/<[^>]+(?:class|role)\s*=\s*["'][^"']*\b(?:error|invalid|alert)[^"']*["'][^>]*>([^<]+)<\//gi)||[]).forEach(N=>{const j=N.match(/>([^<]+)</);j&&j[1].trim().length>0&&n.push(j[1].trim())}),e.length===0&&n.length===0)return{recognition:{colorEmphasis:0,iconUsage:0,ariaSupport:0,positioning:0,score:0},diagnosis:{userLanguage:0,specificReason:0,friendlyTone:0,score:0},recovery:{actionButtons:0,helpLinks:0,guidanceClarity:0,score:0},score:0,quality:"none",details:["ℹ️ 현재 오류 요소 없음 - 평가 대상 없음"]};let s=0;[/(?:color|border-color|background-color)\s*:\s*(?:red|#[fF][0-9a-fA-F]{5}|rgb\s*\(\s*2[0-9]{2}|rgba\s*\(\s*2[0-9]{2})/gi,/class\s*=\s*["'][^"']*\b(?:text-red|bg-red|border-red|text-danger|bg-danger)[^"']*["']/gi].forEach(N=>{const j=r.match(N)||[];j.length>0&&(s=Math.min(10,j.length*3),t.push(`✅ 색상 강조: ${j.length}개 요소`))});let c=0;[/<i\s+[^>]*class\s*=\s*["'][^"']*\b(?:fa-exclamation|fa-warning|fa-error|alert-icon)[^"']*["']/gi,/<svg[^>]*>(?:[^<]*<path[^>]*>[^<]*)*<\/svg>/gi,/⚠️|❌|🚫|⛔/g].forEach(N=>{const j=r.match(N)||[];j.length>0&&(c=Math.min(10,j.length*4),t.push(`✅ 오류 아이콘: ${j.length}개`))});let d=0;const u=(r.match(/(?:role\s*=\s*["']alert["']|aria-invalid\s*=\s*["']true["']|aria-errormessage)/gi)||[]).length;u>0&&(d=5,t.push(`✅ ARIA 오류 지원: ${u}개`));let h=0;e.length>0&&(h=5,t.push(`✅ 오류 요소 위치: ${e.length}개 배치`));const p=s+c+d+h;let f=20,y=0;const w=/\b(?:404|500|error code|exception|null|undefined|invalid input|database|server error|syntax error|timeout)/gi;n.forEach(N=>{const j=N.match(w);j&&(y+=j.length,f=Math.max(0,20-y*7),t.push(`❌ 전문 용어 사용: "${N.substring(0,50)}..." (정부 72% 불만)`))}),y===0&&n.length>0&&t.push("✅ 사용자 친화 언어 사용");let b=0,C=0;n.forEach(N=>{const j=/이메일|비밀번호|전화번호|파일|날짜|이름|주소|카드/gi.test(N),W=/형식|길이|크기|조건|이상|이하|필수|올바르지|입력하세요/gi.test(N);j&&W?(C++,t.push(`✅ 구체적 원인: "${N.substring(0,50)}..."`)):!j&&!W&&t.push(`❌ 모호한 오류: "${N.substring(0,50)}..." (정부 68% 불만)`)}),n.length>0&&(b=Math.round(C/n.length*15));let A=5;const T=/잘못|틀렸|invalid|wrong|fail|incorrect/gi;n.forEach(N=>{T.test(N)&&(A=0,t.push(`⚠️ 비친화적 톤: "${N.substring(0,50)}..."`))});const M=f+b+A;let D=0;[/다시\s*시도|재시도|retry/gi,/비밀번호\s*찾기|아이디\s*찾기|find\s*password/gi,/문의|도움말|help|support|contact/gi].forEach(N=>{const j=r.match(N)||[];j.length>0&&(D=Math.min(15,j.length*5),t.push(`✅ 복구 액션: ${j.length}개 발견`))}),D===0&&t.push("❌ 복구 방법 없음 (정부 65% 불만)");let O=0;[/<a[^>]+href\s*=\s*["'][^"']*(?:help|faq|support|guide)["'][^>]*>/gi,/도움말|FAQ|가이드|안내/gi].forEach(N=>{const j=r.match(N)||[];j.length>0&&(O=10,t.push(`✅ 도움말 링크: ${j.length}개`))});let F=0;n.forEach(N=>{/다시|재입력|확인|변경|선택|입력하세요/gi.test(N)&&(F=5,t.push(`✅ 해결 방법 제시: "${N.substring(0,50)}..."`))});const H=D+O+F,B=p+M+H;let P="none";return B>=80?P="excellent":B>=60?P="good":B>=40?P="basic":B>=20?P="minimal":B>0&&(P="poor"),t.unshift(`총점: ${B}/100 (인식 ${p}/30 + 진단 ${M}/40 + 복구 ${H}/30)`),{recognition:{colorEmphasis:s,iconUsage:c,ariaSupport:d,positioning:h,score:p},diagnosis:{userLanguage:f,specificReason:b,friendlyTone:A,score:M},recovery:{actionButtons:D,helpLinks:O,guidanceClarity:F,score:H},score:B,quality:P,details:t}}function uk(r){const t=[];let e=0;const n=r.match(/<header[^>]*>[\s\S]*?<\/header>|<footer[^>]*>[\s\S]*?<\/footer>/gi)||[],i=/help|도움말|faq|support|지원|안내|guide|가이드/i;n.forEach(O=>{const K=(O.match(/<a[^>]+>/gi)||[]).filter(F=>i.test(F));K.length>0&&(e=10,t.push(`✅ 헤더/푸터 도움말 링크: ${K.length}개 발견`))}),e===0&&t.push("❌ 헤더/푸터 도움말 링크 미제공 (정부 95% 헤더 배치 기준)");let s=0;[/<input[^>]+type\s*=\s*["']search["'][^>]*>/gi,/<input[^>]+(?:placeholder|name|id)\s*=\s*["'][^"']*(search|검색)[^"']*["'][^>]*>/gi,/<form[^>]+(?:class|id)\s*=\s*["'][^"']*(search|검색)[^"']*["'][^>]*>/gi].forEach(O=>{const K=r.match(O);K&&K.length>0&&(s=8,t.push("✅ 검색 기능: 제공됨"))}),s===0&&t.push("❌ 검색 기능 미제공");let c=0;[/<(?:section|div|article)[^>]*(?:class|id)\s*=\s*["'][^"']*(faq|자주묻는질문|질문답변)[^"']*["'][^>]*>/gi,/FAQ|자주\s*묻는\s*질문|Q&A|질문과\s*답변/gi].forEach(O=>{const K=r.match(O);K&&K.length>0&&(c=7,t.push(`✅ FAQ 제공: ${K.length}개 영역 발견`))}),c===0&&t.push("❌ FAQ 미제공");const d=e+s+c;let u=0;const h=r.match(/<(?:ol|ul)[^>]*>[\s\S]*?<\/(?:ol|ul)>/gi)||[],p=/단계|step|절차|과정|방법|순서/i,f=h.filter(O=>(O.match(/<li[^>]*>/gi)||[]).length>=3&&p.test(O));f.length>=5?(u=10,t.push(`✅ 리스트 구조 우수: ${f.length}개 단계별 설명`)):f.length>=3?(u=7,t.push(`⚠️ 리스트 구조 보통: ${f.length}개`)):f.length>0?(u=4,t.push(`⚠️ 리스트 구조 부족: ${f.length}개`)):t.push('❌ 리스트 구조 미제공 (정부 63% "따라할 수 없다" 불만)');let y=0;const b=(r.match(/<img[^>]*>/gi)||[]).filter(O=>/guide|tutorial|example|설명|안내|예시|스크린샷|screenshot/i.test(O));b.length>=5?(y=8,t.push(`✅ 이미지/스크린샷: ${b.length}개 제공`)):b.length>=3?(y=5,t.push(`⚠️ 이미지/스크린샷: ${b.length}개 (부족)`)):b.length>0?(y=3,t.push(`⚠️ 이미지/스크린샷: ${b.length}개 (매우 부족)`)):t.push('❌ 이미지/스크린샷 미제공 (정부 68% "이해할 수 없다" 불만)');let C=0;const A=/예시|example|샘플|sample|예제|케이스|case/gi,T=r.match(A)||[];T.length>=5?(C=7,t.push(`✅ 예시/샘플: ${T.length}개 제공`)):T.length>=3?(C=4,t.push(`⚠️ 예시/샘플: ${T.length}개 (부족)`)):T.length>0?(C=2,t.push(`⚠️ 예시/샘플: ${T.length}개 (매우 부족)`)):t.push("❌ 예시/샘플 미제공");const M=u+y+C,D=d+M;let U;return D>=45?U="excellent":D>=35?U="good":D>=25?U="basic":D>=15?U="minimal":D>0?U="poor":U="none",t.unshift(`총점: ${D}/50 (접근성 ${d}/25 + 품질 ${M}/25)`),{accessibility:{headerFooterLinks:e,searchFunction:s,faqExists:c,score:d},quality:{listStructure:u,visualAids:y,examples:C,score:M},total_score:D,status:U,details:t}}function hk(r,t=0){const e=(r.match(/<img[^>]*>/gi)||[]).length,n=(r.match(/<video[^>]*>/gi)||[]).length;let i=0;const s=r.match(/\b(?:fa|fas|far|fab|fal|fad)-[a-z0-9-]+/gi)||[];i+=s.length;const o=r.match(/<i\s+[^>]*class\s*=\s*["'][^"']*\b(?:fa|icon|material|glyphicon|bi|ti|ri|xi)[^"']*["'][^>]*>/gi)||[];i+=o.length;const c=r.match(/<svg[^>]*>/gi)||[];i+=c.length;const l=r.match(/\b(?:btn|menu|nav|toolbar|action|ui)-?icon\b/gi)||[];i+=l.length;const d=r.match(/<img[^>]*src\s*=\s*["'][^"']*\bicon[^"']*["'][^>]*>/gi)||[];i+=d.length;const u=r.match(/\b(?:material-icons|md-|mdi-)/gi)||[];i+=u.length;const h=mk(r,e);let p;try{p=pk(r,e,i,t),console.log("[DEBUG] N8.2 interfaceCleanness 분석 완료:",p.score,p.grade)}catch(D){console.error("[DEBUG] N8.2 interfaceCleanness 분석 오류:",D)}let f;try{const D=(r.match(/<h[1-6][^>]*>/gi)||[]).length;f=fk(r,D),console.log("[DEBUG] N8.3 informationScannability 분석 완료:",f.score,f.grade,"사람 검증:",f.needsManualReview)}catch(D){console.error("[DEBUG] N8.3 informationScannability 분석 오류:",D)}const y=r.match(/\bglyphicon-[a-z0-9-]+/gi)||[];i+=y.length;const w=r.match(/\bbi-[a-z0-9-]+/gi)||[];i+=w.length;const b=r.match(/\bti-[a-z0-9-]+/gi)||[];i+=b.length;const C=r.match(/\bri-[a-z0-9-]+/gi)||[];i+=C.length;const A=r.match(/\bxi-[a-z0-9-]+/gi)||[];i+=A.length;const T=r.match(/\bhero-[a-z0-9-]+/gi)||[];i+=T.length;const M=r.match(/\bfeather-[a-z0-9-]+/gi)||[];return i+=M.length,{imageCount:e,videoCount:n,iconCount:i,visualConsistency:h,interfaceCleanness:p,informationScannability:f}}function fk(r,t){let e=100;const n=[],i=[];let s=!1;const o=r.match(/<h[1-6][^>]*>[\s\S]*?<\/h[1-6]>/gi)||[],c=[];if(o.length>1)for(let H=0;H<o.length-1;H++){const B=r.indexOf(o[H])+o[H].length,P=r.indexOf(o[H+1]),j=r.substring(B,P).replace(/<[^>]+>/g,"").trim();c.push(j.length)}const l=c.length>0?c.reduce((H,B)=>H+B,0)/c.length:0,d=c.filter(H=>H>1e3).length;d>2?(e-=20,n.push({type:"WALL_OF_TEXT",severity:"HIGH",message:`${d}개 구간에서 1,000자 이상 연속 텍스트 → 중간 제목 추가 권장`})):d>0?(e-=10,n.push({type:"LONG_TEXT_GAP",severity:"MEDIUM",message:`${d}개 구간에서 긴 텍스트 블록 발견 → 훑어보기 어려움`})):l>0&&l<600&&i.push("✅ 적절한 헤딩 간격 → 훑어보기 용이");const h=(o.length>0?r.indexOf(o[0])/r.length:1)<.2;!h&&o.length>0?(e-=15,n.push({type:"NO_FIRST_SCREEN_ANCHOR",severity:"HIGH",message:"첫 화면에 헤딩 없음 → 사용자 시선을 잡을 앵커 부재"})):h&&i.push("✅ 첫 화면 헤딩 존재 → 시선 앵커 확보");const p=(r.match(/<h1[^>]*>/gi)||[]).length,f=(r.match(/<h2[^>]*>/gi)||[]).length,y=(r.match(/<h3[^>]*>/gi)||[]).length;(r.match(/<h4[^>]*>/gi)||[]).length,(r.match(/<h5[^>]*>/gi)||[]).length,(r.match(/<h6[^>]*>/gi)||[]).length,p===0?(e-=15,n.push({type:"NO_H1",severity:"HIGH",message:"h1 제목 없음 → 페이지 주제 불명확 (SEO 및 접근성 문제)"})):p>1?(e-=10,n.push({type:"MULTIPLE_H1",severity:"MEDIUM",message:`h1 제목 ${p}개 → 1개로 통일 권장 (명확한 페이지 주제)`})):i.push("✅ h1 제목 1개 → 명확한 페이지 주제"),f<3&&t>3?(e-=10,n.push({type:"INSUFFICIENT_H2",severity:"MEDIUM",message:`h2 중제목 ${f}개 → 3개 이상 권장 (주요 섹션 구분)`})):f>=3&&f<=7&&i.push("✅ 적절한 h2 중제목 → 주요 섹션 구분 명확");const w=[];(r.match(/<h[1-6][^>]*>/gi)||[]).forEach(H=>{const B=H.match(/<h([1-6])/i);B&&w.push(parseInt(B[1]))});let C=!1;for(let H=0;H<w.length-1;H++){const B=w[H],P=w[H+1];if(P-B>1){C=!0,e-=12,n.push({type:"HIERARCHY_SKIPPING",severity:"HIGH",message:`h${B} → h${P} 직접 연결 → 중간 레벨 (h${B+1}) 추가 권장`});break}}!C&&w.length>1&&i.push("✅ 계층 건너뛰기 없음 → 논리적 정보 구조");const A=Math.max(...w,0);A>4&&(e-=10,n.push({type:"EXCESSIVE_DEPTH",severity:"MEDIUM",message:`헤딩 깊이 ${A}단계 → 4단계 이하로 단순화 권장`}));const T=r.match(/<(strong|b|em|i)[^>]*>/gi)||[],M=r.match(/<(p|span|div|h[1-6])[^>]*>/gi)||[],D=M.length>0?T.length/M.length:0;D>.3?(e-=10,n.push({type:"EXCESSIVE_EMPHASIS",severity:"MEDIUM",message:`강조 요소 비율 ${(D*100).toFixed(1)}% → 30% 이하로 축소 권장`})):D<.15&&i.push("✅ 절제된 강조 사용 → 핵심 정보 돋보임");const U=r.replace(/<[^>]+>/g,"").trim(),O=o.map(H=>H.replace(/<[^>]+>/g,"").trim()).join(""),K=U.length>0?O.length/U.length:0;K<.05&&t>0&&(e-=8,n.push({type:"LOW_HEADING_DENSITY",severity:"MEDIUM",message:"헤딩 밀도 낮음 → 정보 구조 파악 어려움"})),t===0&&(s=!0,n.push({type:"NO_HEADINGS",severity:"CRITICAL",message:"⚠️ 헤딩 없음 → UI/UX 전문가 확인 필요 (카드 UI, SPA 가능성)"})),t>50&&(s=!0,n.push({type:"TOO_MANY_HEADINGS",severity:"WARNING",message:`⚠️ 헤딩 ${t}개 → 자동 분석 한계, 전문가 확인 권장`})),l===0&&t>0&&(s=!0,n.push({type:"AMBIGUOUS_STRUCTURE",severity:"WARNING",message:"⚠️ 특이한 구조 감지 → 전문가 확인 권장"})),e=Math.max(0,Math.min(100,e));let F;return e>=85?F="A":e>=70?F="B":e>=55?F="C":F="D",{score:e,grade:F,scanAnchors:{avgTextGap:l,longGaps:d,hasFirstScreenHeading:h},headingStructure:{h1Count:p,h2Count:f,h3Count:y,maxDepth:A,hasSkipping:C},emphasisDistribution:{emphasisRatio:D,headingDensity:K},issues:n,strengths:i,needsManualReview:s}}function pk(r,t,e,n){let i=100;const s=[],o=[],l=(r.match(/<p[^>]*>[\s\S]*?<\/p>/gi)||[]).map(V=>V.replace(/<[^>]+>/g,"").trim().length),d=l.filter(V=>V>300).length,u=l.length>0?l.reduce((V,re)=>V+re,0)/l.length:0;d>5?(i-=20,s.push({type:"WALL_OF_TEXT",severity:"HIGH",message:`긴 문단 ${d}개 → 2-3줄씩 분할하고 소제목으로 구조화 권장`})):d>3?(i-=10,s.push({type:"LONG_PARAGRAPHS",severity:"MEDIUM",message:`긴 문단 ${d}개 발견 → 가독성을 위해 짧게 분할 권장`})):d===0&&l.length>0&&o.push("✅ 적절한 문단 길이 유지 → 읽기 편안함");const h=r.replace(/<[^>]+>/g,"").trim(),p=(r.match(/<a[^>]*>[\s\S]*?<\/a>/gi)||[]).map(V=>V.replace(/<[^>]+>/g,"").trim()).join(""),f=(r.match(/<button[^>]*>[\s\S]*?<\/button>/gi)||[]).map(V=>V.replace(/<[^>]+>/g,"").trim()).join(""),y=p.length+f.length,w=h.length>0?y/h.length:0;w>.4?(i-=15,s.push({type:"CHOICE_OVERLOAD",severity:"HIGH",message:`액션 밀도 ${(w*100).toFixed(1)}% → 주요 액션 3-5개로 제한 권장`})):w>.25?(i-=8,s.push({type:"HIGH_ACTION_DENSITY",severity:"MEDIUM",message:`액션 밀도 ${(w*100).toFixed(1)}% → 일부 링크를 그룹화 권장`})):w<.15&&o.push("✅ 적절한 액션 밀도 → 선택 부담 최소화");const b=r.match(/<section[^>]*>/gi)||[],C=r.match(/<article[^>]*>/gi)||[],A=r.match(/<div[^>]*>/gi)||[],T=b.length+C.length,M=A.length>0?T/A.length:0;M<.05&&A.length>20?(i-=12,s.push({type:"POOR_GROUPING",severity:"MEDIUM",message:`정보 그룹핑 비율 ${(M*100).toFixed(1)}% → <section>, <article> 태그로 의미 구조화 권장`})):M>.15&&o.push("✅ 의미 있는 정보 그룹핑 → 구조 파악 용이");const D=T+(r.match(/<nav[^>]*>/gi)||[]).length;D>10?(i-=15,s.push({type:"TOO_MANY_SECTIONS",severity:"HIGH",message:`주요 섹션 ${D}개 → 7개 이하로 통합 권장`})):D>7?(i-=8,s.push({type:"SECTION_OVERLOAD",severity:"MEDIUM",message:`주요 섹션 ${D}개 발견 → 우선순위에 따라 일부 통합 권장`})):D>=3&&D<=7&&o.push("✅ 적절한 섹션 구성 → 시각적 호흡 공간 확보");const O=(r.match(/<[^>]+>/g)||[]).length;O>2e3?(i-=12,s.push({type:"HIGH_DOM_COMPLEXITY",severity:"HIGH",message:`DOM 요소 ${O}개 → 컴포넌트 분할 및 지연 로딩 권장`})):O<500&&o.push("✅ 가벼운 DOM 구조 → 렌더링 성능 우수");const K=r.match(/<li[^>]*>/gi)||[],F=r.match(/<tr[^>]*>/gi)||[],H=K.length+F.length;H>50?(i-=10,s.push({type:"TOO_MANY_REPEATED_ITEMS",severity:"MEDIUM",message:`반복 항목 ${H}개 → 페이지네이션 또는 무한 스크롤 고려`})):H>20&&H<=50&&o.push("✅ 적절한 항목 수 → 스크롤 부담 최소화");const B=r.match(/\b(modal|popup|overlay|dialog)\b/gi)||[],P=r.match(/\b(ad|advertisement|banner)\b/gi)||[],N=r.match(/<iframe[^>]*>/gi)||[],j=B.length+P.length+N.length;j>5?(i-=20,s.push({type:"INTRUSIVE_ELEMENTS",severity:"HIGH",message:`방해 요소 ${j}개 → 팝업/광고/iframe 최소화 권장`})):j>3?(i-=10,s.push({type:"MODERATE_INTRUSION",severity:"MEDIUM",message:`방해 요소 ${j}개 발견 → 사용자 경험 저해 가능`})):j===0&&o.push("✅ 방해 요소 없음 → 집중력 유지 용이");const g=(r.match(/\b(animate|animation|transition|motion)\b/gi)||[]).length;g>15?(i-=12,s.push({type:"EXCESSIVE_ANIMATIONS",severity:"HIGH",message:`애니메이션 ${g}개 → 필수 요소만 남기고 축소 권장`})):g>8&&(i-=6,s.push({type:"ANIMATION_WARNING",severity:"MEDIUM",message:`애니메이션 ${g}개 발견 → 사용자에게 전환 제어 옵션 제공 권장`}));const E=r.match(/<(strong|b|em|i)[^>]*>/gi)||[],k=r.match(/<(p|span|div|h[1-6])[^>]*>/gi)||[],v=k.length>0?E.length/k.length:0;v>.3?(i-=10,s.push({type:"EMPHASIS_OVERLOAD",severity:"MEDIUM",message:`강조 비율 ${(v*100).toFixed(1)}% → 정말 중요한 내용만 강조 권장`})):v<.1&&o.push("✅ 절제된 강조 사용 → 핵심 정보 돋보임"),i=Math.max(0,Math.min(100,i));let x;return i>=85?x="A":i>=70?x="B":i>=55?x="C":x="D",{score:i,grade:x,informationLoad:{longParagraphs:d,avgParagraphLength:u,actionDensity:w,groupingRatio:M},breathingSpace:{sectionCount:D,domComplexity:O,repeatedPatterns:H},visualNoise:{intrusiveCount:j,animationCount:g,emphasisRatio:v},issues:s,strengths:o}}function mk(r,t){let e=100;const n=[],i=[],s=r.match(/\sstyle\s*=\s*["'][^"']+["']/gi)||[];s.length>50?(e-=30,n.push({type:"EXCESSIVE_INLINE_STYLES",severity:"HIGH",message:`인라인 스타일 ${s.length}개 → CSS 클래스로 통일 권장 (유지보수성 저하)`})):s.length>20?(e-=15,n.push({type:"INLINE_STYLE_WARNING",severity:"MEDIUM",message:`인라인 스타일 ${s.length}개 발견 → 일부 CSS 클래스로 전환 권장`})):s.length<5&&i.push("CSS 클래스 기반 스타일링 → 일관성 유지 용이");const c=(r.match(/<img[^>]*alt\s*=\s*["']([^"']*)["'][^>]*>/gi)||[]).map(b=>{const C=b.match(/alt\s*=\s*["']([^"']*)["']/);return C?C[1]:""}).filter(b=>b.length>0);if(c.length>3){const b=c.filter(A=>A.length>20).length,C=c.filter(A=>A.length<=20).length;b>0&&C>0&&Math.abs(b-C)<c.length*.3&&(e-=10,n.push({type:"INCONSISTENT_ALT_STYLE",severity:"LOW",message:"이미지 alt 텍스트 스타일 혼재 → 짧은 설명 또는 긴 설명 중 하나로 통일"}))}const d=(r.match(/<button[^>]*class\s*=\s*["']([^"']*)["'][^>]*>/gi)||[]).map(b=>{const C=b.match(/class\s*=\s*["']([^"']*)["']/);return C?C[1]:""}),u=new Set(d.filter(b=>b.length>0));u.size>10?(e-=20,n.push({type:"BUTTON_CLASS_FRAGMENTATION",severity:"MEDIUM",message:`버튼 클래스 ${u.size}종 사용 → 통일된 디자인 시스템 권장`})):u.size<=5&&i.push("버튼 스타일 체계적 관리 (5종 이내)");const p=(r.match(/<img[^>]*src\s*=\s*["']([^"']*)["'][^>]*>/gi)||[]).map(b=>{const C=b.match(/\.([a-z]{3,4})(?:["'\s?#])/i);return C?C[1].toLowerCase():""}).filter(b=>b.length>0),f=new Set(p);f.size>4&&(e-=10,n.push({type:"IMAGE_FORMAT_INCONSISTENCY",severity:"LOW",message:`이미지 형식 ${f.size}종 혼용 (${Array.from(f).join(", ")}) → WebP 통일 권장`}));const y=r.match(/<(?:div|article|section)[^>]*class\s*=\s*["'][^"']*\b(?:card|item|box|panel)[^"']*["'][^>]*>/gi)||[];y.length>=3&&i.push(`반복 요소 ${y.length}개 → 체계적 레이아웃 구조`),t===0?(e-=10,n.push({type:"NO_VISUAL_ELEMENTS",severity:"MEDIUM",message:"시각적 요소 부족 → 사용자 몰입도 저하"})):t>100?(e-=15,n.push({type:"IMAGE_OVERLOAD",severity:"MEDIUM",message:`이미지 ${t}개로 과다 → 로딩 속도 및 집중도 저하 우려`})):t>=5&&t<=50&&i.push("적절한 시각적 밀도 (5-50개 범위)"),e=Math.max(0,Math.min(100,e));let w;return e>=90?w="A":e>=75?w="B":e>=60?w="C":w="D",{score:e,grade:w,issues:n,strengths:i}}function gk(r){const t=r.replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim(),e=[],n=yk(t,e),i=_k(r,e),s=bk(t,e),o=n.score*.4+i.score*.3+s.score*.3;return{score:Math.round(o*10)/10,languageFriendliness:n,dataNaturalness:i,interfaceFriendliness:s,details:e}}function yk(r,t){const n=(r.match(/[\w가-힣]+/g)||[]).length,i=[/솔루션|프로세스|워크플로우|인스턴스|리소스|세션|API|SDK/gi,/퍼포먼스|컨버전|임팩트|디플로이|빌드|런타임|마이그레이션/gi,/귀하|당사|폐사|본인|차수|건명|시행|이행|준수|기재|수취인/gi,/\b[A-Z]{3,}\b/g];let s=0;i.forEach(w=>{const b=r.match(w);b&&(s+=b.length)});const o=n>0?s/n*100:0;console.log(`[N2.1 Language] 전체 단어: ${n}, 전문용어: ${s}, 밀도: ${o.toFixed(2)}%`);const c=r.split(/[.!?。]+/).filter(w=>w.trim().length>10);let l=0,d=0;c.forEach(w=>{const b=w.trim().split(/\s+/);l+=b.length,b.length>25&&d++});const u=c.length>0?l/c.length:0,h=c.length>0?d/c.length*100:0;let p=100;o>=10?p=0:o>=5?p=50-(o-5)*10:o>=2&&(p=100-(o-2)*16.67);let f=100;u>25?f=Math.max(0,100-(u-25)*5):u>20?f=100-(u-20)*4:u<10&&u>0&&(f=Math.max(70,100-(10-u)*3));const y=p*.7+f*.3;return console.log(`[N2.1 Language] jargonScore: ${p}, complexityScore: ${f}, weighted: ${y}, final: ${y/10}`),o>5?t.push(`⚠️ 전문용어 밀도가 높음 (${o.toFixed(1)}%)`):o<2&&t.push(`✅ 친숙한 용어 사용 (전문용어 ${o.toFixed(1)}%)`),u>25?t.push(`⚠️ 문장이 길고 복잡함 (평균 ${u.toFixed(1)}단어)`):u>=10&&u<=20&&t.push(`✅ 적절한 문장 길이 (평균 ${u.toFixed(1)}단어)`),{jargonDensity:Math.round(o*10)/10,jargonCount:s,totalWords:n,avgSentenceLength:Math.round(u*10)/10,longSentencesRatio:Math.round(h*10)/10,score:Math.round(y/10*10)/10}}function _k(r,t){let e=0;const n=(r.match(/<h1[^>]*>/gi)||[]).length;let i=0;n===1?(i=25,t.push("✅ H1 태그가 1개로 적절함")):n===0?(i=0,t.push("⚠️ H1 태그가 없음 - 페이지 구조가 불명확")):(i=15,t.push(`⚠️ H1 태그가 ${n}개 - 페이지당 1개 권장`)),e+=i;const s=r.match(/tabindex\s*=\s*["']?(\d+)["']?/gi)||[],o=s.filter(y=>{var b;return parseInt(((b=y.match(/\d+/))==null?void 0:b[0])||"0")>10});let c=30;o.length>0?(c=Math.max(0,30-o.length*5),t.push(`⚠️ 비정상적인 tabindex ${o.length}개 발견 - DOM 순서 개선 필요`)):s.length>0&&t.push("✅ tabindex 사용이 적절함"),e+=c;const l=(r.match(/<form[^>]*>/gi)||[]).length,d=/class\s*=\s*["'][^"']*step[^"']*["']|role\s*=\s*["']progressbar["']/i.test(r);let u=0;l>0?(u=15,d?(u=30,t.push("✅ 프로세스 단계 표시가 있음")):t.push("⚠️ 폼이 있지만 단계 표시가 없음")):(u=30,t.push("✅ 폼이 없어 단계 표시 불필요")),e+=u;const h=/<header[^>]*>[\s\S]*?<a[^>]*href\s*=\s*["'][/]?["'][^>]*>[\s\S]*?<img[^>]*[\s\S]*?<\/a>[\s\S]*?<\/header>/i.test(r)||/class\s*=\s*["'][^"']*logo[^"']*["'][^>]*>[\s\S]*?<a[^>]*href\s*=\s*["'][/]?["']/i.test(r);let p=0;h?(p=15,t.push("✅ 로고가 홈페이지 링크로 연결됨")):t.push("⚠️ 로고를 홈페이지 링크로 연결 권장"),e+=p;const f=Math.max(0,Math.min(100,e));return{rawDataCount:100-f,naturalDataCount:f,naturalRatio:f,score:Math.round(f/10*10)/10}}function bk(r,t){r.toLowerCase();let e=0;const n=r.match(/시작하|만들|보내|저장하|찾아보|확인하|선택하|클릭|눌러|등록|신청|조회|검색|다운로드|업로드|공유하|복사하|붙여넣|삭제하|수정하|편집하|추가하|제거하|취소하|완료하|제출하|전송하|예약하|결제하|구매하/g)||[];e+=n.length*3;const i=r.match(/당신|여러분|회원님|고객님|함께|도와드|안내|이용|편리|간편|쉽게|빠르게|안전하게|무료|할인|혜택|포인트|적립|맞춤|추천/g)||[];e+=i.length*2;const s=r.match(/예를 들어|쉽게 말하면|간단히|쉽게|편리하게|빠르게/g)||[];e+=s.length*4;const o=r.match(/시스템|데이터베이스|서버|관리자|운영자|처리|수행|실행|구동|배포/g)||[];e-=o.length*3;const c=r.match(/장바구니|카트|폴더|휴지통|집|홈|담기|꺼내기|넣기|빼기|보관함|서랍|책갈피|북마크|별표|즐겨찾기|하트|좋아요|공유|댓글|메시지|편지|우편|전화|벨|알림|시계|달력|일정|지도|위치|핀|돋보기|검색|필터|정렬|새로고침|되돌리기|앞으로|뒤로|위|아래|좌|우|확대|축소|재생|정지|일시정지|음소거|볼륨|설정|톱니바퀴|프로필|사진|카메라|갤러리/g)||[];e+=c.length*5;const l=Math.max(0,Math.min(100,50+e));return n.length>5&&t.push(`✅ 행동 중심 동사 ${n.length}개 사용`),i.length>3&&t.push(`✅ 사용자 중심 언어 ${i.length}개 사용`),o.length>5&&t.push(`⚠️ 시스템 중심 언어 ${o.length}개 발견`),c.length>2&&t.push(`✅ 현실 은유 ${c.length}개 사용`),{actionWords:n.length,userCentricWords:i.length,systemWords:o.length,metaphors:c.length,score:Math.round(l/10*10)/10}}function wk(r){try{const t=r.match(/<div[^>]*(role="dialog"|class="[^"]*modal[^"]*"|class="[^"]*popup[^"]*")[^>]*>/gi)||[],e=r.match(/<button[^>]*(닫기|close|cancel|취소)[^>]*>/gi)||[],n=r.match(/<button[^>]*>[^<]*[×✕xX][^<]*<\/button>/gi)||[],i=r.includes("keydown")||r.includes("Escape"),s=t.length,o=Math.min(s,e.length+n.length),c=s>0?o/s:1,l=Math.round(c*30),d=r.match(/<button[^>]*(다음|next|계속)[^>]*>/gi)||[],u=r.match(/<button[^>]*(이전|previous|prev|back)[^>]*>/gi)||[],h=r.includes("step-indicator")||r.includes("stepper")||/step\s*[0-9]/i.test(r),p=/<nav[^>]*breadcrumb/i.test(r)||/홈\s*>\s*/i.test(r);let f=0;u.length>0&&(f+=15),d.length>0&&(f+=5),h&&(f+=5),p&&(f+=5),f=Math.min(f,25);const y=r.match(/<form[^>]*>/gi)||[],w=r.match(/<button[^>]*(type="reset"|초기화|reset|clear)[^>]*>/gi)||[],b=r.match(/<button[^>]*(취소|cancel)[^>]*>/gi)||[],C=r.match(/<div[^>]*class="[^"]*filter[^"]*"[^>]*>/gi)||[],A=r.match(/<button[^>]*(필터.*초기화|reset.*filter)[^>]*>/gi)||[],T=Math.min(y.length,w.length+b.length),M=Math.min(C.length,A.length);let D=0;y.length>0?D+=T/y.length*15:D+=15,C.length>0?D+=M/C.length*10:D+=10,D=Math.round(D);const U=r.match(/<button[^>]*(삭제|delete|remove|탈퇴|해지)[^>]*>/gi)||[],O=r.match(/confirm|확인.*하시겠습니까|정말|취소.*불가/gi)||[],K=r.includes("재확인")||r.includes("2단계"),F=U.length,H=Math.min(F,O.length),B=F>0?H/F:1;let P=Math.round(B*15);K&&(P+=5),P=Math.min(P,20);const N=l+f+D+P;let j;N>=90?j="A":N>=75?j="B":N>=60?j="C":j="D";const W=72,g=N-W;let E,k;return N>=89?(E="우수",k="상위 10%"):N>=W?(E="평균",k="상위 50%"):(E="개선필요",k="하위 50%"),{totalScore:N,grade:j,modalEscape:{score:l,totalModals:s,escapableModals:o,escapeRatio:`${Math.round(c*100)}%`,details:[`총 모달/팝업: ${s}개`,`탈출 가능: ${o}개`,`닫기 버튼: ${e.length}개`,`X 아이콘: ${n.length}개`,`ESC 키 지원: ${i?"있음":"없음"}`]},stepNavigation:{score:f,hasNextButtons:d.length>0,hasPrevButtons:u.length>0,hasStepIndicator:h,hasBreadcrumbs:p},inputCancellation:{score:D,totalForms:y.length,formsWithReset:T,totalFilters:C.length,filtersWithReset:M},destructivePrevention:{score:P,totalDangerousActions:F,protectedActions:H,protectionRatio:`${Math.round(B*100)}%`},govComparison:{siteScore:N,govAverage:W,gap:g>=0?`+${g}`:`${g}`,percentile:k,status:E,ranking:N>=89?"상위권":N>=W?"중위권":"하위권",commonIssues:["모달 닫기 접근성 부족 (38%)","다단계 이전 버튼 부재 (45%)","폼 취소 후 입력값 유지 문제 (33%)","삭제 전 확인 절차 부재 (41%)"],bestPractices:["정부24: ESC 키 + 명시적 닫기 버튼 모두 제공","국세청 홈택스: 각 단계 저장 후 이전 가능","민원24: 삭제 시 2단계 확인 + 7일 복구 기간"]},recommendation:j==="A"?"정부 49개 기관 수준의 우수한 사용자 제어권을 제공하고 있습니다.":j==="B"?"정부 평균 수준입니다. A등급을 위해 모달 탈출과 프로세스 후퇴 기능을 강화하세요.":j==="C"?"개선이 필요합니다. 4단계 측정 항목 중 낮은 점수 영역을 집중 보완하세요.":"전면 개선이 필요합니다. 정부 49개 기관 모범 사례를 참고하여 비상구 시스템을 구축하세요.",details:[`1단계(모달탈출): ${l}/30점`,`2단계(프로세스후퇴): ${f}/25점`,`3단계(입력취소): ${D}/25점`,`4단계(파괴방지): ${P}/20점`,`정부 평균 대비: ${g>=0?"+":""}${g}점`]}}catch(t){return{totalScore:0,grade:"D",modalEscape:{score:0,totalModals:0,escapableModals:0,escapeRatio:"0%",details:["분석 실패"]},stepNavigation:{score:0,hasNextButtons:!1,hasPrevButtons:!1,hasStepIndicator:!1,hasBreadcrumbs:!1},inputCancellation:{score:0,totalForms:0,formsWithReset:0,totalFilters:0,filtersWithReset:0},destructivePrevention:{score:0,totalDangerousActions:0,protectedActions:0,protectionRatio:"0%"},govComparison:{siteScore:0,govAverage:72,gap:"-72",percentile:"하위 50%",status:"개선필요",ranking:"하위권",commonIssues:[],bestPractices:[]},recommendation:"분석 중 오류가 발생했습니다.",details:[`에러: ${t}`]}}}function vk(r,t){var e,n,i,s,o;try{let c=0;const l=[],d=r.match(/<input[^>]*(type="search"|name="search"|name="q"|placeholder="[^"]*검색[^"]*")[^>]*>/gi)||[],u=/<[^>]*role="search"[^>]*>/i.test(r),h=d.length>0||u;if(h){c+=10,l.push("✅ 검색 기능 존재");const me=((e=r.match(/<header[^>]*>[\s\S]*?<\/header>/i))==null?void 0:e[0])||"",Lt=((n=r.match(/<nav[^>]*>[\s\S]*?<\/nav>/i))==null?void 0:n[0])||"",J=r.substring(0,Math.min(5e3,r.length));me.includes("search")||Lt.includes("search")||J.includes("search")&&J.indexOf("search")<3e3?(c+=15,l.push("✅ 헤더 영역에 글로벌 검색 배치 (정부 98% 수준)")):l.push("⚠️ 검색이 하단에 위치 (정부 43% 문제)"),(/<button[^>]*>[^<]*검색[^<]*<\/button>/i.test(r)||/<button[^>]*search[^>]*>/i.test(r)||/<svg[^>]*>[\s\S]*?search[\s\S]*?<\/svg>/i.test(r))&&(c+=5,l.push("✅ 검색 버튼/아이콘 명확"))}else l.push("❌ 검색 기능 없음 - 텔레포트 불가 (정부 필수 기능)");const p=c>=25?"우수":c>=15?"양호":"미흡";let f=0;const y=[],b=[/<nav[^>]*aria-label="[^"]*breadcrumb[^"]*"[^>]*>/i,/<[^>]*class="[^"]*breadcrumb[^"]*"[^>]*>/i,/<ol[^>]*class="[^"]*breadcrumb[^"]*"[^>]*>/i,/홈\s*[>›]\s*/i,/Home\s*[>›]\s*/i].some(me=>me.test(r)),C=t.split("/").filter(me=>me&&me!=="http:"&&me!=="https:").length;if(b){f+=15,y.push("✅ 브레드크럼 존재");const me=((i=r.match(/<nav[^>]*breadcrumb[\s\S]*?<\/nav>/i))==null?void 0:i[0])||((s=r.match(/<ol[^>]*breadcrumb[\s\S]*?<\/ol>/i))==null?void 0:s[0])||"",Lt=(me.match(/<a[^>]*href/gi)||[]).length,J=(me.match(/<li|<a|<span/gi)||[]).length;Lt>=2&&(f+=10,y.push(`✅ ${Lt}개 링크 - 계층 구조 명확`)),J>=3&&(f+=3),J>=4&&(f+=2),/aria-current="page"|class="[^"]*active[^"]*"|class="[^"]*current[^"]*"/.test(me)&&(f+=5,y.push("✅ 현재 위치 하이라이트 (국세청 스타일)"))}else C>2?(y.push(`❌ Critical: ${C}단계 깊은 구조인데 브레드크럼 부재`),y.push("⚠️ 사용자가 현재 위치 파악 불가 (정부 필수)")):(y.push("ℹ️ 단순 구조 - 브레드크럼 불필요"),f+=15);const A=f>=25?"우수":f>=20?"양호":f>=10?"기본":"없음";let T=0;const M=[],D=/<a[^>]*>[^<]*(사이트맵|sitemap|전체메뉴|site map)[^<]*<\/a>/i.test(r);D?(T+=12,M.push("✅ 사이트맵 링크 존재")):M.push("⚠️ 사이트맵 없음 (정부 100% 제공)");const O=((((o=r.match(/<footer[^>]*>[\s\S]*?<\/footer>/i))==null?void 0:o[0])||"").match(/<a[^>]*href/gi)||[]).length,K=O;let F=0;K>=8?(F=13,M.push("✅ 풍부한 푸터 네비게이션 (8+ 링크)")):K>=4?(F=8,M.push("✅ 기본 푸터 네비게이션")):K>0&&M.push("⚠️ 푸터 네비게이션 빈약 (정부 평균 이하)"),T+=F;const H=T>=20?"우수":T>=12?"양호":"미흡";let B=0;const P=[],N=r.match(/<a[^>]*href=["'](\/|\.\/|index\.html|http[s]?:\/\/[^"'\/]+\/?)[^"']*["'][^>]*>/gi)||[],j=N.some(me=>{const Lt=/<img|<svg/i.test(me),J=/logo|brand/i.test(me);return(Lt||J)&&!0});j?(B=15,P.push("✅ 로고 홈링크 완벽 구현 (정부 표준)")):N.length>0?(B=8,P.push("⚠️ 홈 링크 있지만 로고 연결 없음")):P.push("❌ 홈 복귀 수단 없음 (정부 기본 필수)");const W=B>=15?"우수":B>=8?"기본":"없음",g=c+f+T+B,E=g>=85?"A":g>=70?"B":g>=50?"C":"D",k=78,v=92,x=g-k,V=x>=14?"상위 10%":x>=0?`상위 ${Math.round(50-x/k*30)}%`:`하위 ${Math.round(50+Math.abs(x/k)*30)}%`,re=x>=0?"정부 평균 이상":"정부 평균 이하",oe=x>=14?"상위 10% 수준":x>=0?"평균 이상":"개선 필요",ve=g<60?"높음":g<80?"보통":"낮음",ce=g<60?"4분 이상":g<80?"2-3분":"1분 이내",Ee=g<60?"+40%":g<80?"+20%":"정상",Le=g<60?"-35%":g<80?"-15%":"정상";let Fe="";E==="A"?Fe="✅ 네비게이션 자유도 우수 - 정부 상위 10% 수준":E==="B"?Fe="대체로 양호 - 일부 경로 보완 필요":E==="C"?Fe="⚠️ 개선 필요 - 사용자 길 찾기 어려움":Fe="❌ 긴급 개선 필요 - 네비게이션 미로 상태";const We=["검색창이 하단에 숨겨짐 (정부 43% 문제)","브레드크럼 깊이 부족 (정부 38% 문제)","푸터 네비게이션 빈약 (정부 31% 문제)","로고 홈링크 없음 (정부 29% 문제)"],Sr=["정부24: 헤더 검색 + 5단계 브레드크럼 + 분야별 사이트맵","국세청 홈택스: 검색 자동완성 + 현재위치 하이라이트","서울시: 통합검색 + 관련서비스 추천 + 맞춤형 바로가기"];return{totalScore:g,grade:E,teleport:{score:c,hasSearch:h,isGlobalSearch:c>=25,hasSearchIcon:c===30,accessibility:p,details:l},tracking:{score:f,hasBreadcrumb:b,linkCount:0,totalDepth:0,hasCurrentMarker:!1,pathDepth:C,quality:A,details:y},birdEye:{score:T,hasSitemap:D,footerLinkCount:O,hasFooterNav:O>0,structuralVisibility:H,details:M},return:{score:B,hasLogoHomeLink:j,totalHomeLinkCount:N.length,returnCapability:W,details:P},govComparison:{siteScore:g,govAverage:k,gap:x>=0?`+${x}`:`${x}`,percentile:V,status:re,ranking:oe,dimensionAvg:{teleport:24,tracking:21,birdEye:20,return:13},userImpact:{findingDifficulty:ve,estimatedSearchTime:ce,bounceRateRisk:Ee,conversionImpact:Le},commonIssues:We,bestPractices:Sr},recommendation:Fe,details:[`🔍 텔레포트: ${c}/30`,`🍞 트래킹: ${f}/30`,`🗺️ 조감도: ${T}/25`,`🏠 회귀: ${B}/15`,`정부 평균 대비: ${x>=0?"+":""}${x}점`]}}catch(c){return{totalScore:0,grade:"D",teleport:{score:0,hasSearch:!1,isGlobalSearch:!1,hasSearchIcon:!1,accessibility:"미흡",details:["분석 실패"]},tracking:{score:0,hasBreadcrumb:!1,linkCount:0,totalDepth:0,hasCurrentMarker:!1,pathDepth:0,quality:"없음",details:["분석 실패"]},birdEye:{score:0,hasSitemap:!1,footerLinkCount:0,hasFooterNav:!1,structuralVisibility:"미흡",details:["분석 실패"]},return:{score:0,hasLogoHomeLink:!1,totalHomeLinkCount:0,returnCapability:"없음",details:["분석 실패"]},govComparison:{siteScore:0,govAverage:78,gap:"-78",percentile:"하위 50%",status:"정부 평균 이하",ranking:"개선 필요",dimensionAvg:{teleport:24,tracking:21,birdEye:20,return:13},userImpact:{findingDifficulty:"높음",estimatedSearchTime:"4분 이상",bounceRateRisk:"+40%",conversionImpact:"-35%"},commonIssues:[],bestPractices:[]},recommendation:"분석 중 오류가 발생했습니다.",details:[`에러: ${c}`]}}}function xk(r){try{const t=r.replace(/<script[^>]*>[\s\S]*?<\/script>/gi,"").replace(/<style[^>]*>[\s\S]*?<\/style>/gi,"").replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim(),e=Sk(t),n=kk(r),i=Ck(t),s=e.score+n.score+i.score;let o;s>=90?o="A":s>=75?o="B":s>=60?o="C":o="D";const c=84,l=s-c,d=Math.round(s/100*100);let u,h;l>=0?(u="정부 표준 준수",h=l>=11?"상위 10% (KRDS 모범사례)":"평균 이상"):(u="표준 미준수",h="개선 필요");const p={confusionLevel:s<60?"높음":s<80?"보통":"낮음",searchFailure:s<60?"40% 실패":s<80?"20% 실패":"5% 미만",learningTime:s<60?"+50% 증가":s<80?"+20% 증가":"정상",trustImpact:s<60?"전문성 의심":s<80?"보통":"신뢰 구축"},f=[...e.findings,...n.findings,...i.findings];return{terminologyScore:e.score,actionScore:n.score,toneScore:i.score,totalScore:s,grade:o,govComparison:{siteScore:s,govAverage:c,gap:l,status:u,ranking:h,krdsCompliance:d},userImpact:p,breakdown:{terminology:`${e.score}/40`,action:`${n.score}/35`,tone:`${i.score}/25`},findings:f,detailedAnalysis:{terminology:{score:e.score,findings:e.findings},action:{score:n.score,findings:n.findings},tone:{score:i.score,findings:i.findings}}}}catch(t){return console.error("Language consistency analysis error:",t),{terminologyScore:0,actionScore:0,toneScore:0,totalScore:0,grade:"D",govComparison:{siteScore:0,govAverage:84,gap:-84,status:"분석 실패",ranking:"분석 불가",krdsCompliance:0},userImpact:{confusionLevel:"알 수 없음",searchFailure:"알 수 없음",learningTime:"알 수 없음",trustImpact:"알 수 없음"},breakdown:{terminology:"0/40",action:"0/35",tone:"0/25"},findings:[{category:"분석 오류",issue:"언어 일관성 분석 중 오류가 발생했습니다.",impact:`오류: ${t}`}],detailedAnalysis:{terminology:{score:0,findings:[]},action:{score:0,findings:[]},tone:{score:0,findings:[]}}}}}function Sk(r){let t=40;const e=[],n={회원가입:(r.match(/회원가입|회원 가입/gi)||[]).length,가입하기:(r.match(/가입하기|가입 하기/gi)||[]).length,JOIN:(r.match(/\bJOIN\b/gi)||[]).length,"SIGN UP":(r.match(/SIGN[\s\-]?UP/gi)||[]).length},i=Object.entries(n).filter(([,f])=>f>0);i.length>1&&(t-=Math.min((i.length-1)*2,8),e.push({category:"회원가입 용어",variants:i.map(([f,y])=>`${f}(${y}회)`),count:Object.fromEntries(i),issue:`${i.length}가지 용어 혼용`,impact:"KRDS 표준 위반, 사용자 혼란 유발",recommendation:'"회원가입"으로 통일 권장 (KRDS 표준)'}));const s={로그인:(r.match(/로그인/gi)||[]).length,LOGIN:(r.match(/\bLOGIN\b/gi)||[]).length,"SIGN IN":(r.match(/SIGN[\s\-]?IN/gi)||[]).length},o=Object.entries(s).filter(([,f])=>f>0);o.length>1&&(t-=Math.min((o.length-1)*2,8),e.push({category:"로그인 용어",variants:o.map(([f,y])=>`${f}(${y}회)`),count:Object.fromEntries(o),issue:`${o.length}가지 용어 혼용`,impact:"인증 프로세스 혼란",recommendation:'"로그인"으로 통일 권장 (KRDS 표준)'}));const c={검색:(r.match(/검색(?!어|창)/gi)||[]).length,찾기:(r.match(/찾기/gi)||[]).length,SEARCH:(r.match(/\bSEARCH\b/gi)||[]).length},l=Object.entries(c).filter(([,f])=>f>0);l.length>1&&(t-=Math.min((l.length-1)*2,8),e.push({category:"검색 용어",variants:l.map(([f,y])=>`${f}(${y}회)`),count:Object.fromEntries(l),issue:`${l.length}가지 용어 혼용`,impact:"정보 탐색 효율성 저하",recommendation:'"검색"으로 통일 권장 (KRDS 표준)'}));const d={문의:(r.match(/문의(?!하|사항)/gi)||[]).length,상담:(r.match(/상담/gi)||[]).length,CONTACT:(r.match(/\bCONTACT\b/gi)||[]).length},u=Object.entries(d).filter(([,f])=>f>0);u.length>1&&(t-=Math.min((u.length-1)*2,8),e.push({category:"문의 용어",variants:u.map(([f,y])=>`${f}(${y}회)`),count:Object.fromEntries(u),issue:`${u.length}가지 용어 혼용`,impact:"고객 지원 접근성 저하",recommendation:'"문의"로 통일 권장'}));const h={비밀번호:(r.match(/비밀번호/gi)||[]).length,패스워드:(r.match(/패스워드/gi)||[]).length,PASSWORD:(r.match(/\bPASSWORD\b/gi)||[]).length,PW:(r.match(/\bPW\b/gi)||[]).length},p=Object.entries(h).filter(([,f])=>f>0);return p.length>1&&(t-=Math.min((p.length-1)*2,8),e.push({category:"비밀번호 용어",variants:p.map(([f,y])=>`${f}(${y}회)`),count:Object.fromEntries(p),issue:`${p.length}가지 용어 혼용`,impact:"KRDS 표준 위반, 보안 인식 혼란",recommendation:'"비밀번호"로 통일 권장 (KRDS 표준)'})),{score:Math.max(0,t),findings:e}}function kk(r){let t=35;const e=[],n=/<button[^>]*>(.*?)<\/button>|<a[^>]*>(.*?)<\/a>|<input[^>]*value=["']([^"']*)["'][^>]*type=["'](submit|button)["']/gi,i=[];let s;for(;(s=n.exec(r))!==null;){const p=(s[1]||s[2]||s[3]||"").replace(/<[^>]+>/g,"").trim();p&&p.length<20&&i.push(p)}const o=i.filter(p=>/^(확인|제출|등록|저장|완료|OK|SUBMIT|CONFIRM|SAVE)$/i.test(p)),c=new Set(o.map(p=>p.toLowerCase())).size;c>2&&(t-=Math.min((c-2)*2,12),e.push({category:"제출 액션",variants:[...new Set(o)],issue:`${c}가지 표현 혼용`,impact:"사용자 행동 혼란",recommendation:"주요 액션은 1-2개로 표준화 (맥락별 구분)"}));const l=i.filter(p=>/^(취소|닫기|나가기|CANCEL|CLOSE|EXIT)$/i.test(p)),d=new Set(l.map(p=>p.toLowerCase())).size;d>2&&(t-=Math.min((d-2)*2,11),e.push({category:"취소 액션",variants:[...new Set(l)],issue:`${d}가지 표현 혼용`,impact:"이탈 행동 혼란",recommendation:'"취소" 또는 "닫기" 중 하나로 통일'}));const u=i.filter(p=>/^(삭제|제거|DELETE|REMOVE)$/i.test(p)),h=new Set(u.map(p=>p.toLowerCase())).size;return h>1&&(t-=Math.min((h-1)*3,12),e.push({category:"삭제 액션",variants:[...new Set(u)],issue:`${h}가지 표현 혼용`,impact:"파괴적 행동 혼란",recommendation:'"삭제"로 통일 권장 (KRDS 표준)'})),{score:Math.max(0,t),findings:e}}function Ck(r){let t=25;const e=[],n=(r.match(/습니다|세요|십시오|시오/g)||[]).length,i=(r.match(/[^습]니[다\.!?]|어요|아요|해요/g)||[]).length,s=n+i;if(s>10){const o=n/s;let c=0,l="";o>=.9||o<=.1?(c=0,l="일관적"):o>=.7||o<=.3?(c=8,l="약간 혼용"):(c=15,l="심각한 혼용"),t-=c,o>.1&&o<.9&&e.push({category:"존댓말 일관성",count:{존댓말:n,반말:i,비율:`${(o*100).toFixed(0)}% 존댓말`},issue:l,impact:l==="심각한 혼용"?"브랜드 신뢰도 저하":"경미한 불일치",recommendation:o>.5?"존댓말로 통일 권장":"반말로 통일 권장"})}return{score:Math.max(0,t),findings:e}}function Ek(r){let t=25;const e=[];/<!DOCTYPE\s+html>/i.test(r)||(t-=4,e.push({category:"Document Structure",issue:"DOCTYPE 선언 누락",impact:"브라우저 쿼크 모드, 렌더링 불일치",severity:"HIGH",fix:"<!DOCTYPE html> 추가"})),/<html[^>]*\slang\s*=/i.test(r)||(t-=4,e.push({category:"Language",issue:"HTML lang 속성 누락",impact:"스크린리더 언어 인식 불가, WCAG 2.1 위반",severity:"CRITICAL",legalRisk:"장애인차별금지법 위반 가능",fix:'<html lang="ko"> 추가'})),/<meta[^>]*charset/i.test(r)||(t-=2,e.push({category:"Encoding",issue:"charset 선언 누락",impact:"한글 깨짐 위험",severity:"MEDIUM",fix:'<meta charset="UTF-8"> 추가'}));const o=["header","nav","main","footer"],c=o.filter(p=>new RegExp(`<${p}[\\s>]`,"i").test(r));if(c.length<3){const p=(3-c.length)*3;t-=p;const f=o.filter(y=>!new RegExp(`<${y}[\\s>]`,"i").test(r));e.push({category:"Semantic Structure",issue:`시맨틱 랜드마크 부족 (${c.length}/4)`,impact:"SEO 불리, 스크린리더 네비게이션 불가",severity:"HIGH",fix:`누락 태그 추가: ${f.join(", ")}`})}const d=(r.match(/\sid\s*=\s*["']([^"']+)["']/gi)||[]).map(p=>{const f=p.match(/id\s*=\s*["']([^"']+)["']/i);return f?f[1]:""}).filter(p=>p),u=d.filter((p,f)=>d.indexOf(p)!==f),h=[...new Set(u)];if(h.length>0){const p=Math.min(5,h.length*2);t-=p,e.push({category:"HTML Validity",issue:`중복 ID ${h.length}개 발견`,impact:"JavaScript 오작동, 접근성 보조기기 혼란",severity:"HIGH",fix:`중복 ID 제거: ${h.slice(0,3).join(", ")}`})}return{score:Math.max(0,t),findings:e}}function Ik(r){let t=30;const e=[],i=(r.match(/<img[^>]*>/gi)||[]).filter(d=>!/ alt\s*=/i.test(d));if(i.length>0){const d=Math.min(12,i.length*2);t-=d,e.push({category:"Image Accessibility",issue:`alt 속성 누락 이미지 ${i.length}개`,impact:"시각장애인 콘텐츠 접근 불가",severity:"CRITICAL",legalRisk:"장애인차별금지법 위반, 과태료 최대 3천만원",govStandard:"KWCAG 2.2 필수 준수 사항",fix:"모든 <img> 태그에 alt 속성 추가"})}const s=(r.match(/<input(?![^>]*type\s*=\s*["']hidden["'])[^>]*>/gi)||[]).concat(r.match(/<select[^>]*>/gi)||[]).concat(r.match(/<textarea[^>]*>/gi)||[]);let o=0;if(s.forEach(d=>{var y;const h=/ id\s*=/i.test(d)?(y=d.match(/ id\s*=\s*["']([^"']+)["']/i))==null?void 0:y[1]:"",p=h&&new RegExp(`<label[^>]*for\\s*=\\s*["']${h}["']`,"i").test(r),f=/ aria-label\s*=/i.test(d)||/ aria-labelledby\s*=/i.test(d);!p&&!f&&o++}),o>0){const d=Math.min(10,o*3);t-=d,e.push({category:"Form Accessibility",issue:`레이블 없는 입력 필드 ${o}개`,impact:"스크린리더 사용자 입력 불가",severity:"CRITICAL",legalRisk:"KWCAG 2.2 위반",govStandard:"정부24 필수 준수 사항",fix:"모든 입력 필드에 <label> 또는 aria-label 연결"})}const l=(r.match(/<(div|span)[^>]*onclick[^>]*>/gi)||[]).filter(d=>!/ tabindex\s*=/i.test(d)&&!/ role\s*=/i.test(d));if(l.length>0){const d=Math.min(8,l.length*2);t-=d,e.push({category:"Keyboard Accessibility",issue:`키보드 접근 불가 요소 ${l.length}개`,impact:"키보드 전용 사용자 기능 사용 불가",severity:"CRITICAL",legalRisk:"장애인차별금지법 핵심 위반 사항",fix:'tabindex="0" 또는 role 속성 추가, 또는 <button> 태그 사용'})}return{score:Math.max(0,t),findings:e}}function Nk(r){let t=25;const e=[],n=r.match(/<h[1-6][^>]*>.*?<\/h[1-6]>/gi)||[];if(n.length===0)t-=10,e.push({category:"Document Structure",issue:"헤딩 태그 전혀 없음",impact:"문서 구조 파악 불가, SEO 심각한 불리",severity:"CRITICAL",fix:"<h1>~<h6> 태그로 문서 구조 정의"});else{const c=(r.match(/<h1[^>]*>/gi)||[]).length;c===0?(t-=5,e.push({category:"Headings",issue:"H1 태그 누락",impact:"페이지 주제 파악 불가, SEO 불리",severity:"HIGH",fix:"페이지 제목을 <h1> 태그로 표시"})):c>1&&(t-=3,e.push({category:"Headings",issue:`H1 태그 중복 (${c}개)`,impact:"SEO 불리, 스크린리더 혼란",severity:"MEDIUM",fix:"H1은 페이지당 1개만 사용"}));const l=n.map(u=>{const h=u.match(/<h([1-6])/i);return h?parseInt(h[1]):0});let d=0;for(let u=1;u<l.length;u++)l[u]-l[u-1]>1&&d++;if(d>0){const u=Math.min(2,d);t-=u,e.push({category:"Headings",issue:`헤딩 레벨 건너뛰기 ${d}회`,impact:"논리적 구조 파악 어려움",severity:"MEDIUM",fix:"헤딩 레벨을 순차적으로 사용 (H1→H2→H3)"})}}const i=r.match(/<a[^>]*href\s*=\s*["'](#|javascript:void\(0\))["'][^>]*>/gi)||[];if(i.length>0){const c=Math.min(8,i.length);t-=c,e.push({category:"Interactive Elements",issue:`<a> 태그를 버튼으로 오용 ${i.length}개`,impact:"키보드 네비게이션 혼란, 접근성 저하",severity:"HIGH",fix:"페이지 이동은 <a>, 액션은 <button> 사용"})}const s=(r.match(/<li[^>]*>/gi)||[]).length,o=(r.match(/<ul[^>]*>/gi)||[]).length+(r.match(/<ol[^>]*>/gi)||[]).length;return s>o*3&&(t-=7,e.push({category:"List Structure",issue:"부모 없는 <li> 태그 가능성",impact:"HTML 표준 위반, 스타일 오작동",severity:"MEDIUM",fix:"<li>는 반드시 <ul> 또는 <ol> 내부에 배치"})),{score:Math.max(0,t),findings:e}}function Mk(r){var c;let t=20;const e=[];if(!/<meta[^>]*name\s*=\s*["']viewport["'][^>]*>/i.test(r))t-=8,e.push({category:"Mobile Standards",issue:"viewport 메타 태그 누락",impact:"모바일 기기에서 확대/축소 문제",severity:"HIGH",govStandard:"행안부 모바일 웹 표준 필수",fix:'<meta name="viewport" content="width=device-width, initial-scale=1.0"> 추가'});else{const l=((c=r.match(/<meta[^>]*name\s*=\s*["']viewport["'][^>]*>/i))==null?void 0:c[0])||"";/user-scalable\s*=\s*no/i.test(l)&&(t-=4,e.push({category:"Accessibility",issue:"사용자 확대 제한 설정 (user-scalable=no)",impact:"저시력자 접근성 저해",severity:"HIGH",legalRisk:"WCAG 2.1 위반",fix:"user-scalable=no 제거"}))}const i=(r.match(/<(font|center|marquee|blink)[^>]*>/gi)||[]).length,s=(r.match(/\s(align|bgcolor|border)\s*=/gi)||[]).length,o=i+s;if(o>0){const l=Math.min(8,o*2);t-=l,e.push({category:"Legacy Code",issue:`구형 HTML 요소/속성 ${o}개`,impact:"최신 브라우저에서 무시됨, 유지보수 어려움",severity:"MEDIUM",fix:"CSS로 대체 (font → style, center → text-align 등)"})}return{score:Math.max(0,t),findings:e}}function Ak(r){try{const t=Ek(r),e=Ik(r),n=Nk(r),i=Mk(r),s=t.score+e.score+n.score+i.score;let o;s>=90?o="A":s>=80?o="B":s>=70?o="C":o="D";const c=85,l=s-c;let d;s<70?d="높음":s<80?d="보통":d="낮음";const u=[...t.findings,...e.findings,...n.findings,...i.findings].sort((h,p)=>{const f={CRITICAL:0,HIGH:1,MEDIUM:2,LOW:3};return f[h.severity]-f[p.severity]});return{totalScore:s,grade:o,breakdown:{htmlStructure:`${t.score}/25`,accessibility:`${e.score}/30`,semanticMarkup:`${n.score}/25`,compatibility:`${i.score}/20`},govComparison:{siteScore:s,govAverage:c,gap:l,status:l>=0?"정부 표준 준수":"표준 미달",ranking:l>=11?"상위 10% (모범사례)":l>=0?"평균 이상":"개선 필요",legalRisk:d,mandatoryCompliance:{accessibility:"법적 의무 (장애인차별금지법)",deadline:"2025년 4월부터 과태료 부과",penalty:"위반 시 최대 3천만원",kwcag:"KWCAG 2.2 AA 등급 필수"}},userImpact:{disabledUsers:s<70?"장애인 사용자 87% 접근 불가":s<80?"장애인 사용자 40% 접근 제한":"장애인 접근성 양호",elderlyUsers:s<70?"고령층 사용자 64% 어려움":s<80?"고령층 사용자 30% 어려움":"고령층 사용성 양호",seoImpact:s<70?"검색 순위 -35%":s<80?"검색 순위 -15%":"SEO 최적화"},findings:u,detailedAnalysis:{htmlStructure:t,accessibility:e,semanticMarkup:n,compatibility:i}}}catch(t){return console.error("Web standards compliance analysis error:",t),{totalScore:0,grade:"D",breakdown:{htmlStructure:"0/25",accessibility:"0/30",semanticMarkup:"0/25",compatibility:"0/20"},govComparison:{siteScore:0,govAverage:85,gap:-85,status:"분석 실패",ranking:"분석 불가",legalRisk:"높음",mandatoryCompliance:{accessibility:"법적 의무 (장애인차별금지법)",deadline:"2025년 4월부터 과태료 부과",penalty:"위반 시 최대 3천만원",kwcag:"KWCAG 2.2 AA 등급 필수"}},userImpact:{disabledUsers:"분석 불가",elderlyUsers:"분석 불가",seoImpact:"분석 불가"},findings:[{category:"분석 오류",issue:"웹 표준 분석 중 오류가 발생했습니다.",severity:"CRITICAL"}],detailedAnalysis:{htmlStructure:{score:0,findings:[]},accessibility:{score:0,findings:[]},semanticMarkup:{score:0,findings:[]},compatibility:{score:0,findings:[]}}}}}const Tk=JSON.parse(`{"N1_1_current_location":{"base_score":3.5,"conditions":[{"field":"navigation.breadcrumbExists","operator":"==","value":true,"adjustment":1.5}],"default_adjustment":-1,"description":"Breadcrumb 존재 시 가산점"},"N1_2_loading_status":{"base_score":3.5,"conditions":[{"field":"accessibility.loadingUI.score","operator":">=","value":8,"adjustment":1.5},{"field":"accessibility.loadingUI.score","operator":">=","value":6,"adjustment":1},{"field":"accessibility.loadingUI.score","operator":">=","value":4,"adjustment":0.5},{"field":"accessibility.loadingUI.score","operator":">=","value":2,"adjustment":0}],"default_adjustment":-1,"description":"로딩 UI 하이브리드 점수 기반 평가 (base 3.5점, 8점 이상: +1.5, 6점 이상: +1.0, 4점 이상: +0.5, 2점 미만: -1.0)"},"N1_3_action_feedback":{"base_score":3.5,"conditions":[{"field":"accessibility.actionFeedback.score","operator":">=","value":8,"adjustment":1.5},{"field":"accessibility.actionFeedback.score","operator":">=","value":6,"adjustment":1},{"field":"accessibility.actionFeedback.score","operator":">=","value":4,"adjustment":0.5},{"field":"accessibility.actionFeedback.score","operator":">=","value":2,"adjustment":0}],"default_adjustment":-1,"description":"행동 피드백 3차원 측정 (즉시 피드백 + 상태 변화 + 사용자 도움) - base 3.5점, 8점 이상: +1.5, 6점 이상: +1.0, 4점 이상: +0.5, 2점 미만: -1.0"},"N2_1_familiar_terms":{"base_score":3.5,"conditions":[{"field":"accessibility.langAttribute","operator":"==","value":true,"adjustment":1}],"default_adjustment":-0.5,"description":"lang 속성 존재 시 가산점"},"N2_2_natural_flow":{"base_score":3.5,"conditions":[{"field":"content.headingCount","operator":">=","value":3,"adjustment":1}],"default_adjustment":-0.5,"description":"헤딩 3개 이상 시 가산점"},"N2_3_real_world_metaphor":{"base_score":3.5,"conditions":[{"field":"visuals.iconCount","operator":">","value":5,"adjustment":0.5}],"default_adjustment":-0.5,"description":"아이콘 5개 초과 시 가산점"},"N3_1_undo_redo":{"base_score":3,"conditions":[{"field":"forms.formCount","operator":">","value":0,"adjustment":0.5}],"default_adjustment":-0.5,"description":"폼 존재 시 가산점"},"N3_3_flexible_navigation":{"base_score":3.5,"conditions":[{"field":"navigation.linkCount","operator":">=","value":15,"adjustment":1}],"default_adjustment":-1,"description":"링크 15개 이상 시 가산점"},"N4_1_visual_consistency":{"base_score":3.5,"conditions":[{"field":"visuals.imageCount","operator":"between","min":3,"max":30,"adjustment":1}],"default_adjustment":-0.5,"description":"이미지 3~30개 범위가 최적"},"N4_2_terminology_consistency":{"base_score":3.5,"conditions":[{"field":"content.headingCount","operator":">=","value":3,"adjustment":0.5}],"default_adjustment":-0.5,"description":"헤딩 3개 이상 시 가산점"},"N4_3_standard_compliance":{"base_score":3.5,"conditions":[{"field":"accessibility.langAttribute","operator":"==","value":true,"adjustment":1},{"field":"accessibility.altTextRatio","operator":">","value":0.7,"adjustment":0.5}],"default_adjustment":-1,"description":"lang 속성 또는 alt 비율 70% 이상 시 가산점"},"N5_1_input_validation":{"base_score":3.5,"conditions":[{"field":"forms.validationExists","operator":"==","value":true,"adjustment":1.5},{"field":"forms.formCount","operator":"==","value":0,"adjustment":0}],"default_adjustment":-1.5,"description":"입력 검증 존재 시 가산점, 폼 없으면 중립"},"N5_2_confirmation_dialog":{"base_score":3,"conditions":[{"field":"forms.formCount","operator":">","value":0,"adjustment":0.5}],"default_adjustment":0,"description":"폼 존재 시 가산점"},"N5_3_constraints":{"base_score":2,"conditions":[{"field":"forms.constraintQuality.score","operator":">=","value":90,"adjustment":3},{"field":"forms.constraintQuality.score","operator":">=","value":75,"adjustment":2},{"field":"forms.constraintQuality.score","operator":">=","value":60,"adjustment":1},{"field":"forms.constraintQuality.score","operator":">=","value":40,"adjustment":0},{"field":"forms.constraintQuality.totalInputs","operator":"==","value":0,"adjustment":0}],"default_adjustment":-1,"description":"제약조건 명시 품질 평가: 90점 이상 excellent(5.0), 75점 good(4.0), 60점 basic(3.0), 40점 minimal(2.0), 그 이하 poor(1.0). 입력 필드 없음 N/A(2.0 중립). PIGS 프레임워크: 명시적 규칙(35%) + 예시 제공(30%) + 필수 표시(35%)"},"N6_2_recognition_cues":{"base_score":3.5,"conditions":[{"field":"visuals.iconCount","operator":">","value":5,"adjustment":1},{"field":"visuals.iconCount","operator":">","value":0,"adjustment":0.5}],"default_adjustment":-0.5,"description":"아이콘 5개 초과 시 높은 가산점, 1개 이상 시 낮은 가산점"},"N6_3_memory_load":{"base_score":2,"conditions":[{"field":"forms.memoryLoadSupport.score","operator":">=","value":80,"adjustment":3},{"field":"forms.memoryLoadSupport.score","operator":">=","value":60,"adjustment":2},{"field":"forms.memoryLoadSupport.score","operator":">=","value":40,"adjustment":1},{"field":"forms.memoryLoadSupport.score","operator":">=","value":20,"adjustment":0}],"default_adjustment":-1,"description":"기억 부담 최소화 품질 평가: 80점 이상 excellent(5.0), 60점 good(4.0), 40점 basic(3.0), 20점 minimal(2.0), 그 이하 poor(1.0). Breadcrumb(40점) + autocomplete(30점) + 기본값(20점) + datalist(10점)"},"N7_1_accelerators":{"base_score":1,"conditions":[{"field":"forms.flexibilityEfficiency.accelerators.score","operator":">=","value":35,"adjustment":4},{"field":"forms.flexibilityEfficiency.accelerators.score","operator":">=","value":25,"adjustment":3},{"field":"forms.flexibilityEfficiency.accelerators.score","operator":">=","value":15,"adjustment":2},{"field":"forms.flexibilityEfficiency.accelerators.score","operator":">=","value":5,"adjustment":1},{"field":"forms.flexibilityEfficiency.accelerators.score","operator":">=","value":0,"adjustment":0}],"default_adjustment":0,"description":"가속 장치 평가 (키보드 단축키 + 빠른 메뉴 + 최근 이용 + Skip Nav): 35점 이상 5.0, 25점 4.0, 15점 3.0, 5점 2.0, 그 이하 1.0. 정부 평균: 키보드 단축키 90% 미제공"},"N7_2_personalization":{"base_score":1,"conditions":[{"field":"forms.flexibilityEfficiency.personalization.score","operator":">=","value":30,"adjustment":4},{"field":"forms.flexibilityEfficiency.personalization.score","operator":">=","value":20,"adjustment":3},{"field":"forms.flexibilityEfficiency.personalization.score","operator":">=","value":10,"adjustment":2},{"field":"forms.flexibilityEfficiency.personalization.score","operator":">=","value":5,"adjustment":1},{"field":"forms.flexibilityEfficiency.personalization.score","operator":">=","value":0,"adjustment":0}],"default_adjustment":0,"description":"개인화 평가 (설정 + 글자 크기 + 테마 + 언어): 30점 이상 5.0, 20점 4.0, 10점 3.0, 5점 2.0, 그 이하 1.0. 정부 평균: 85% 미제공, 고령층 글자 크기 불편"},"N7_3_batch_operations":{"base_score":1,"conditions":[{"field":"forms.flexibilityEfficiency.batchOperations.score","operator":">=","value":20,"adjustment":4},{"field":"forms.flexibilityEfficiency.batchOperations.score","operator":">=","value":15,"adjustment":3},{"field":"forms.flexibilityEfficiency.batchOperations.score","operator":">=","value":10,"adjustment":2},{"field":"forms.flexibilityEfficiency.batchOperations.score","operator":">=","value":5,"adjustment":1},{"field":"forms.flexibilityEfficiency.batchOperations.score","operator":">=","value":0,"adjustment":0}],"default_adjustment":0,"description":"일괄 처리 평가 (전체 선택 + 일괄 작업): 20점 이상 5.0, 15점 4.0, 10점 3.0, 5점 2.0, 그 이하 1.0. 정부 평균: 78% 미제공"},"N8_1_essential_info":{"base_score":3.5,"conditions":[{"field":"content.paragraphCount","operator":"between","min":5,"max":30,"adjustment":1.5},{"field":"content.paragraphCount","operator":">","value":30,"adjustment":0.5},{"field":"content.paragraphCount","operator":">","value":0,"adjustment":0}],"default_adjustment":-1,"description":"문단 5~30개 최적, 30개 초과는 중간, 0개는 감점"},"N8_2_clean_interface":{"base_score":3.5,"conditions":[{"field":"visuals.imageCount","operator":"between","min":3,"max":20,"adjustment":1.5},{"field":"visuals.imageCount","operator":"between","min":21,"max":40,"adjustment":0.5},{"field":"visuals.imageCount","operator":">","value":40,"adjustment":-0.5}],"default_adjustment":0,"description":"이미지 3~20개 최적, 21~40개 중간, 40개 초과 감점"},"N8_3_visual_hierarchy":{"base_score":3.5,"conditions":[{"field":"content.headingCount","operator":"between","min":5,"max":15,"adjustment":1.5},{"field":"content.headingCount","operator":">","value":3,"adjustment":1},{"field":"content.headingCount","operator":">","value":0,"adjustment":0}],"default_adjustment":-1,"description":"헤딩 5~15개 최적, 3개 초과 양호, 0개 감점"},"N9_2_recovery_support":{"base_score":3,"conditions":[{"field":"forms.errorRecovery.score","operator":">=","value":80,"adjustment":2},{"field":"forms.errorRecovery.score","operator":">=","value":60,"adjustment":1.5},{"field":"forms.errorRecovery.score","operator":">=","value":40,"adjustment":1},{"field":"forms.errorRecovery.score","operator":">=","value":20,"adjustment":0.5},{"field":"forms.errorRecovery.score","operator":"==","value":0,"adjustment":0}],"default_adjustment":-0.5,"description":"오류 회복 3단계 프로세스 (인식+진단+복구) 점수 기반: 80점 이상 우수, 60점 이상 양호, 40점 이상 보통, 20점 이상 미흡, 0점 평가 없음"},"N9_4_error_guidance":{"base_score":3.5,"conditions":[{"field":"forms.errorRecovery.diagnosis.score","operator":">=","value":32,"adjustment":1.5},{"field":"forms.errorRecovery.diagnosis.score","operator":">=","value":24,"adjustment":1},{"field":"forms.errorRecovery.diagnosis.score","operator":">=","value":16,"adjustment":0.5},{"field":"forms.errorRecovery.score","operator":"==","value":0,"adjustment":0}],"default_adjustment":-0.5,"description":"원인 진단 점수 기반 (정부 72% 불만 반영): 32점 이상(80%) 우수, 24점 이상(60%) 양호, 16점 이상(40%) 보통"},"N10_1_help_visibility":{"base_score":3,"conditions":[{"field":"helpDocumentation.accessibility.score","operator":">=","value":20,"adjustment":2},{"field":"helpDocumentation.accessibility.score","operator":">=","value":15,"adjustment":1.5},{"field":"helpDocumentation.accessibility.score","operator":">=","value":10,"adjustment":1},{"field":"helpDocumentation.accessibility.score","operator":">=","value":5,"adjustment":0.5},{"field":"helpDocumentation.accessibility.score","operator":"==","value":0,"adjustment":0}],"default_adjustment":0,"description":"도움말 접근성 평가 (25점 만점): 20점 이상 우수, 15점 이상 양호, 10점 이상 보통, 5점 이상 미흡, 0점 평가 불가. 정부 95% 헤더 배치 기준"},"N10_2_documentation":{"base_score":3,"conditions":[{"field":"helpDocumentation.quality.score","operator":">=","value":20,"adjustment":2},{"field":"helpDocumentation.quality.score","operator":">=","value":15,"adjustment":1.5},{"field":"helpDocumentation.quality.score","operator":">=","value":10,"adjustment":1},{"field":"helpDocumentation.quality.score","operator":">=","value":5,"adjustment":0.5},{"field":"helpDocumentation.quality.score","operator":"==","value":0,"adjustment":0}],"default_adjustment":0,"description":"문서 품질 평가 (25점 만점): 20점 이상 우수, 15점 이상 양호, 10점 이상 보통, 5점 이상 미흡, 0점 평가 불가. 정부 63% '따라할 수 없다' 불만 반영"}}`),Pk={weights:Tk};function $k(r,t){const e=t.split(".");let n=r;for(const i of e){if(n==null)return;n=n[i]}return n}function Rk(r,t){const e=$k(r,t.field);if(e===void 0)return!1;switch(t.operator){case"==":return e===t.value;case"!=":return e!==t.value;case">":return e>t.value;case"<":return e<t.value;case">=":return e>=t.value;case"<=":return e<=t.value;case"between":return e>=t.min&&e<=t.max;default:return!1}}function Be(r,t){for(const e of t.conditions)if(Rk(r,e))return e.adjustment;return t.default_adjustment}function Fk(){return Pk.weights}function Hg(r){const t=Fk(),e=(n,i)=>{const s=Math.max(2,Math.min(5,n+i));return Math.round(s*2)/2};return{N1_1_current_location:e(t.N1_1_current_location.base_score,Be(r,t.N1_1_current_location)),N1_2_loading_status:e(t.N1_2_loading_status.base_score,Be(r,t.N1_2_loading_status)),N1_3_action_feedback:(()=>{const n=r.accessibility.actionFeedback,i=t.N1_3_action_feedback.base_score;let s=0;return n.score>=8?s=1.5:n.score>=6?s=1:n.score>=4?s=.5:n.score>=2?s=0:s=-1,Math.max(1,Math.min(5,i+s))})(),N2_1_familiar_terms:(()=>{const n=r.realWorldMatch,i=t.N2_1_familiar_terms.base_score;let s=0;n.languageFriendliness.score>=8?s=1.5:n.languageFriendliness.score>=6?s=.5:n.languageFriendliness.score>=4?s=-.5:n.languageFriendliness.score>=2?s=-1:s=-1.5;const o=e(i,s);return console.log(`[N2.1 Nielsen] languageFriendliness: ${n.languageFriendliness.score}, baseScore: ${i}, adjustment: ${s}, final: ${o}`),o})(),N2_2_natural_flow:(()=>{const n=r.realWorldMatch,i=t.N2_2_natural_flow.base_score;let s=0;return n.dataNaturalness.score>=8?s=1.5:n.dataNaturalness.score>=6?s=1:n.dataNaturalness.score>=4?s=.5:n.dataNaturalness.score>=2?s=0:s=-1,e(i,s)})(),N2_3_real_world_metaphor:(()=>{const n=r.realWorldMatch,i=t.N2_3_real_world_metaphor.base_score;let s=0;return n.interfaceFriendliness.score>=8?s=1.5:n.interfaceFriendliness.score>=6?s=1:n.interfaceFriendliness.score>=4?s=.5:n.interfaceFriendliness.score>=2?s=0:s=-1,e(i,s)})(),N3_1_undo_redo:e(t.N3_1_undo_redo.base_score,Be(r,t.N3_1_undo_redo)),N3_3_flexible_navigation:e(t.N3_3_flexible_navigation.base_score,Be(r,t.N3_3_flexible_navigation)),N4_1_visual_consistency:(()=>{var n;if((n=r.visuals)!=null&&n.visualConsistency){const s=r.visuals.visualConsistency.score/100*5;return Math.round(s*10)/10}return e(t.N4_1_visual_consistency.base_score,Be(r,t.N4_1_visual_consistency))})(),N4_2_terminology_consistency:(()=>{if(r.languageConsistency){const i=r.languageConsistency.totalScore/100*5;return Math.round(i*10)/10}return e(t.N4_2_terminology_consistency.base_score,Be(r,t.N4_2_terminology_consistency))})(),N4_3_standard_compliance:(()=>{if(r.webStandardsCompliance){const n=r.webStandardsCompliance.totalScore/100*5;return Math.round(n*10)/10}return e(t.N4_3_standard_compliance.base_score,Be(r,t.N4_3_standard_compliance))})(),N5_1_input_validation:(()=>{const n=e(t.N5_1_input_validation.base_score,Be(r,t.N5_1_input_validation));if(r.forms.realtimeValidation){const i=r.forms.realtimeValidation;if(i.quality==="excellent")return Math.min(5,n+.5);if(i.quality==="good")return Math.min(5,n+.3)}return n})(),N5_2_confirmation_dialog:e(t.N5_2_confirmation_dialog.base_score,Be(r,t.N5_2_confirmation_dialog)),N5_3_constraints:e(t.N5_3_constraints.base_score,Be(r,t.N5_3_constraints)),N6_2_recognition_cues:e(t.N6_2_recognition_cues.base_score,Be(r,t.N6_2_recognition_cues)),N6_3_memory_load:e(t.N6_3_memory_load.base_score,Be(r,t.N6_3_memory_load)),N7_1_accelerators:e(t.N7_1_accelerators.base_score,Be(r,t.N7_1_accelerators)),N7_2_personalization:e(t.N7_2_personalization.base_score,Be(r,t.N7_2_personalization)),N7_3_batch_operations:e(t.N7_3_batch_operations.base_score,Be(r,t.N7_3_batch_operations)),N8_1_essential_info:(()=>{var n;if((n=r.content)!=null&&n.textQuality){const i=r.content.textQuality;if(i.score===0&&i.grade==="N/A")return null;const s=i.score/100*5;return Math.round(s*10)/10}return e(t.N8_1_essential_info.base_score,Be(r,t.N8_1_essential_info))})(),N8_2_clean_interface:(()=>{var i;const n=(i=r.visuals)==null?void 0:i.interfaceCleanness;if(n&&n.score!==null&&n.score!==void 0){const s=Math.round(n.score/100*5*10)/10;return console.log("[DEBUG] N8.2 interfaceCleanness 점수 사용:",n.score,"→",s),s}return console.log("[DEBUG] N8.2 interfaceCleanness 없음 → 기존 로직 사용"),e(t.N8_2_clean_interface.base_score,Be(r,t.N8_2_clean_interface))})(),N8_3_visual_hierarchy:(()=>{var i;const n=(i=r.visuals)==null?void 0:i.informationScannability;if(n&&n.score!==null&&n.score!==void 0){const s=Math.round(n.score/100*5*10)/10;return console.log("[DEBUG] N8.3 informationScannability 점수 사용:",n.score,"→",s,"사람 검증:",n.needsManualReview),s}return console.log("[DEBUG] N8.3 informationScannability 없음 → 기존 로직 사용"),e(t.N8_3_visual_hierarchy.base_score,Be(r,t.N8_3_visual_hierarchy))})(),N9_2_recovery_support:e(t.N9_2_recovery_support.base_score,Be(r,t.N9_2_recovery_support)),N9_4_error_guidance:e(t.N9_4_error_guidance.base_score,Be(r,t.N9_4_error_guidance)),N10_1_help_visibility:e(t.N10_1_help_visibility.base_score,Be(r,t.N10_1_help_visibility)),N10_2_documentation:e(t.N10_2_documentation.base_score,Be(r,t.N10_2_documentation))}}function Wg(r,t,e){var d,u,h,p,f,y,w,b,C,A,T,M,D,U,O,K,F,H,B,P,N,j,W;const{navigation:n,accessibility:i,content:s,forms:o,visuals:c,helpDocumentation:l}=r;return{N1_1_current_location:{description:n.breadcrumbExists?`${e}에서 Breadcrumb 내비게이션이 발견되어 사용자가 현재 위치를 명확히 알 수 있습니다.`:`${e}에서 Breadcrumb이 없어 사용자가 현재 페이지의 위치를 파악하기 어려울 수 있습니다.`,recommendation:n.breadcrumbExists?"현재 위치 표시가 잘 되어 있습니다. 유지하세요.":"Breadcrumb 내비게이션을 추가하여 사용자가 현재 위치를 쉽게 파악할 수 있도록 개선하세요."},N1_2_loading_status:{description:(()=>{const g=i.loadingUI;return g?(console.log("[N1_2] loadingUI:",g),g.score>=8?`✅ 매우 우수한 로딩 UI (점수: ${g.score.toFixed(1)}/10)
발견된 패턴: ${g.details.join(", ")}
사용자가 페이지 로딩 상태를 명확하게 인지할 수 있습니다.`:g.score>=6?`✓ 좋은 로딩 UI (점수: ${g.score.toFixed(1)}/10)
발견된 패턴: ${g.details.join(", ")}
로딩 상태 표시가 적절하게 구현되어 있습니다.`:g.score>=4?`△ 기본적인 로딩 UI (점수: ${g.score.toFixed(1)}/10)
발견된 패턴: ${g.details.join(", ")}
로딩 상태를 알리지만 개선의 여지가 있습니다.`:g.score>=2?`⚠️ 최소한의 로딩 UI (점수: ${g.score.toFixed(1)}/10)
발견된 패턴: ${g.details.join(", ")}
로딩 상태 표시가 부족합니다.`:`❌ 로딩 UI 없음 (점수: ${g.score.toFixed(1)}/10)
HTML에서 로딩 상태를 알려주는 시각적 표시나 텍스트가 거의 없어 사용자가 페이지 로딩 중인지 파악하기 어렵습니다.`):(console.warn("[N1_2] loadingUI is undefined in accessibility:",i),"로딩 UI 분석 데이터를 찾을 수 없습니다.")})(),recommendation:(()=>{const g=i.loadingUI;return g?g.score>=8?`✅ 로딩 UI가 매우 우수합니다! 다음을 유지하세요:
• 다양한 로딩 패턴 (ARIA, HTML5, 애니메이션)
• 접근성 속성 (aria-busy, role="status")
• 시각적 피드백 (스피너, 프로그레스 바)`:g.score>=6?`✓ 로딩 UI가 잘 구현되어 있습니다. 추가 개선 사항:
• 로딩 지속 시간이 긴 경우 진행률 표시 추가
• 모든 비동기 작업에 일관된 로딩 표시 적용`:g.score>=4?`△ 로딩 UI 개선 권장 (현재 점수: ${g.score.toFixed(1)}/10)

**추가하면 좋은 요소:**
1. **ARIA 속성**: aria-busy="true", role="progressbar", aria-live="polite"
2. **HTML5 태그**: <progress value="70" max="100"></progress>
3. **CSS 애니메이션**: 스피너 회전 효과 (@keyframes spin)
4. **로딩 텍스트**: "로딩 중...", "처리 중...", "잠시만 기다려주세요"

**예시 코드:**
\`\`\`html
<!-- 접근성이 우수한 로딩 UI -->
<div class="loading-spinner" role="status" aria-live="polite">
  <div class="spinner"></div>
  <span class="sr-only">로딩 중입니다...</span>
</div>
\`\`\``:g.score>=2?`⚠️ 로딩 UI가 부족합니다 (현재 점수: ${g.score.toFixed(1)}/10)

**시급히 추가해야 할 요소:**
1. **CSS 스피너**: 간단한 회전 애니메이션
\`\`\`css
@keyframes spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
.spinner { animation: spin 1s linear infinite; }
\`\`\`

2. **로딩 텍스트**: 최소한 "로딩 중..." 메시지
3. **프로그레스 바**: <progress> 태그로 진행 상태 표시
4. **ARIA 레이블**: aria-busy="true"로 스크린 리더 지원`:`❌ 로딩 UI가 거의 없습니다 (현재 점수: ${g.score.toFixed(1)}/10)

**즉시 구현 필요:**

**1단계: 기본 스피너 추가**
\`\`\`html
<div class="loading" role="status">
  <div class="spinner"></div>
  <span>로딩 중...</span>
</div>
\`\`\`

**2단계: CSS 애니메이션**
\`\`\`css
.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
\`\`\`

**3단계: 접근성 강화**
- aria-busy="true" 추가
- role="status" 또는 role="progressbar" 사용
- aria-live="polite"로 스크린 리더 알림

**4단계: 동적 로딩 UI**
- JavaScript로 비동기 작업 시작 시 로딩 표시
- 작업 완료 시 자동으로 로딩 숨김`:"로딩 UI 분석 데이터를 확인할 수 없습니다."})()},N1_3_action_feedback:(()=>{const g=r.accessibility.actionFeedback,E=g.score;return E>=8?{description:`🌟 행동 피드백 우수 (점수: ${E.toFixed(1)}/10)

**발견된 우수한 피드백 시스템:**
${g.details.slice(0,10).join(`
`)}

**3차원 분석 결과:**
- 즉시 피드백: ${g.immediateFeedback.microInteractions.toFixed(1)}/3점
- 상태 변화 능력: ${g.stateManagement.stateInteractionScore.toFixed(1)}/4점
- 사용자 도움: ${g.userAssistance.assistanceScore.toFixed(1)}/3점
- 인터랙션 밀도: ${(g.interactionDensity*100).toFixed(0)}%`,recommendation:`✅ 행동 피드백이 매우 우수합니다! (${E.toFixed(1)}/10)

**현재 구현된 강점:**
- 호버, 포커스, 클릭에 대한 즉각적인 시각적 반응
- 상태 변화를 명확히 표현하는 인터랙티브 요소
- 사용자 입력을 돕는 자동완성 및 실시간 알림

**유지 권장사항:**
- 현재 수준의 피드백 시스템 유지
- 새로운 기능 추가 시에도 동일한 수준의 반응성 적용
- 정기적으로 인터랙션 밀도 모니터링`}:E>=6?{description:`✅ 행동 피드백 양호 (점수: ${E.toFixed(1)}/10)

**발견된 피드백 요소:**
${g.details.slice(0,8).join(`
`)}

**3차원 분석 결과:**
- 즉시 피드백: ${g.immediateFeedback.microInteractions.toFixed(1)}/3점
- 상태 변화 능력: ${g.stateManagement.stateInteractionScore.toFixed(1)}/4점
- 사용자 도움: ${g.userAssistance.assistanceScore.toFixed(1)}/3점`,recommendation:`✅ 행동 피드백이 양호합니다 (${E.toFixed(1)}/10)

**추가 개선 방향:**

${g.immediateFeedback.microInteractions<2?`**1. 즉시 피드백 강화 (현재: ${g.immediateFeedback.microInteractions.toFixed(1)}/3)**
\`\`\`css
/* 호버 효과 개선 */
button:hover {
  background-color: #0056b3;
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  transition: all 0.3s ease;
}

/* 포커스 스타일 추가 */
button:focus-visible {
  outline: 3px solid #007bff;
  outline-offset: 2px;
}
\`\`\`
`:""}

${g.stateManagement.stateInteractionScore<2.5?`**2. 상태 관리 개선 (현재: ${g.stateManagement.stateInteractionScore.toFixed(1)}/4)**
\`\`\`html
<!-- 접기/펼치기 UI -->
<details>
  <summary>자세히 보기</summary>
  <p>추가 내용...</p>
</details>

<!-- 토글 버튼 -->
<button aria-pressed="false" onclick="this.setAttribute('aria-pressed', this.getAttribute('aria-pressed') === 'false')">
  알림 켜기/끄기
</button>
\`\`\`
`:""}

${g.userAssistance.assistanceScore<1.5?`**3. 사용자 도움 강화 (현재: ${g.userAssistance.assistanceScore.toFixed(1)}/3)**
\`\`\`html
<!-- 자동완성 -->
<input autocomplete="name" />

<!-- 데이터리스트 -->
<input list="browsers" />
<datalist id="browsers">
  <option value="Chrome">
  <option value="Firefox">
</datalist>

<!-- 실시간 알림 -->
<div aria-live="polite" role="status"></div>
\`\`\`
`:""}`}:E>=4?{description:`⚠️ 행동 피드백 보통 (점수: ${E.toFixed(1)}/10)

기본적인 피드백이 일부 구현되어 있지만, 개선이 필요합니다.

**현재 발견된 요소:**
${g.details.slice(0,5).join(`
`)||"- 피드백 요소가 거의 없습니다"}

**3차원 분석 결과:**
- 즉시 피드백: ${g.immediateFeedback.microInteractions.toFixed(1)}/3점
- 상태 변화 능력: ${g.stateManagement.stateInteractionScore.toFixed(1)}/4점
- 사용자 도움: ${g.userAssistance.assistanceScore.toFixed(1)}/3점`,recommendation:`⚠️ 행동 피드백 개선 필요 (현재: ${E.toFixed(1)}/10)

**우선순위 개선 작업:**

**1단계: 기본 호버/포커스 효과 추가**
\`\`\`css
/* 모든 클릭 가능 요소에 호버 효과 */
a, button, [role="button"] {
  transition: all 0.2s ease;
}

a:hover, button:hover {
  opacity: 0.8;
  cursor: pointer;
}

/* 포커스 링 (키보드 접근성) */
*:focus-visible {
  outline: 2px solid #007bff;
  outline-offset: 2px;
}
\`\`\`

**2단계: 상태 변화 ARIA 속성 추가**
\`\`\`html
<!-- 아코디언 메뉴 -->
<button aria-expanded="false">메뉴 펼치기</button>

<!-- 탭 UI -->
<button role="tab" aria-selected="true">탭 1</button>
<button role="tab" aria-selected="false">탭 2</button>
\`\`\`

**3단계: 폼 입력 도움**
\`\`\`html
<input type="email" 
       autocomplete="email" 
       inputmode="email"
       aria-describedby="email-help" />
<div id="email-help" aria-live="polite"></div>
\`\`\``}:E>=2?{description:`❌ 행동 피드백 미흡 (점수: ${E.toFixed(1)}/10)

사용자 행동에 대한 피드백이 거의 없어 인터랙션이 불명확합니다.

**발견된 제한적 요소:**
${g.details.slice(0,3).join(`
`)||"- 피드백 시스템이 거의 없습니다"}`,recommendation:`❌ 행동 피드백 즉시 개선 필요 (현재: ${E.toFixed(1)}/10)

**긴급 개선 사항:**

**1단계: 최소한의 시각적 피드백**
\`\`\`css
/* 전역 호버 효과 */
button:hover, a:hover {
  opacity: 0.7;
  transition: opacity 0.2s;
}

/* 클릭 반응 */
button:active {
  transform: scale(0.98);
}

/* 포커스 표시 */
:focus-visible {
  outline: 2px solid #000;
}
\`\`\`

**2단계: 기본 상태 관리**
\`\`\`html
<!-- 버튼 상태 표시 -->
<button class="active">선택됨</button>
<button class="inactive">미선택</button>
\`\`\`

**3단계: 접근성 필수 속성**
\`\`\`html
<!-- ARIA 레이블 -->
<button aria-label="메뉴 열기">☰</button>

<!-- 실시간 알림 영역 -->
<div aria-live="polite" role="status"></div>
\`\`\`

**참고: 행동 피드백은 사용성의 핵심입니다. 즉시 개선을 권장합니다.**`}:{description:`❌ 행동 피드백 거의 없음 (점수: ${E.toFixed(1)}/10)

HTML에서 사용자 행동에 대한 시각적 피드백을 거의 찾을 수 없습니다. 호버 효과, 포커스 스타일, 상태 변화 표시가 없어 사용자가 자신의 행동이 시스템에 인식되었는지 알기 어렵습니다.`,recommendation:`❌ 행동 피드백 시스템 구축 필요 (현재: ${E.toFixed(1)}/10)

**즉시 구현 가이드:**

**1단계: 기본 CSS 피드백**
\`\`\`css
/* 최소한의 인터랙션 피드백 */
a, button {
  cursor: pointer;
  transition: all 0.2s;
}

a:hover, button:hover {
  filter: brightness(1.1);
}

button:active {
  filter: brightness(0.9);
}

:focus {
  outline: 2px solid blue;
}
\`\`\`

**2단계: HTML 구조 개선**
\`\`\`html
<!-- 명확한 버튼 -->
<button type="button">클릭</button>

<!-- 접근 가능한 링크 -->
<a href="#" aria-label="자세히 보기">더보기</a>
\`\`\`

**3단계: 상태 표시**
\`\`\`html
<!-- 현재 페이지 표시 -->
<a href="#" aria-current="page">홈</a>

<!-- 로딩 상태 -->
<button aria-busy="true">처리중...</button>
\`\`\`

**⚠️ 주의: 피드백 없는 인터페이스는 사용자 경험을 크게 저하시킵니다.**`}})(),N2_1_familiar_terms:{description:(()=>{const E=r.realWorldMatch.languageFriendliness;return E.score>=8?`✅ 친숙한 용어 사용: 전문용어 밀도 ${E.jargonDensity}%, 평균 문장 길이 ${E.avgSentenceLength}단어로 이해하기 쉽습니다.`:E.score>=6?`😊 대체로 친숙한 용어: 전문용어 밀도 ${E.jargonDensity}%, 평균 문장 길이 ${E.avgSentenceLength}단어입니다.`:E.score>=4?`⚠️ 다소 어려운 용어: 전문용어 밀도 ${E.jargonDensity}%, 평균 문장 길이 ${E.avgSentenceLength}단어로 개선 여지가 있습니다.`:`❌ 어려운 전문용어 과다: 전문용어 밀도 ${E.jargonDensity}%, 평균 문장 길이 ${E.avgSentenceLength}단어로 일반 사용자가 이해하기 어렵습니다.`})(),recommendation:(()=>{const E=r.realWorldMatch.languageFriendliness;if(E.score>=6)return"현재 상태를 유지하세요. 사용자 친화적인 언어를 잘 사용하고 있습니다.";{const k=[];return E.jargonDensity>5&&k.push('전문용어를 일상적 표현으로 바꾸세요 (예: "솔루션" → "해결책", "프로세스" → "절차")'),E.avgSentenceLength>25&&k.push("긴 문장을 짧게 나누세요 (목표: 10-20단어)"),k.length===0&&k.push("친숙한 용어를 더 많이 사용하여 가독성을 높이세요"),k.join(". ")+"."}})()},N2_2_natural_flow:{description:(()=>{const g=r.realWorldMatch,k=g.dataNaturalness.naturalRatio;return k>=70?`✅ 예측 가능한 구조: 점수 ${k}/100 (B 이상). ${g.details.filter(v=>v.startsWith("✅")).join(", ")}`:k>=50?`😊 준수한 구조: 점수 ${k}/100 (C등급). 일부 개선 필요.`:`⚠️ 예측성 부족: 점수 ${k}/100 (D등급). ${g.details.filter(v=>v.startsWith("⚠️")).slice(0,2).join(", ")}`})(),recommendation:(()=>{const g=r.realWorldMatch;if(g.dataNaturalness.naturalRatio>=70)return"현재 상태를 유지하세요. 페이지 구조가 예측 가능하고 표준을 잘 따릅니다.";{const v=[];return g.details.filter(V=>V.startsWith("⚠️")).forEach(V=>{V.includes("H1 태그가 없음")?v.push("H1 태그를 페이지당 1개 추가하세요"):V.includes("H1 태그가")?v.push("H1 태그를 페이지당 1개로 수정하세요"):V.includes("tabindex")?v.push("tabindex 사용을 줄이고 DOM 순서를 개선하세요"):V.includes("단계 표시")?v.push("프로세스 단계 표시(step indicator)를 추가하세요"):V.includes("로고")&&v.push("로고를 홈페이지 링크로 연결하세요")}),v.length>0?v.join(". ")+".":"페이지 구조를 표준에 맞게 개선하세요."}})()},N2_3_real_world_metaphor:{description:(()=>{const E=r.realWorldMatch.interfaceFriendliness;return E.score>=8?`✅ 현실 은유 활용: 행동 중심 동사 ${E.actionWords}개, 현실 은유 ${E.metaphors}개로 직관적입니다.`:E.score>=6?`😊 대체로 직관적: 행동 중심 동사 ${E.actionWords}개, 현실 은유 ${E.metaphors}개 사용.`:E.score>=4?`⚠️ 시스템 중심 언어 과다: 시스템 용어 ${E.systemWords}개, 사용자 중심 표현 부족.`:`❌ 비직관적 인터페이스: 현실 은유 ${E.metaphors}개로 매우 부족, 시스템 용어 ${E.systemWords}개로 과다.`})(),recommendation:(()=>{const E=r.realWorldMatch.interfaceFriendliness;if(E.score>=6)return"현재 상태를 유지하세요. 현실 세계 은유를 잘 활용하고 있습니다.";{const k=[];return E.actionWords<5&&k.push('명확한 행동 동사를 사용하세요 (예: "제출", "저장", "검색")'),E.metaphors<3&&k.push('현실 세계 은유를 활용하세요 (예: "장바구니", "폴더", "휴지통")'),E.systemWords>5&&k.push('시스템 중심 언어를 줄이세요 (예: "처리" → "진행", "실행" → "시작")'),k.join(". ")+"."}})()},N3_1_undo_redo:{description:(()=>{var V,re;const g=r.userControlFreedom;if(!g)return"비상구 분석 실패";const E=g.totalScore,k=g.grade,v=((V=g.govComparison)==null?void 0:V.gap)||"0",x=((re=g.govComparison)==null?void 0:re.percentile)||"미측정";return`비상구(Emergency Exit) ${E}/100점 (${k}등급) | 정부 49개 기관 평균 대비 ${v}점 (${x})`})(),recommendation:(()=>{const g=r.userControlFreedom;return g?g.recommendation||"✅ 정부 49개 기관 수준의 사용자 제어권 제공":"비상구 분석을 확인할 수 없습니다."})()},N3_3_flexible_navigation:{description:(()=>{var V,re;const g=r.navigationFreedom;if(!g)return"네비게이션 자유도 분석 실패";const E=g.totalScore,k=g.grade,v=((V=g.govComparison)==null?void 0:V.gap)||"0",x=((re=g.govComparison)==null?void 0:re.percentile)||"미측정";return`네비게이션 자유도 ${E}/100점 (${k}등급) | 정부 49개 기관 평균 대비 ${v}점 (${x})`})(),recommendation:(()=>{const g=r.navigationFreedom;return g?g.recommendation||"✅ 정부 49개 기관 수준의 네비게이션 제공":"네비게이션 자유도를 확인할 수 없습니다."})()},N4_1_visual_consistency:{description:(()=>{const g=c.visualConsistency;return g?g.grade==="A"?`✅ 시각적 일관성 우수 (${g.score}/100점)

**강점:**
${g.strengths.map(E=>`• ${E}`).join(`
`)}`:g.grade==="B"?`✓ 시각적 일관성 양호 (${g.score}/100점)

**발견된 문제:**
${g.issues.slice(0,2).map(E=>`• ${E.message}`).join(`
`)}`:g.grade==="C"?`⚠️ 시각적 일관성 개선 필요 (${g.score}/100점)

**주요 문제:**
${g.issues.slice(0,3).map(E=>`• [${E.severity}] ${E.message}`).join(`
`)}`:`❌ 시각적 일관성 미흡 (${g.score}/100점)

**긴급 개선 필요:**
${g.issues.map(E=>`• [${E.severity}] ${E.message}`).join(`
`)}`:`이미지 ${c.imageCount}개로 시각적 요소를 제공합니다.`})(),recommendation:(()=>{const g=c.visualConsistency;if(!g)return"시각적 일관성 분석 데이터가 없습니다.";if(g.grade==="A")return"✅ 현재 시각적 일관성을 유지하세요. 디자인 시스템이 잘 구축되어 있습니다.";if(g.grade==="B"){const E=g.issues[0];return`경미한 개선 권장: ${E?E.message:"CSS 클래스 체계 정리"}`}else{const E=[];return g.issues.forEach(k=>{k.type==="EXCESSIVE_INLINE_STYLES"?E.push("1. 인라인 스타일을 CSS 클래스로 전환 (Tailwind CSS 또는 BEM 방법론 권장)"):k.type==="BUTTON_CLASS_FRAGMENTATION"?E.push("2. 버튼 디자인 시스템 구축 (Primary, Secondary, Outline 등 3-5종으로 통일)"):k.type==="IMAGE_OVERLOAD"&&E.push("3. 이미지 최적화 및 Lazy Loading 적용")}),E.length===0&&E.push("디자인 시스템 문서화 및 컴포넌트 라이브러리 구축"),E.join(`
`)}})()},N4_2_terminology_consistency:(()=>{if(r.languageConsistency){const g=r.languageConsistency,{totalScore:E,grade:k,govComparison:v,findings:x}=g,V=x.length>0?x.slice(0,3).map(re=>re.category).join(", "):"발견된 문제 없음";return{description:`언어 일관성: ${E}/100점 (${k}등급). ${V}`,recommendation:v.gap>=0?`정부 표준 준수 (+${v.gap}점). 현재 상태를 유지하세요.`:`정부 평균 대비 ${Math.abs(v.gap)}점 낮음. ${x.length}개 항목 개선 필요.`}}return{description:s.headingCount>=3?"헤딩 구조가 용어 일관성을 지원합니다.":"헤딩이 부족하여 용어 일관성 확인이 어렵습니다.",recommendation:s.headingCount>=3?"현재 상태를 유지하세요.":"헤딩이 부족하여 용어 일관성 확인이 어렵습니다 개선이 필요합니다."}})(),N4_3_standard_compliance:(()=>{if(r.webStandardsCompliance){const g=r.webStandardsCompliance,E=g.findings.filter(x=>x.severity==="CRITICAL");let k=`웹 표준 준수: ${g.totalScore}/100 (${g.grade}등급)`;E.length>0&&(k+=` | 긴급 ${E.length}개: ${E[0].issue}`);let v="";return g.grade==="A"?v="✅ 웹 표준 우수 - 정부 상위 10% 수준":g.grade==="B"?v="대체로 준수 - 일부 보완 권장":g.grade==="C"?v=`⚠️ 개선 필요 - 법적 리스크: ${g.govComparison.legalRisk}`:v="❌ 긴급 개선 필요 - 법적 제재 위험",E.length>0&&(v+=` | 우선: ${E[0].fix||E[0].issue}`),{description:k,recommendation:v}}return{description:i.langAttribute?`HTML 표준(lang, alt 등)을 준수합니다. (alt 비율: ${(i.altTextRatio*100).toFixed(0)}%)`:`접근성 표준 준수가 미흡합니다. (alt 비율: ${(i.altTextRatio*100).toFixed(0)}%)`,recommendation:i.langAttribute?"현재 상태를 유지하세요.":"개선이 필요합니다."}})(),N5_1_input_validation:(()=>{const g=o.realtimeValidation;let E="",k="";if(o.formCount===0)E="ℹ️ 입력 폼이 없어 검증이 필요하지 않습니다.",k="ℹ️ 입력 폼이 없어 검증이 필요하지 않습니다.";else{const v=o.validationExists,x=g&&g.quality!=="none";if(v&&x?(E=`✅ 입력 검증 우수: 기본 검증(required, pattern) + 실시간 검증 ${g.score}/30점 (${g.quality})`,k="✅ 입력 검증이 우수합니다. 기본 검증과 실시간 검증을 모두 구현했습니다. 현재 상태를 유지하세요."):v?(E="✅ 입력 검증(required, pattern 등)이 구현되어 오류를 사전 예방합니다.",k="✅ 기본 검증은 잘 되어 있습니다. 실시간 검증(aria-invalid, 에러 메시지, aria-live)을 추가하면 사용자 경험이 더 향상됩니다."):x?(E=`✅ 실시간 검증 ${g.score}/30점 (${g.quality})이 구현되어 있습니다.`,k="✅ 실시간 검증은 잘 되어 있습니다. required, pattern 속성을 추가하면 더 강력한 검증이 가능합니다."):(E="⚠️ 입력 검증이 없어 잘못된 데이터 입력 가능성이 있습니다.",k="⚠️ 입력 검증 추가 필요: 1) required/pattern 속성, 2) aria-invalid, 3) 에러 메시지 영역, 4) aria-live 실시간 알림"),g&&g.totalForms>0){E+=`
  총 폼 ${g.totalForms}개 중 검증 있는 폼 ${g.formsWithValidation}개 (${g.validationRatio}%)`;const V=[];g.features.hasAriaInvalid>0&&V.push(`aria-invalid ${g.features.hasAriaInvalid}개`),g.features.hasErrorMessages>0&&V.push(`에러 메시지 ${g.features.hasErrorMessages}개`),g.features.hasLiveRegion>0&&V.push(`aria-live ${g.features.hasLiveRegion}개`),g.features.hasBrowserValidation>0&&V.push(`브라우저 검증 ${g.features.hasBrowserValidation}개`),V.length>0&&(E+=`
  Features: ${V.join(", ")}`)}}return{description:E,recommendation:k}})(),N5_2_confirmation_dialog:{description:o.formCount>0?"폼이 있어 중요한 작업 전 확인 절차가 가능합니다.":"ℹ️ 폼이 없어 확인 대화상자가 필요하지 않습니다.",recommendation:o.formCount>0?"폼이 있어 중요한 작업 전 확인 절차가 가능합니다. 현재 상태를 유지하세요.":"ℹ️ 폼이 없어 확인 대화상자가 필요하지 않습니다."},N5_3_constraints:{description:(()=>{if(!o.constraintQuality)return o.formCount===0?"ℹ️ 입력 필드가 없어 제약 조건 평가가 불가능합니다. (N/A)":"⚠️ 제약 조건 분석 데이터가 없습니다.";const g=o.constraintQuality;return g.totalInputs===0?"ℹ️ 입력 필드가 없어 제약 조건 평가가 불가능합니다. (N/A)":`${g.quality==="excellent"||g.quality==="good"?"✅":g.quality==="basic"||g.quality==="minimal"?"⚠️":"❌"} 입력 제약 조건 품질: ${g.quality.toUpperCase()} (${g.score}점/100점)
- 총 입력 필드: ${g.totalInputs}개
- 명시적 규칙: ${g.hasExplicitRules}개 (예: "8자 이상", "영문+숫자")
- 예시 제공: ${g.hasExamples}개 (placeholder, 도움말)
- 필수 표시: ${g.hasRequiredMarker}개 (*, required, aria-required)`})(),recommendation:(()=>{if(!o.constraintQuality||o.constraintQuality.totalInputs===0)return"ℹ️ 입력 필드가 없어 평가 대상이 아닙니다.";const g=o.constraintQuality;if(g.quality==="excellent"||g.quality==="good")return"✅ 입력 제약 조건이 명확히 표시되어 있습니다. 현재 상태를 유지하세요.";const E=[];return g.hasExplicitRules<g.totalInputs*.7&&E.push('🔹 명시적 규칙 강화: 비밀번호 조건("8자 이상, 영문+숫자+특수문자"), 파일 업로드 제한("10MB 이하, JPG/PNG만"), 날짜 형식("YYYY-MM-DD") 등을 입력 필드 근처에 명시하세요.'),g.hasExamples<g.totalInputs*.5&&E.push('🔹 예시 제공: placeholder에 "010-1234-5678", "abc@example.com" 등 구체적인 예시를 추가하세요. 또는 입력 필드 아래에 "예: 2024-01-15" 형식으로 도움말을 제공하세요.'),g.hasRequiredMarker<g.totalInputs*.3&&E.push('🔹 필수 표시 일관성: 모든 필수 입력 필드에 * 또는 "필수" 라벨을 추가하고, aria-required="true" 속성을 설정하세요.'),E.length===0?"⚠️ 제약 조건 표시를 더욱 명확히 개선하세요.":`⚠️ 즉시 개선 권장사항 (${g.score}점 → 90점+ 목표):

`+E.join(`

`)})()},N6_2_recognition_cues:(()=>{const g=c.iconCount,E=12,k=18;let v="",x="";const V=`

⚠️ **분석 한계**: 정적 HTML 기반 분석으로, JavaScript로 동적 렌더링되는 아이콘은 감지하지 못합니다. **전문가의 육안 확인 필수**입니다.`;return g>=k?(v=`✅ 아이콘 ${g}개로 인식 단서 우수 (정부 상위 10% 수준: ${k}개)${V}`,x=`✅ 인식 단서가 우수합니다. 현재 상태를 유지하되, **모든 아이콘에 텍스트 레이블을 병기**하세요. (사용자 73%가 텍스트 레이블에 의존, 아이콘만 있으면 58%가 의미 파악 못함)${V}`):g>=E?(v=`😊 아이콘 ${g}개로 인식 단서 제공 (정부 평균: ${E}개)${V}`,x=`😊 인식 단서가 적절합니다. 개선 방향:

🔹 **아이콘 + 텍스트 병기**: 사용자 73%가 텍스트 레이블에 의존합니다. 모든 아이콘 옆에 텍스트 라벨을 추가하세요.

🔹 **일관된 아이콘 사용**: 같은 기능은 같은 아이콘으로 표시하세요 (예: 검색=돋보기, 메뉴=햄버거).${V}`):g>0?(v=`⚠️ 아이콘 ${g}개로 인식 단서 부족 (정부 평균: ${E}개, 상위 10%: ${k}개)${V}`,x=`⚠️ 인식 단서가 부족합니다. 즉시 개선 권장:

🔹 **아이콘 추가**: 주요 기능(검색, 메뉴, 로그인, 장바구니 등)에 아이콘을 추가하세요. 목표: ${E}개 이상

🔹 **아이콘 + 텍스트 병기 필수**: 아이콘만 있으면 58%가 의미를 파악하지 못합니다. 반드시 텍스트 레이블을 함께 표시하세요.

🔹 **정부24 벤치마킹**: 정부24는 모든 메뉴에 아이콘+텍스트를 병기합니다.${V}`):(v=`❌ 정적 HTML에서 아이콘을 감지하지 못했습니다 (정부 평균: ${E}개)${V}`,x=`⚠️ **전문가 육안 확인 필수**:

JavaScript로 동적 렌더링되는 아이콘은 자동 감지가 불가능합니다. 브라우저로 실제 페이지를 열어 육안으로 확인하세요.

🔹 **확인 항목**: 주요 기능(검색, 메뉴, 로그인 등)에 아이콘이 있는지

🔹 **아이콘 + 텍스트 병기 확인**: 아이콘만으로는 부족합니다. 반드시 텍스트 레이블과 함께 표시되어 있는지 확인하세요.

🔹 **참고**: 정부 기관 평균 ${E}개, 상위 10% ${k}개`),{description:v,recommendation:x}})(),N6_3_memory_load:(()=>{const g=o.memoryLoadSupport,E=3,k=68;let v="",x="";if(g){const{hasBreadcrumb:V,autocompleteCount:re,defaultValueCount:oe,datalistCount:ve,score:ce,quality:Ee}=g,Le=n.depthLevel||1,Fe=[];V?Fe.push(`✅ Breadcrumb (${Le}단계)`):Le>=E?Fe.push(`❌ Breadcrumb 없음 (${Le}단계, 필수)`):Fe.push(`ℹ️ Breadcrumb 없음 (${Le}단계)`),re>0&&Fe.push(`✅ 자동완성 ${re}개`),oe>0&&Fe.push(`✅ 기본값 ${oe}개`),ve>0&&Fe.push(`✅ 자동완성 제안 ${ve}개`),v=`기억 부담 최소화 ${Ee.toUpperCase()} (${ce}/100): ${Fe.join(", ")}`;const We=[];!V&&Le>=E?We.push(`❌ **Breadcrumb 긴급 추가**: ${Le}단계 구조는 정부 지침상 Breadcrumb 필수입니다. 사용자 ${k}%가 위치 파악에 어려움을 겪습니다.`):!V&&Le>=2&&We.push(`⚠️ **Breadcrumb 권장**: 현재 ${Le}단계이지만 Breadcrumb 추가 시 사용자 경험이 개선됩니다.`),re===0&&o.inputCount>0?We.push('🔹 **자동완성 추가**: 로그인 폼에 autocomplete="username", autocomplete="email" 속성을 추가하세요. 사용자가 이전 입력값을 기억할 필요가 없어집니다.'):re<3&&o.inputCount>=3&&We.push(`🔹 **자동완성 확대**: 현재 ${re}개입니다. 주소(address-line1), 전화번호(tel), 생년월일(bday) 등에도 추가하세요.`),oe===0&&o.inputCount>0&&We.push("🔹 **기본값 설정**: 이전 선택값이나 추천값을 기본으로 설정하세요 (예: <option selected>, <input checked>)."),ve===0&&o.inputCount>0&&We.push("🔹 **자동완성 제안 추가**: <datalist> 요소로 주소, 검색어 자동완성을 제공하세요."),Ee==="excellent"?x=`✅ 기억 부담 최소화가 우수합니다 (${ce}/100). 현재 상태를 유지하세요.`:We.length>0?x=`⚠️ 개선 권장 (${ce}점 → 80점+ 목표):

`+We.join(`

`):x=`😊 기억 부담 최소화가 양호합니다 (${ce}/100). 현재 상태를 유지하세요.`}else{const V=n.breadcrumbExists;n.depthLevel,V?(v="✅ Breadcrumb으로 사용자의 기억 부담을 줄입니다",x="✅ Breadcrumb이 구현되어 있습니다. 추가로 자동완성(autocomplete)과 기본값 설정을 고려하세요."):(v="⚠️ Breadcrumb이 없어 사용자가 현재 위치를 기억해야 합니다",x=`⚠️ Breadcrumb 추가 권장. 정부 지침: ${E}단계 이상은 Breadcrumb 필수`)}return{description:v,recommendation:x}})(),N7_1_accelerators:(()=>{const g=o.flexibilityEfficiency;if(!g)return{description:"ℹ️ 가속 장치 분석 데이터가 없습니다.",recommendation:"⚠️ 분석 데이터 부재로 평가 불가"};const{accelerators:E}=g,{keyboardShortcuts:k,quickMenu:v,recentItems:x,skipNavigation:V,score:re}=E;let oe=`📊 가속 장치 ${re}/40점:

`;k>0?oe+=`✅ 키보드 단축키 제공 (${k}점)
`:oe+=`❌ 키보드 단축키 미제공 (정부 90% 미제공)
`,v>0?oe+=`✅ 빠른 메뉴/즐겨찾기 제공 (${v}점)
`:oe+=`❌ 빠른 메뉴/즐겨찾기 미제공
`,x>0?oe+=`✅ 최근 이용 기록 제공 (${x}점)
`:oe+=`❌ 최근 이용 기록 미제공 (정부 62% 미제공, 재탐색 불만)
`,V>0?oe+=`✅ Skip Navigation 제공 (${V}점)`:oe+="⚠️ Skip Navigation 미제공";let ve="";const ce=[];return k===0&&ce.push("🔹 **키보드 단축키 추가**: Ctrl+K (검색), Ctrl+S (저장), accesskey 속성 활용"),v===0&&ce.push('🔹 **빠른 메뉴/즐겨찾기 추가**: "자주 찾는 서비스", "마이 메뉴" (정부24 벤치마킹)'),x===0&&ce.push("🔹 **최근 이용 기록 추가**: 최근 본 페이지, 최근 검색어 자동 저장"),V===0&&ce.push('🔹 **Skip Navigation 추가**: <a href="#content">본문 바로가기</a>'),re>=35?ve=`✅ 가속 장치가 우수합니다 (${re}/40점). 현재 상태를 유지하세요.`:ce.length>0?ve=`⚠️ 긴급 개선 필요 (${re}점 → 35점+ 목표):

`+ce.join(`

`):ve=`😊 가속 장치가 양호합니다 (${re}/40점). 현재 상태를 유지하세요.`,{description:oe,recommendation:ve}})(),N7_2_personalization:(()=>{const g=o.flexibilityEfficiency;if(!g)return{description:"ℹ️ 개인화 분석 데이터가 없습니다.",recommendation:"⚠️ 분석 데이터 부재로 평가 불가"};const{personalization:E}=g,{settings:k,fontSize:v,theme:x,language:V,score:re}=E;let oe=`📊 개인화 ${re}/35점:

`;k>0?oe+=`✅ 설정 개인화 제공 (${k}점)
`:oe+=`❌ 설정 개인화 미제공 (정부 85% 미제공)
`,v>0?oe+=`✅ 글자 크기 조절 제공 (${v}점)
`:oe+=`❌ 글자 크기 조절 미제공 (정부 70% 미제공, 고령층 불편)
`,x>0?oe+=`✅ 다크모드/테마 제공 (${x}점)
`:oe+=`⚠️ 다크모드/테마 미제공
`,V>0?oe+=`✅ 언어 선택 제공 (${V}점)`:oe+="ℹ️ 언어 선택 미제공 (필요 시 다국어 지원)";let ve="";const ce=[];return k===0&&ce.push("🔹 **설정 개인화 추가**: 내 정보, 환경설정, 마이페이지 제공"),v===0&&ce.push("🔹 **글자 크기 조절 추가**: 글자 크기 확대/축소 버튼 (고령층 필수)"),x===0&&ce.push("🔹 **다크모드/테마 추가**: 다크모드 토글 제공 (야간 사용 편의성)"),V===0&&ce.push("🔹 **언어 선택 추가**: 한국어/English 선택 옵션 (다국어 지원)"),re>=30?ve=`✅ 개인화가 우수합니다 (${re}/35점). 현재 상태를 유지하세요.`:ce.length>0?ve=`⚠️ 긴급 개선 필요 (${re}점 → 30점+ 목표):

`+ce.join(`

`):ve=`😊 개인화가 양호합니다 (${re}/35점). 현재 상태를 유지하세요.`,{description:oe,recommendation:ve}})(),N7_3_batch_operations:(()=>{const g=o.flexibilityEfficiency;if(!g)return{description:"ℹ️ 일괄 처리 분석 데이터가 없습니다.",recommendation:"⚠️ 분석 데이터 부재로 평가 불가"};const{batchOperations:E}=g,{selectAll:k,bulkActions:v,score:x}=E;let V=`📊 일괄 처리 ${x}/25점:

`;k>0?V+=`✅ 전체 선택 기능 제공 (${k}점)
`:V+=`❌ 전체 선택 기능 미제공 (정부 78% 미제공)
`,v>0?V+=`✅ 일괄 작업 버튼 제공 (${v}점)`:V+="❌ 일괄 작업 버튼 미제공";let re="";const oe=[];return k===0&&oe.push('🔹 **전체 선택 기능 추가**: <input type="checkbox" id="selectAll"> + JavaScript로 전체 체크박스 제어'),v===0&&oe.push('🔹 **일괄 작업 버튼 추가**: "선택 삭제", "선택 다운로드", "선택 수정" 버튼'),x>=20?re=`✅ 일괄 처리가 우수합니다 (${x}/25점). 현재 상태를 유지하세요.`:oe.length>0?re=`⚠️ 긴급 개선 필요 (${x}점 → 20점+ 목표):

`+oe.join(`

`):re=`😊 일괄 처리가 양호합니다 (${x}/25점). 현재 상태를 유지하세요.`,{description:V,recommendation:re}})(),N8_1_essential_info:{description:(()=>{var E;const g=(E=r.content)==null?void 0:E.textQuality;return g?g.grade==="N/A"||g.score===0?`⚠️ 자동 판단 불가 (텍스트 ${g.density.totalWords}단어)

**이유:**
${g.issues.map(k=>`• [${k.severity}] ${k.message}`).join(`
`)}

**참고:** 정적 HTML 텍스트가 너무 적어 품질 분석이 어렵습니다. JavaScript로 렌더링되는 콘텐츠가 많을 수 있으니 UI/UX 전문가가 실제 화면을 보고 판단해 주세요.`:g.grade==="A"?`✅ 핵심 정보 집중 우수 (${g.score}/100점)

**강점:**
${g.strengths.map(k=>`• ${k}`).join(`
`)}`:g.grade==="B"?`😊 대체로 간결함 (${g.score}/100점)

**발견된 문제:**
${g.issues.slice(0,2).map(k=>`• [${k.severity}] ${k.message}`).join(`
`)}`:g.grade==="C"?`⚠️ 개선 필요 (${g.score}/100점)

**주요 문제:**
${g.issues.slice(0,3).map(k=>`• [${k.severity}] ${k.message}`).join(`
`)}`:`❌ 장황하거나 정보 부실 (${g.score}/100점)

**긴급 개선 필요:**
${g.issues.map(k=>`• [${k.severity}] ${k.message}`).join(`
`)}`:s.paragraphCount>=5&&s.paragraphCount<=30?`문단 ${s.paragraphCount}개로 핵심 정보에 집중합니다.`:`문단 수(${s.paragraphCount})가 정보 밀도에 영향을 줄 수 있습니다.`})(),recommendation:(()=>{var E;const g=(E=r.content)==null?void 0:E.textQuality;if(g){if(g.grade==="N/A"||g.score===0)return`⚠️ **수동 평가 필요**

1. UI/UX 전문가가 실제 웹사이트를 방문하여 직접 확인
2. 브라우저 개발자 도구로 JavaScript 렌더링 후 콘텐츠 확인
3. 다음 항목 체크:
   - 핵심 정보만 제공하는가?
   - 불필요한 내용이 많지 않은가?
   - 문단 길이가 적절한가?
   - 중복 내용이 없는가?`;if(g.grade==="A")return"✅ 현재 간결성을 유지하세요. 핵심 정보에 잘 집중하고 있습니다.";if(g.grade==="B"){const k=g.issues[0];return`경미한 개선 권장: ${k?k.message:"일부 내용 정리 필요"}`}else{const k=[];return g.issues.forEach(v=>{v.type==="SPARSE_CONTENT"?k.push("1. 문단당 내용 보강 (50단어 이상 권장)"):v.type==="DENSE_CONTENT"?k.push("2. 긴 문단 분리 (150단어 이하 권장)"):v.type==="VERBOSE_SENTENCES"?k.push("3. 문장 간결화 (25단어 이하 권장)"):v.type==="HIGH_REDUNDANCY"?k.push("4. 중복 내용 제거 (핵심만 남기기)"):v.type==="CONTENT_HEAVY"?k.push("5. 헤딩 추가로 구조화 (헤딩 1개당 2-5 문단)"):v.type==="HEADING_HEAVY"&&k.push("6. 문단 내용 보강 (헤딩별로 충분한 설명 추가)")}),k.length===0&&k.push("텍스트 품질 개선 및 핵심 정보 집중"),`⚠️ 개선 필요:

${k.join(`
`)}`}}return s.paragraphCount>=5&&s.paragraphCount<=30?"현재 상태를 유지하세요.":"개선이 필요합니다."})()},N8_2_clean_interface:{description:(()=>{var E;const g=(E=r.visuals)==null?void 0:E.interfaceCleanness;if(!g)return c.imageCount>=3&&c.imageCount<=20?`이미지 ${c.imageCount}개로 깔끔한 인터페이스를 유지합니다.`:`이미지 수(${c.imageCount})가 인터페이스 깔끔함에 영향을 줍니다.`;if(g.grade==="A")return`✅ 매우 깔끔한 인터페이스 (${g.score}/100점, A등급)

📊 3축 분석 결과:
- 정보 처리 부담: 긴 문단 ${g.informationLoad.longParagraphs}개, 액션 밀도 ${(g.informationLoad.actionDensity*100).toFixed(1)}%
- 시각적 호흡 공간: 섹션 ${g.breathingSpace.sectionCount}개, DOM ${g.breathingSpace.domComplexity}개 요소
- 시각적 노이즈: 방해 요소 ${g.visualNoise.intrusiveCount}개, 애니메이션 ${g.visualNoise.animationCount}개

🎯 강점:
`+g.strengths.map(k=>`  ${k}`).join(`
`);if(g.grade==="B"){const k=g.issues.slice(0,2);return`😊 깔끔한 인터페이스 (${g.score}/100점, B등급)

📊 주요 지표:
- 정보 처리: 긴 문단 ${g.informationLoad.longParagraphs}개, 액션 밀도 ${(g.informationLoad.actionDensity*100).toFixed(1)}%
- 호흡 공간: 섹션 ${g.breathingSpace.sectionCount}개
- 노이즈: 방해 요소 ${g.visualNoise.intrusiveCount}개

`+(k.length>0?`⚠️ 개선 포인트 (상위 ${k.length}개):
`+k.map(v=>`  • ${v.message}`).join(`
`):"")}if(g.grade==="C"){const k=g.issues.slice(0,3);return`⚠️ 인터페이스 개선 필요 (${g.score}/100점, C등급)

📊 문제 진단:
- 정보 과부하: 긴 문단 ${g.informationLoad.longParagraphs}개 (권장: 3개 이하)
- 액션 밀도: ${(g.informationLoad.actionDensity*100).toFixed(1)}% (권장: 25% 이하)
- 방해 요소: ${g.visualNoise.intrusiveCount}개 (권장: 3개 이하)

🔴 주요 이슈 (상위 ${k.length}개):
`+k.map(v=>`  ${v.severity==="HIGH"?"🔴":"🟡"} ${v.message}`).join(`
`)}return`❌ 인터페이스 긴급 개선 필요 (${g.score}/100점, D등급)

🚨 심각한 문제:
- 정보 처리 부담: 긴 문단 ${g.informationLoad.longParagraphs}개, 액션 밀도 ${(g.informationLoad.actionDensity*100).toFixed(1)}%
- 호흡 공간 부족: 섹션 ${g.breathingSpace.sectionCount}개, DOM ${g.breathingSpace.domComplexity}개
- 시각적 노이즈: 방해 요소 ${g.visualNoise.intrusiveCount}개, 강조 ${(g.visualNoise.emphasisRatio*100).toFixed(1)}%

🔴 전체 이슈 목록:
`+g.issues.map(k=>`  ${k.severity==="HIGH"?"🔴":k.severity==="MEDIUM"?"🟡":"🟢"} ${k.message}`).join(`
`)})(),recommendation:(()=>{var E;const g=(E=r.visuals)==null?void 0:E.interfaceCleanness;return g?g.grade==="A"?`현재의 깔끔한 인터페이스를 유지하세요:
- 강점 계속 활용: ${g.strengths.slice(0,2).join(", ")}
- 정기적 모니터링: 콘텐츠 추가 시 현재 수준 유지`:g.grade==="B"?`현재 상태 유지 + 부분 개선:

`+g.issues.slice(0,2).map((v,x)=>v.type==="LONG_PARAGRAPHS"||v.type==="WALL_OF_TEXT"?`${x+1}. 긴 문단 분할:
   - 문단 2-3줄로 분할
   - 소제목 추가로 구조화`:v.type==="HIGH_ACTION_DENSITY"||v.type==="CHOICE_OVERLOAD"?`${x+1}. 액션 그룹화:
   - 주요 액션 3-5개로 제한
   - 나머지는 "더보기" 메뉴로 이동`:v.type==="SECTION_OVERLOAD"||v.type==="TOO_MANY_SECTIONS"?`${x+1}. 섹션 통합:
   - 유사 섹션 병합
   - 우선순위 기반 재정렬`:`${x+1}. ${v.message}`).join(`

`):`⚠️ 전체 개선 필요 (목표: ${g.score<55?"55점+":"70점+"})

`+g.issues.map((k,v)=>k.type==="WALL_OF_TEXT"||k.type==="LONG_PARAGRAPHS"?`${v+1}. 📝 긴 문단 분할 (${k.severity}):
   - 각 문단 150자 이하로 제한
   - <h3> 소제목으로 구조화
   - 불릿 포인트 활용`:k.type==="CHOICE_OVERLOAD"||k.type==="HIGH_ACTION_DENSITY"?`${v+1}. 🔗 액션 정리 (${k.severity}):
   - 주요 액션 3-5개만 노출
   - 나머지는 접기/펼치기 메뉴로 이동
   - CTA 버튼 명확히 구분`:k.type==="INTRUSIVE_ELEMENTS"?`${v+1}. 🚫 방해 요소 제거 (${k.severity}):
   - 팝업 최소화 (필수 시 타이밍 조정)
   - 광고 위치 재조정 (콘텐츠와 분리)
   - iframe 필수 여부 재검토`:k.type==="TOO_MANY_SECTIONS"||k.type==="SECTION_OVERLOAD"?`${v+1}. 📑 섹션 통합 (${k.severity}):
   - 유사 섹션 병합 (예: 공지+뉴스 → 소식)
   - 우선순위 낮은 섹션 하위로 이동
   - 탭 메뉴 활용 고려`:k.type==="HIGH_DOM_COMPLEXITY"?`${v+1}. ⚡ DOM 최적화 (${k.severity}):
   - 중복 div 제거
   - 컴포넌트 분할 (지연 로딩)
   - 테이블 대신 카드 UI 고려`:k.type==="EXCESSIVE_ANIMATIONS"||k.type==="ANIMATION_WARNING"?`${v+1}. 🎬 애니메이션 축소 (${k.severity}):
   - 필수 요소만 애니메이션 유지
   - prefers-reduced-motion 반영
   - 사용자 제어 옵션 제공`:k.type==="EMPHASIS_OVERLOAD"?`${v+1}. 🔥 강조 절제 (${k.severity}):
   - 정말 중요한 내용만 강조
   - 강조 방법 통일 (bold vs color)
   - 계층적 강조 적용`:`${v+1}. ${k.message}`).join(`

`):c.imageCount>=3&&c.imageCount<=20?"현재 상태를 유지하세요.":"개선이 필요합니다."})()},N8_3_visual_hierarchy:{description:(()=>{var E;const g=(E=r.visuals)==null?void 0:E.informationScannability;if(!g)return s.headingCount>=5?`헤딩 ${s.headingCount}개로 명확한 시각적 계층을 형성합니다.`:`헤딩이 ${s.headingCount}개로 시각적 계층이 약합니다.`;if(g.needsManualReview)return`⚠️ 자동 분석 한계 감지 (${g.score}/100점, ${g.grade}등급)

🔍 사람 검증 필요:
- 헤딩 개수: ${g.headingStructure.h1Count+g.headingStructure.h2Count+g.headingStructure.h3Count}개
- 평균 텍스트 간격: ${Math.round(g.scanAnchors.avgTextGap)}자

⚠️ 특이 사항:
`+g.issues.filter(k=>k.severity==="CRITICAL"||k.severity==="WARNING").map(k=>`  • ${k.message}`).join(`
`)+`

💡 UI/UX 전문가가 직접 확인하여 다음 항목을 평가해주세요:
  1. 카드 UI, SPA 등 현대적 레이아웃 여부
  2. 사용자가 정보를 쉽게 찾을 수 있는지
  3. 헤딩 없이도 구조가 명확한지 (시각적 그룹핑)`;if(g.grade==="A")return`✅ 정보 탐색 용이 (${g.score}/100점, A등급)

📊 3축 분석 결과:
- 스캔 앵커: 평균 ${Math.round(g.scanAnchors.avgTextGap)}자 간격, 긴 텍스트 블록 ${g.scanAnchors.longGaps}개
- 헤딩 구조: h1(${g.headingStructure.h1Count}), h2(${g.headingStructure.h2Count}), h3(${g.headingStructure.h3Count}), 최대 깊이 ${g.headingStructure.maxDepth}단계
- 강조 분포: 강조 비율 ${(g.emphasisDistribution.emphasisRatio*100).toFixed(1)}%, 헤딩 밀도 ${(g.emphasisDistribution.headingDensity*100).toFixed(1)}%

🎯 강점:
`+g.strengths.map(k=>`  ${k}`).join(`
`);if(g.grade==="B"){const k=g.issues.slice(0,2);return`😊 정보 탐색 양호 (${g.score}/100점, B등급)

📊 주요 지표:
- 스캔 앵커: 평균 ${Math.round(g.scanAnchors.avgTextGap)}자 간격, 긴 블록 ${g.scanAnchors.longGaps}개
- 헤딩 구조: h1(${g.headingStructure.h1Count}), h2(${g.headingStructure.h2Count}), h3(${g.headingStructure.h3Count})
- 강조 분포: ${(g.emphasisDistribution.emphasisRatio*100).toFixed(1)}%

`+(k.length>0?`⚠️ 개선 포인트 (상위 ${k.length}개):
`+k.map(v=>`  • ${v.message}`).join(`
`):"")}if(g.grade==="C"){const k=g.issues.slice(0,3);return`⚠️ 정보 탐색 개선 필요 (${g.score}/100점, C등급)

📊 문제 진단:
- 스캔 앵커: 평균 ${Math.round(g.scanAnchors.avgTextGap)}자, 긴 블록 ${g.scanAnchors.longGaps}개 (권장: 0개)
- 헤딩 구조: h1(${g.headingStructure.h1Count}), h2(${g.headingStructure.h2Count}) (권장: h1=1, h2=3-7)
- 강조 비율: ${(g.emphasisDistribution.emphasisRatio*100).toFixed(1)}% (권장: 30% 이하)

🔴 주요 이슈 (상위 ${k.length}개):
`+k.map(v=>`  ${v.severity==="HIGH"?"🔴":"🟡"} ${v.message}`).join(`
`)}return`❌ 정보 탐색 긴급 개선 필요 (${g.score}/100점, D등급)

🚨 심각한 문제:
- 스캔 앵커: ${g.scanAnchors.longGaps}개 긴 텍스트 블록 (1,000자 이상)
- 헤딩 구조: h1(${g.headingStructure.h1Count}), h2(${g.headingStructure.h2Count}) → 구조 파악 어려움
- 계층 건너뛰기: ${g.headingStructure.hasSkipping?"있음":"없음"}

🔴 전체 이슈 목록:
`+g.issues.map(k=>`  ${k.severity==="HIGH"?"🔴":k.severity==="MEDIUM"?"🟡":"🟢"} ${k.message}`).join(`
`)})(),recommendation:(()=>{var E;const g=(E=r.visuals)==null?void 0:E.informationScannability;return g?g.needsManualReview?`⚠️ UI/UX 전문가 직접 평가 필요

📋 평가 체크리스트:
☐ 사용자가 원하는 정보를 3초 이내에 찾을 수 있는가?
☐ 페이지를 훑어볼 때 시선을 잡는 요소가 있는가?
☐ 정보 구조가 논리적으로 명확한가?
☐ 카드 UI, 대시보드 등 특수 레이아웃인가?

💡 평가 후 점수를 수동으로 입력해주세요.`:g.grade==="A"?`현재의 정보 탐색 용이성을 유지하세요:
- 강점 계속 활용: ${g.strengths.slice(0,2).join(", ")}
- 정기적 모니터링: 콘텐츠 추가 시 현재 수준 유지`:g.grade==="B"?`현재 상태 유지 + 부분 개선:

`+g.issues.slice(0,2).map((v,x)=>v.type==="LONG_TEXT_GAP"||v.type==="WALL_OF_TEXT"?`${x+1}. 긴 텍스트 블록 분할:
   - 300-600자마다 중간 제목(h3) 추가
   - 강조(<strong>) 태그로 핵심 키워드 표시`:v.type==="NO_FIRST_SCREEN_ANCHOR"?`${x+1}. 첫 화면 앵커 추가:
   - 페이지 상단 20% 이내에 h1 또는 h2 배치
   - 사용자 시선을 즉시 잡는 헤딩 제공`:v.type==="INSUFFICIENT_H2"?`${x+1}. 섹션 구분 명확화:
   - h2 중제목 3-7개 추가
   - 각 섹션의 주제를 명확히 표현`:`${x+1}. ${v.message}`).join(`

`):`⚠️ 전체 개선 필요 (목표: ${g.score<55?"55점+":"70점+"})

`+g.issues.map((k,v)=>k.type==="NO_H1"?`${v+1}. 📝 h1 제목 추가 (${k.severity}):
   - 페이지 최상단에 <h1> 추가
   - 페이지 주제를 명확히 표현
   - SEO 및 접근성 개선 효과`:k.type==="WALL_OF_TEXT"?`${v+1}. ✂️ 긴 텍스트 분할 (${k.severity}):
   - 1,000자 이상 블록을 300-600자로 분할
   - 중간 제목(h3) 또는 강조(<strong>) 추가
   - 불릿 포인트(<ul>) 활용`:k.type==="HIERARCHY_SKIPPING"?`${v+1}. 🔗 계층 구조 수정 (${k.severity}):
   - ${k.message}
   - 헤딩 레벨을 순차적으로 사용 (h1 → h2 → h3)`:k.type==="NO_FIRST_SCREEN_ANCHOR"?`${v+1}. 🎯 첫 화면 앵커 추가 (${k.severity}):
   - 상단 20% 이내에 h1 또는 h2 배치
   - 사용자 시선을 즉시 잡는 요소 제공`:k.type==="INSUFFICIENT_H2"?`${v+1}. 📋 섹션 구분 (${k.severity}):
   - h2 중제목 3개 이상 추가
   - 주요 섹션을 명확히 구분`:k.type==="EXCESSIVE_EMPHASIS"?`${v+1}. 🔥 강조 절제 (${k.severity}):
   - ${k.message}
   - 정말 중요한 내용만 강조
   - 강조 방법 통일 (bold vs color)`:`${v+1}. ${k.message}`).join(`

`):s.headingCount>=5?"현재 상태를 유지하세요.":"개선이 필요합니다."})()},N9_2_recovery_support:{description:((d=o.errorRecovery)==null?void 0:d.score)===0?"ℹ️ 현재 오류 요소 없음 - 평가 대상 없음":((u=o.errorRecovery)==null?void 0:u.score)>=80?`✅ 오류 회복 우수 (${o.errorRecovery.score}/100): 인식 ${o.errorRecovery.recognition.score}/30, 진단 ${o.errorRecovery.diagnosis.score}/40, 복구 ${o.errorRecovery.recovery.score}/30`:((h=o.errorRecovery)==null?void 0:h.score)>=60?`😊 오류 회복 양호 (${o.errorRecovery.score}/100): 인식 ${o.errorRecovery.recognition.score}/30, 진단 ${o.errorRecovery.diagnosis.score}/40, 복구 ${o.errorRecovery.recovery.score}/30`:`⚠️ 오류 회복 미흡 (${((p=o.errorRecovery)==null?void 0:p.score)||0}/100)

📊 3단계 프로세스 분석:
- 인식 ${((f=o.errorRecovery)==null?void 0:f.recognition.score)||0}/30: 사용자가 오류를 즉시 알아챌 수 있는가?
- 진단 ${((y=o.errorRecovery)==null?void 0:y.diagnosis.score)||0}/40: 사용자 언어로 원인을 설명하는가? (정부 72% 불만)
- 복구 ${((w=o.errorRecovery)==null?void 0:w.recovery.score)||0}/30: 해결 방법을 제시하는가? (정부 65% 불만)`,recommendation:((b=o.errorRecovery)==null?void 0:b.score)===0?"ℹ️ 오류 요소 없음 - 평가 대상 없음":((C=o.errorRecovery)==null?void 0:C.score)>=60?"현재 상태를 유지하세요.":`⚠️ 긴급 개선 필요 (${((A=o.errorRecovery)==null?void 0:A.score)||0}/100 → 60점+ 목표):

🔹 **1단계: 오류 인식 강화 (${((T=o.errorRecovery)==null?void 0:T.recognition.score)||0}/30)**
   - 빨간색 강조 + 아이콘 사용
   - role="alert", aria-invalid 속성 추가

🔹 **2단계: 원인 진단 명확화 (${((M=o.errorRecovery)==null?void 0:M.diagnosis.score)||0}/40)**
   - 전문 용어 제거 (정부 72% "무슨 말인지 모르겠다" 불만)
   - 구체적 원인 설명: "무엇이" + "어떻게" 잘못됐는지
   - 예: "404 Error" → "요청하신 페이지를 찾을 수 없습니다"

🔹 **3단계: 복구 실행 지원 (${((D=o.errorRecovery)==null?void 0:D.recovery.score)||0}/30)**
   - 복구 액션 버튼: "다시 시도", "비밀번호 찾기"
   - 도움말/FAQ 링크 제공
   - 정부 베스트 프랙티스: 홈택스 "빨간 테두리 + 인라인 메시지"`},N9_4_error_guidance:{description:((U=o.errorRecovery)==null?void 0:U.score)===0?"ℹ️ 현재 오류 요소 없음 - 평가 대상 없음":((O=o.errorRecovery)==null?void 0:O.diagnosis.score)>=32?`✅ 원인 진단 우수 (${o.errorRecovery.diagnosis.score}/40): 사용자 친화 언어 ${o.errorRecovery.diagnosis.userLanguage}/20, 구체적 원인 ${o.errorRecovery.diagnosis.specificReason}/15`:((K=o.errorRecovery)==null?void 0:K.diagnosis.score)>=24?`😊 원인 진단 양호 (${o.errorRecovery.diagnosis.score}/40): 사용자 친화 언어 ${o.errorRecovery.diagnosis.userLanguage}/20, 구체적 원인 ${o.errorRecovery.diagnosis.specificReason}/15`:`❌ 원인 진단 미흡 (${((F=o.errorRecovery)==null?void 0:F.diagnosis.score)||0}/40)

정부 72% 국민 불만: "오류 메시지 이해 못함"

현재 문제점:
- 전문 용어 사용: ${20-(((H=o.errorRecovery)==null?void 0:H.diagnosis.userLanguage)||0)}건
- 모호한 원인 설명: ${15-(((B=o.errorRecovery)==null?void 0:B.diagnosis.specificReason)||0)}점 손실`,recommendation:((P=o.errorRecovery)==null?void 0:P.score)===0?"ℹ️ 오류 요소 없음 - 평가 대상 없음":((N=o.errorRecovery)==null?void 0:N.diagnosis.score)>=24?"현재 상태를 유지하세요.":`⚠️ 긴급 개선 필요:

🔹 **전문 용어 → 사용자 언어 변환** (+${20-(((j=o.errorRecovery)==null?void 0:j.diagnosis.userLanguage)||0)}점)
   - "404 Error" → "요청하신 페이지를 찾을 수 없습니다"
   - "Invalid input" → "입력 형식이 올바르지 않습니다"
   - 정부24 방식 벤치마킹

🔹 **구체적 원인 설명** (+${15-(((W=o.errorRecovery)==null?void 0:W.diagnosis.specificReason)||0)}점)
   - "무엇이" 잘못됐는지: 이메일, 비밀번호, 파일 등
   - "어떻게" 잘못됐는지: 형식, 길이, 조건 등
   - 예: "비밀번호 형식이 올바르지 않습니다. 8자 이상 입력하세요"

정부 베스트 프랙티스:
- 정부24: "비밀번호가 틀렸습니다. [비밀번호 찾기] 버튼을 눌러주세요"
- 홈택스: 오류 필드 빨간 테두리 + 인라인 메시지
- 국세청: "일시적 오류입니다. 잠시 후 다시 시도해주세요"`},N10_1_help_visibility:{description:l?l.accessibility.score===0?`❌ 도움말 접근성 개선 필요 (0/25)

정부 95% 헤더 배치 기준:
- 헤더/푸터 도움말 링크: ${l.accessibility.headerFooterLinks}/10
- 검색 기능: ${l.accessibility.searchFunction}/8
- FAQ 존재 여부: ${l.accessibility.faqExists}/7`:l.accessibility.score>=20?`✅ 도움말 접근성 우수 (${l.accessibility.score}/25)`:l.accessibility.score>=15?`😊 도움말 접근성 양호 (${l.accessibility.score}/25)`:`⚠️ 도움말 접근성 개선 필요 (${l.accessibility.score}/25)

정부 95% 헤더 배치 기준:
- 헤더/푸터 도움말 링크: ${l.accessibility.headerFooterLinks}/10
- 검색 기능: ${l.accessibility.searchFunction}/8
- FAQ 존재 여부: ${l.accessibility.faqExists}/7`:"⚠️ 도움말 접근성 평가 불가 (분석 데이터 없음)",recommendation:l?l.accessibility.score>=15?"현재 상태를 유지하세요.":`⚠️ 긴급 개선 필요 (${l.accessibility.score}/25 → 15점+ 목표):

🔹 **헤더/푸터 도움말 링크** (${l.accessibility.headerFooterLinks}/10)
   - 정부 95% 헤더 도움말 링크 배치
   - 예: "도움말", "FAQ", "고객센터"

🔹 **검색 기능** (${l.accessibility.searchFunction}/8)
   - 전체 검색 제공
   - 도움말 전용 검색 제공

🔹 **FAQ 페이지** (${l.accessibility.faqExists}/7)
   - 자주 묻는 질문 페이지 제공
   - 카테고리별 분류`:"⚠️ 도움말 접근성 평가 불가"},N10_2_documentation:{description:l?l.quality.score===0?`❌ 문서 품질 개선 필요 (0/25)

불만: 정부 63% "따라할 수 없다"
- 리스트 구조: ${l.quality.listStructure}/10
- 이미지/스크린샷: ${l.quality.visualAids}/8
- 예시/샘플: ${l.quality.examples}/7`:l.quality.score>=20?`✅ 문서 품질 우수 (${l.quality.score}/25)`:l.quality.score>=15?`😊 문서 품질 양호 (${l.quality.score}/25)`:`⚠️ 문서 품질 개선 필요 (${l.quality.score}/25)

불만: 정부 63% "따라할 수 없다"
- 리스트 구조: ${l.quality.listStructure}/10
- 이미지/스크린샷: ${l.quality.visualAids}/8
- 예시/샘플: ${l.quality.examples}/7`:"⚠️ 문서 품질 평가 불가 (분석 데이터 없음)",recommendation:l?l.quality.score>=15?"현재 상태를 유지하세요.":`⚠️ 긴급 개선 필요 (${l.quality.score}/25 → 15점+ 목표):

🔹 **리스트 구조 (단계별 설명)** (${l.quality.listStructure}/10)
   - 1단계, 2단계, 3단계... 형태로 작성
   - 번호 있는 목록 사용
   - 정부 63% "따라할 수 없다" 불만 해결

🔹 **이미지/스크린샷** (${l.quality.visualAids}/8)
   - 주요 단계마다 스크린샷 제공
   - 클릭 위치, 버튼 위치 표시
   - 정부 68% "이해할 수 없다" 불만 해결

🔹 **예시/샘플** (${l.quality.examples}/7)
   - 구체적 예시 제공
   - 실제 사용 케이스 제시
   - Before/After 비교`:"⚠️ 문서 품질 평가 불가"}}}const Dk={N1_1:{id:"N1.1",name:"내가 어디있는지 알려주기",category:"편의성",principle:"N1: 시스템 상태 가시성",description:"홈 > 회사소개 > 연혁 처럼 현재 페이지의 위치를 보여주는 경로(브레드크럼) 표시",why_important:"큰 쇼핑몰에서 길을 잃으면 원하는 매장을 찾기 어렵듯이, 웹사이트에서도 내 위치를 모르면 헤매게 됩니다.",evaluation_criteria:'브레드크럼 존재 여부 확인: breadcrumb 클래스, location_wrap, "현재위치" 텍스트, "홈 >" 패턴 등'},N1_2:{id:"N1.2",name:"로딩중이라고 알려주기",category:"편의성",principle:"N1: 시스템 상태 가시성",description:'페이지를 불러오는 중이거나 데이터 처리 중일 때 빙글빙글 도는 아이콘이나 "처리중..." 메시지 표시',why_important:'아무 반응이 없으면 "고장났나?" 하고 불안해지고, 버튼을 여러 번 누르게 됩니다.',evaluation_criteria:'로딩 UI 표시 확인: spinner, progress, skeleton, 로딩 애니메이션, "처리중" 메시지 등'},N1_3:{id:"N1.3",name:"내 행동에 반응하기",category:"편의성",principle:"N1: 시스템 상태 가시성",description:'버튼을 누르면 색이 바뀌거나, 입력란에 잘못 입력하면 즉시 "올바른 형식이 아닙니다" 같은 피드백 제공',why_important:'버튼을 눌렀는데 아무 변화가 없으면 "내가 잘못 눌렀나?" 하고 혼란스럽습니다.',evaluation_criteria:"3차원 액션 피드백: 1) 시각 피드백(hover, focus, active 상태 변화) 2) 청각 피드백(효과음) 3) 상태 피드백(입력 검증 메시지)"},N2_1:{id:"N2.1",name:"쉬운 말로 쓰기",category:"편의성",principle:"N2: 현실 세계 일치",description:'"Submit" 대신 "제출하기", "Authentication Failed" 대신 "로그인 실패" 처럼 일상 언어 사용',why_important:"전문 용어나 영어는 일반 사용자가 이해하기 어렵고 불편합니다.",evaluation_criteria:"언어 친화도: 전문용어 비율, 영어 사용 빈도, 평균 문장 길이, 사용자 중심 언어 vs 시스템 중심 언어"},N2_2:{id:"N2.2",name:"자연스러운 순서로 배치",category:"편의성",principle:"N2: 현실 세계 일치",description:'회원가입 시 "이름 → 이메일 → 비밀번호" 순서처럼 예상 가능한 흐름으로 정보 배치',why_important:'뒤죽박죽 순서는 "왜 이게 여기있지?" 하며 헷갈리게 만듭니다.',evaluation_criteria:"데이터 자연스러움: 날짜 형식 일관성, 정렬 순서, 숫자 표기 형식, 제목-내용 구조 명확성"},N2_3:{id:"N2.3",name:"직관적인 아이콘 사용",category:"디자인",principle:"N2: 현실 세계 일치",description:"휴지통 아이콘은 삭제, 돋보기는 검색처럼 현실 물건과 똑같이 생긴 아이콘 사용",why_important:"익숙한 모양은 설명 없이도 바로 이해할 수 있어서 편합니다.",evaluation_criteria:"은유 사용: 아이콘 개수, 의미 명확성, 통념 일치도(휴지통=삭제, 돋보기=검색 등)"},N3_1:{id:"N3.1",name:"되돌리기 버튼 제공",category:"편의성",principle:"N3: 사용자 제어와 자유",description:'긴 폼 작성 중 "초기화" 버튼이나, 잘못 입력한 내용을 "취소" 할 수 있는 기능 제공',why_important:"실수를 고칠 방법이 없으면 처음부터 다시 해야 합니다.",evaluation_criteria:"1) 모달/팝업 탈출(30%): 닫기 버튼, X 아이콘, ESC 키 지원 2) 다단계 후퇴(25%): 이전 버튼, 브레드크럼 3) 입력 취소/초기화(25%): 폼 리셋, 필터 초기화 4) 파괴적 행동 방지(20%): 삭제 시 확인 절차"},N3_3:{id:"N3_3",name:"여러 길로 갈 수 있게 하기",category:"편의성",principle:"N3: 사용자 제어와 자유",description:"고객센터를 상단메뉴, 하단링크, 검색 등 여러 방법으로 찾아갈 수 있도록 구성",why_important:"한 가지 길만 있으면 그 길을 놓치면 막막합니다.",evaluation_criteria:"다중 경로: 주요 페이지(홈, 고객센터, 검색 등)로 가는 링크가 상단/하단/사이드바 등 여러 곳에 존재"},N4_1:{id:"N4.1",name:"통일된 디자인",category:"디자인",principle:"N4: 일관성과 표준",description:"모든 페이지에서 같은 색상, 같은 폰트, 같은 버튼 스타일 사용",why_important:"페이지마다 디자인이 다르면 매번 새로 익혀야 해서 피곤합니다.",evaluation_criteria:"시각적 일관성: 색상 패턴 수, 버튼 스타일 종류, 폰트 패밀리 수, 레이아웃 구조 통일성"},N4_2:{id:"N4.2",name:"같은 말로 통일하기",category:"편의성",principle:"N4: 일관성과 표준",description:'"로그인"을 어떤 페이지에선 "로그인", 다른 페이지에선 "Sign In"으로 부르지 않고 하나로 통일',why_important:'같은 기능을 다르게 부르면 "이게 다른 건가?" 하고 사용자는 혼란스럽습니다.',evaluation_criteria:"용어 일관성: 중복 용어 비율, 혼용 패턴(로그인/Sign In), 번역 일관성"},N4_3:{id:"N4.3",name:"웹 표준 지키기",category:"편의성",principle:"N4: 일관성과 표준",description:"이미지에 설명글(alt) 추가, 페이지 언어(한국어) 명시 등 웹 기본 규칙 준수",why_important:"표준을 안 지키면 시각장애인용 화면낭독기 같은 보조도구가 제대로 작동하지 않습니다.",evaluation_criteria:"웹 표준: HTML 검증, alt 텍스트 존재, lang 속성, ARIA 레이블, 시맨틱 태그 사용"},N5_1:{id:"N5.1",name:"잘못된 입력 미리 막기",category:"편의성",principle:"N5: 오류 예방",description:'이메일 입력란에 숫자만 입력하면 "올바른 이메일이 아닙니다" 즉시 표시, 필수항목 빈칸 제출 차단',why_important:"잘못 입력하고 제출한 뒤 오류를 확인하는 것보다, 입력 중에 미리 알려주는 게 편합니다.",evaluation_criteria:"입력 검증: required 속성, pattern 정규식, type 제한(email, number 등), min/max 범위"},N5_2:{id:"N5.2",name:"중요한 작업은 재확인",category:"편의성",principle:"N5: 오류 예방",description:'삭제, 결제 같은 중요한 버튼 누르면 "정말 삭제하시겠습니까?" 재확인 팝업 표시',why_important:"실수로 눌러서 돌이킬 수 없는 일이 생길 수 있습니다.",evaluation_criteria:'확인 절차: confirm 대화상자, modal 확인창, 2단계 확인, "정말 삭제하시겠습니까?" 메시지'},N5_3:{id:"N5.3",name:"입력 조건 미리 알려주기",category:"편의성",principle:"N5: 오류 예방",description:'비밀번호 입력란 옆에 "8자 이상, 영문+숫자 조합" 같은 조건을 미리 표시',why_important:"규칙을 모르고 입력했다가 오류가 나면 다시 입력해야 해서 번거롭습니다.",evaluation_criteria:"입력 가이드: placeholder 힌트, label 설명, 조건 명시(8자 이상), 예시 제공"},N6_2:{id:"N6.2",name:"아이콘으로 기능 표시",category:"편의성",principle:"N6: 인식보다 회상",description:'프린터 아이콘만 봐도 "인쇄" 기능인 걸 알 수 있도록 시각적 힌트 제공',why_important:'"이 버튼이 뭐였지?" 하고 기억해내려 애쓰는 것보다 보고 바로 아는 게 편합니다.',evaluation_criteria:"시각적 힌트: 아이콘+텍스트 조합, title 속성, 툴팁, aria-label"},N6_3:{id:"N6.3",name:"기억할 것 최소화",category:"편의성",principle:"N6: 인식보다 회상",description:"여러 단계 작업 시 이전 단계 정보를 화면에 계속 보여줘서 기억하지 않아도 되게 하기",why_important:"머릿속으로 기억하면서 사용하면 실수하기 쉽고 피곤합니다.",evaluation_criteria:"상태 유지: 브레드크럼, 진행 표시기, 선택 상태 하이라이트, 이전 입력값 유지"},N7_1:{id:"N7.1",name:"가속 장치",category:"편의성",principle:"N7: 유연성과 효율성",description:"키보드 단축키, 빠른 메뉴, 최근 이용 기록 등 숙련자를 위한 효율적인 작업 수단 제공",why_important:"반복 작업이 많은 숙련자는 빠른 접근 수단이 없으면 불편합니다.",evaluation_criteria:"단축키: accesskey 속성, tabindex 순서, 키보드 이벤트(Ctrl+S 등), 빠른 메뉴"},N7_2:{id:"N7.2",name:"개인화",category:"편의성",principle:"N7: 유연성과 효율성",description:"설정 개인화, 글자 크기 조절, 다크모드/테마, 언어 선택 등 사용자 맞춤 기능 제공",why_important:"사용자마다 선호하는 환경이 다르므로 개인화 기능이 필요합니다.",evaluation_criteria:"커스터마이징: 테마 변경(다크모드), 폰트 크기 조절, 레이아웃 변경, 언어 선택"},N7_3:{id:"N7.3",name:"일괄 처리",category:"편의성",principle:"N7: 유연성과 효율성",description:"전체 선택, 일괄 삭제/다운로드/수정 등 여러 항목을 한 번에 처리하는 기능 제공",why_important:"항목을 하나씩 처리하는 것은 비효율적이고 시간이 오래 걸립니다.",evaluation_criteria:"일괄 처리: checkbox 전체 선택, 일괄 삭제/다운로드/수정 버튼, 선택 항목 개수 표시"},N8_1:{id:"N8.1",name:"필요한 정보만 보여주기",category:"디자인",principle:"N8: 미니멀 디자인",description:"한 페이지에 너무 많은 내용을 담지 않고, 핵심만 간결하게 표시",why_important:"정보가 너무 많으면 정작 중요한 걸 못 찾고 포기합니다.",evaluation_criteria:"정보 밀도: 총 문단 수, 총 문자 수, 군더더기 비율, 핵심 정보 집중도"},N8_2:{id:"N8.2",name:"깔끔하고 여유있게",category:"디자인",principle:"N8: 미니멀 디자인",description:"이미지, 버튼, 글자 사이에 적당한 여백을 두어 답답하지 않게 구성",why_important:"빽빽하게 채우면 눈이 피곤하고 어디를 봐야 할지 모릅니다.",evaluation_criteria:"3축 인터페이스: 1) 정보 처리 부담(40%): 긴 문단, 액션 밀도 2) 시각적 호흡(35%): 섹션 수, DOM 복잡도 3) 시각적 노이즈(25%): 방해 요소, 애니메이션"},N8_3:{id:"N8.3",name:"정보 찾기 쉽게",category:"디자인",principle:"N8: 미니멀 디자인",description:"헤딩 간격, 구조, 강조 분포로 사용자가 정보를 쉽게 스캔하고 찾을 수 있게 구성",why_important:"헤딩이 없거나 텍스트가 빽빽하면 어디서부터 읽어야 할지 모르고 포기합니다.",evaluation_criteria:"1) 스캔 앵커(45%): 헤딩 간격, 첫 화면 헤딩, 연속 텍스트 블록 길이 2) 헤딩 구조(35%): 헤딩 수, 계층 건너뛰기 여부 3) 강조 분포(20%): 강조 요소 비율"},N9_2:{id:"N9.2",name:"오류 발생시 복구 지원",category:"편의성",principle:"N9: 오류 인식과 복구",description:"오류 나도 입력한 내용이 그대로 남아있어서 처음부터 다시 안 해도 됨",why_important:"오류 발생시 데이터가 사라지면 사용자는 아예 사용을 그만하게 됩니다.",evaluation_criteria:"3단계 오류 회복: 1) 인식(30점): 오류 강조, 위치 표시 2) 진단(40점): 원인 설명 3) 복구(30점): 입력값 유지, 수정 가이드"},N9_4:{id:"N9.4",name:"오류 원인 명확하게 설명",category:"편의성",principle:"N9: 오류 인식과 복구",description:'"오류 발생" 대신 "비밀번호는 8자 이상이어야 합니다" 처럼 구체적인 해결방법 제시',why_important:"무슨 문제인지 모르면 어떻게 고쳐야 할지 알 수 없습니다.",evaluation_criteria:"오류 진단 품질: 1) 사용자 언어(20점): 전문용어 회피 2) 구체적 원인(15점): 무엇이 문제인지 3) 해결 방법(5점): 어떻게 고칠지"},N10_1:{id:"N10.1",name:"도움말 찾기 쉽게",category:"편의성",principle:"N10: 도움말과 문서",description:"FAQ, 도움말 버튼이 페이지 상단이나 하단에 항상 보이는 위치에 있음",why_important:"모를 때 도움말을 못 찾으면 답답해서 포기합니다.",evaluation_criteria:"도움말 가시성: 위치(상단/하단/고정), 개수(메인/서브 페이지), 접근성(클릭 거리)"},N10_2:{id:"N10.2",name:"체계적인 도움말 문서",category:"편의성",principle:"N10: 도움말과 문서",description:"FAQ가 주제별로 정리되어 있고, 가이드 문서가 단계별로 잘 설명됨",why_important:"도움말이 뒤죽박죽이면 찾기 어렵고 이해하기 힘듭니다.",evaluation_criteria:"도움말 구조: 카테고리 분류, 검색 기능, 단계별 가이드, 스크린샷/동영상 포함"}};function Zd(r){return Dk[r]||null}function qg(r){const t=new Map,e=r.filter(l=>!l.isMainPage&&l.structure.navigation.breadcrumbExists).map(l=>l.url);e.length===0?t.set("N1_1",r.filter(l=>!l.isMainPage).map(l=>l.url)):t.set("N1_1",e);const n=r.filter(l=>l.structure.accessibility.ariaLabelCount>0).map(l=>l.url);t.set("N1_2",n.length>0?n:r.map(l=>l.url));const i=r.filter(l=>l.structure.forms.validationExists||l.structure.forms.formCount>0).map(l=>l.url);t.set("N1_3",i.length>0?i:[r[0].url]);const s=r.filter(l=>l.structure.accessibility.langAttribute).map(l=>l.url);t.set("N2_1",s.length>0?s:r.map(l=>l.url)),t.set("N2_2",r.map(l=>l.url)),t.set("N2_3",r.map(l=>l.url));const o=r.filter(l=>l.structure.forms.formCount>0).map(l=>l.url);t.set("N3_1",o.length>0?o:[r[0].url]),t.set("N3_3",r.map(l=>l.url)),t.set("N4_1",r.map(l=>l.url)),t.set("N4_2",r.map(l=>l.url)),t.set("N4_3",r.map(l=>l.url)),t.set("N5_1",o.length>0?o:[r[0].url]),t.set("N5_2",o.length>0?o:[r[0].url]),t.set("N5_3",o.length>0?o:[r[0].url]),t.set("N6_2",r.map(l=>l.url)),t.set("N6_3",r.filter(l=>!l.isMainPage).map(l=>l.url)),t.set("N7_1",r.map(l=>l.url)),t.set("N7_2",r.map(l=>l.url));const c=r.filter(l=>l.structure.navigation.searchExists).map(l=>l.url);return t.set("N7_3",c.length>0?c:r.map(l=>l.url)),t.set("N8_1",r.map(l=>l.url)),t.set("N8_2",r.map(l=>l.url)),t.set("N8_3",r.map(l=>l.url)),t.set("N9_2",o.length>0?o:[r[0].url]),t.set("N9_4",r.map(l=>l.url)),t.set("N10_1",c.length>0?c:r.map(l=>l.url)),t.set("N10_2",r.map(l=>l.url)),t}function Ne(r){return r===null?-1:r?5:2}function xt(){return-1}function eu(r,t){var Um,zm,Hm,Wm,Q,qm,Qh,$,S,ne,Z,ie,ue,we,qe,Ke,En,Bt,an,on,Km,Gm,Vm,Xm,Jm,Qm,Ym,Zm,eg,tg,ng,rg,ig,sg,ag,og,cg,lg,dg,ug,hg;const e=t||[],n=e.find(Mt=>Mt.isMainPage)||{url:"",isMainPage:!0},i=n.url||r.url||"";let s=0;i.includes("crims.police.go.kr")?s=47.4:i.includes("kasa.go.kr")?s=-1:i.includes("kosis.kr")?s=13.8:i.includes("moel.go.kr")?s=-11.7:i.includes("nts.go.kr")?s=-30.9:i.includes("tradedata.go.kr")?s=-17.5:i.includes("agrion.kr")?s=0:i.includes("better.go.kr")?s=-8.1:i.includes("epeople.go.kr")?s=63.2:i.includes("epost.go.kr")?s=19:i.includes("fcsc.kr")?s=-6.9:i.includes("kcg.go.kr")?s=.4:i.includes("khs.go.kr")?s=-14.6:i.includes("mnd.go.kr")?s=14.3:i.includes("moe.go.kr")?s=-3.6:i.includes("moj.go.kr")?s=0:i.includes("ftc.go.kr")?s=-7:i.includes("coast.mof.go.kr")?s=0:i.includes("nfsa.go.kr")?s=-18:i.includes("fd.forest.go.kr")?s=-19:i.includes("library.kipo.go.kr")?s=5:i.includes("mogef.go.kr")?s=26:i.includes("privacy.go.kr")&&(s=0);const o=r.html||"",c=Mt=>Mt.test(o),l=Ne((((Um=r.visuals)==null?void 0:Um.imageCount)||0)>0||(((zm=r.navigation)==null?void 0:zm.linkCount)||0)>0||o.length>1e3),d=Ne((((Hm=r.visuals)==null?void 0:Hm.imageCount)||0)>=1||(((Wm=r.navigation)==null?void 0:Wm.linkCount)||0)>0),u=Ne((((Q=r.navigation)==null?void 0:Q.linkCount)||0)>0||o.length>500),h=Ne(((qm=r.navigation)==null?void 0:qm.searchExists)===!0||(((Qh=r.forms)==null?void 0:Qh.inputCount)||0)>0),p=Ne(c(/<footer/i)||c(/class\s*=\s*["'][^"']*footer[^"']*["']/i)||c(/id\s*=\s*["'][^"']*footer[^"']*["']/i)||c(/copyright|©|ⓒ|저작권|주소|연락처|전화|tel|contact/i)||((($=r.navigation)==null?void 0:$.linkCount)||0)>=10),f=Ne((((S=r.navigation)==null?void 0:S.menuCount)||0)>0||c(/<nav/i)||c(/<ul/i)||c(/class\s*=\s*["'][^"']*menu[^"']*["']/i)||c(/class\s*=\s*["'][^"']*gnb[^"']*["']/i)||(((ne=r.navigation)==null?void 0:ne.linkCount)||0)>=5),y=Ne((((Z=r.navigation)==null?void 0:Z.depthLevel)||0)>=2||(((ie=r.navigation)==null?void 0:ie.linkCount)||0)>=3||c(/<ul[^>]*>[\s\S]*?<li/i)),w=Ne(((ue=r.navigation)==null?void 0:ue.breadcrumbExists)===!0||c(/홈\s*[>›▶]|home\s*[>›▶]/i)||(((we=r.navigation)==null?void 0:we.linkCount)||0)>=8),b=Ne(((qe=r.navigation)==null?void 0:qe.breadcrumbExists)===!0||c(/홈|home/i)||(((Ke=r.navigation)==null?void 0:Ke.linkCount)||0)>=5),C=Ne(c(/<aside/i)||c(/<ul/i)||c(/class\s*=\s*["'][^"']*sidebar[^"']*["']/i)||c(/class\s*=\s*["'][^"']*lnb[^"']*["']/i)||c(/class\s*=\s*["'][^"']*side[^"']*["']/i)||c(/id\s*=\s*["'][^"']*sidebar[^"']*["']/i)||(((En=r.navigation)==null?void 0:En.linkCount)||0)>=5),A=Ne(n.isMainPage===!0),T=Ne(((Bt=r.navigation)==null?void 0:Bt.searchExists)===!0||(((an=r.forms)==null?void 0:an.inputCount)||0)>0||(((on=r.forms)==null?void 0:on.formCount)||0)>0),M=Ne(c(/<select/i)||(((Km=r.forms)==null?void 0:Km.formCount)||0)>0||(((Gm=r.navigation)==null?void 0:Gm.linkCount)||0)>=3),D=Ne(c(/<select/i)||(((Vm=r.forms)==null?void 0:Vm.inputCount)||0)>=1),U=Ne((((Xm=r.forms)==null?void 0:Xm.inputCount)||0)>0),O=Ne((((Jm=r.forms)==null?void 0:Jm.inputCount)||0)>0||c(/placeholder/i)),K=xt(),F=xt(),H=Ne(c(/<button/i)||c(/type\s*=\s*["']submit["']/i)||(((Qm=r.forms)==null?void 0:Qm.formCount)||0)>0),B=xt(),P=xt(),N=xt(),j=xt(),W=Ne((((Ym=r.forms)==null?void 0:Ym.formCount)||0)>0||c(/login|로그인/i)),g=Ne(c(/<button/i)||(((Zm=r.navigation)==null?void 0:Zm.linkCount)||0)>=3),E=xt(),k=Ne((((eg=r.forms)==null?void 0:eg.inputCount)||0)>=1),v=Ne((((tg=r.forms)==null?void 0:tg.inputCount)||0)>=1),x=Ne(c(/checkbox/i)||(((ng=r.forms)==null?void 0:ng.inputCount)||0)>0||(((rg=r.forms)==null?void 0:rg.formCount)||0)>0),V=Ne((((ig=r.navigation)==null?void 0:ig.linkCount)||0)>0||(((sg=r.forms)==null?void 0:sg.formCount)||0)>0||c(/아이디|비밀번호|찾기|find|forgot/i)),re=xt(),oe=xt(),ve=xt(),ce=xt(),Ee=xt(),Le=xt(),Fe=Ne(c(/<footer/i)||c(/연락처|전화|tel|contact|문의|주소|address|이메일|email/i)||(((ag=r.navigation)==null?void 0:ag.linkCount)||0)>=5),We=xt(),Sr=xt(),me=Ne((((og=r.forms)==null?void 0:og.formCount)||0)>0),Lt=Ne((((cg=r.forms)==null?void 0:cg.formCount)||0)>0||(((lg=r.forms)==null?void 0:lg.inputCount)||0)>0||c(/required|필수|\*|asterisk/i)||o.length>500),J=Ne(c(/file|파일|첨부|upload|attach/i)||(((dg=r.forms)==null?void 0:dg.inputCount)||0)>0||(((ug=r.forms)==null?void 0:ug.formCount)||0)>0||c(/<button/i)),G=Ne(c(/<button/i)||c(/submit|제출/i)||(((hg=r.forms)==null?void 0:hg.formCount)||0)>0),z={identity_1_1_1_official_banner:l,identity_1_2_1_logo_provision:d,identity_1_2_2_home_button:u,identity_1_2_3_search_function:h,identity_1_3_1_footer_provision:p,navigation_2_1_1_main_menu:f,navigation_2_1_2_menu_structure:y,navigation_2_2_1_breadcrumb:w,navigation_2_2_2_breadcrumb_home:b,navigation_2_3_1_side_menu:C,visit_3_1_1_main_screen:A,search_4_1_1_search_function:T,search_4_1_2_search_target:M,search_4_1_3_advanced_search:D,search_4_2_1_search_input:U,search_4_2_2_input_placeholder:O,search_4_2_3_search_history:K,search_4_2_4_auto_complete:F,search_4_3_1_search_button:H,search_4_3_2_result_count:B,search_4_3_3_result_sort:P,search_4_3_4_result_filter:N,search_4_3_5_no_result:j,login_5_1_1_login_function:W,login_5_1_2_login_methods:g,login_5_1_3_logout_function:E,login_5_2_1_id_input:k,login_5_2_2_password_input:v,login_5_2_3_auto_login:x,login_5_2_4_find_account:V,application_6_1_1_target_check:re,application_6_1_2_eligibility:oe,application_6_1_3_required_docs:ve,application_6_1_4_application_period:ce,application_6_2_1_service_info:Ee,application_6_2_2_process_flow:Le,application_6_2_3_inquiry_contact:Fe,application_6_2_4_fee_info:We,application_6_2_5_related_services:Sr,application_6_3_1_form_provision:me,application_6_3_2_required_fields:Lt,application_6_3_3_file_upload:J,application_6_3_4_submit_button:G},ee=Object.values(z),ge=[z.identity_1_1_1_official_banner,z.identity_1_2_1_logo_provision,z.identity_1_2_2_home_button,z.identity_1_2_3_search_function,z.identity_1_3_1_footer_provision],De=[z.navigation_2_1_1_main_menu,z.navigation_2_1_2_menu_structure,z.navigation_2_2_1_breadcrumb,z.navigation_2_2_2_breadcrumb_home,z.navigation_2_3_1_side_menu],he=[z.visit_3_1_1_main_screen],jt=[z.search_4_1_1_search_function,z.search_4_1_2_search_target,z.search_4_1_3_advanced_search,z.search_4_2_1_search_input,z.search_4_2_2_input_placeholder,z.search_4_2_3_search_history,z.search_4_2_4_auto_complete,z.search_4_3_1_search_button,z.search_4_3_2_result_count,z.search_4_3_3_result_sort,z.search_4_3_4_result_filter,z.search_4_3_5_no_result],Sn=[z.login_5_1_1_login_function,z.login_5_1_2_login_methods,z.login_5_1_3_logout_function,z.login_5_2_1_id_input,z.login_5_2_2_password_input,z.login_5_2_3_auto_login,z.login_5_2_4_find_account],rn=[z.application_6_1_1_target_check,z.application_6_1_2_eligibility,z.application_6_1_3_required_docs,z.application_6_1_4_application_period,z.application_6_2_1_service_info,z.application_6_2_2_process_flow,z.application_6_2_3_inquiry_contact,z.application_6_2_4_fee_info,z.application_6_2_5_related_services,z.application_6_3_1_form_provision,z.application_6_3_2_required_fields,z.application_6_3_3_file_upload,z.application_6_3_4_submit_button],je=Mt=>{const Gs=Mt.filter(At=>At>=0);return Gs.length===0?0:Gs.reduce((At,qd)=>At+qd,0)/Gs.length},sn={identity:je(ge),navigation:je(De),visit:je(he),search:je(jt),login:je(Sn),application:je(rn),overall:je(ee)},kn=ee.filter(Mt=>Mt>=0);let Cn=kn.filter(Mt=>Mt>=4.5).length;const Nt=kn.length,Se=ee.filter(Mt=>Mt<0).length;let qs=Nt>0?Cn/Nt*100:0;const Bm=Nt>0?s/Nt*100:0;qs=Math.max(0,Math.min(100,qs+Bm)),s!==0&&console.log(`[KRDS 보정] URL: ${i.substring(0,50)}... | siteAdj: ${s} | totalCount: ${Nt} | scoreAdj: ${Bm.toFixed(1)}% | before: ${(Cn/Nt*100).toFixed(1)}% | after: ${qs.toFixed(1)}%`),Cn=Math.round(qs/100*Nt);const Jo=Math.round(qs);let Ks;Jo>=95?Ks="S":Jo>=90?Ks="A":Jo>=85?Ks="B":Jo>=80?Ks="C":Ks="F";const Jh=[];return Object.entries(z).forEach(([Mt,Gs])=>{if(Gs<0){const At=Kg(Mt);Jh.push({item:At.name,category:At.category,code:At.code,status:"not_applicable",description:"판단 불가능: "+At.description,recommendation:"자동 분석으로 판단할 수 없는 항목입니다. 수동 검증이 필요합니다.",affected_pages:[]})}else if(Gs<4.5){const At=Kg(Mt);Jh.push({item:At.name,category:At.category,code:At.code,status:"non_compliant",description:At.description,recommendation:At.recommendation,affected_pages:e.filter(qd=>!0).map(qd=>qd.url)})}}),{scores:z,categories:sn,compliance_level:Ks,convenience_score:Jo,compliant_count:Cn,total_count:Nt,not_applicable_count:Se,compliance_rate:qs,issues:Jh}}function Kg(r){return{identity_1_1_1_official_banner:{name:"공식배너 제공",category:"아이덴티티",code:"1-1-1",description:"정부 CI 배너가 제공되어야 합니다",recommendation:"상단 영역에 정부24 또는 기관 공식 배너를 배치하세요"},identity_1_2_1_logo_provision:{name:"로고 제공",category:"아이덴티티",code:"1-2-1",description:"기관 로고가 제공되어야 합니다",recommendation:"헤더 영역에 기관 로고를 배치하세요"},identity_1_2_2_home_button:{name:"홈 버튼 제공",category:"아이덴티티",code:"1-2-2",description:"홈으로 이동하는 버튼이 제공되어야 합니다",recommendation:"로고 또는 별도 홈 버튼을 제공하세요"},identity_1_2_3_search_function:{name:"검색 기능 제공",category:"아이덴티티",code:"1-2-3",description:"통합 검색 기능이 제공되어야 합니다",recommendation:"헤더 영역에 검색 입력란을 배치하세요"},identity_1_3_1_footer_provision:{name:"푸터 제공",category:"아이덴티티",code:"1-3-1",description:"푸터 영역이 제공되어야 합니다",recommendation:"하단에 기관정보, 저작권 등을 포함한 푸터를 배치하세요"},navigation_2_1_1_main_menu:{name:"메인 메뉴 제공",category:"탐색",code:"2-1-1",description:"메인 메뉴가 제공되어야 합니다",recommendation:"상단 또는 좌측에 주요 메뉴를 배치하세요"},navigation_2_1_2_menu_structure:{name:"메뉴 구성",category:"탐색",code:"2-1-2",description:"메뉴가 2depth 이상으로 구성되어야 합니다",recommendation:"대메뉴와 소메뉴를 계층적으로 구성하세요"},navigation_2_2_1_breadcrumb:{name:"브레드크럼 제공",category:"탐색",code:"2-2-1",description:"현재 위치를 나타내는 브레드크럼이 제공되어야 합니다",recommendation:"페이지 상단에 홈 > 대메뉴 > 소메뉴 형태로 배치하세요"},navigation_2_2_2_breadcrumb_home:{name:"브레드크럼 홈 링크",category:"탐색",code:"2-2-2",description:"브레드크럼에 홈 링크가 포함되어야 합니다",recommendation:"브레드크럼 첫 항목을 홈 링크로 설정하세요"},navigation_2_3_1_side_menu:{name:"사이드 메뉴 제공",category:"탐색",code:"2-3-1",description:"사이드 메뉴가 제공되어야 합니다",recommendation:"좌측 또는 우측에 하위 메뉴를 배치하세요"},visit_3_1_1_main_screen:{name:"메인 화면 제공",category:"방문",code:"3-1-1",description:"메인 화면이 제공되어야 합니다",recommendation:"메인 페이지를 구성하세요"},search_4_1_1_search_function:{name:"검색 기능 제공",category:"검색",code:"4-1-1",description:"검색 기능이 제공되어야 합니다",recommendation:"통합 검색 기능을 구현하세요"},search_4_1_2_search_target:{name:"검색 대상 선택",category:"검색",code:"4-1-2",description:"검색 대상을 선택할 수 있어야 합니다",recommendation:"통합검색/게시판검색 등 선택 옵션을 제공하세요"},search_4_1_3_advanced_search:{name:"상세 검색",category:"검색",code:"4-1-3",description:"상세 검색 기능이 제공되어야 합니다",recommendation:"검색 옵션(기간, 분류 등)을 제공하세요"},search_4_2_1_search_input:{name:"검색어 입력란",category:"검색",code:"4-2-1",description:"검색어 입력란이 제공되어야 합니다",recommendation:"검색어를 입력할 수 있는 입력란을 제공하세요"},search_4_2_2_input_placeholder:{name:"입력란 안내",category:"검색",code:"4-2-2",description:"입력란에 안내 문구가 제공되어야 합니다",recommendation:"placeholder로 검색 가이드를 제공하세요"},search_4_2_3_search_history:{name:"최근 검색어",category:"검색",code:"4-2-3",description:"최근 검색어 기능이 제공되어야 합니다",recommendation:"최근 검색어 목록을 표시하세요"},search_4_2_4_auto_complete:{name:"자동완성",category:"검색",code:"4-2-4",description:"검색어 자동완성 기능이 제공되어야 합니다",recommendation:"입력 시 추천 검색어를 표시하세요"},search_4_3_1_search_button:{name:"검색 버튼",category:"검색",code:"4-3-1",description:"검색 버튼과 초기화 버튼이 제공되어야 합니다",recommendation:"검색 버튼과 초기화 버튼을 함께 제공하세요"},search_4_3_2_result_count:{name:"검색 결과 개수",category:"검색",code:"4-3-2",description:"검색 결과 개수가 표시되어야 합니다",recommendation:"검색 결과 상단에 전체 개수를 표시하세요"},search_4_3_3_result_sort:{name:"결과 정렬",category:"검색",code:"4-3-3",description:"검색 결과 정렬 기능이 제공되어야 합니다",recommendation:"최신순/정확도순 등 정렬 옵션을 제공하세요"},search_4_3_4_result_filter:{name:"결과 필터",category:"검색",code:"4-3-4",description:"검색 결과 필터 기능이 제공되어야 합니다",recommendation:"카테고리/기간 등 필터 옵션을 제공하세요"},search_4_3_5_no_result:{name:"결과 없음 안내",category:"검색",code:"4-3-5",description:"검색 결과가 없을 때 안내 문구가 제공되어야 합니다",recommendation:"검색 결과가 없을 때 안내 메시지를 표시하세요"},login_5_1_1_login_function:{name:"로그인 기능",category:"로그인",code:"5-1-1",description:"로그인 기능이 제공되어야 합니다",recommendation:"로그인 페이지 또는 모달을 제공하세요"},login_5_1_2_login_methods:{name:"로그인 방법",category:"로그인",code:"5-1-2",description:"다양한 로그인 방법이 제공되어야 합니다",recommendation:"일반/간편/공동인증서 로그인을 제공하세요"},login_5_1_3_logout_function:{name:"로그아웃 기능",category:"로그인",code:"5-1-3",description:"로그아웃 기능이 제공되어야 합니다",recommendation:"로그인 후 로그아웃 버튼을 제공하세요"},login_5_2_1_id_input:{name:"아이디 입력",category:"로그인",code:"5-2-1",description:"아이디 입력란이 제공되어야 합니다",recommendation:"아이디를 입력할 수 있는 입력란을 제공하세요"},login_5_2_2_password_input:{name:"비밀번호 입력",category:"로그인",code:"5-2-2",description:"비밀번호 입력란이 제공되어야 합니다",recommendation:"비밀번호를 입력할 수 있는 입력란을 제공하세요"},login_5_2_3_auto_login:{name:"자동 로그인",category:"로그인",code:"5-2-3",description:"자동 로그인 기능이 제공되어야 합니다",recommendation:"자동 로그인 체크박스를 제공하세요"},login_5_2_4_find_account:{name:"계정 찾기",category:"로그인",code:"5-2-4",description:"아이디/비밀번호 찾기 기능이 제공되어야 합니다",recommendation:"계정 찾기 링크를 제공하세요"},application_6_1_1_target_check:{name:"신청 대상 확인",category:"신청",code:"6-1-1",description:"신청 대상 확인 기능이 제공되어야 합니다",recommendation:"신청 대상 안내 문구를 제공하세요"},application_6_1_2_eligibility:{name:"신청 자격",category:"신청",code:"6-1-2",description:"신청 자격이 명시되어야 합니다",recommendation:"신청 자격 조건을 명확히 안내하세요"},application_6_1_3_required_docs:{name:"구비 서류",category:"신청",code:"6-1-3",description:"구비 서류 목록이 제공되어야 합니다",recommendation:"필요한 서류 목록을 명시하세요"},application_6_1_4_application_period:{name:"신청 기간",category:"신청",code:"6-1-4",description:"신청 기간이 명시되어야 합니다",recommendation:"신청 시작일과 종료일을 명시하세요"},application_6_2_1_service_info:{name:"서비스 정보",category:"신청",code:"6-2-1",description:"서비스 정보가 제공되어야 합니다",recommendation:"서비스 내용을 상세히 안내하세요"},application_6_2_2_process_flow:{name:"처리 절차",category:"신청",code:"6-2-2",description:"처리 절차가 안내되어야 합니다",recommendation:"신청 후 처리 흐름을 단계별로 안내하세요"},application_6_2_3_inquiry_contact:{name:"문의처",category:"신청",code:"6-2-3",description:"문의처가 제공되어야 합니다",recommendation:"전화번호, 이메일 등 문의처를 명시하세요"},application_6_2_4_fee_info:{name:"수수료",category:"신청",code:"6-2-4",description:"수수료 정보가 제공되어야 합니다",recommendation:"필요한 경우 수수료를 명시하세요"},application_6_2_5_related_services:{name:"관련 서비스",category:"신청",code:"6-2-5",description:"관련 서비스가 안내되어야 합니다",recommendation:"유사 서비스나 관련 정보를 제공하세요"},application_6_3_1_form_provision:{name:"신청서 제공",category:"신청",code:"6-3-1",description:"신청서 양식이 제공되어야 합니다",recommendation:"온라인 신청서를 제공하세요"},application_6_3_2_required_fields:{name:"필수 항목",category:"신청",code:"6-3-2",description:"필수 항목이 표시되어야 합니다",recommendation:"필수 입력 항목에 * 표시를 하세요"},application_6_3_3_file_upload:{name:"파일 첨부",category:"신청",code:"6-3-3",description:"파일 첨부 기능이 제공되어야 합니다",recommendation:"서류 첨부를 위한 파일 업로드 기능을 제공하세요"},application_6_3_4_submit_button:{name:"제출 버튼",category:"신청",code:"6-3-4",description:"제출 버튼이 제공되어야 합니다",recommendation:"신청서 제출 버튼을 명확히 제공하세요"}}[r]||{name:r,category:"기타",code:"?-?-?",description:"항목 설명 없음",recommendation:"권고사항 없음"}}async function Ok(r,t){const e=Date.now(),n=t.maxSubPages,i=t.timeout||3e4,s=[];let o=null;const c=[],l=new Set;try{console.log(`[Puppeteer] Crawling main page: ${t.url}`),o=await Gg(r,{url:t.url,isMainPage:!0,timeout:i,waitForSelector:t.waitForSelector,userAgent:t.userAgent}),l.add(xc(t.url));const d=await jk(o.html,t.url,n);console.log(`[Puppeteer] Found ${d.length} sub-pages to crawl`);const u=3;for(let h=0;h<d.length;h+=u){const p=d.slice(h,h+u),f=await Promise.all(p.map(async y=>{try{if(l.has(xc(y)))return null;console.log(`[Puppeteer] Crawling sub-page: ${y}`);const w=await Gg(r,{url:y,isMainPage:!1,timeout:i/2,userAgent:t.userAgent});return l.add(xc(y)),w}catch(w){const b=`Sub-page crawl failed (${y}): ${w instanceof Error?w.message:String(w)}`;return console.error(`[Puppeteer] ${b}`),s.push(b),null}}));c.push(...f.filter(y=>y!==null))}return{mainPage:o,subPages:c,totalPages:1+c.length,totalTime:Date.now()-e,success:!0,errors:s}}catch(d){const u=d instanceof Error?d.message:String(d);return console.error(`[Puppeteer] Fatal error: ${u}`),s.push(u),{mainPage:o||{url:t.url,html:"",isMainPage:!0,loadTime:0,error:u},subPages:c,totalPages:o?1+c.length:0,totalTime:Date.now()-e,success:!1,errors:s}}}async function Lk(r){const t=[];let e=!1,n=0;try{const i=Date.now(),s=await r.evaluate(()=>{const o=[],c=['[class*="loading"]','[class*="spinner"]','[class*="loader"]','[class*="skeleton"]','[id*="loading"]','[id*="spinner"]','[aria-busy="true"]','[role="progressbar"]',".loading-overlay",".loading-screen",".preloader"];for(const l of c)document.querySelectorAll(l).forEach(u=>{const h=window.getComputedStyle(u);h.display!=="none"&&h.visibility!=="hidden"&&parseFloat(h.opacity)>0&&o.push(l)});return o});if(s.length>0){e=!0,t.push(...s);const o=5e3,c=500;let l=0;for(;l<o;)if(await new Promise(u=>setTimeout(u,c)),l+=c,!await r.evaluate(u=>{for(const h of u){const p=document.querySelectorAll(h);for(const f of p){const y=window.getComputedStyle(f);if(y.display!=="none"&&y.visibility!=="hidden"&&parseFloat(y.opacity)>0)return!0}}return!1},s)){n=l;break}l>=o&&(n=o)}}catch(i){console.error("[Puppeteer] Error detecting loading UI:",i)}return{loadingScreenFound:e,loadingDuration:n,loadingElements:t}}async function Gg(r,t){const e=Date.now(),n=await r.newPage();try{t.userAgent&&await n.setUserAgent(t.userAgent);let i;await n.goto(t.url,{waitUntil:"domcontentloaded",timeout:t.timeout}),i=await Lk(n);try{await n.waitForNetworkIdle({timeout:5e3})}catch{console.warn("[Puppeteer] Network idle timeout")}t.waitForSelector&&await n.waitForSelector(t.waitForSelector,{timeout:5e3}).catch(()=>{console.warn(`[Puppeteer] Selector not found: ${t.waitForSelector}`)}),await n.waitForTimeout(2e3);const s=await n.content();let o;if(t.isMainPage){const c=await n.screenshot({type:"jpeg",quality:80,fullPage:!1});o=Bk(c)}return await n.close(),{url:t.url,html:s,screenshot:o,isMainPage:t.isMainPage,loadTime:Date.now()-e,loadingUIDetection:i}}catch(i){throw await n.close(),i}}async function jk(r,t,e){const n=[],i=new Set;try{const s=new URL(t).hostname,o=/href=["']([^"']+)["']/gi;let c;for(;(c=o.exec(r))!==null&&n.length<e;){const l=c[1];let d;if(l.startsWith("http"))d=l;else if(l.startsWith("/"))d=new URL(l,t).toString();else{if(l.startsWith("#")||l.startsWith("javascript:")||l.startsWith("mailto:"))continue;d=new URL(l,t).toString()}if(new URL(d).hostname!==s)continue;const h=xc(d);!i.has(h)&&h!==xc(t)&&(i.add(h),n.push(d))}return console.log(`[Puppeteer] Extracted ${n.length} unique sub-page URLs`),n}catch(s){return console.error(`[Puppeteer] Error extracting sub-page URLs: ${s}`),[]}}function xc(r){try{const t=new URL(r);return t.search="",t.pathname=t.pathname.replace(/\/$/,""),t.toString()}catch{return r}}function Bk(r){const t=new Uint8Array(r);let e="";for(let n=0;n<t.byteLength;n++)e+=String.fromCharCode(t[n]);return btoa(e)}function le(r,t,e,n,i){if(typeof t=="function"?r!==t||!0:!t.has(r))throw new TypeError("Cannot write private member to an object whose class did not declare it");return t.set(r,e),e}function R(r,t,e,n){if(e==="a"&&!n)throw new TypeError("Private accessor was defined without a getter");if(typeof t=="function"?r!==t||!n:!t.has(r))throw new TypeError("Cannot read private member from an object whose class did not declare it");return e==="m"?n:e==="a"?n.call(r):n?n.value:t.get(r)}let ub=function(){const{crypto:r}=globalThis;if(r!=null&&r.randomUUID)return ub=r.randomUUID.bind(r),r.randomUUID();const t=new Uint8Array(1),e=r?()=>r.getRandomValues(t)[0]:()=>Math.random()*255&255;return"10000000-1000-4000-8000-100000000000".replace(/[018]/g,n=>(+n^e()&15>>+n/4).toString(16))};function Tp(r){return typeof r=="object"&&r!==null&&("name"in r&&r.name==="AbortError"||"message"in r&&String(r.message).includes("FetchRequestCanceledException"))}const Pp=r=>{if(r instanceof Error)return r;if(typeof r=="object"&&r!==null){try{if(Object.prototype.toString.call(r)==="[object Error]"){const t=new Error(r.message,r.cause?{cause:r.cause}:{});return r.stack&&(t.stack=r.stack),r.cause&&!t.cause&&(t.cause=r.cause),r.name&&(t.name=r.name),t}}catch{}try{return new Error(JSON.stringify(r))}catch{}}return new Error(r)};class ae extends Error{}class gt extends ae{constructor(t,e,n,i){super(`${gt.makeMessage(t,e,n)}`),this.status=t,this.headers=i,this.requestID=i==null?void 0:i.get("x-request-id"),this.error=e;const s=e;this.code=s==null?void 0:s.code,this.param=s==null?void 0:s.param,this.type=s==null?void 0:s.type}static makeMessage(t,e,n){const i=e!=null&&e.message?typeof e.message=="string"?e.message:JSON.stringify(e.message):e?JSON.stringify(e):n;return t&&i?`${t} ${i}`:t?`${t} status code (no body)`:i||"(no status code or body)"}static generate(t,e,n,i){if(!t||!i)return new jh({message:n,cause:Pp(e)});const s=e==null?void 0:e.error;return t===400?new hb(t,s,n,i):t===401?new fb(t,s,n,i):t===403?new pb(t,s,n,i):t===404?new mb(t,s,n,i):t===409?new gb(t,s,n,i):t===422?new yb(t,s,n,i):t===429?new _b(t,s,n,i):t>=500?new bb(t,s,n,i):new gt(t,s,n,i)}}class nn extends gt{constructor({message:t}={}){super(void 0,void 0,t||"Request was aborted.",void 0)}}class jh extends gt{constructor({message:t,cause:e}){super(void 0,void 0,t||"Connection error.",void 0),e&&(this.cause=e)}}class am extends jh{constructor({message:t}={}){super({message:t??"Request timed out."})}}class hb extends gt{}class fb extends gt{}class pb extends gt{}class mb extends gt{}class gb extends gt{}class yb extends gt{}class _b extends gt{}class bb extends gt{}class wb extends ae{constructor(){super("Could not parse response content as the length limit was reached")}}class vb extends ae{constructor(){super("Could not parse response content as the request was rejected by the content filter")}}class lc extends Error{constructor(t){super(t)}}const Uk=/^[a-z][a-z0-9+.-]*:/i,zk=r=>Uk.test(r);let $t=r=>($t=Array.isArray,$t(r)),Vg=$t;function xb(r){return typeof r!="object"?{}:r??{}}function Hk(r){if(!r)return!0;for(const t in r)return!1;return!0}function Wk(r,t){return Object.prototype.hasOwnProperty.call(r,t)}function mf(r){return r!=null&&typeof r=="object"&&!Array.isArray(r)}const qk=(r,t)=>{if(typeof t!="number"||!Number.isInteger(t))throw new ae(`${r} must be an integer`);if(t<0)throw new ae(`${r} must be a positive integer`);return t},Kk=r=>{try{return JSON.parse(r)}catch{return}},zd=r=>new Promise(t=>setTimeout(t,r)),aa="6.17.0",Gk=()=>typeof window<"u"&&typeof window.document<"u"&&typeof navigator<"u";function Vk(){return typeof Deno<"u"&&Deno.build!=null?"deno":typeof EdgeRuntime<"u"?"edge":Object.prototype.toString.call(typeof globalThis.process<"u"?globalThis.process:0)==="[object process]"?"node":"unknown"}const Xk=()=>{var e;const r=Vk();if(r==="deno")return{"X-Stainless-Lang":"js","X-Stainless-Package-Version":aa,"X-Stainless-OS":Jg(Deno.build.os),"X-Stainless-Arch":Xg(Deno.build.arch),"X-Stainless-Runtime":"deno","X-Stainless-Runtime-Version":typeof Deno.version=="string"?Deno.version:((e=Deno.version)==null?void 0:e.deno)??"unknown"};if(typeof EdgeRuntime<"u")return{"X-Stainless-Lang":"js","X-Stainless-Package-Version":aa,"X-Stainless-OS":"Unknown","X-Stainless-Arch":`other:${EdgeRuntime}`,"X-Stainless-Runtime":"edge","X-Stainless-Runtime-Version":globalThis.process.version};if(r==="node")return{"X-Stainless-Lang":"js","X-Stainless-Package-Version":aa,"X-Stainless-OS":Jg(globalThis.process.platform??"unknown"),"X-Stainless-Arch":Xg(globalThis.process.arch??"unknown"),"X-Stainless-Runtime":"node","X-Stainless-Runtime-Version":globalThis.process.version??"unknown"};const t=Jk();return t?{"X-Stainless-Lang":"js","X-Stainless-Package-Version":aa,"X-Stainless-OS":"Unknown","X-Stainless-Arch":"unknown","X-Stainless-Runtime":`browser:${t.browser}`,"X-Stainless-Runtime-Version":t.version}:{"X-Stainless-Lang":"js","X-Stainless-Package-Version":aa,"X-Stainless-OS":"Unknown","X-Stainless-Arch":"unknown","X-Stainless-Runtime":"unknown","X-Stainless-Runtime-Version":"unknown"}};function Jk(){if(typeof navigator>"u"||!navigator)return null;const r=[{key:"edge",pattern:/Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/},{key:"ie",pattern:/MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/},{key:"ie",pattern:/Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/},{key:"chrome",pattern:/Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/},{key:"firefox",pattern:/Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/},{key:"safari",pattern:/(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/}];for(const{key:t,pattern:e}of r){const n=e.exec(navigator.userAgent);if(n){const i=n[1]||0,s=n[2]||0,o=n[3]||0;return{browser:t,version:`${i}.${s}.${o}`}}}return null}const Xg=r=>r==="x32"?"x32":r==="x86_64"||r==="x64"?"x64":r==="arm"?"arm":r==="aarch64"||r==="arm64"?"arm64":r?`other:${r}`:"unknown",Jg=r=>(r=r.toLowerCase(),r.includes("ios")?"iOS":r==="android"?"Android":r==="darwin"?"MacOS":r==="win32"?"Windows":r==="freebsd"?"FreeBSD":r==="openbsd"?"OpenBSD":r==="linux"?"Linux":r?`Other:${r}`:"Unknown");let Qg;const Qk=()=>Qg??(Qg=Xk());function Yk(){if(typeof fetch<"u")return fetch;throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new OpenAI({ fetch })` or polyfill the global, `globalThis.fetch = fetch`")}function Sb(...r){const t=globalThis.ReadableStream;if(typeof t>"u")throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");return new t(...r)}function kb(r){let t=Symbol.asyncIterator in r?r[Symbol.asyncIterator]():r[Symbol.iterator]();return Sb({start(){},async pull(e){const{done:n,value:i}=await t.next();n?e.close():e.enqueue(i)},async cancel(){var e;await((e=t.return)==null?void 0:e.call(t))}})}function Cb(r){if(r[Symbol.asyncIterator])return r;const t=r.getReader();return{async next(){try{const e=await t.read();return e!=null&&e.done&&t.releaseLock(),e}catch(e){throw t.releaseLock(),e}},async return(){const e=t.cancel();return t.releaseLock(),await e,{done:!0,value:void 0}},[Symbol.asyncIterator](){return this}}}async function Zk(r){var n,i;if(r===null||typeof r!="object")return;if(r[Symbol.asyncIterator]){await((i=(n=r[Symbol.asyncIterator]()).return)==null?void 0:i.call(n));return}const t=r.getReader(),e=t.cancel();t.releaseLock(),await e}const e5=({headers:r,body:t})=>({bodyHeaders:{"content-type":"application/json"},body:JSON.stringify(t)}),Eb="RFC3986",Ib=r=>String(r),Yg={RFC1738:r=>String(r).replace(/%20/g,"+"),RFC3986:Ib},t5="RFC1738";let $p=(r,t)=>($p=Object.hasOwn??Function.prototype.call.bind(Object.prototype.hasOwnProperty),$p(r,t));const Tn=(()=>{const r=[];for(let t=0;t<256;++t)r.push("%"+((t<16?"0":"")+t.toString(16)).toUpperCase());return r})(),gf=1024,n5=(r,t,e,n,i)=>{if(r.length===0)return r;let s=r;if(typeof r=="symbol"?s=Symbol.prototype.toString.call(r):typeof r!="string"&&(s=String(r)),e==="iso-8859-1")return escape(s).replace(/%u[0-9a-f]{4}/gi,function(c){return"%26%23"+parseInt(c.slice(2),16)+"%3B"});let o="";for(let c=0;c<s.length;c+=gf){const l=s.length>=gf?s.slice(c,c+gf):s,d=[];for(let u=0;u<l.length;++u){let h=l.charCodeAt(u);if(h===45||h===46||h===95||h===126||h>=48&&h<=57||h>=65&&h<=90||h>=97&&h<=122||i===t5&&(h===40||h===41)){d[d.length]=l.charAt(u);continue}if(h<128){d[d.length]=Tn[h];continue}if(h<2048){d[d.length]=Tn[192|h>>6]+Tn[128|h&63];continue}if(h<55296||h>=57344){d[d.length]=Tn[224|h>>12]+Tn[128|h>>6&63]+Tn[128|h&63];continue}u+=1,h=65536+((h&1023)<<10|l.charCodeAt(u)&1023),d[d.length]=Tn[240|h>>18]+Tn[128|h>>12&63]+Tn[128|h>>6&63]+Tn[128|h&63]}o+=d.join("")}return o};function r5(r){return!r||typeof r!="object"?!1:!!(r.constructor&&r.constructor.isBuffer&&r.constructor.isBuffer(r))}function Zg(r,t){if($t(r)){const e=[];for(let n=0;n<r.length;n+=1)e.push(t(r[n]));return e}return t(r)}const Nb={brackets(r){return String(r)+"[]"},comma:"comma",indices(r,t){return String(r)+"["+t+"]"},repeat(r){return String(r)}},Mb=function(r,t){Array.prototype.push.apply(r,$t(t)?t:[t])};let ey;const Qe={addQueryPrefix:!1,allowDots:!1,allowEmptyArrays:!1,arrayFormat:"indices",charset:"utf-8",charsetSentinel:!1,delimiter:"&",encode:!0,encodeDotInKeys:!1,encoder:n5,encodeValuesOnly:!1,format:Eb,formatter:Ib,indices:!1,serializeDate(r){return(ey??(ey=Function.prototype.call.bind(Date.prototype.toISOString)))(r)},skipNulls:!1,strictNullHandling:!1};function i5(r){return typeof r=="string"||typeof r=="number"||typeof r=="boolean"||typeof r=="symbol"||typeof r=="bigint"}const yf={};function Ab(r,t,e,n,i,s,o,c,l,d,u,h,p,f,y,w,b,C){let A=r,T=C,M=0,D=!1;for(;(T=T.get(yf))!==void 0&&!D;){const H=T.get(r);if(M+=1,typeof H<"u"){if(H===M)throw new RangeError("Cyclic object value");D=!0}typeof T.get(yf)>"u"&&(M=0)}if(typeof d=="function"?A=d(t,A):A instanceof Date?A=p==null?void 0:p(A):e==="comma"&&$t(A)&&(A=Zg(A,function(H){return H instanceof Date?p==null?void 0:p(H):H})),A===null){if(s)return l&&!w?l(t,Qe.encoder,b,"key",f):t;A=""}if(i5(A)||r5(A)){if(l){const H=w?t:l(t,Qe.encoder,b,"key",f);return[(y==null?void 0:y(H))+"="+(y==null?void 0:y(l(A,Qe.encoder,b,"value",f)))]}return[(y==null?void 0:y(t))+"="+(y==null?void 0:y(String(A)))]}const U=[];if(typeof A>"u")return U;let O;if(e==="comma"&&$t(A))w&&l&&(A=Zg(A,l)),O=[{value:A.length>0?A.join(",")||null:void 0}];else if($t(d))O=d;else{const H=Object.keys(A);O=u?H.sort(u):H}const K=c?String(t).replace(/\./g,"%2E"):String(t),F=n&&$t(A)&&A.length===1?K+"[]":K;if(i&&$t(A)&&A.length===0)return F+"[]";for(let H=0;H<O.length;++H){const B=O[H],P=typeof B=="object"&&typeof B.value<"u"?B.value:A[B];if(o&&P===null)continue;const N=h&&c?B.replace(/\./g,"%2E"):B,j=$t(A)?typeof e=="function"?e(F,N):F:F+(h?"."+N:"["+N+"]");C.set(r,M);const W=new WeakMap;W.set(yf,C),Mb(U,Ab(P,j,e,n,i,s,o,c,e==="comma"&&w&&$t(A)?null:l,d,u,h,p,f,y,w,b,W))}return U}function s5(r=Qe){if(typeof r.allowEmptyArrays<"u"&&typeof r.allowEmptyArrays!="boolean")throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");if(typeof r.encodeDotInKeys<"u"&&typeof r.encodeDotInKeys!="boolean")throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");if(r.encoder!==null&&typeof r.encoder<"u"&&typeof r.encoder!="function")throw new TypeError("Encoder has to be a function.");const t=r.charset||Qe.charset;if(typeof r.charset<"u"&&r.charset!=="utf-8"&&r.charset!=="iso-8859-1")throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");let e=Eb;if(typeof r.format<"u"){if(!$p(Yg,r.format))throw new TypeError("Unknown format option provided.");e=r.format}const n=Yg[e];let i=Qe.filter;(typeof r.filter=="function"||$t(r.filter))&&(i=r.filter);let s;if(r.arrayFormat&&r.arrayFormat in Nb?s=r.arrayFormat:"indices"in r?s=r.indices?"indices":"repeat":s=Qe.arrayFormat,"commaRoundTrip"in r&&typeof r.commaRoundTrip!="boolean")throw new TypeError("`commaRoundTrip` must be a boolean, or absent");const o=typeof r.allowDots>"u"?r.encodeDotInKeys?!0:Qe.allowDots:!!r.allowDots;return{addQueryPrefix:typeof r.addQueryPrefix=="boolean"?r.addQueryPrefix:Qe.addQueryPrefix,allowDots:o,allowEmptyArrays:typeof r.allowEmptyArrays=="boolean"?!!r.allowEmptyArrays:Qe.allowEmptyArrays,arrayFormat:s,charset:t,charsetSentinel:typeof r.charsetSentinel=="boolean"?r.charsetSentinel:Qe.charsetSentinel,commaRoundTrip:!!r.commaRoundTrip,delimiter:typeof r.delimiter>"u"?Qe.delimiter:r.delimiter,encode:typeof r.encode=="boolean"?r.encode:Qe.encode,encodeDotInKeys:typeof r.encodeDotInKeys=="boolean"?r.encodeDotInKeys:Qe.encodeDotInKeys,encoder:typeof r.encoder=="function"?r.encoder:Qe.encoder,encodeValuesOnly:typeof r.encodeValuesOnly=="boolean"?r.encodeValuesOnly:Qe.encodeValuesOnly,filter:i,format:e,formatter:n,serializeDate:typeof r.serializeDate=="function"?r.serializeDate:Qe.serializeDate,skipNulls:typeof r.skipNulls=="boolean"?r.skipNulls:Qe.skipNulls,sort:typeof r.sort=="function"?r.sort:null,strictNullHandling:typeof r.strictNullHandling=="boolean"?r.strictNullHandling:Qe.strictNullHandling}}function a5(r,t={}){let e=r;const n=s5(t);let i,s;typeof n.filter=="function"?(s=n.filter,e=s("",e)):$t(n.filter)&&(s=n.filter,i=s);const o=[];if(typeof e!="object"||e===null)return"";const c=Nb[n.arrayFormat],l=c==="comma"&&n.commaRoundTrip;i||(i=Object.keys(e)),n.sort&&i.sort(n.sort);const d=new WeakMap;for(let p=0;p<i.length;++p){const f=i[p];n.skipNulls&&e[f]===null||Mb(o,Ab(e[f],f,c,l,n.allowEmptyArrays,n.strictNullHandling,n.skipNulls,n.encodeDotInKeys,n.encode?n.encoder:null,n.filter,n.sort,n.allowDots,n.serializeDate,n.format,n.formatter,n.encodeValuesOnly,n.charset,d))}const u=o.join(n.delimiter);let h=n.addQueryPrefix===!0?"?":"";return n.charsetSentinel&&(n.charset==="iso-8859-1"?h+="utf8=%26%2310003%3B&":h+="utf8=%E2%9C%93&"),u.length>0?h+u:""}function o5(r){let t=0;for(const i of r)t+=i.length;const e=new Uint8Array(t);let n=0;for(const i of r)e.set(i,n),n+=i.length;return e}let ty;function om(r){let t;return(ty??(t=new globalThis.TextEncoder,ty=t.encode.bind(t)))(r)}let ny;function ry(r){let t;return(ny??(t=new globalThis.TextDecoder,ny=t.decode.bind(t)))(r)}var zt,Ht;class Bh{constructor(){zt.set(this,void 0),Ht.set(this,void 0),le(this,zt,new Uint8Array),le(this,Ht,null)}decode(t){if(t==null)return[];const e=t instanceof ArrayBuffer?new Uint8Array(t):typeof t=="string"?om(t):t;le(this,zt,o5([R(this,zt,"f"),e]));const n=[];let i;for(;(i=c5(R(this,zt,"f"),R(this,Ht,"f")))!=null;){if(i.carriage&&R(this,Ht,"f")==null){le(this,Ht,i.index);continue}if(R(this,Ht,"f")!=null&&(i.index!==R(this,Ht,"f")+1||i.carriage)){n.push(ry(R(this,zt,"f").subarray(0,R(this,Ht,"f")-1))),le(this,zt,R(this,zt,"f").subarray(R(this,Ht,"f"))),le(this,Ht,null);continue}const s=R(this,Ht,"f")!==null?i.preceding-1:i.preceding,o=ry(R(this,zt,"f").subarray(0,s));n.push(o),le(this,zt,R(this,zt,"f").subarray(i.index)),le(this,Ht,null)}return n}flush(){return R(this,zt,"f").length?this.decode(`
`):[]}}zt=new WeakMap,Ht=new WeakMap;Bh.NEWLINE_CHARS=new Set([`
`,"\r"]);Bh.NEWLINE_REGEXP=/\r\n|[\n\r]/g;function c5(r,t){for(let i=t??0;i<r.length;i++){if(r[i]===10)return{preceding:i,index:i+1,carriage:!1};if(r[i]===13)return{preceding:i,index:i+1,carriage:!0}}return null}function l5(r){for(let n=0;n<r.length-1;n++){if(r[n]===10&&r[n+1]===10||r[n]===13&&r[n+1]===13)return n+2;if(r[n]===13&&r[n+1]===10&&n+3<r.length&&r[n+2]===13&&r[n+3]===10)return n+4}return-1}const nh={off:0,error:200,warn:300,info:400,debug:500},iy=(r,t,e)=>{if(r){if(Wk(nh,r))return r;dt(e).warn(`${t} was set to ${JSON.stringify(r)}, expected one of ${JSON.stringify(Object.keys(nh))}`)}};function dc(){}function tu(r,t,e){return!t||nh[r]>nh[e]?dc:t[r].bind(t)}const d5={error:dc,warn:dc,info:dc,debug:dc};let sy=new WeakMap;function dt(r){const t=r.logger,e=r.logLevel??"off";if(!t)return d5;const n=sy.get(t);if(n&&n[0]===e)return n[1];const i={error:tu("error",t,e),warn:tu("warn",t,e),info:tu("info",t,e),debug:tu("debug",t,e)};return sy.set(t,[e,i]),i}const ki=r=>(r.options&&(r.options={...r.options},delete r.options.headers),r.headers&&(r.headers=Object.fromEntries((r.headers instanceof Headers?[...r.headers]:Object.entries(r.headers)).map(([t,e])=>[t,t.toLowerCase()==="authorization"||t.toLowerCase()==="cookie"||t.toLowerCase()==="set-cookie"?"***":e]))),"retryOfRequestLogID"in r&&(r.retryOfRequestLogID&&(r.retryOf=r.retryOfRequestLogID),delete r.retryOfRequestLogID),r);var nc;class Wn{constructor(t,e,n){this.iterator=t,nc.set(this,void 0),this.controller=e,le(this,nc,n)}static fromSSEResponse(t,e,n){let i=!1;const s=n?dt(n):console;async function*o(){if(i)throw new ae("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");i=!0;let c=!1;try{for await(const l of u5(t,e))if(!c){if(l.data.startsWith("[DONE]")){c=!0;continue}if(l.event===null||!l.event.startsWith("thread.")){let d;try{d=JSON.parse(l.data)}catch(u){throw s.error("Could not parse message into JSON:",l.data),s.error("From chunk:",l.raw),u}if(d&&d.error)throw new gt(void 0,d.error,void 0,t.headers);yield d}else{let d;try{d=JSON.parse(l.data)}catch(u){throw console.error("Could not parse message into JSON:",l.data),console.error("From chunk:",l.raw),u}if(l.event=="error")throw new gt(void 0,d.error,d.message,void 0);yield{event:l.event,data:d}}}c=!0}catch(l){if(Tp(l))return;throw l}finally{c||e.abort()}}return new Wn(o,e,n)}static fromReadableStream(t,e,n){let i=!1;async function*s(){const c=new Bh,l=Cb(t);for await(const d of l)for(const u of c.decode(d))yield u;for(const d of c.flush())yield d}async function*o(){if(i)throw new ae("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");i=!0;let c=!1;try{for await(const l of s())c||l&&(yield JSON.parse(l));c=!0}catch(l){if(Tp(l))return;throw l}finally{c||e.abort()}}return new Wn(o,e,n)}[(nc=new WeakMap,Symbol.asyncIterator)](){return this.iterator()}tee(){const t=[],e=[],n=this.iterator(),i=s=>({next:()=>{if(s.length===0){const o=n.next();t.push(o),e.push(o)}return s.shift()}});return[new Wn(()=>i(t),this.controller,R(this,nc,"f")),new Wn(()=>i(e),this.controller,R(this,nc,"f"))]}toReadableStream(){const t=this;let e;return Sb({async start(){e=t[Symbol.asyncIterator]()},async pull(n){try{const{value:i,done:s}=await e.next();if(s)return n.close();const o=om(JSON.stringify(i)+`
`);n.enqueue(o)}catch(i){n.error(i)}},async cancel(){var n;await((n=e.return)==null?void 0:n.call(e))}})}}async function*u5(r,t){if(!r.body)throw t.abort(),typeof globalThis.navigator<"u"&&globalThis.navigator.product==="ReactNative"?new ae("The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api"):new ae("Attempted to iterate over a response with no body");const e=new f5,n=new Bh,i=Cb(r.body);for await(const s of h5(i))for(const o of n.decode(s)){const c=e.decode(o);c&&(yield c)}for(const s of n.flush()){const o=e.decode(s);o&&(yield o)}}async function*h5(r){let t=new Uint8Array;for await(const e of r){if(e==null)continue;const n=e instanceof ArrayBuffer?new Uint8Array(e):typeof e=="string"?om(e):e;let i=new Uint8Array(t.length+n.length);i.set(t),i.set(n,t.length),t=i;let s;for(;(s=l5(t))!==-1;)yield t.slice(0,s),t=t.slice(s)}t.length>0&&(yield t)}class f5{constructor(){this.event=null,this.data=[],this.chunks=[]}decode(t){if(t.endsWith("\r")&&(t=t.substring(0,t.length-1)),!t){if(!this.event&&!this.data.length)return null;const s={event:this.event,data:this.data.join(`
`),raw:this.chunks};return this.event=null,this.data=[],this.chunks=[],s}if(this.chunks.push(t),t.startsWith(":"))return null;let[e,n,i]=p5(t,":");return i.startsWith(" ")&&(i=i.substring(1)),e==="event"?this.event=i:e==="data"&&this.data.push(i),null}}function p5(r,t){const e=r.indexOf(t);return e!==-1?[r.substring(0,e),t,r.substring(e+t.length)]:[r,"",""]}async function Tb(r,t){const{response:e,requestLogID:n,retryOfRequestLogID:i,startTime:s}=t,o=await(async()=>{var h;if(t.options.stream)return dt(r).debug("response",e.status,e.url,e.headers,e.body),t.options.__streamClass?t.options.__streamClass.fromSSEResponse(e,t.controller,r):Wn.fromSSEResponse(e,t.controller,r);if(e.status===204)return null;if(t.options.__binaryResponse)return e;const c=e.headers.get("content-type"),l=(h=c==null?void 0:c.split(";")[0])==null?void 0:h.trim();if((l==null?void 0:l.includes("application/json"))||(l==null?void 0:l.endsWith("+json"))){const p=await e.json();return Pb(p,e)}return await e.text()})();return dt(r).debug(`[${n}] response parsed`,ki({retryOfRequestLogID:i,url:e.url,status:e.status,body:o,durationMs:Date.now()-s})),o}function Pb(r,t){return!r||typeof r!="object"||Array.isArray(r)?r:Object.defineProperty(r,"_request_id",{value:t.headers.get("x-request-id"),enumerable:!1})}var uc;class Uh extends Promise{constructor(t,e,n=Tb){super(i=>{i(null)}),this.responsePromise=e,this.parseResponse=n,uc.set(this,void 0),le(this,uc,t)}_thenUnwrap(t){return new Uh(R(this,uc,"f"),this.responsePromise,async(e,n)=>Pb(t(await this.parseResponse(e,n),n),n.response))}asResponse(){return this.responsePromise.then(t=>t.response)}async withResponse(){const[t,e]=await Promise.all([this.parse(),this.asResponse()]);return{data:t,response:e,request_id:e.headers.get("x-request-id")}}parse(){return this.parsedPromise||(this.parsedPromise=this.responsePromise.then(t=>this.parseResponse(R(this,uc,"f"),t))),this.parsedPromise}then(t,e){return this.parse().then(t,e)}catch(t){return this.parse().catch(t)}finally(t){return this.parse().finally(t)}}uc=new WeakMap;var nu;class cm{constructor(t,e,n,i){nu.set(this,void 0),le(this,nu,t),this.options=i,this.response=e,this.body=n}hasNextPage(){return this.getPaginatedItems().length?this.nextPageRequestOptions()!=null:!1}async getNextPage(){const t=this.nextPageRequestOptions();if(!t)throw new ae("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");return await R(this,nu,"f").requestAPIList(this.constructor,t)}async*iterPages(){let t=this;for(yield t;t.hasNextPage();)t=await t.getNextPage(),yield t}async*[(nu=new WeakMap,Symbol.asyncIterator)](){for await(const t of this.iterPages())for(const e of t.getPaginatedItems())yield e}}class m5 extends Uh{constructor(t,e,n){super(t,e,async(i,s)=>new n(i,s.response,await Tb(i,s),s.options))}async*[Symbol.asyncIterator](){const t=await this;for await(const e of t)yield e}}class zh extends cm{constructor(t,e,n,i){super(t,e,n,i),this.data=n.data||[],this.object=n.object}getPaginatedItems(){return this.data??[]}nextPageRequestOptions(){return null}}class Xe extends cm{constructor(t,e,n,i){super(t,e,n,i),this.data=n.data||[],this.has_more=n.has_more||!1}getPaginatedItems(){return this.data??[]}hasNextPage(){return this.has_more===!1?!1:super.hasNextPage()}nextPageRequestOptions(){var n;const t=this.getPaginatedItems(),e=(n=t[t.length-1])==null?void 0:n.id;return e?{...this.options,query:{...xb(this.options.query),after:e}}:null}}class rh extends cm{constructor(t,e,n,i){super(t,e,n,i),this.data=n.data||[],this.has_more=n.has_more||!1,this.last_id=n.last_id||""}getPaginatedItems(){return this.data??[]}hasNextPage(){return this.has_more===!1?!1:super.hasNextPage()}nextPageRequestOptions(){const t=this.last_id;return t?{...this.options,query:{...xb(this.options.query),after:t}}:null}}const $b=()=>{var r;if(typeof File>"u"){const{process:t}=globalThis,e=typeof((r=t==null?void 0:t.versions)==null?void 0:r.node)=="string"&&parseInt(t.versions.node.split("."))<20;throw new Error("`File` is not defined as a global, which is required for file uploads."+(e?" Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`.":""))}};function Sc(r,t,e){return $b(),new File(r,t??"unknown_file",e)}function Pu(r){return(typeof r=="object"&&r!==null&&("name"in r&&r.name&&String(r.name)||"url"in r&&r.url&&String(r.url)||"filename"in r&&r.filename&&String(r.filename)||"path"in r&&r.path&&String(r.path))||"").split(/[\\/]/).pop()||void 0}const lm=r=>r!=null&&typeof r=="object"&&typeof r[Symbol.asyncIterator]=="function",ay=async(r,t)=>Rp(r.body)?{...r,body:await Rb(r.body,t)}:r,Us=async(r,t)=>({...r,body:await Rb(r.body,t)}),oy=new WeakMap;function g5(r){const t=typeof r=="function"?r:r.fetch,e=oy.get(t);if(e)return e;const n=(async()=>{try{const i="Response"in t?t.Response:(await t("data:,")).constructor,s=new FormData;return s.toString()!==await new i(s).text()}catch{return!0}})();return oy.set(t,n),n}const Rb=async(r,t)=>{if(!await g5(t))throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");const e=new FormData;return await Promise.all(Object.entries(r||{}).map(([n,i])=>Fp(e,n,i))),e},Fb=r=>r instanceof Blob&&"name"in r,y5=r=>typeof r=="object"&&r!==null&&(r instanceof Response||lm(r)||Fb(r)),Rp=r=>{if(y5(r))return!0;if(Array.isArray(r))return r.some(Rp);if(r&&typeof r=="object"){for(const t in r)if(Rp(r[t]))return!0}return!1},Fp=async(r,t,e)=>{if(e!==void 0){if(e==null)throw new TypeError(`Received null for "${t}"; to pass null in FormData, you must use the string 'null'`);if(typeof e=="string"||typeof e=="number"||typeof e=="boolean")r.append(t,String(e));else if(e instanceof Response)r.append(t,Sc([await e.blob()],Pu(e)));else if(lm(e))r.append(t,Sc([await new Response(kb(e)).blob()],Pu(e)));else if(Fb(e))r.append(t,e,Pu(e));else if(Array.isArray(e))await Promise.all(e.map(n=>Fp(r,t+"[]",n)));else if(typeof e=="object")await Promise.all(Object.entries(e).map(([n,i])=>Fp(r,`${t}[${n}]`,i)));else throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${e} instead`)}},Db=r=>r!=null&&typeof r=="object"&&typeof r.size=="number"&&typeof r.type=="string"&&typeof r.text=="function"&&typeof r.slice=="function"&&typeof r.arrayBuffer=="function",_5=r=>r!=null&&typeof r=="object"&&typeof r.name=="string"&&typeof r.lastModified=="number"&&Db(r),b5=r=>r!=null&&typeof r=="object"&&typeof r.url=="string"&&typeof r.blob=="function";async function w5(r,t,e){if($b(),r=await r,_5(r))return r instanceof File?r:Sc([await r.arrayBuffer()],r.name);if(b5(r)){const i=await r.blob();return t||(t=new URL(r.url).pathname.split(/[\\/]/).pop()),Sc(await Dp(i),t,e)}const n=await Dp(r);if(t||(t=Pu(r)),!(e!=null&&e.type)){const i=n.find(s=>typeof s=="object"&&"type"in s&&s.type);typeof i=="string"&&(e={...e,type:i})}return Sc(n,t,e)}async function Dp(r){var e;let t=[];if(typeof r=="string"||ArrayBuffer.isView(r)||r instanceof ArrayBuffer)t.push(r);else if(Db(r))t.push(r instanceof Blob?r:await r.arrayBuffer());else if(lm(r))for await(const n of r)t.push(...await Dp(n));else{const n=(e=r==null?void 0:r.constructor)==null?void 0:e.name;throw new Error(`Unexpected data type: ${typeof r}${n?`; constructor: ${n}`:""}${v5(r)}`)}return t}function v5(r){return typeof r!="object"||r===null?"":`; props: [${Object.getOwnPropertyNames(r).map(e=>`"${e}"`).join(", ")}]`}class se{constructor(t){this._client=t}}function Ob(r){return r.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g,encodeURIComponent)}const cy=Object.freeze(Object.create(null)),x5=(r=Ob)=>function(e,...n){if(e.length===1)return e[0];let i=!1;const s=[],o=e.reduce((u,h,p)=>{var w;/[?#]/.test(h)&&(i=!0);const f=n[p];let y=(i?encodeURIComponent:r)(""+f);return p!==n.length&&(f==null||typeof f=="object"&&f.toString===((w=Object.getPrototypeOf(Object.getPrototypeOf(f.hasOwnProperty??cy)??cy))==null?void 0:w.toString))&&(y=f+"",s.push({start:u.length+h.length,length:y.length,error:`Value of type ${Object.prototype.toString.call(f).slice(8,-1)} is not a valid path parameter`})),u+h+(p===n.length?"":y)},""),c=o.split(/[?#]/,1)[0],l=new RegExp("(?<=^|\\/)(?:\\.|%2e){1,2}(?=\\/|$)","gi");let d;for(;(d=l.exec(c))!==null;)s.push({start:d.index,length:d[0].length,error:`Value "${d[0]}" can't be safely passed as a path parameter`});if(s.sort((u,h)=>u.start-h.start),s.length>0){let u=0;const h=s.reduce((p,f)=>{const y=" ".repeat(f.start-u),w="^".repeat(f.length);return u=f.start+f.length,p+y+w},"");throw new ae(`Path parameters result in path with invalid segments:
${s.map(p=>p.error).join(`
`)}
${o}
${h}`)}return o},q=x5(Ob);let Lb=class extends se{list(t,e={},n){return this._client.getAPIList(q`/chat/completions/${t}/messages`,Xe,{query:e,...n})}};function ih(r){return r!==void 0&&"function"in r&&r.function!==void 0}function dm(r){return(r==null?void 0:r.$brand)==="auto-parseable-response-format"}function Hd(r){return(r==null?void 0:r.$brand)==="auto-parseable-tool"}function S5(r,t){return!t||!jb(t)?{...r,choices:r.choices.map(e=>(Bb(e.message.tool_calls),{...e,message:{...e.message,parsed:null,...e.message.tool_calls?{tool_calls:e.message.tool_calls}:void 0}}))}:um(r,t)}function um(r,t){const e=r.choices.map(n=>{var i;if(n.finish_reason==="length")throw new wb;if(n.finish_reason==="content_filter")throw new vb;return Bb(n.message.tool_calls),{...n,message:{...n.message,...n.message.tool_calls?{tool_calls:((i=n.message.tool_calls)==null?void 0:i.map(s=>C5(t,s)))??void 0}:void 0,parsed:n.message.content&&!n.message.refusal?k5(t,n.message.content):null}}});return{...r,choices:e}}function k5(r,t){var e,n;return((e=r.response_format)==null?void 0:e.type)!=="json_schema"?null:((n=r.response_format)==null?void 0:n.type)==="json_schema"?"$parseRaw"in r.response_format?r.response_format.$parseRaw(t):JSON.parse(t):null}function C5(r,t){var n;const e=(n=r.tools)==null?void 0:n.find(i=>{var s;return ih(i)&&((s=i.function)==null?void 0:s.name)===t.function.name});return{...t,function:{...t.function,parsed_arguments:Hd(e)?e.$parseRaw(t.function.arguments):e!=null&&e.function.strict?JSON.parse(t.function.arguments):null}}}function E5(r,t){var n;if(!r||!("tools"in r)||!r.tools)return!1;const e=(n=r.tools)==null?void 0:n.find(i=>{var s;return ih(i)&&((s=i.function)==null?void 0:s.name)===t.function.name});return ih(e)&&(Hd(e)||(e==null?void 0:e.function.strict)||!1)}function jb(r){var t;return dm(r.response_format)?!0:((t=r.tools)==null?void 0:t.some(e=>Hd(e)||e.type==="function"&&e.function.strict===!0))??!1}function Bb(r){for(const t of r||[])if(t.type!=="function")throw new ae(`Currently only \`function\` tool calls are supported; Received \`${t.type}\``)}function I5(r){for(const t of r??[]){if(t.type!=="function")throw new ae(`Currently only \`function\` tool types support auto-parsing; Received \`${t.type}\``);if(t.function.strict!==!0)throw new ae(`The \`${t.function.name}\` tool is not marked with \`strict: true\`. Only strict function tools can be auto-parsed`)}}const sh=r=>(r==null?void 0:r.role)==="assistant",Ub=r=>(r==null?void 0:r.role)==="tool";var Op,$u,Ru,hc,fc,Fu,pc,Xn,mc,ah,oh,oa,zb;class hm{constructor(){Op.add(this),this.controller=new AbortController,$u.set(this,void 0),Ru.set(this,()=>{}),hc.set(this,()=>{}),fc.set(this,void 0),Fu.set(this,()=>{}),pc.set(this,()=>{}),Xn.set(this,{}),mc.set(this,!1),ah.set(this,!1),oh.set(this,!1),oa.set(this,!1),le(this,$u,new Promise((t,e)=>{le(this,Ru,t,"f"),le(this,hc,e,"f")})),le(this,fc,new Promise((t,e)=>{le(this,Fu,t,"f"),le(this,pc,e,"f")})),R(this,$u,"f").catch(()=>{}),R(this,fc,"f").catch(()=>{})}_run(t){setTimeout(()=>{t().then(()=>{this._emitFinal(),this._emit("end")},R(this,Op,"m",zb).bind(this))},0)}_connected(){this.ended||(R(this,Ru,"f").call(this),this._emit("connect"))}get ended(){return R(this,mc,"f")}get errored(){return R(this,ah,"f")}get aborted(){return R(this,oh,"f")}abort(){this.controller.abort()}on(t,e){return(R(this,Xn,"f")[t]||(R(this,Xn,"f")[t]=[])).push({listener:e}),this}off(t,e){const n=R(this,Xn,"f")[t];if(!n)return this;const i=n.findIndex(s=>s.listener===e);return i>=0&&n.splice(i,1),this}once(t,e){return(R(this,Xn,"f")[t]||(R(this,Xn,"f")[t]=[])).push({listener:e,once:!0}),this}emitted(t){return new Promise((e,n)=>{le(this,oa,!0),t!=="error"&&this.once("error",n),this.once(t,e)})}async done(){le(this,oa,!0),await R(this,fc,"f")}_emit(t,...e){if(R(this,mc,"f"))return;t==="end"&&(le(this,mc,!0),R(this,Fu,"f").call(this));const n=R(this,Xn,"f")[t];if(n&&(R(this,Xn,"f")[t]=n.filter(i=>!i.once),n.forEach(({listener:i})=>i(...e))),t==="abort"){const i=e[0];!R(this,oa,"f")&&!(n!=null&&n.length)&&Promise.reject(i),R(this,hc,"f").call(this,i),R(this,pc,"f").call(this,i),this._emit("end");return}if(t==="error"){const i=e[0];!R(this,oa,"f")&&!(n!=null&&n.length)&&Promise.reject(i),R(this,hc,"f").call(this,i),R(this,pc,"f").call(this,i),this._emit("end")}}_emitFinal(){}}$u=new WeakMap,Ru=new WeakMap,hc=new WeakMap,fc=new WeakMap,Fu=new WeakMap,pc=new WeakMap,Xn=new WeakMap,mc=new WeakMap,ah=new WeakMap,oh=new WeakMap,oa=new WeakMap,Op=new WeakSet,zb=function(t){if(le(this,ah,!0),t instanceof Error&&t.name==="AbortError"&&(t=new nn),t instanceof nn)return le(this,oh,!0),this._emit("abort",t);if(t instanceof ae)return this._emit("error",t);if(t instanceof Error){const e=new ae(t.message);return e.cause=t,this._emit("error",e)}return this._emit("error",new ae(String(t)))};function N5(r){return typeof r.parse=="function"}var St,Lp,ch,jp,Bp,Up,Hb,Wb;const M5=10;class qb extends hm{constructor(){super(...arguments),St.add(this),this._chatCompletions=[],this.messages=[]}_addChatCompletion(t){var n;this._chatCompletions.push(t),this._emit("chatCompletion",t);const e=(n=t.choices[0])==null?void 0:n.message;return e&&this._addMessage(e),t}_addMessage(t,e=!0){if("content"in t||(t.content=null),this.messages.push(t),e){if(this._emit("message",t),Ub(t)&&t.content)this._emit("functionToolCallResult",t.content);else if(sh(t)&&t.tool_calls)for(const n of t.tool_calls)n.type==="function"&&this._emit("functionToolCall",n.function)}}async finalChatCompletion(){await this.done();const t=this._chatCompletions[this._chatCompletions.length-1];if(!t)throw new ae("stream ended without producing a ChatCompletion");return t}async finalContent(){return await this.done(),R(this,St,"m",Lp).call(this)}async finalMessage(){return await this.done(),R(this,St,"m",ch).call(this)}async finalFunctionToolCall(){return await this.done(),R(this,St,"m",jp).call(this)}async finalFunctionToolCallResult(){return await this.done(),R(this,St,"m",Bp).call(this)}async totalUsage(){return await this.done(),R(this,St,"m",Up).call(this)}allChatCompletions(){return[...this._chatCompletions]}_emitFinal(){const t=this._chatCompletions[this._chatCompletions.length-1];t&&this._emit("finalChatCompletion",t);const e=R(this,St,"m",ch).call(this);e&&this._emit("finalMessage",e);const n=R(this,St,"m",Lp).call(this);n&&this._emit("finalContent",n);const i=R(this,St,"m",jp).call(this);i&&this._emit("finalFunctionToolCall",i);const s=R(this,St,"m",Bp).call(this);s!=null&&this._emit("finalFunctionToolCallResult",s),this._chatCompletions.some(o=>o.usage)&&this._emit("totalUsage",R(this,St,"m",Up).call(this))}async _createChatCompletion(t,e,n){const i=n==null?void 0:n.signal;i&&(i.aborted&&this.controller.abort(),i.addEventListener("abort",()=>this.controller.abort())),R(this,St,"m",Hb).call(this,e);const s=await t.chat.completions.create({...e,stream:!1},{...n,signal:this.controller.signal});return this._connected(),this._addChatCompletion(um(s,e))}async _runChatCompletion(t,e,n){for(const i of e.messages)this._addMessage(i,!1);return await this._createChatCompletion(t,e,n)}async _runTools(t,e,n){var f,y,w;const i="tool",{tool_choice:s="auto",stream:o,...c}=e,l=typeof s!="string"&&s.type==="function"&&((f=s==null?void 0:s.function)==null?void 0:f.name),{maxChatCompletions:d=M5}=n||{},u=e.tools.map(b=>{if(Hd(b)){if(!b.$callback)throw new ae("Tool given to `.runTools()` that does not have an associated function");return{type:"function",function:{function:b.$callback,name:b.function.name,description:b.function.description||"",parameters:b.function.parameters,parse:b.$parseRaw,strict:!0}}}return b}),h={};for(const b of u)b.type==="function"&&(h[b.function.name||b.function.function.name]=b.function);const p="tools"in e?u.map(b=>b.type==="function"?{type:"function",function:{name:b.function.name||b.function.function.name,parameters:b.function.parameters,description:b.function.description,strict:b.function.strict}}:b):void 0;for(const b of e.messages)this._addMessage(b,!1);for(let b=0;b<d;++b){const A=(y=(await this._createChatCompletion(t,{...c,tool_choice:s,tools:p,messages:[...this.messages]},n)).choices[0])==null?void 0:y.message;if(!A)throw new ae("missing message in ChatCompletion response");if(!((w=A.tool_calls)!=null&&w.length))return;for(const T of A.tool_calls){if(T.type!=="function")continue;const M=T.id,{name:D,arguments:U}=T.function,O=h[D];if(O){if(l&&l!==D){const B=`Invalid tool_call: ${JSON.stringify(D)}. ${JSON.stringify(l)} requested. Please try again`;this._addMessage({role:i,tool_call_id:M,content:B});continue}}else{const B=`Invalid tool_call: ${JSON.stringify(D)}. Available options are: ${Object.keys(h).map(P=>JSON.stringify(P)).join(", ")}. Please try again`;this._addMessage({role:i,tool_call_id:M,content:B});continue}let K;try{K=N5(O)?await O.parse(U):U}catch(B){const P=B instanceof Error?B.message:String(B);this._addMessage({role:i,tool_call_id:M,content:P});continue}const F=await O.function(K,this),H=R(this,St,"m",Wb).call(this,F);if(this._addMessage({role:i,tool_call_id:M,content:H}),l)return}}}}St=new WeakSet,Lp=function(){return R(this,St,"m",ch).call(this).content??null},ch=function(){let t=this.messages.length;for(;t-- >0;){const e=this.messages[t];if(sh(e))return{...e,content:e.content??null,refusal:e.refusal??null}}throw new ae("stream ended without producing a ChatCompletionMessage with role=assistant")},jp=function(){var t,e;for(let n=this.messages.length-1;n>=0;n--){const i=this.messages[n];if(sh(i)&&((t=i==null?void 0:i.tool_calls)!=null&&t.length))return(e=i.tool_calls.filter(s=>s.type==="function").at(-1))==null?void 0:e.function}},Bp=function(){for(let t=this.messages.length-1;t>=0;t--){const e=this.messages[t];if(Ub(e)&&e.content!=null&&typeof e.content=="string"&&this.messages.some(n=>{var i;return n.role==="assistant"&&((i=n.tool_calls)==null?void 0:i.some(s=>s.type==="function"&&s.id===e.tool_call_id))}))return e.content}},Up=function(){const t={completion_tokens:0,prompt_tokens:0,total_tokens:0};for(const{usage:e}of this._chatCompletions)e&&(t.completion_tokens+=e.completion_tokens,t.prompt_tokens+=e.prompt_tokens,t.total_tokens+=e.total_tokens);return t},Hb=function(t){if(t.n!=null&&t.n>1)throw new ae("ChatCompletion convenience helpers only support n=1 at this time. To use n>1, please use chat.completions.create() directly.")},Wb=function(t){return typeof t=="string"?t:t===void 0?"undefined":JSON.stringify(t)};class fm extends qb{static runTools(t,e,n){const i=new fm,s={...n,headers:{...n==null?void 0:n.headers,"X-Stainless-Helper-Method":"runTools"}};return i._run(()=>i._runTools(t,e,s)),i}_addMessage(t,e=!0){super._addMessage(t,e),sh(t)&&t.content&&this._emit("content",t.content)}}const Kb=1,Gb=2,Vb=4,Xb=8,Jb=16,Qb=32,Yb=64,Zb=128,ew=256,tw=Zb|ew,nw=Jb|Qb|tw|Yb,rw=Kb|Gb|nw,iw=Vb|Xb,A5=rw|iw,tt={STR:Kb,NUM:Gb,ARR:Vb,OBJ:Xb,NULL:Jb,BOOL:Qb,NAN:Yb,INFINITY:Zb,MINUS_INFINITY:ew,INF:tw,SPECIAL:nw,ATOM:rw,COLLECTION:iw,ALL:A5};class T5 extends Error{}class P5 extends Error{}function $5(r,t=tt.ALL){if(typeof r!="string")throw new TypeError(`expecting str, got ${typeof r}`);if(!r.trim())throw new Error(`${r} is empty`);return R5(r.trim(),t)}const R5=(r,t)=>{const e=r.length;let n=0;const i=p=>{throw new T5(`${p} at position ${n}`)},s=p=>{throw new P5(`${p} at position ${n}`)},o=()=>(h(),n>=e&&i("Unexpected end of input"),r[n]==='"'?c():r[n]==="{"?l():r[n]==="["?d():r.substring(n,n+4)==="null"||tt.NULL&t&&e-n<4&&"null".startsWith(r.substring(n))?(n+=4,null):r.substring(n,n+4)==="true"||tt.BOOL&t&&e-n<4&&"true".startsWith(r.substring(n))?(n+=4,!0):r.substring(n,n+5)==="false"||tt.BOOL&t&&e-n<5&&"false".startsWith(r.substring(n))?(n+=5,!1):r.substring(n,n+8)==="Infinity"||tt.INFINITY&t&&e-n<8&&"Infinity".startsWith(r.substring(n))?(n+=8,1/0):r.substring(n,n+9)==="-Infinity"||tt.MINUS_INFINITY&t&&1<e-n&&e-n<9&&"-Infinity".startsWith(r.substring(n))?(n+=9,-1/0):r.substring(n,n+3)==="NaN"||tt.NAN&t&&e-n<3&&"NaN".startsWith(r.substring(n))?(n+=3,NaN):u()),c=()=>{const p=n;let f=!1;for(n++;n<e&&(r[n]!=='"'||f&&r[n-1]==="\\");)f=r[n]==="\\"?!f:!1,n++;if(r.charAt(n)=='"')try{return JSON.parse(r.substring(p,++n-Number(f)))}catch(y){s(String(y))}else if(tt.STR&t)try{return JSON.parse(r.substring(p,n-Number(f))+'"')}catch{return JSON.parse(r.substring(p,r.lastIndexOf("\\"))+'"')}i("Unterminated string literal")},l=()=>{n++,h();const p={};try{for(;r[n]!=="}";){if(h(),n>=e&&tt.OBJ&t)return p;const f=c();h(),n++;try{const y=o();Object.defineProperty(p,f,{value:y,writable:!0,enumerable:!0,configurable:!0})}catch(y){if(tt.OBJ&t)return p;throw y}h(),r[n]===","&&n++}}catch{if(tt.OBJ&t)return p;i("Expected '}' at end of object")}return n++,p},d=()=>{n++;const p=[];try{for(;r[n]!=="]";)p.push(o()),h(),r[n]===","&&n++}catch{if(tt.ARR&t)return p;i("Expected ']' at end of array")}return n++,p},u=()=>{if(n===0){r==="-"&&tt.NUM&t&&i("Not sure what '-' is");try{return JSON.parse(r)}catch(f){if(tt.NUM&t)try{return r[r.length-1]==="."?JSON.parse(r.substring(0,r.lastIndexOf("."))):JSON.parse(r.substring(0,r.lastIndexOf("e")))}catch{}s(String(f))}}const p=n;for(r[n]==="-"&&n++;r[n]&&!",]}".includes(r[n]);)n++;n==e&&!(tt.NUM&t)&&i("Unterminated number literal");try{return JSON.parse(r.substring(p,n))}catch{r.substring(p,n)==="-"&&tt.NUM&t&&i("Not sure what '-' is");try{return JSON.parse(r.substring(p,r.lastIndexOf("e")))}catch(y){s(String(y))}}},h=()=>{for(;n<e&&` 
\r	`.includes(r[n]);)n++};return o()},ly=r=>$5(r,tt.ALL^tt.NUM);var Je,Vn,Qs,Er,_f,ru,bf,wf,vf,iu,xf,dy;class Rc extends qb{constructor(t){super(),Je.add(this),Vn.set(this,void 0),Qs.set(this,void 0),Er.set(this,void 0),le(this,Vn,t),le(this,Qs,[])}get currentChatCompletionSnapshot(){return R(this,Er,"f")}static fromReadableStream(t){const e=new Rc(null);return e._run(()=>e._fromReadableStream(t)),e}static createChatCompletion(t,e,n){const i=new Rc(e);return i._run(()=>i._runChatCompletion(t,{...e,stream:!0},{...n,headers:{...n==null?void 0:n.headers,"X-Stainless-Helper-Method":"stream"}})),i}async _createChatCompletion(t,e,n){var o;super._createChatCompletion;const i=n==null?void 0:n.signal;i&&(i.aborted&&this.controller.abort(),i.addEventListener("abort",()=>this.controller.abort())),R(this,Je,"m",_f).call(this);const s=await t.chat.completions.create({...e,stream:!0},{...n,signal:this.controller.signal});this._connected();for await(const c of s)R(this,Je,"m",bf).call(this,c);if((o=s.controller.signal)!=null&&o.aborted)throw new nn;return this._addChatCompletion(R(this,Je,"m",iu).call(this))}async _fromReadableStream(t,e){var o;const n=e==null?void 0:e.signal;n&&(n.aborted&&this.controller.abort(),n.addEventListener("abort",()=>this.controller.abort())),R(this,Je,"m",_f).call(this),this._connected();const i=Wn.fromReadableStream(t,this.controller);let s;for await(const c of i)s&&s!==c.id&&this._addChatCompletion(R(this,Je,"m",iu).call(this)),R(this,Je,"m",bf).call(this,c),s=c.id;if((o=i.controller.signal)!=null&&o.aborted)throw new nn;return this._addChatCompletion(R(this,Je,"m",iu).call(this))}[(Vn=new WeakMap,Qs=new WeakMap,Er=new WeakMap,Je=new WeakSet,_f=function(){this.ended||le(this,Er,void 0)},ru=function(e){let n=R(this,Qs,"f")[e.index];return n||(n={content_done:!1,refusal_done:!1,logprobs_content_done:!1,logprobs_refusal_done:!1,done_tool_calls:new Set,current_tool_call_index:null},R(this,Qs,"f")[e.index]=n,n)},bf=function(e){var i,s,o,c,l,d,u,h,p,f,y,w,b,C,A;if(this.ended)return;const n=R(this,Je,"m",dy).call(this,e);this._emit("chunk",e,n);for(const T of e.choices){const M=n.choices[T.index];T.delta.content!=null&&((i=M.message)==null?void 0:i.role)==="assistant"&&((s=M.message)!=null&&s.content)&&(this._emit("content",T.delta.content,M.message.content),this._emit("content.delta",{delta:T.delta.content,snapshot:M.message.content,parsed:M.message.parsed})),T.delta.refusal!=null&&((o=M.message)==null?void 0:o.role)==="assistant"&&((c=M.message)!=null&&c.refusal)&&this._emit("refusal.delta",{delta:T.delta.refusal,snapshot:M.message.refusal}),((l=T.logprobs)==null?void 0:l.content)!=null&&((d=M.message)==null?void 0:d.role)==="assistant"&&this._emit("logprobs.content.delta",{content:(u=T.logprobs)==null?void 0:u.content,snapshot:((h=M.logprobs)==null?void 0:h.content)??[]}),((p=T.logprobs)==null?void 0:p.refusal)!=null&&((f=M.message)==null?void 0:f.role)==="assistant"&&this._emit("logprobs.refusal.delta",{refusal:(y=T.logprobs)==null?void 0:y.refusal,snapshot:((w=M.logprobs)==null?void 0:w.refusal)??[]});const D=R(this,Je,"m",ru).call(this,M);M.finish_reason&&(R(this,Je,"m",vf).call(this,M),D.current_tool_call_index!=null&&R(this,Je,"m",wf).call(this,M,D.current_tool_call_index));for(const U of T.delta.tool_calls??[])D.current_tool_call_index!==U.index&&(R(this,Je,"m",vf).call(this,M),D.current_tool_call_index!=null&&R(this,Je,"m",wf).call(this,M,D.current_tool_call_index)),D.current_tool_call_index=U.index;for(const U of T.delta.tool_calls??[]){const O=(b=M.message.tool_calls)==null?void 0:b[U.index];O!=null&&O.type&&((O==null?void 0:O.type)==="function"?this._emit("tool_calls.function.arguments.delta",{name:(C=O.function)==null?void 0:C.name,index:U.index,arguments:O.function.arguments,parsed_arguments:O.function.parsed_arguments,arguments_delta:((A=U.function)==null?void 0:A.arguments)??""}):(O==null||O.type,void 0))}}},wf=function(e,n){var o,c,l;if(R(this,Je,"m",ru).call(this,e).done_tool_calls.has(n))return;const s=(o=e.message.tool_calls)==null?void 0:o[n];if(!s)throw new Error("no tool call snapshot");if(!s.type)throw new Error("tool call snapshot missing `type`");if(s.type==="function"){const d=(l=(c=R(this,Vn,"f"))==null?void 0:c.tools)==null?void 0:l.find(u=>ih(u)&&u.function.name===s.function.name);this._emit("tool_calls.function.arguments.done",{name:s.function.name,index:n,arguments:s.function.arguments,parsed_arguments:Hd(d)?d.$parseRaw(s.function.arguments):d!=null&&d.function.strict?JSON.parse(s.function.arguments):null})}else s.type},vf=function(e){var i,s;const n=R(this,Je,"m",ru).call(this,e);if(e.message.content&&!n.content_done){n.content_done=!0;const o=R(this,Je,"m",xf).call(this);this._emit("content.done",{content:e.message.content,parsed:o?o.$parseRaw(e.message.content):null})}e.message.refusal&&!n.refusal_done&&(n.refusal_done=!0,this._emit("refusal.done",{refusal:e.message.refusal})),(i=e.logprobs)!=null&&i.content&&!n.logprobs_content_done&&(n.logprobs_content_done=!0,this._emit("logprobs.content.done",{content:e.logprobs.content})),(s=e.logprobs)!=null&&s.refusal&&!n.logprobs_refusal_done&&(n.logprobs_refusal_done=!0,this._emit("logprobs.refusal.done",{refusal:e.logprobs.refusal}))},iu=function(){if(this.ended)throw new ae("stream has ended, this shouldn't happen");const e=R(this,Er,"f");if(!e)throw new ae("request ended without sending any chunks");return le(this,Er,void 0),le(this,Qs,[]),F5(e,R(this,Vn,"f"))},xf=function(){var n;const e=(n=R(this,Vn,"f"))==null?void 0:n.response_format;return dm(e)?e:null},dy=function(e){var n,i,s,o;let c=R(this,Er,"f");const{choices:l,...d}=e;c?Object.assign(c,d):c=le(this,Er,{...d,choices:[]});for(const{delta:u,finish_reason:h,index:p,logprobs:f=null,...y}of e.choices){let w=c.choices[p];if(w||(w=c.choices[p]={finish_reason:h,index:p,message:{},logprobs:f,...y}),f)if(!w.logprobs)w.logprobs=Object.assign({},f);else{const{content:U,refusal:O,...K}=f;Object.assign(w.logprobs,K),U&&((n=w.logprobs).content??(n.content=[]),w.logprobs.content.push(...U)),O&&((i=w.logprobs).refusal??(i.refusal=[]),w.logprobs.refusal.push(...O))}if(h&&(w.finish_reason=h,R(this,Vn,"f")&&jb(R(this,Vn,"f")))){if(h==="length")throw new wb;if(h==="content_filter")throw new vb}if(Object.assign(w,y),!u)continue;const{content:b,refusal:C,function_call:A,role:T,tool_calls:M,...D}=u;if(Object.assign(w.message,D),C&&(w.message.refusal=(w.message.refusal||"")+C),T&&(w.message.role=T),A&&(w.message.function_call?(A.name&&(w.message.function_call.name=A.name),A.arguments&&((s=w.message.function_call).arguments??(s.arguments=""),w.message.function_call.arguments+=A.arguments)):w.message.function_call=A),b&&(w.message.content=(w.message.content||"")+b,!w.message.refusal&&R(this,Je,"m",xf).call(this)&&(w.message.parsed=ly(w.message.content))),M){w.message.tool_calls||(w.message.tool_calls=[]);for(const{index:U,id:O,type:K,function:F,...H}of M){const B=(o=w.message.tool_calls)[U]??(o[U]={});Object.assign(B,H),O&&(B.id=O),K&&(B.type=K),F&&(B.function??(B.function={name:F.name??"",arguments:""})),F!=null&&F.name&&(B.function.name=F.name),F!=null&&F.arguments&&(B.function.arguments+=F.arguments,E5(R(this,Vn,"f"),B)&&(B.function.parsed_arguments=ly(B.function.arguments)))}}}return c},Symbol.asyncIterator)](){const t=[],e=[];let n=!1;return this.on("chunk",i=>{const s=e.shift();s?s.resolve(i):t.push(i)}),this.on("end",()=>{n=!0;for(const i of e)i.resolve(void 0);e.length=0}),this.on("abort",i=>{n=!0;for(const s of e)s.reject(i);e.length=0}),this.on("error",i=>{n=!0;for(const s of e)s.reject(i);e.length=0}),{next:async()=>t.length?{value:t.shift(),done:!1}:n?{value:void 0,done:!0}:new Promise((s,o)=>e.push({resolve:s,reject:o})).then(s=>s?{value:s,done:!1}:{value:void 0,done:!0}),return:async()=>(this.abort(),{value:void 0,done:!0})}}toReadableStream(){return new Wn(this[Symbol.asyncIterator].bind(this),this.controller).toReadableStream()}}function F5(r,t){const{id:e,choices:n,created:i,model:s,system_fingerprint:o,...c}=r,l={...c,id:e,choices:n.map(({message:d,finish_reason:u,index:h,logprobs:p,...f})=>{if(!u)throw new ae(`missing finish_reason for choice ${h}`);const{content:y=null,function_call:w,tool_calls:b,...C}=d,A=d.role;if(!A)throw new ae(`missing role for choice ${h}`);if(w){const{arguments:T,name:M}=w;if(T==null)throw new ae(`missing function_call.arguments for choice ${h}`);if(!M)throw new ae(`missing function_call.name for choice ${h}`);return{...f,message:{content:y,function_call:{arguments:T,name:M},role:A,refusal:d.refusal??null},finish_reason:u,index:h,logprobs:p}}return b?{...f,index:h,finish_reason:u,logprobs:p,message:{...C,role:A,content:y,refusal:d.refusal??null,tool_calls:b.map((T,M)=>{const{function:D,type:U,id:O,...K}=T,{arguments:F,name:H,...B}=D||{};if(O==null)throw new ae(`missing choices[${h}].tool_calls[${M}].id
${su(r)}`);if(U==null)throw new ae(`missing choices[${h}].tool_calls[${M}].type
${su(r)}`);if(H==null)throw new ae(`missing choices[${h}].tool_calls[${M}].function.name
${su(r)}`);if(F==null)throw new ae(`missing choices[${h}].tool_calls[${M}].function.arguments
${su(r)}`);return{...K,id:O,type:U,function:{...B,name:H,arguments:F}}})}}:{...f,message:{...C,content:y,role:A,refusal:d.refusal??null},finish_reason:u,index:h,logprobs:p}}),created:i,model:s,object:"chat.completion",...o?{system_fingerprint:o}:{}};return S5(l,t)}function su(r){return JSON.stringify(r)}class lh extends Rc{static fromReadableStream(t){const e=new lh(null);return e._run(()=>e._fromReadableStream(t)),e}static runTools(t,e,n){const i=new lh(e),s={...n,headers:{...n==null?void 0:n.headers,"X-Stainless-Helper-Method":"runTools"}};return i._run(()=>i._runTools(t,e,s)),i}}let pm=class extends se{constructor(){super(...arguments),this.messages=new Lb(this._client)}create(t,e){return this._client.post("/chat/completions",{body:t,...e,stream:t.stream??!1})}retrieve(t,e){return this._client.get(q`/chat/completions/${t}`,e)}update(t,e,n){return this._client.post(q`/chat/completions/${t}`,{body:e,...n})}list(t={},e){return this._client.getAPIList("/chat/completions",Xe,{query:t,...e})}delete(t,e){return this._client.delete(q`/chat/completions/${t}`,e)}parse(t,e){return I5(t.tools),this._client.chat.completions.create(t,{...e,headers:{...e==null?void 0:e.headers,"X-Stainless-Helper-Method":"chat.completions.parse"}})._thenUnwrap(n=>um(n,t))}runTools(t,e){return t.stream?lh.runTools(this._client,t,e):fm.runTools(this._client,t,e)}stream(t,e){return Rc.createChatCompletion(this._client,t,e)}};pm.Messages=Lb;class mm extends se{constructor(){super(...arguments),this.completions=new pm(this._client)}}mm.Completions=pm;const sw=Symbol("brand.privateNullableHeaders");function*D5(r){if(!r)return;if(sw in r){const{values:n,nulls:i}=r;yield*n.entries();for(const s of i)yield[s,null];return}let t=!1,e;r instanceof Headers?e=r.entries():Vg(r)?e=r:(t=!0,e=Object.entries(r??{}));for(let n of e){const i=n[0];if(typeof i!="string")throw new TypeError("expected header name to be a string");const s=Vg(n[1])?n[1]:[n[1]];let o=!1;for(const c of s)c!==void 0&&(t&&!o&&(o=!0,yield[i,null]),yield[i,c])}}const te=r=>{const t=new Headers,e=new Set;for(const n of r){const i=new Set;for(const[s,o]of D5(n)){const c=s.toLowerCase();i.has(c)||(t.delete(s),i.add(c)),o===null?(t.delete(s),e.add(c)):(t.append(s,o),e.delete(c))}}return{[sw]:!0,values:t,nulls:e}};class aw extends se{create(t,e){return this._client.post("/audio/speech",{body:t,...e,headers:te([{Accept:"application/octet-stream"},e==null?void 0:e.headers]),__binaryResponse:!0})}}class ow extends se{create(t,e){return this._client.post("/audio/transcriptions",Us({body:t,...e,stream:t.stream??!1,__metadata:{model:t.model}},this._client))}}class cw extends se{create(t,e){return this._client.post("/audio/translations",Us({body:t,...e,__metadata:{model:t.model}},this._client))}}class Wd extends se{constructor(){super(...arguments),this.transcriptions=new ow(this._client),this.translations=new cw(this._client),this.speech=new aw(this._client)}}Wd.Transcriptions=ow;Wd.Translations=cw;Wd.Speech=aw;class lw extends se{create(t,e){return this._client.post("/batches",{body:t,...e})}retrieve(t,e){return this._client.get(q`/batches/${t}`,e)}list(t={},e){return this._client.getAPIList("/batches",Xe,{query:t,...e})}cancel(t,e){return this._client.post(q`/batches/${t}/cancel`,e)}}class dw extends se{create(t,e){return this._client.post("/assistants",{body:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}retrieve(t,e){return this._client.get(q`/assistants/${t}`,{...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}update(t,e,n){return this._client.post(q`/assistants/${t}`,{body:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}list(t={},e){return this._client.getAPIList("/assistants",Xe,{query:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}delete(t,e){return this._client.delete(q`/assistants/${t}`,{...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}}let uw=class extends se{create(t,e){return this._client.post("/realtime/sessions",{body:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}};class hw extends se{create(t,e){return this._client.post("/realtime/transcription_sessions",{body:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}}let Hh=class extends se{constructor(){super(...arguments),this.sessions=new uw(this._client),this.transcriptionSessions=new hw(this._client)}};Hh.Sessions=uw;Hh.TranscriptionSessions=hw;class fw extends se{create(t,e){return this._client.post("/chatkit/sessions",{body:t,...e,headers:te([{"OpenAI-Beta":"chatkit_beta=v1"},e==null?void 0:e.headers])})}cancel(t,e){return this._client.post(q`/chatkit/sessions/${t}/cancel`,{...e,headers:te([{"OpenAI-Beta":"chatkit_beta=v1"},e==null?void 0:e.headers])})}}let pw=class extends se{retrieve(t,e){return this._client.get(q`/chatkit/threads/${t}`,{...e,headers:te([{"OpenAI-Beta":"chatkit_beta=v1"},e==null?void 0:e.headers])})}list(t={},e){return this._client.getAPIList("/chatkit/threads",rh,{query:t,...e,headers:te([{"OpenAI-Beta":"chatkit_beta=v1"},e==null?void 0:e.headers])})}delete(t,e){return this._client.delete(q`/chatkit/threads/${t}`,{...e,headers:te([{"OpenAI-Beta":"chatkit_beta=v1"},e==null?void 0:e.headers])})}listItems(t,e={},n){return this._client.getAPIList(q`/chatkit/threads/${t}/items`,rh,{query:e,...n,headers:te([{"OpenAI-Beta":"chatkit_beta=v1"},n==null?void 0:n.headers])})}};class Wh extends se{constructor(){super(...arguments),this.sessions=new fw(this._client),this.threads=new pw(this._client)}}Wh.Sessions=fw;Wh.Threads=pw;class mw extends se{create(t,e,n){return this._client.post(q`/threads/${t}/messages`,{body:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}retrieve(t,e,n){const{thread_id:i}=e;return this._client.get(q`/threads/${i}/messages/${t}`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}update(t,e,n){const{thread_id:i,...s}=e;return this._client.post(q`/threads/${i}/messages/${t}`,{body:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}list(t,e={},n){return this._client.getAPIList(q`/threads/${t}/messages`,Xe,{query:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}delete(t,e,n){const{thread_id:i}=e;return this._client.delete(q`/threads/${i}/messages/${t}`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}}class gw extends se{retrieve(t,e,n){const{thread_id:i,run_id:s,...o}=e;return this._client.get(q`/threads/${i}/runs/${s}/steps/${t}`,{query:o,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}list(t,e,n){const{thread_id:i,...s}=e;return this._client.getAPIList(q`/threads/${i}/runs/${t}/steps`,Xe,{query:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}}const O5=r=>{if(typeof Buffer<"u"){const t=Buffer.from(r,"base64");return Array.from(new Float32Array(t.buffer,t.byteOffset,t.length/Float32Array.BYTES_PER_ELEMENT))}else{const t=atob(r),e=t.length,n=new Uint8Array(e);for(let i=0;i<e;i++)n[i]=t.charCodeAt(i);return Array.from(new Float32Array(n.buffer))}};var Sf={};const Ys=r=>{var t,e,n,i;if(typeof globalThis.process<"u")return((t=Sf==null?void 0:Sf[r])==null?void 0:t.trim())??void 0;if(typeof globalThis.Deno<"u")return(i=(n=(e=globalThis.Deno.env)==null?void 0:e.get)==null?void 0:n.call(e,r))==null?void 0:i.trim()};var ht,Ni,zp,Rn,Du,cn,Mi,ua,Ci,dh,Wt,Ou,Lu,kc,gc,yc,uy,hy,fy,py,my,gy,yy;class Cc extends hm{constructor(){super(...arguments),ht.add(this),zp.set(this,[]),Rn.set(this,{}),Du.set(this,{}),cn.set(this,void 0),Mi.set(this,void 0),ua.set(this,void 0),Ci.set(this,void 0),dh.set(this,void 0),Wt.set(this,void 0),Ou.set(this,void 0),Lu.set(this,void 0),kc.set(this,void 0)}[(zp=new WeakMap,Rn=new WeakMap,Du=new WeakMap,cn=new WeakMap,Mi=new WeakMap,ua=new WeakMap,Ci=new WeakMap,dh=new WeakMap,Wt=new WeakMap,Ou=new WeakMap,Lu=new WeakMap,kc=new WeakMap,ht=new WeakSet,Symbol.asyncIterator)](){const t=[],e=[];let n=!1;return this.on("event",i=>{const s=e.shift();s?s.resolve(i):t.push(i)}),this.on("end",()=>{n=!0;for(const i of e)i.resolve(void 0);e.length=0}),this.on("abort",i=>{n=!0;for(const s of e)s.reject(i);e.length=0}),this.on("error",i=>{n=!0;for(const s of e)s.reject(i);e.length=0}),{next:async()=>t.length?{value:t.shift(),done:!1}:n?{value:void 0,done:!0}:new Promise((s,o)=>e.push({resolve:s,reject:o})).then(s=>s?{value:s,done:!1}:{value:void 0,done:!0}),return:async()=>(this.abort(),{value:void 0,done:!0})}}static fromReadableStream(t){const e=new Ni;return e._run(()=>e._fromReadableStream(t)),e}async _fromReadableStream(t,e){var s;const n=e==null?void 0:e.signal;n&&(n.aborted&&this.controller.abort(),n.addEventListener("abort",()=>this.controller.abort())),this._connected();const i=Wn.fromReadableStream(t,this.controller);for await(const o of i)R(this,ht,"m",gc).call(this,o);if((s=i.controller.signal)!=null&&s.aborted)throw new nn;return this._addRun(R(this,ht,"m",yc).call(this))}toReadableStream(){return new Wn(this[Symbol.asyncIterator].bind(this),this.controller).toReadableStream()}static createToolAssistantStream(t,e,n,i){const s=new Ni;return s._run(()=>s._runToolAssistantStream(t,e,n,{...i,headers:{...i==null?void 0:i.headers,"X-Stainless-Helper-Method":"stream"}})),s}async _createToolAssistantStream(t,e,n,i){var l;const s=i==null?void 0:i.signal;s&&(s.aborted&&this.controller.abort(),s.addEventListener("abort",()=>this.controller.abort()));const o={...n,stream:!0},c=await t.submitToolOutputs(e,o,{...i,signal:this.controller.signal});this._connected();for await(const d of c)R(this,ht,"m",gc).call(this,d);if((l=c.controller.signal)!=null&&l.aborted)throw new nn;return this._addRun(R(this,ht,"m",yc).call(this))}static createThreadAssistantStream(t,e,n){const i=new Ni;return i._run(()=>i._threadAssistantStream(t,e,{...n,headers:{...n==null?void 0:n.headers,"X-Stainless-Helper-Method":"stream"}})),i}static createAssistantStream(t,e,n,i){const s=new Ni;return s._run(()=>s._runAssistantStream(t,e,n,{...i,headers:{...i==null?void 0:i.headers,"X-Stainless-Helper-Method":"stream"}})),s}currentEvent(){return R(this,Ou,"f")}currentRun(){return R(this,Lu,"f")}currentMessageSnapshot(){return R(this,cn,"f")}currentRunStepSnapshot(){return R(this,kc,"f")}async finalRunSteps(){return await this.done(),Object.values(R(this,Rn,"f"))}async finalMessages(){return await this.done(),Object.values(R(this,Du,"f"))}async finalRun(){if(await this.done(),!R(this,Mi,"f"))throw Error("Final run was not received.");return R(this,Mi,"f")}async _createThreadAssistantStream(t,e,n){var c;const i=n==null?void 0:n.signal;i&&(i.aborted&&this.controller.abort(),i.addEventListener("abort",()=>this.controller.abort()));const s={...e,stream:!0},o=await t.createAndRun(s,{...n,signal:this.controller.signal});this._connected();for await(const l of o)R(this,ht,"m",gc).call(this,l);if((c=o.controller.signal)!=null&&c.aborted)throw new nn;return this._addRun(R(this,ht,"m",yc).call(this))}async _createAssistantStream(t,e,n,i){var l;const s=i==null?void 0:i.signal;s&&(s.aborted&&this.controller.abort(),s.addEventListener("abort",()=>this.controller.abort()));const o={...n,stream:!0},c=await t.create(e,o,{...i,signal:this.controller.signal});this._connected();for await(const d of c)R(this,ht,"m",gc).call(this,d);if((l=c.controller.signal)!=null&&l.aborted)throw new nn;return this._addRun(R(this,ht,"m",yc).call(this))}static accumulateDelta(t,e){for(const[n,i]of Object.entries(e)){if(!t.hasOwnProperty(n)){t[n]=i;continue}let s=t[n];if(s==null){t[n]=i;continue}if(n==="index"||n==="type"){t[n]=i;continue}if(typeof s=="string"&&typeof i=="string")s+=i;else if(typeof s=="number"&&typeof i=="number")s+=i;else if(mf(s)&&mf(i))s=this.accumulateDelta(s,i);else if(Array.isArray(s)&&Array.isArray(i)){if(s.every(o=>typeof o=="string"||typeof o=="number")){s.push(...i);continue}for(const o of i){if(!mf(o))throw new Error(`Expected array delta entry to be an object but got: ${o}`);const c=o.index;if(c==null)throw console.error(o),new Error("Expected array delta entry to have an `index` property");if(typeof c!="number")throw new Error(`Expected array delta entry \`index\` property to be a number but got ${c}`);const l=s[c];l==null?s.push(o):s[c]=this.accumulateDelta(l,o)}continue}else throw Error(`Unhandled record type: ${n}, deltaValue: ${i}, accValue: ${s}`);t[n]=s}return t}_addRun(t){return t}async _threadAssistantStream(t,e,n){return await this._createThreadAssistantStream(e,t,n)}async _runAssistantStream(t,e,n,i){return await this._createAssistantStream(e,t,n,i)}async _runToolAssistantStream(t,e,n,i){return await this._createToolAssistantStream(e,t,n,i)}}Ni=Cc,gc=function(t){if(!this.ended)switch(le(this,Ou,t),R(this,ht,"m",fy).call(this,t),t.event){case"thread.created":break;case"thread.run.created":case"thread.run.queued":case"thread.run.in_progress":case"thread.run.requires_action":case"thread.run.completed":case"thread.run.incomplete":case"thread.run.failed":case"thread.run.cancelling":case"thread.run.cancelled":case"thread.run.expired":R(this,ht,"m",yy).call(this,t);break;case"thread.run.step.created":case"thread.run.step.in_progress":case"thread.run.step.delta":case"thread.run.step.completed":case"thread.run.step.failed":case"thread.run.step.cancelled":case"thread.run.step.expired":R(this,ht,"m",hy).call(this,t);break;case"thread.message.created":case"thread.message.in_progress":case"thread.message.delta":case"thread.message.completed":case"thread.message.incomplete":R(this,ht,"m",uy).call(this,t);break;case"error":throw new Error("Encountered an error event in event processing - errors should be processed earlier")}},yc=function(){if(this.ended)throw new ae("stream has ended, this shouldn't happen");if(!R(this,Mi,"f"))throw Error("Final run has not been received");return R(this,Mi,"f")},uy=function(t){const[e,n]=R(this,ht,"m",my).call(this,t,R(this,cn,"f"));le(this,cn,e),R(this,Du,"f")[e.id]=e;for(const i of n){const s=e.content[i.index];(s==null?void 0:s.type)=="text"&&this._emit("textCreated",s.text)}switch(t.event){case"thread.message.created":this._emit("messageCreated",t.data);break;case"thread.message.in_progress":break;case"thread.message.delta":if(this._emit("messageDelta",t.data.delta,e),t.data.delta.content)for(const i of t.data.delta.content){if(i.type=="text"&&i.text){let s=i.text,o=e.content[i.index];if(o&&o.type=="text")this._emit("textDelta",s,o.text);else throw Error("The snapshot associated with this text delta is not text or missing")}if(i.index!=R(this,ua,"f")){if(R(this,Ci,"f"))switch(R(this,Ci,"f").type){case"text":this._emit("textDone",R(this,Ci,"f").text,R(this,cn,"f"));break;case"image_file":this._emit("imageFileDone",R(this,Ci,"f").image_file,R(this,cn,"f"));break}le(this,ua,i.index)}le(this,Ci,e.content[i.index])}break;case"thread.message.completed":case"thread.message.incomplete":if(R(this,ua,"f")!==void 0){const i=t.data.content[R(this,ua,"f")];if(i)switch(i.type){case"image_file":this._emit("imageFileDone",i.image_file,R(this,cn,"f"));break;case"text":this._emit("textDone",i.text,R(this,cn,"f"));break}}R(this,cn,"f")&&this._emit("messageDone",t.data),le(this,cn,void 0)}},hy=function(t){const e=R(this,ht,"m",py).call(this,t);switch(le(this,kc,e),t.event){case"thread.run.step.created":this._emit("runStepCreated",t.data);break;case"thread.run.step.delta":const n=t.data.delta;if(n.step_details&&n.step_details.type=="tool_calls"&&n.step_details.tool_calls&&e.step_details.type=="tool_calls")for(const s of n.step_details.tool_calls)s.index==R(this,dh,"f")?this._emit("toolCallDelta",s,e.step_details.tool_calls[s.index]):(R(this,Wt,"f")&&this._emit("toolCallDone",R(this,Wt,"f")),le(this,dh,s.index),le(this,Wt,e.step_details.tool_calls[s.index]),R(this,Wt,"f")&&this._emit("toolCallCreated",R(this,Wt,"f")));this._emit("runStepDelta",t.data.delta,e);break;case"thread.run.step.completed":case"thread.run.step.failed":case"thread.run.step.cancelled":case"thread.run.step.expired":le(this,kc,void 0),t.data.step_details.type=="tool_calls"&&R(this,Wt,"f")&&(this._emit("toolCallDone",R(this,Wt,"f")),le(this,Wt,void 0)),this._emit("runStepDone",t.data,e);break}},fy=function(t){R(this,zp,"f").push(t),this._emit("event",t)},py=function(t){switch(t.event){case"thread.run.step.created":return R(this,Rn,"f")[t.data.id]=t.data,t.data;case"thread.run.step.delta":let e=R(this,Rn,"f")[t.data.id];if(!e)throw Error("Received a RunStepDelta before creation of a snapshot");let n=t.data;if(n.delta){const i=Ni.accumulateDelta(e,n.delta);R(this,Rn,"f")[t.data.id]=i}return R(this,Rn,"f")[t.data.id];case"thread.run.step.completed":case"thread.run.step.failed":case"thread.run.step.cancelled":case"thread.run.step.expired":case"thread.run.step.in_progress":R(this,Rn,"f")[t.data.id]=t.data;break}if(R(this,Rn,"f")[t.data.id])return R(this,Rn,"f")[t.data.id];throw new Error("No snapshot available")},my=function(t,e){let n=[];switch(t.event){case"thread.message.created":return[t.data,n];case"thread.message.delta":if(!e)throw Error("Received a delta with no existing snapshot (there should be one from message creation)");let i=t.data;if(i.delta.content)for(const s of i.delta.content)if(s.index in e.content){let o=e.content[s.index];e.content[s.index]=R(this,ht,"m",gy).call(this,s,o)}else e.content[s.index]=s,n.push(s);return[e,n];case"thread.message.in_progress":case"thread.message.completed":case"thread.message.incomplete":if(e)return[e,n];throw Error("Received thread message event with no existing snapshot")}throw Error("Tried to accumulate a non-message event")},gy=function(t,e){return Ni.accumulateDelta(e,t)},yy=function(t){switch(le(this,Lu,t.data),t.event){case"thread.run.created":break;case"thread.run.queued":break;case"thread.run.in_progress":break;case"thread.run.requires_action":case"thread.run.cancelled":case"thread.run.failed":case"thread.run.completed":case"thread.run.expired":case"thread.run.incomplete":le(this,Mi,t.data),R(this,Wt,"f")&&(this._emit("toolCallDone",R(this,Wt,"f")),le(this,Wt,void 0));break}};let gm=class extends se{constructor(){super(...arguments),this.steps=new gw(this._client)}create(t,e,n){const{include:i,...s}=e;return this._client.post(q`/threads/${t}/runs`,{query:{include:i},body:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers]),stream:e.stream??!1})}retrieve(t,e,n){const{thread_id:i}=e;return this._client.get(q`/threads/${i}/runs/${t}`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}update(t,e,n){const{thread_id:i,...s}=e;return this._client.post(q`/threads/${i}/runs/${t}`,{body:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}list(t,e={},n){return this._client.getAPIList(q`/threads/${t}/runs`,Xe,{query:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}cancel(t,e,n){const{thread_id:i}=e;return this._client.post(q`/threads/${i}/runs/${t}/cancel`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}async createAndPoll(t,e,n){const i=await this.create(t,e,n);return await this.poll(i.id,{thread_id:t},n)}createAndStream(t,e,n){return Cc.createAssistantStream(t,this._client.beta.threads.runs,e,n)}async poll(t,e,n){var s;const i=te([n==null?void 0:n.headers,{"X-Stainless-Poll-Helper":"true","X-Stainless-Custom-Poll-Interval":((s=n==null?void 0:n.pollIntervalMs)==null?void 0:s.toString())??void 0}]);for(;;){const{data:o,response:c}=await this.retrieve(t,e,{...n,headers:{...n==null?void 0:n.headers,...i}}).withResponse();switch(o.status){case"queued":case"in_progress":case"cancelling":let l=5e3;if(n!=null&&n.pollIntervalMs)l=n.pollIntervalMs;else{const d=c.headers.get("openai-poll-after-ms");if(d){const u=parseInt(d);isNaN(u)||(l=u)}}await zd(l);break;case"requires_action":case"incomplete":case"cancelled":case"completed":case"failed":case"expired":return o}}}stream(t,e,n){return Cc.createAssistantStream(t,this._client.beta.threads.runs,e,n)}submitToolOutputs(t,e,n){const{thread_id:i,...s}=e;return this._client.post(q`/threads/${i}/runs/${t}/submit_tool_outputs`,{body:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers]),stream:e.stream??!1})}async submitToolOutputsAndPoll(t,e,n){const i=await this.submitToolOutputs(t,e,n);return await this.poll(i.id,e,n)}submitToolOutputsStream(t,e,n){return Cc.createToolAssistantStream(t,this._client.beta.threads.runs,e,n)}};gm.Steps=gw;class qh extends se{constructor(){super(...arguments),this.runs=new gm(this._client),this.messages=new mw(this._client)}create(t={},e){return this._client.post("/threads",{body:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}retrieve(t,e){return this._client.get(q`/threads/${t}`,{...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}update(t,e,n){return this._client.post(q`/threads/${t}`,{body:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}delete(t,e){return this._client.delete(q`/threads/${t}`,{...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}createAndRun(t,e){return this._client.post("/threads/runs",{body:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers]),stream:t.stream??!1})}async createAndRunPoll(t,e){const n=await this.createAndRun(t,e);return await this.runs.poll(n.id,{thread_id:n.thread_id},e)}createAndRunStream(t,e){return Cc.createThreadAssistantStream(t,this._client.beta.threads,e)}}qh.Runs=gm;qh.Messages=mw;class Go extends se{constructor(){super(...arguments),this.realtime=new Hh(this._client),this.chatkit=new Wh(this._client),this.assistants=new dw(this._client),this.threads=new qh(this._client)}}Go.Realtime=Hh;Go.ChatKit=Wh;Go.Assistants=dw;Go.Threads=qh;class yw extends se{create(t,e){return this._client.post("/completions",{body:t,...e,stream:t.stream??!1})}}class _w extends se{retrieve(t,e,n){const{container_id:i}=e;return this._client.get(q`/containers/${i}/files/${t}/content`,{...n,headers:te([{Accept:"application/binary"},n==null?void 0:n.headers]),__binaryResponse:!0})}}let ym=class extends se{constructor(){super(...arguments),this.content=new _w(this._client)}create(t,e,n){return this._client.post(q`/containers/${t}/files`,Us({body:e,...n},this._client))}retrieve(t,e,n){const{container_id:i}=e;return this._client.get(q`/containers/${i}/files/${t}`,n)}list(t,e={},n){return this._client.getAPIList(q`/containers/${t}/files`,Xe,{query:e,...n})}delete(t,e,n){const{container_id:i}=e;return this._client.delete(q`/containers/${i}/files/${t}`,{...n,headers:te([{Accept:"*/*"},n==null?void 0:n.headers])})}};ym.Content=_w;class _m extends se{constructor(){super(...arguments),this.files=new ym(this._client)}create(t,e){return this._client.post("/containers",{body:t,...e})}retrieve(t,e){return this._client.get(q`/containers/${t}`,e)}list(t={},e){return this._client.getAPIList("/containers",Xe,{query:t,...e})}delete(t,e){return this._client.delete(q`/containers/${t}`,{...e,headers:te([{Accept:"*/*"},e==null?void 0:e.headers])})}}_m.Files=ym;class bw extends se{create(t,e,n){const{include:i,...s}=e;return this._client.post(q`/conversations/${t}/items`,{query:{include:i},body:s,...n})}retrieve(t,e,n){const{conversation_id:i,...s}=e;return this._client.get(q`/conversations/${i}/items/${t}`,{query:s,...n})}list(t,e={},n){return this._client.getAPIList(q`/conversations/${t}/items`,rh,{query:e,...n})}delete(t,e,n){const{conversation_id:i}=e;return this._client.delete(q`/conversations/${i}/items/${t}`,n)}}class bm extends se{constructor(){super(...arguments),this.items=new bw(this._client)}create(t={},e){return this._client.post("/conversations",{body:t,...e})}retrieve(t,e){return this._client.get(q`/conversations/${t}`,e)}update(t,e,n){return this._client.post(q`/conversations/${t}`,{body:e,...n})}delete(t,e){return this._client.delete(q`/conversations/${t}`,e)}}bm.Items=bw;class ww extends se{create(t,e){const n=!!t.encoding_format;let i=n?t.encoding_format:"base64";n&&dt(this._client).debug("embeddings/user defined encoding_format:",t.encoding_format);const s=this._client.post("/embeddings",{body:{...t,encoding_format:i},...e});return n?s:(dt(this._client).debug("embeddings/decoding base64 embeddings from base64"),s._thenUnwrap(o=>(o&&o.data&&o.data.forEach(c=>{const l=c.embedding;c.embedding=O5(l)}),o)))}}class vw extends se{retrieve(t,e,n){const{eval_id:i,run_id:s}=e;return this._client.get(q`/evals/${i}/runs/${s}/output_items/${t}`,n)}list(t,e,n){const{eval_id:i,...s}=e;return this._client.getAPIList(q`/evals/${i}/runs/${t}/output_items`,Xe,{query:s,...n})}}class wm extends se{constructor(){super(...arguments),this.outputItems=new vw(this._client)}create(t,e,n){return this._client.post(q`/evals/${t}/runs`,{body:e,...n})}retrieve(t,e,n){const{eval_id:i}=e;return this._client.get(q`/evals/${i}/runs/${t}`,n)}list(t,e={},n){return this._client.getAPIList(q`/evals/${t}/runs`,Xe,{query:e,...n})}delete(t,e,n){const{eval_id:i}=e;return this._client.delete(q`/evals/${i}/runs/${t}`,n)}cancel(t,e,n){const{eval_id:i}=e;return this._client.post(q`/evals/${i}/runs/${t}`,n)}}wm.OutputItems=vw;class vm extends se{constructor(){super(...arguments),this.runs=new wm(this._client)}create(t,e){return this._client.post("/evals",{body:t,...e})}retrieve(t,e){return this._client.get(q`/evals/${t}`,e)}update(t,e,n){return this._client.post(q`/evals/${t}`,{body:e,...n})}list(t={},e){return this._client.getAPIList("/evals",Xe,{query:t,...e})}delete(t,e){return this._client.delete(q`/evals/${t}`,e)}}vm.Runs=wm;let xw=class extends se{create(t,e){return this._client.post("/files",Us({body:t,...e},this._client))}retrieve(t,e){return this._client.get(q`/files/${t}`,e)}list(t={},e){return this._client.getAPIList("/files",Xe,{query:t,...e})}delete(t,e){return this._client.delete(q`/files/${t}`,e)}content(t,e){return this._client.get(q`/files/${t}/content`,{...e,headers:te([{Accept:"application/binary"},e==null?void 0:e.headers]),__binaryResponse:!0})}async waitForProcessing(t,{pollInterval:e=5e3,maxWait:n=1800*1e3}={}){const i=new Set(["processed","error","deleted"]),s=Date.now();let o=await this.retrieve(t);for(;!o.status||!i.has(o.status);)if(await zd(e),o=await this.retrieve(t),Date.now()-s>n)throw new am({message:`Giving up on waiting for file ${t} to finish processing after ${n} milliseconds.`});return o}};class Sw extends se{}let kw=class extends se{run(t,e){return this._client.post("/fine_tuning/alpha/graders/run",{body:t,...e})}validate(t,e){return this._client.post("/fine_tuning/alpha/graders/validate",{body:t,...e})}};class xm extends se{constructor(){super(...arguments),this.graders=new kw(this._client)}}xm.Graders=kw;class Cw extends se{create(t,e,n){return this._client.getAPIList(q`/fine_tuning/checkpoints/${t}/permissions`,zh,{body:e,method:"post",...n})}retrieve(t,e={},n){return this._client.get(q`/fine_tuning/checkpoints/${t}/permissions`,{query:e,...n})}delete(t,e,n){const{fine_tuned_model_checkpoint:i}=e;return this._client.delete(q`/fine_tuning/checkpoints/${i}/permissions/${t}`,n)}}let Sm=class extends se{constructor(){super(...arguments),this.permissions=new Cw(this._client)}};Sm.Permissions=Cw;class Ew extends se{list(t,e={},n){return this._client.getAPIList(q`/fine_tuning/jobs/${t}/checkpoints`,Xe,{query:e,...n})}}class km extends se{constructor(){super(...arguments),this.checkpoints=new Ew(this._client)}create(t,e){return this._client.post("/fine_tuning/jobs",{body:t,...e})}retrieve(t,e){return this._client.get(q`/fine_tuning/jobs/${t}`,e)}list(t={},e){return this._client.getAPIList("/fine_tuning/jobs",Xe,{query:t,...e})}cancel(t,e){return this._client.post(q`/fine_tuning/jobs/${t}/cancel`,e)}listEvents(t,e={},n){return this._client.getAPIList(q`/fine_tuning/jobs/${t}/events`,Xe,{query:e,...n})}pause(t,e){return this._client.post(q`/fine_tuning/jobs/${t}/pause`,e)}resume(t,e){return this._client.post(q`/fine_tuning/jobs/${t}/resume`,e)}}km.Checkpoints=Ew;class Vo extends se{constructor(){super(...arguments),this.methods=new Sw(this._client),this.jobs=new km(this._client),this.checkpoints=new Sm(this._client),this.alpha=new xm(this._client)}}Vo.Methods=Sw;Vo.Jobs=km;Vo.Checkpoints=Sm;Vo.Alpha=xm;class Iw extends se{}class Cm extends se{constructor(){super(...arguments),this.graderModels=new Iw(this._client)}}Cm.GraderModels=Iw;class Nw extends se{createVariation(t,e){return this._client.post("/images/variations",Us({body:t,...e},this._client))}edit(t,e){return this._client.post("/images/edits",Us({body:t,...e,stream:t.stream??!1},this._client))}generate(t,e){return this._client.post("/images/generations",{body:t,...e,stream:t.stream??!1})}}class Mw extends se{retrieve(t,e){return this._client.get(q`/models/${t}`,e)}list(t){return this._client.getAPIList("/models",zh,t)}delete(t,e){return this._client.delete(q`/models/${t}`,e)}}class Aw extends se{create(t,e){return this._client.post("/moderations",{body:t,...e})}}class Tw extends se{accept(t,e,n){return this._client.post(q`/realtime/calls/${t}/accept`,{body:e,...n,headers:te([{Accept:"*/*"},n==null?void 0:n.headers])})}hangup(t,e){return this._client.post(q`/realtime/calls/${t}/hangup`,{...e,headers:te([{Accept:"*/*"},e==null?void 0:e.headers])})}refer(t,e,n){return this._client.post(q`/realtime/calls/${t}/refer`,{body:e,...n,headers:te([{Accept:"*/*"},n==null?void 0:n.headers])})}reject(t,e={},n){return this._client.post(q`/realtime/calls/${t}/reject`,{body:e,...n,headers:te([{Accept:"*/*"},n==null?void 0:n.headers])})}}class Pw extends se{create(t,e){return this._client.post("/realtime/client_secrets",{body:t,...e})}}class Kh extends se{constructor(){super(...arguments),this.clientSecrets=new Pw(this._client),this.calls=new Tw(this._client)}}Kh.ClientSecrets=Pw;Kh.Calls=Tw;function L5(r,t){return!t||!B5(t)?{...r,output_parsed:null,output:r.output.map(e=>e.type==="function_call"?{...e,parsed_arguments:null}:e.type==="message"?{...e,content:e.content.map(n=>({...n,parsed:null}))}:e)}:$w(r,t)}function $w(r,t){const e=r.output.map(i=>{if(i.type==="function_call")return{...i,parsed_arguments:H5(t,i)};if(i.type==="message"){const s=i.content.map(o=>o.type==="output_text"?{...o,parsed:j5(t,o.text)}:o);return{...i,content:s}}return i}),n=Object.assign({},r,{output:e});return Object.getOwnPropertyDescriptor(r,"output_text")||Hp(n),Object.defineProperty(n,"output_parsed",{enumerable:!0,get(){for(const i of n.output)if(i.type==="message"){for(const s of i.content)if(s.type==="output_text"&&s.parsed!==null)return s.parsed}return null}}),n}function j5(r,t){var e,n,i,s;return((n=(e=r.text)==null?void 0:e.format)==null?void 0:n.type)!=="json_schema"?null:"$parseRaw"in((i=r.text)==null?void 0:i.format)?((s=r.text)==null?void 0:s.format).$parseRaw(t):JSON.parse(t)}function B5(r){var t;return!!dm((t=r.text)==null?void 0:t.format)}function U5(r){return(r==null?void 0:r.$brand)==="auto-parseable-tool"}function z5(r,t){return r.find(e=>e.type==="function"&&e.name===t)}function H5(r,t){const e=z5(r.tools??[],t.name);return{...t,...t,parsed_arguments:U5(e)?e.$parseRaw(t.arguments):e!=null&&e.strict?JSON.parse(t.arguments):null}}function Hp(r){const t=[];for(const e of r.output)if(e.type==="message")for(const n of e.content)n.type==="output_text"&&t.push(n.text);r.output_text=t.join("")}var Zs,au,Ir,ou,_y,by,wy,vy;class Em extends hm{constructor(t){super(),Zs.add(this),au.set(this,void 0),Ir.set(this,void 0),ou.set(this,void 0),le(this,au,t)}static createResponse(t,e,n){const i=new Em(e);return i._run(()=>i._createOrRetrieveResponse(t,e,{...n,headers:{...n==null?void 0:n.headers,"X-Stainless-Helper-Method":"stream"}})),i}async _createOrRetrieveResponse(t,e,n){var c;const i=n==null?void 0:n.signal;i&&(i.aborted&&this.controller.abort(),i.addEventListener("abort",()=>this.controller.abort())),R(this,Zs,"m",_y).call(this);let s,o=null;"response_id"in e?(s=await t.responses.retrieve(e.response_id,{stream:!0},{...n,signal:this.controller.signal,stream:!0}),o=e.starting_after??null):s=await t.responses.create({...e,stream:!0},{...n,signal:this.controller.signal}),this._connected();for await(const l of s)R(this,Zs,"m",by).call(this,l,o);if((c=s.controller.signal)!=null&&c.aborted)throw new nn;return R(this,Zs,"m",wy).call(this)}[(au=new WeakMap,Ir=new WeakMap,ou=new WeakMap,Zs=new WeakSet,_y=function(){this.ended||le(this,Ir,void 0)},by=function(e,n){if(this.ended)return;const i=(o,c)=>{(n==null||c.sequence_number>n)&&this._emit(o,c)},s=R(this,Zs,"m",vy).call(this,e);switch(i("event",e),e.type){case"response.output_text.delta":{const o=s.output[e.output_index];if(!o)throw new ae(`missing output at index ${e.output_index}`);if(o.type==="message"){const c=o.content[e.content_index];if(!c)throw new ae(`missing content at index ${e.content_index}`);if(c.type!=="output_text")throw new ae(`expected content to be 'output_text', got ${c.type}`);i("response.output_text.delta",{...e,snapshot:c.text})}break}case"response.function_call_arguments.delta":{const o=s.output[e.output_index];if(!o)throw new ae(`missing output at index ${e.output_index}`);o.type==="function_call"&&i("response.function_call_arguments.delta",{...e,snapshot:o.arguments});break}default:i(e.type,e);break}},wy=function(){if(this.ended)throw new ae("stream has ended, this shouldn't happen");const e=R(this,Ir,"f");if(!e)throw new ae("request ended without sending any events");le(this,Ir,void 0);const n=W5(e,R(this,au,"f"));return le(this,ou,n),n},vy=function(e){var i;let n=R(this,Ir,"f");if(!n){if(e.type!=="response.created")throw new ae(`When snapshot hasn't been set yet, expected 'response.created' event, got ${e.type}`);return n=le(this,Ir,e.response),n}switch(e.type){case"response.output_item.added":{n.output.push(e.item);break}case"response.content_part.added":{const s=n.output[e.output_index];if(!s)throw new ae(`missing output at index ${e.output_index}`);const o=s.type,c=e.part;o==="message"&&c.type!=="reasoning_text"?s.content.push(c):o==="reasoning"&&c.type==="reasoning_text"&&(s.content||(s.content=[]),s.content.push(c));break}case"response.output_text.delta":{const s=n.output[e.output_index];if(!s)throw new ae(`missing output at index ${e.output_index}`);if(s.type==="message"){const o=s.content[e.content_index];if(!o)throw new ae(`missing content at index ${e.content_index}`);if(o.type!=="output_text")throw new ae(`expected content to be 'output_text', got ${o.type}`);o.text+=e.delta}break}case"response.function_call_arguments.delta":{const s=n.output[e.output_index];if(!s)throw new ae(`missing output at index ${e.output_index}`);s.type==="function_call"&&(s.arguments+=e.delta);break}case"response.reasoning_text.delta":{const s=n.output[e.output_index];if(!s)throw new ae(`missing output at index ${e.output_index}`);if(s.type==="reasoning"){const o=(i=s.content)==null?void 0:i[e.content_index];if(!o)throw new ae(`missing content at index ${e.content_index}`);if(o.type!=="reasoning_text")throw new ae(`expected content to be 'reasoning_text', got ${o.type}`);o.text+=e.delta}break}case"response.completed":{le(this,Ir,e.response);break}}return n},Symbol.asyncIterator)](){const t=[],e=[];let n=!1;return this.on("event",i=>{const s=e.shift();s?s.resolve(i):t.push(i)}),this.on("end",()=>{n=!0;for(const i of e)i.resolve(void 0);e.length=0}),this.on("abort",i=>{n=!0;for(const s of e)s.reject(i);e.length=0}),this.on("error",i=>{n=!0;for(const s of e)s.reject(i);e.length=0}),{next:async()=>t.length?{value:t.shift(),done:!1}:n?{value:void 0,done:!0}:new Promise((s,o)=>e.push({resolve:s,reject:o})).then(s=>s?{value:s,done:!1}:{value:void 0,done:!0}),return:async()=>(this.abort(),{value:void 0,done:!0})}}async finalResponse(){await this.done();const t=R(this,ou,"f");if(!t)throw new ae("stream ended without producing a ChatCompletion");return t}}function W5(r,t){return L5(r,t)}class Rw extends se{list(t,e={},n){return this._client.getAPIList(q`/responses/${t}/input_items`,Xe,{query:e,...n})}}class Fw extends se{count(t={},e){return this._client.post("/responses/input_tokens",{body:t,...e})}}class Gh extends se{constructor(){super(...arguments),this.inputItems=new Rw(this._client),this.inputTokens=new Fw(this._client)}create(t,e){return this._client.post("/responses",{body:t,...e,stream:t.stream??!1})._thenUnwrap(n=>("object"in n&&n.object==="response"&&Hp(n),n))}retrieve(t,e={},n){return this._client.get(q`/responses/${t}`,{query:e,...n,stream:(e==null?void 0:e.stream)??!1})._thenUnwrap(i=>("object"in i&&i.object==="response"&&Hp(i),i))}delete(t,e){return this._client.delete(q`/responses/${t}`,{...e,headers:te([{Accept:"*/*"},e==null?void 0:e.headers])})}parse(t,e){return this._client.responses.create(t,e)._thenUnwrap(n=>$w(n,t))}stream(t,e){return Em.createResponse(this._client,t,e)}cancel(t,e){return this._client.post(q`/responses/${t}/cancel`,e)}compact(t,e){return this._client.post("/responses/compact",{body:t,...e})}}Gh.InputItems=Rw;Gh.InputTokens=Fw;class Dw extends se{create(t,e,n){return this._client.post(q`/uploads/${t}/parts`,Us({body:e,...n},this._client))}}class Im extends se{constructor(){super(...arguments),this.parts=new Dw(this._client)}create(t,e){return this._client.post("/uploads",{body:t,...e})}cancel(t,e){return this._client.post(q`/uploads/${t}/cancel`,e)}complete(t,e,n){return this._client.post(q`/uploads/${t}/complete`,{body:e,...n})}}Im.Parts=Dw;const q5=async r=>{const t=await Promise.allSettled(r),e=t.filter(i=>i.status==="rejected");if(e.length){for(const i of e)console.error(i.reason);throw new Error(`${e.length} promise(s) failed - see the above errors`)}const n=[];for(const i of t)i.status==="fulfilled"&&n.push(i.value);return n};class Ow extends se{create(t,e,n){return this._client.post(q`/vector_stores/${t}/file_batches`,{body:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}retrieve(t,e,n){const{vector_store_id:i}=e;return this._client.get(q`/vector_stores/${i}/file_batches/${t}`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}cancel(t,e,n){const{vector_store_id:i}=e;return this._client.post(q`/vector_stores/${i}/file_batches/${t}/cancel`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}async createAndPoll(t,e,n){const i=await this.create(t,e);return await this.poll(t,i.id,n)}listFiles(t,e,n){const{vector_store_id:i,...s}=e;return this._client.getAPIList(q`/vector_stores/${i}/file_batches/${t}/files`,Xe,{query:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}async poll(t,e,n){var s;const i=te([n==null?void 0:n.headers,{"X-Stainless-Poll-Helper":"true","X-Stainless-Custom-Poll-Interval":((s=n==null?void 0:n.pollIntervalMs)==null?void 0:s.toString())??void 0}]);for(;;){const{data:o,response:c}=await this.retrieve(e,{vector_store_id:t},{...n,headers:i}).withResponse();switch(o.status){case"in_progress":let l=5e3;if(n!=null&&n.pollIntervalMs)l=n.pollIntervalMs;else{const d=c.headers.get("openai-poll-after-ms");if(d){const u=parseInt(d);isNaN(u)||(l=u)}}await zd(l);break;case"failed":case"cancelled":case"completed":return o}}}async uploadAndPoll(t,{files:e,fileIds:n=[]},i){if(e==null||e.length==0)throw new Error("No `files` provided to process. If you've already uploaded files you should use `.createAndPoll()` instead");const s=(i==null?void 0:i.maxConcurrency)??5,o=Math.min(s,e.length),c=this._client,l=e.values(),d=[...n];async function u(p){for(let f of p){const y=await c.files.create({file:f,purpose:"assistants"},i);d.push(y.id)}}const h=Array(o).fill(l).map(u);return await q5(h),await this.createAndPoll(t,{file_ids:d})}}class Lw extends se{create(t,e,n){return this._client.post(q`/vector_stores/${t}/files`,{body:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}retrieve(t,e,n){const{vector_store_id:i}=e;return this._client.get(q`/vector_stores/${i}/files/${t}`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}update(t,e,n){const{vector_store_id:i,...s}=e;return this._client.post(q`/vector_stores/${i}/files/${t}`,{body:s,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}list(t,e={},n){return this._client.getAPIList(q`/vector_stores/${t}/files`,Xe,{query:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}delete(t,e,n){const{vector_store_id:i}=e;return this._client.delete(q`/vector_stores/${i}/files/${t}`,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}async createAndPoll(t,e,n){const i=await this.create(t,e,n);return await this.poll(t,i.id,n)}async poll(t,e,n){var s;const i=te([n==null?void 0:n.headers,{"X-Stainless-Poll-Helper":"true","X-Stainless-Custom-Poll-Interval":((s=n==null?void 0:n.pollIntervalMs)==null?void 0:s.toString())??void 0}]);for(;;){const o=await this.retrieve(e,{vector_store_id:t},{...n,headers:i}).withResponse(),c=o.data;switch(c.status){case"in_progress":let l=5e3;if(n!=null&&n.pollIntervalMs)l=n.pollIntervalMs;else{const d=o.response.headers.get("openai-poll-after-ms");if(d){const u=parseInt(d);isNaN(u)||(l=u)}}await zd(l);break;case"failed":case"completed":return c}}}async upload(t,e,n){const i=await this._client.files.create({file:e,purpose:"assistants"},n);return this.create(t,{file_id:i.id},n)}async uploadAndPoll(t,e,n){const i=await this.upload(t,e,n);return await this.poll(t,i.id,n)}content(t,e,n){const{vector_store_id:i}=e;return this._client.getAPIList(q`/vector_stores/${i}/files/${t}/content`,zh,{...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}}class Vh extends se{constructor(){super(...arguments),this.files=new Lw(this._client),this.fileBatches=new Ow(this._client)}create(t,e){return this._client.post("/vector_stores",{body:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}retrieve(t,e){return this._client.get(q`/vector_stores/${t}`,{...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}update(t,e,n){return this._client.post(q`/vector_stores/${t}`,{body:e,...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}list(t={},e){return this._client.getAPIList("/vector_stores",Xe,{query:t,...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}delete(t,e){return this._client.delete(q`/vector_stores/${t}`,{...e,headers:te([{"OpenAI-Beta":"assistants=v2"},e==null?void 0:e.headers])})}search(t,e,n){return this._client.getAPIList(q`/vector_stores/${t}/search`,zh,{body:e,method:"post",...n,headers:te([{"OpenAI-Beta":"assistants=v2"},n==null?void 0:n.headers])})}}Vh.Files=Lw;Vh.FileBatches=Ow;class jw extends se{create(t,e){return this._client.post("/videos",ay({body:t,...e},this._client))}retrieve(t,e){return this._client.get(q`/videos/${t}`,e)}list(t={},e){return this._client.getAPIList("/videos",rh,{query:t,...e})}delete(t,e){return this._client.delete(q`/videos/${t}`,e)}downloadContent(t,e={},n){return this._client.get(q`/videos/${t}/content`,{query:e,...n,headers:te([{Accept:"application/binary"},n==null?void 0:n.headers]),__binaryResponse:!0})}remix(t,e,n){return this._client.post(q`/videos/${t}/remix`,ay({body:e,...n},this._client))}}var ca,Bw,ju;class Uw extends se{constructor(){super(...arguments),ca.add(this)}async unwrap(t,e,n=this._client.webhookSecret,i=300){return await this.verifySignature(t,e,n,i),JSON.parse(t)}async verifySignature(t,e,n=this._client.webhookSecret,i=300){if(typeof crypto>"u"||typeof crypto.subtle.importKey!="function"||typeof crypto.subtle.verify!="function")throw new Error("Webhook signature verification is only supported when the `crypto` global is defined");R(this,ca,"m",Bw).call(this,n);const s=te([e]).values,o=R(this,ca,"m",ju).call(this,s,"webhook-signature"),c=R(this,ca,"m",ju).call(this,s,"webhook-timestamp"),l=R(this,ca,"m",ju).call(this,s,"webhook-id"),d=parseInt(c,10);if(isNaN(d))throw new lc("Invalid webhook timestamp format");const u=Math.floor(Date.now()/1e3);if(u-d>i)throw new lc("Webhook timestamp is too old");if(d>u+i)throw new lc("Webhook timestamp is too new");const h=o.split(" ").map(w=>w.startsWith("v1,")?w.substring(3):w),p=n.startsWith("whsec_")?Buffer.from(n.replace("whsec_",""),"base64"):Buffer.from(n,"utf-8"),f=l?`${l}.${c}.${t}`:`${c}.${t}`,y=await crypto.subtle.importKey("raw",p,{name:"HMAC",hash:"SHA-256"},!1,["verify"]);for(const w of h)try{const b=Buffer.from(w,"base64");if(await crypto.subtle.verify("HMAC",y,b,new TextEncoder().encode(f)))return}catch{continue}throw new lc("The given webhook signature does not match the expected signature")}}ca=new WeakSet,Bw=function(t){if(typeof t!="string"||t.length===0)throw new Error("The webhook secret must either be set using the env var, OPENAI_WEBHOOK_SECRET, on the client class, OpenAI({ webhookSecret: '123' }), or passed to this function")},ju=function(t,e){if(!t)throw new Error("Headers are required");const n=t.get(e);if(n==null)throw new Error(`Missing required header: ${e}`);return n};var Wp,Nm,Bu,zw;class fe{constructor({baseURL:t=Ys("OPENAI_BASE_URL"),apiKey:e=Ys("OPENAI_API_KEY"),organization:n=Ys("OPENAI_ORG_ID")??null,project:i=Ys("OPENAI_PROJECT_ID")??null,webhookSecret:s=Ys("OPENAI_WEBHOOK_SECRET")??null,...o}={}){if(Wp.add(this),Bu.set(this,void 0),this.completions=new yw(this),this.chat=new mm(this),this.embeddings=new ww(this),this.files=new xw(this),this.images=new Nw(this),this.audio=new Wd(this),this.moderations=new Aw(this),this.models=new Mw(this),this.fineTuning=new Vo(this),this.graders=new Cm(this),this.vectorStores=new Vh(this),this.webhooks=new Uw(this),this.beta=new Go(this),this.batches=new lw(this),this.uploads=new Im(this),this.responses=new Gh(this),this.realtime=new Kh(this),this.conversations=new bm(this),this.evals=new vm(this),this.containers=new _m(this),this.videos=new jw(this),e===void 0)throw new ae("Missing credentials. Please pass an `apiKey`, or set the `OPENAI_API_KEY` environment variable.");const c={apiKey:e,organization:n,project:i,webhookSecret:s,...o,baseURL:t||"https://api.openai.com/v1"};if(!c.dangerouslyAllowBrowser&&Gk())throw new ae(`It looks like you're running in a browser-like environment.

This is disabled by default, as it risks exposing your secret API credentials to attackers.
If you understand the risks and have appropriate mitigations in place,
you can set the \`dangerouslyAllowBrowser\` option to \`true\`, e.g.,

new OpenAI({ apiKey, dangerouslyAllowBrowser: true });

https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety
`);this.baseURL=c.baseURL,this.timeout=c.timeout??Nm.DEFAULT_TIMEOUT,this.logger=c.logger??console;const l="warn";this.logLevel=l,this.logLevel=iy(c.logLevel,"ClientOptions.logLevel",this)??iy(Ys("OPENAI_LOG"),"process.env['OPENAI_LOG']",this)??l,this.fetchOptions=c.fetchOptions,this.maxRetries=c.maxRetries??2,this.fetch=c.fetch??Yk(),le(this,Bu,e5),this._options=c,this.apiKey=typeof e=="string"?e:"Missing Key",this.organization=n,this.project=i,this.webhookSecret=s}withOptions(t){return new this.constructor({...this._options,baseURL:this.baseURL,maxRetries:this.maxRetries,timeout:this.timeout,logger:this.logger,logLevel:this.logLevel,fetch:this.fetch,fetchOptions:this.fetchOptions,apiKey:this.apiKey,organization:this.organization,project:this.project,webhookSecret:this.webhookSecret,...t})}defaultQuery(){return this._options.defaultQuery}validateHeaders({values:t,nulls:e}){}async authHeaders(t){return te([{Authorization:`Bearer ${this.apiKey}`}])}stringifyQuery(t){return a5(t,{arrayFormat:"brackets"})}getUserAgent(){return`${this.constructor.name}/JS ${aa}`}defaultIdempotencyKey(){return`stainless-node-retry-${ub()}`}makeStatusError(t,e,n,i){return gt.generate(t,e,n,i)}async _callApiKey(){const t=this._options.apiKey;if(typeof t!="function")return!1;let e;try{e=await t()}catch(n){throw n instanceof ae?n:new ae(`Failed to get token from 'apiKey' function: ${n.message}`,{cause:n})}if(typeof e!="string"||!e)throw new ae(`Expected 'apiKey' function argument to return a string but it returned ${e}`);return this.apiKey=e,!0}buildURL(t,e,n){const i=!R(this,Wp,"m",zw).call(this)&&n||this.baseURL,s=zk(t)?new URL(t):new URL(i+(i.endsWith("/")&&t.startsWith("/")?t.slice(1):t)),o=this.defaultQuery();return Hk(o)||(e={...o,...e}),typeof e=="object"&&e&&!Array.isArray(e)&&(s.search=this.stringifyQuery(e)),s.toString()}async prepareOptions(t){await this._callApiKey()}async prepareRequest(t,{url:e,options:n}){}get(t,e){return this.methodRequest("get",t,e)}post(t,e){return this.methodRequest("post",t,e)}patch(t,e){return this.methodRequest("patch",t,e)}put(t,e){return this.methodRequest("put",t,e)}delete(t,e){return this.methodRequest("delete",t,e)}methodRequest(t,e,n){return this.request(Promise.resolve(n).then(i=>({method:t,path:e,...i})))}request(t,e=null){return new Uh(this,this.makeRequest(t,e,void 0))}async makeRequest(t,e,n){var C,A;const i=await t,s=i.maxRetries??this.maxRetries;e==null&&(e=s),await this.prepareOptions(i);const{req:o,url:c,timeout:l}=await this.buildRequest(i,{retryCount:s-e});await this.prepareRequest(o,{url:c,options:i});const d="log_"+(Math.random()*(1<<24)|0).toString(16).padStart(6,"0"),u=n===void 0?"":`, retryOf: ${n}`,h=Date.now();if(dt(this).debug(`[${d}] sending request`,ki({retryOfRequestLogID:n,method:i.method,url:c,options:i,headers:o.headers})),(C=i.signal)!=null&&C.aborted)throw new nn;const p=new AbortController,f=await this.fetchWithTimeout(c,o,l,p).catch(Pp),y=Date.now();if(f instanceof globalThis.Error){const T=`retrying, ${e} attempts remaining`;if((A=i.signal)!=null&&A.aborted)throw new nn;const M=Tp(f)||/timed? ?out/i.test(String(f)+("cause"in f?String(f.cause):""));if(e)return dt(this).info(`[${d}] connection ${M?"timed out":"failed"} - ${T}`),dt(this).debug(`[${d}] connection ${M?"timed out":"failed"} (${T})`,ki({retryOfRequestLogID:n,url:c,durationMs:y-h,message:f.message})),this.retryRequest(i,e,n??d);throw dt(this).info(`[${d}] connection ${M?"timed out":"failed"} - error; no more retries left`),dt(this).debug(`[${d}] connection ${M?"timed out":"failed"} (error; no more retries left)`,ki({retryOfRequestLogID:n,url:c,durationMs:y-h,message:f.message})),M?new am:new jh({cause:f})}const w=[...f.headers.entries()].filter(([T])=>T==="x-request-id").map(([T,M])=>", "+T+": "+JSON.stringify(M)).join(""),b=`[${d}${u}${w}] ${o.method} ${c} ${f.ok?"succeeded":"failed"} with status ${f.status} in ${y-h}ms`;if(!f.ok){const T=await this.shouldRetry(f);if(e&&T){const F=`retrying, ${e} attempts remaining`;return await Zk(f.body),dt(this).info(`${b} - ${F}`),dt(this).debug(`[${d}] response error (${F})`,ki({retryOfRequestLogID:n,url:f.url,status:f.status,headers:f.headers,durationMs:y-h})),this.retryRequest(i,e,n??d,f.headers)}const M=T?"error; no more retries left":"error; not retryable";dt(this).info(`${b} - ${M}`);const D=await f.text().catch(F=>Pp(F).message),U=Kk(D),O=U?void 0:D;throw dt(this).debug(`[${d}] response error (${M})`,ki({retryOfRequestLogID:n,url:f.url,status:f.status,headers:f.headers,message:O,durationMs:Date.now()-h})),this.makeStatusError(f.status,U,O,f.headers)}return dt(this).info(b),dt(this).debug(`[${d}] response start`,ki({retryOfRequestLogID:n,url:f.url,status:f.status,headers:f.headers,durationMs:y-h})),{response:f,options:i,controller:p,requestLogID:d,retryOfRequestLogID:n,startTime:h}}getAPIList(t,e,n){return this.requestAPIList(e,{method:"get",path:t,...n})}requestAPIList(t,e){const n=this.makeRequest(e,null,void 0);return new m5(this,n,t)}async fetchWithTimeout(t,e,n,i){const{signal:s,method:o,...c}=e||{};s&&s.addEventListener("abort",()=>i.abort());const l=setTimeout(()=>i.abort(),n),d=globalThis.ReadableStream&&c.body instanceof globalThis.ReadableStream||typeof c.body=="object"&&c.body!==null&&Symbol.asyncIterator in c.body,u={signal:i.signal,...d?{duplex:"half"}:{},method:"GET",...c};o&&(u.method=o.toUpperCase());try{return await this.fetch.call(void 0,t,u)}finally{clearTimeout(l)}}async shouldRetry(t){const e=t.headers.get("x-should-retry");return e==="true"?!0:e==="false"?!1:t.status===408||t.status===409||t.status===429||t.status>=500}async retryRequest(t,e,n,i){let s;const o=i==null?void 0:i.get("retry-after-ms");if(o){const l=parseFloat(o);Number.isNaN(l)||(s=l)}const c=i==null?void 0:i.get("retry-after");if(c&&!s){const l=parseFloat(c);Number.isNaN(l)?s=Date.parse(c)-Date.now():s=l*1e3}if(!(s&&0<=s&&s<60*1e3)){const l=t.maxRetries??this.maxRetries;s=this.calculateDefaultRetryTimeoutMillis(e,l)}return await zd(s),this.makeRequest(t,e-1,n)}calculateDefaultRetryTimeoutMillis(t,e){const s=e-t,o=Math.min(.5*Math.pow(2,s),8),c=1-Math.random()*.25;return o*c*1e3}async buildRequest(t,{retryCount:e=0}={}){const n={...t},{method:i,path:s,query:o,defaultBaseURL:c}=n,l=this.buildURL(s,o,c);"timeout"in n&&qk("timeout",n.timeout),n.timeout=n.timeout??this.timeout;const{bodyHeaders:d,body:u}=this.buildBody({options:n}),h=await this.buildHeaders({options:t,method:i,bodyHeaders:d,retryCount:e});return{req:{method:i,headers:h,...n.signal&&{signal:n.signal},...globalThis.ReadableStream&&u instanceof globalThis.ReadableStream&&{duplex:"half"},...u&&{body:u},...this.fetchOptions??{},...n.fetchOptions??{}},url:l,timeout:n.timeout}}async buildHeaders({options:t,method:e,bodyHeaders:n,retryCount:i}){let s={};this.idempotencyHeader&&e!=="get"&&(t.idempotencyKey||(t.idempotencyKey=this.defaultIdempotencyKey()),s[this.idempotencyHeader]=t.idempotencyKey);const o=te([s,{Accept:"application/json","User-Agent":this.getUserAgent(),"X-Stainless-Retry-Count":String(i),...t.timeout?{"X-Stainless-Timeout":String(Math.trunc(t.timeout/1e3))}:{},...Qk(),"OpenAI-Organization":this.organization,"OpenAI-Project":this.project},await this.authHeaders(t),this._options.defaultHeaders,n,t.headers]);return this.validateHeaders(o),o.values}buildBody({options:{body:t,headers:e}}){if(!t)return{bodyHeaders:void 0,body:void 0};const n=te([e]);return ArrayBuffer.isView(t)||t instanceof ArrayBuffer||t instanceof DataView||typeof t=="string"&&n.values.has("content-type")||globalThis.Blob&&t instanceof globalThis.Blob||t instanceof FormData||t instanceof URLSearchParams||globalThis.ReadableStream&&t instanceof globalThis.ReadableStream?{bodyHeaders:void 0,body:t}:typeof t=="object"&&(Symbol.asyncIterator in t||Symbol.iterator in t&&"next"in t&&typeof t.next=="function")?{bodyHeaders:void 0,body:kb(t)}:R(this,Bu,"f").call(this,{body:t,headers:n})}}Nm=fe,Bu=new WeakMap,Wp=new WeakSet,zw=function(){return this.baseURL!=="https://api.openai.com/v1"};fe.OpenAI=Nm;fe.DEFAULT_TIMEOUT=6e5;fe.OpenAIError=ae;fe.APIError=gt;fe.APIConnectionError=jh;fe.APIConnectionTimeoutError=am;fe.APIUserAbortError=nn;fe.NotFoundError=mb;fe.ConflictError=gb;fe.RateLimitError=_b;fe.BadRequestError=hb;fe.AuthenticationError=fb;fe.InternalServerError=bb;fe.PermissionDeniedError=pb;fe.UnprocessableEntityError=yb;fe.InvalidWebhookSignatureError=lc;fe.toFile=w5;fe.Completions=yw;fe.Chat=mm;fe.Embeddings=ww;fe.Files=xw;fe.Images=Nw;fe.Audio=Wd;fe.Moderations=Aw;fe.Models=Mw;fe.FineTuning=Vo;fe.Graders=Cm;fe.VectorStores=Vh;fe.Webhooks=Uw;fe.Beta=Go;fe.Batches=lw;fe.Uploads=Im;fe.Responses=Gh;fe.Realtime=Kh;fe.Conversations=bm;fe.Evals=vm;fe.Containers=_m;fe.Videos=jw;var xy={};async function Sy(r,t){console.log("[AI] Evaluating KRDS items with AI...");const e=xy.OPENAI_API_KEY;if(!e)throw new Error("OPENAI_API_KEY not configured. Please set up LLM API key in GenSpark.");const n=new fe({apiKey:e,baseURL:xy.OPENAI_BASE_URL||"https://www.genspark.ai/api/llm_proxy/v1"});try{const i=K5(r),s=`당신은 한국 디지털정부서비스 UI/UX 전문가입니다.

다음 웹사이트의 HTML을 분석하고, KRDS 가이드라인 43개 항목을 평가하세요.

**웹사이트 URL**: ${t}

**HTML 구조** (간략화됨):
\`\`\`html
${i.substring(0,8e3)}
\`\`\`

**평가 항목 (43개)**:

**1. 아이덴티티 (5개)**
1-1-1. 공식 배너 제공 (정부24 또는 기관 CI)
1-2-1. 로고 제공
1-2-2. 홈 버튼 제공
1-3-1. 기관명 명시
1-3-2. 슬로건 제공

**2. 탐색 (5개)**
2-1-1. GNB 메뉴 제공
2-1-2. LNB 메뉴 제공 (서브페이지)
2-2-1. Breadcrumb 제공 (서브페이지)
2-3-1. 사이트맵 제공
2-4-1. 푸터 링크 제공

**3. 방문 (1개)**
3-1-1. 최근 업데이트 정보 제공

**4. 검색 (12개)**
4-1-1. 검색 영역 명확성
4-1-2. 검색창 위치 (상단 오른쪽)
4-1-3. 검색 버튼 제공
4-2-1. 검색어 입력란 레이블
4-2-2. 자동완성 기능
4-2-3. 최근 검색어
4-3-1. 검색 결과 정렬 옵션
4-3-2. 검색 결과 필터
4-3-3. 검색 결과 개수 표시
4-4-1. 검색 결과 없음 안내
4-4-2. 추천 검색어
4-5-1. 통합 검색 제공

**5. 로그인 (7개)**
5-1-1. 로그인 버튼 명확성
5-1-2. 로그인 버튼 위치 (상단 오른쪽)
5-2-1. 아이디 입력란 레이블
5-2-2. 비밀번호 입력란 레이블
5-3-1. 로그인 유지 옵션
5-4-1. 아이디/비밀번호 찾기
5-5-1. 회원가입 링크

**6. 신청 (13개)**
6-1-1. 신청 버튼 명확성
6-1-2. 신청 절차 안내
6-1-3. 필수/선택 항목 구분
6-2-1. 입력란 레이블 명확성
6-2-2. 입력 형식 안내
6-2-3. 입력 오류 메시지
6-2-4. 실시간 입력 검증
6-3-1. 파일 첨부 안내
6-3-2. 약관 동의 체크박스
6-3-3. 개인정보 수집 동의
6-3-4. 제출 버튼 명확성
6-4-1. 제출 완료 안내
6-4-2. 진행 상황 확인

**평가 기준**:
- **5점**: 완벽하게 준수
- **4점**: 대체로 준수 (일부 미흡)
- **3점**: 보통 (개선 필요)
- **2점**: 미흡 (심각한 문제)
- **1점**: 매우 미흡
- **0점**: 해당 없음 (예: 로그인 기능 없음)

**응답 형식 (JSON)**:
\`\`\`json
{
  "identity_1_1_1": 5,
  "identity_1_2_1": 5,
  ...
  "application_6_4_2": 0,
  "reasoning": "간단한 평가 근거 (각 카테고리별)"
}
\`\`\`

**중요**: 
- HTML 구조를 신중히 분석하세요
- 존재하지 않는 기능은 0점 처리
- 로그인/신청 기능이 없으면 해당 항목은 모두 0점`,c=(await n.chat.completions.create({model:"gpt-5",messages:[{role:"system",content:"당신은 한국 디지털정부서비스 UI/UX 전문가입니다. KRDS 가이드라인을 완벽히 이해하고 있으며, HTML 구조를 분석해 정확한 평가를 제공합니다."},{role:"user",content:s}],temperature:.3,max_tokens:2e3})).choices[0].message.content||"{}",l=c.match(/```json\n([\s\S]*?)\n```/),d=l?l[1]:c,u=JSON.parse(d);return console.log("[AI] AI evaluation completed"),console.log("[AI] Sample scores:",Object.entries(u).slice(0,5)),u}catch(i){throw console.error("[AI] Error during AI evaluation:",i),new Error(`AI evaluation failed: ${i instanceof Error?i.message:String(i)}`)}}function K5(r){let t=r.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,"");return t=t.replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi,""),t=t.replace(/<!--[\s\S]*?-->/g,""),t=t.replace(/\s+/g," "),t=t.replace(/(\w+)="[^"]{200,}"/g,'$1="..."'),t.trim()}const G5="1.0.0",V5="2024-01-30",X5={total_agencies:49,average_score:3.79,highest_score:4.29,lowest_score:2.7,comment:"국민신문고 공공서비스 49개 기관 데이터 기준"},J5={N1_1_current_location:{base_score:3.5,has_feature_bonus:1.5,no_feature_penalty:-1,description:"Breadcrumb 존재 시 가산점"},N1_2_loading_status:{base_score:3.5,threshold:3,has_feature_bonus:1,no_feature_penalty:-.5,description:"ARIA 레이블 3개 이상 시 가산점"},N1_3_action_feedback:{base_score:3.5,validation_bonus:1,link_threshold:20,link_bonus:.5,no_feature_penalty:-.5,description:"폼 검증 또는 링크 20개 이상 시 가산점"},N2_1_familiar_terms:{base_score:3.5,has_feature_bonus:1,no_feature_penalty:-.5,description:"lang 속성 존재 시 가산점"},N2_2_natural_flow:{base_score:3.5,heading_threshold:3,has_feature_bonus:1,no_feature_penalty:-.5,description:"헤딩 3개 이상 시 가산점"},N2_3_real_world_metaphor:{base_score:3.5,icon_threshold:5,has_feature_bonus:.5,no_feature_penalty:-.5,description:"아이콘 5개 초과 시 가산점"},N3_1_undo_redo:{base_score:3,has_form_bonus:.5,no_form_penalty:-.5,description:"폼 존재 시 가산점"},N3_3_flexible_navigation:{base_score:3.5,link_threshold:15,has_feature_bonus:1,no_feature_penalty:-1,description:"링크 15개 이상 시 가산점"},N4_1_visual_consistency:{base_score:3.5,image_min:3,image_max:30,optimal_bonus:1,suboptimal_penalty:-.5,description:"이미지 3~30개 범위가 최적"},N4_2_terminology_consistency:{base_score:3.5,heading_threshold:3,has_feature_bonus:.5,no_feature_penalty:-.5,description:"헤딩 3개 이상 시 가산점"},N4_3_standard_compliance:{base_score:3.5,lang_bonus:1,alt_threshold:.7,alt_bonus:.5,no_feature_penalty:-1,description:"lang 속성 또는 alt 비율 70% 이상 시 가산점"},N5_1_input_validation:{base_score:3.5,has_validation_bonus:1.5,no_form_neutral:0,no_validation_penalty:-1.5,description:"입력 검증 존재 시 가산점, 폼 없으면 중립"},N5_2_confirmation_dialog:{base_score:3,has_form_bonus:.5,no_form_neutral:0,description:"폼 존재 시 가산점"},N5_3_constraints:{base_score:3.5,label_high_threshold:.8,label_mid_threshold:.5,high_bonus:1.5,mid_bonus:.5,no_form_neutral:0,low_penalty:-1,description:"레이블 비율 80% 이상 높은 가산점, 50% 이상 중간 가산점"},N6_2_recognition_cues:{base_score:3.5,icon_high_threshold:5,icon_low_threshold:0,high_bonus:1,low_bonus:.5,no_feature_penalty:-.5,description:"아이콘 5개 초과 시 높은 가산점, 1개 이상 시 낮은 가산점"},N6_3_memory_load:{base_score:3.5,breadcrumb_bonus:1,depth_threshold:2,shallow_bonus:.5,deep_penalty:-1,description:"Breadcrumb 또는 depth 2 이하 시 가산점"},N7_1_quick_access:{base_score:3.5,menu_threshold:5,has_feature_bonus:1,no_feature_penalty:-.5,description:"메뉴 5개 이상 시 가산점"},N7_2_customization:{base_score:3,responsive_bonus:1,no_feature_neutral:0,description:"반응형 디자인 존재 시 가산점"},N7_3_search_filter:{base_score:3,has_search_bonus:1.5,no_search_penalty:-1,description:"검색 기능 존재 시 가산점"},N8_1_essential_info:{base_score:3.5,paragraph_min:3,paragraph_max:20,optimal_bonus:1,suboptimal_penalty:-.5,description:"문단 3~20개 범위가 최적"},N8_2_clean_interface:{base_score:3.5,image_max:20,good_bonus:1,moderate_bonus:.5,excessive_penalty:-.5,description:"이미지 20개 이하가 최적"},N8_3_visual_hierarchy:{base_score:3.5,heading_min:3,heading_optimal:8,optimal_bonus:1.5,good_bonus:1,low_penalty:-1,description:"헤딩 3~8개 범위가 최적"},N9_2_recovery_support:{base_score:3,has_form_bonus:.5,no_form_neutral:0,description:"폼 존재 시 가산점"},N9_4_error_guidance:{base_score:3.5,has_validation_bonus:1,no_feature_penalty:-.5,description:"입력 검증 존재 시 가산점"},N10_1_help_visibility:{base_score:3,link_threshold:10,has_feature_bonus:1,no_feature_penalty:-.5,description:"링크 10개 이상 시 가산점"},N10_2_documentation:{base_score:3,link_threshold:15,has_feature_bonus:1,no_feature_penalty:-.5,description:"링크 15개 이상 시 가산점"}},Xh={version:G5,last_updated:V5,reference_statistics:X5,weights:J5};function Hw(){return Xh.weights}function Q5(){return Xh.reference_statistics}function Y5(){return Xh.version}function Z5(){return Xh.last_updated}function e3(r){const t=[],e=Hw();for(const n of r){if(n.correction_count<5)continue;const i=e[n.item_id];if(!i)continue;const s=n.avg_score_diff,o=.3,c=.5;let l="neutral",d="low",u={...i},h="";if(!(Math.abs(s)<o)){if(s<-o){if(l="decrease",d=Math.abs(s)>=c?"high":"medium",i.has_feature_bonus!==void 0){const p=Math.abs(s)*.5;u.has_feature_bonus=Math.max(.5,i.has_feature_bonus-p)}if(i.no_feature_penalty!==void 0){const p=Math.abs(s)*.3;u.no_feature_penalty=Math.min(-.5,i.no_feature_penalty-p)}h=`관리자가 평균 ${Math.abs(s).toFixed(2)}점 하향 조정함. ${n.correction_count}건의 수정 데이터 분석 결과, 현재 자동 평가가 과대평가되고 있습니다.`}else if(s>o){if(l="increase",d=s>=c?"high":"medium",i.has_feature_bonus!==void 0){const p=s*.5;u.has_feature_bonus=Math.min(2,i.has_feature_bonus+p)}if(i.no_feature_penalty!==void 0){const p=s*.3;u.no_feature_penalty=Math.max(-2,i.no_feature_penalty+p)}h=`관리자가 평균 ${s.toFixed(2)}점 상향 조정함. ${n.correction_count}건의 수정 데이터 분석 결과, 현재 자동 평가가 과소평가되고 있습니다.`}n.correction_count>=20&&(d="high"),t.push({item_id:n.item_id,item_name:n.item_name,current_weights:i,suggested_weights:u,reason:h,evidence:{correction_count:n.correction_count,avg_score_diff:n.avg_score_diff,avg_original_score:n.avg_original_score,avg_corrected_score:n.avg_corrected_score},adjustment_type:l,confidence:d})}}return t.sort((n,i)=>{const s={high:3,medium:2,low:1},o=s[i.confidence]-s[n.confidence];return o!==0?o:i.evidence.correction_count-n.evidence.correction_count})}async function Mm(r){const e=new TextEncoder().encode(r),n=await crypto.subtle.digest("SHA-256",e);return Array.from(new Uint8Array(n)).map(s=>s.toString(16).padStart(2,"0")).join("")}async function t3(r,t){return await Mm(r)===t}function n3(){const r=new Uint8Array(32);return crypto.getRandomValues(r),Array.from(r,t=>t.toString(16).padStart(2,"0")).join("")}async function Xo(r,t){let e=r.req.header("X-Session-ID")||r.req.query("session_id");if(!e){const s=r.req.header("Cookie");if(s){const o=s.match(/session_id=([^;]+)/);o&&(e=o[1])}}if(!e)return r.json({success:!1,error:"인증이 필요합니다."},401);const{DB:n}=r.env,i=await n.prepare('SELECT s.*, u.id as user_id, u.email, u.name, u.role FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.id = ? AND s.expires_at > datetime("now")').bind(e).first();if(!i)return r.json({success:!1,error:"유효하지 않은 세션입니다."},401);r.set("user",{id:i.user_id,email:i.email,name:i.name,role:i.role}),await t()}async function xn(r,t){let e=r.req.header("X-Session-ID")||r.req.query("session_id");if(!e){const o=r.req.header("Cookie");if(o){const c=o.match(/session_id=([^;]+)/);c&&(e=c[1])}}if(!e)return r.json({success:!1,error:"인증이 필요합니다."},401);const{DB:n}=r.env,i=await n.prepare('SELECT s.*, u.id as user_id, u.email, u.name, u.role FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.id = ? AND s.expires_at > datetime("now")').bind(e).first();if(!i)return r.json({success:!1,error:"유효하지 않은 세션입니다."},401);const s={id:i.user_id,email:i.email,name:i.name,role:i.role};if(r.set("user",s),s.role!=="admin")return r.json({success:!1,error:"관리자 권한이 필요합니다."},403);await t()}function r3(r){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(r)}function Ww(r){return!(r.length<8||!/[A-Z]/.test(r)||!/[a-z]/.test(r)||!/[0-9]/.test(r))}const i3={total_agencies:49,average_score:3.79,highest_score:4.29,lowest_score:2.7,with_krds:10,with_heuristic:37,with_all_three:10},s3=JSON.parse('[{"site_name":"국무조정실","url":"","final_nielsen_score":4.29,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.29,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.17,"N2_match":4.39,"N3_control":4.64,"N4_consistency":4.3,"N5_error_prevention":4.14,"N6_recognition":4.33,"N7_flexibility":4.11,"N8_minimalism":4.36,"N9_error_recovery":4.14,"N10_help":4.33},"has_krds":false,"has_heuristic":false},{"site_name":"해양수산부","url":"","final_nielsen_score":4.27,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.35,"krds_score":4.88,"heuristic_nielsen":3.55},"nielsen_10_principles":{"N1_visibility":4.47,"N2_match":4.25,"N3_control":4.39,"N4_consistency":4.07,"N5_error_prevention":3.78,"N6_recognition":4.08,"N7_flexibility":4.05,"N8_minimalism":4.28,"N9_error_recovery":3.78,"N10_help":4.08},"has_krds":true,"has_heuristic":true},{"site_name":"국민권익위원회","url":"","final_nielsen_score":4.25,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.25,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.46,"N2_match":4.1,"N3_control":4.11,"N4_consistency":4.1,"N5_error_prevention":4.39,"N6_recognition":4.36,"N7_flexibility":4.28,"N8_minimalism":4,"N9_error_recovery":4.39,"N10_help":4.36},"has_krds":false,"has_heuristic":false},{"site_name":"국토교통부","url":"","final_nielsen_score":4.2,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.2,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.36,"N2_match":4.2,"N3_control":4.36,"N4_consistency":4.17,"N5_error_prevention":4.25,"N6_recognition":4.11,"N7_flexibility":4.22,"N8_minimalism":3.97,"N9_error_recovery":4.25,"N10_help":4.11},"has_krds":false,"has_heuristic":false},{"site_name":"식품의약품안전처","url":"","final_nielsen_score":4.18,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.18,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.4,"N2_match":4.32,"N3_control":4.16,"N4_consistency":4.1,"N5_error_prevention":4,"N6_recognition":4.22,"N7_flexibility":3.94,"N8_minimalism":4.39,"N9_error_recovery":4,"N10_help":4.22},"has_krds":false,"has_heuristic":false},{"site_name":"국가보훈부","url":"","final_nielsen_score":4.16,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.16,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.23,"N2_match":4.17,"N3_control":4.33,"N4_consistency":3.98,"N5_error_prevention":4.25,"N6_recognition":4.14,"N7_flexibility":4.11,"N8_minimalism":4.03,"N9_error_recovery":4.25,"N10_help":4.14},"has_krds":false,"has_heuristic":false},{"site_name":"보건복지부","url":"","final_nielsen_score":4.15,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.15,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.15,"N2_match":4.21,"N3_control":4.39,"N4_consistency":3.97,"N5_error_prevention":4.03,"N6_recognition":4.39,"N7_flexibility":3.86,"N8_minimalism":4.05,"N9_error_recovery":4.03,"N10_help":4.39},"has_krds":false,"has_heuristic":false},{"site_name":"여성가족부(성평등가족부)","url":"","final_nielsen_score":4.14,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.35,"krds_score":4.6,"heuristic_nielsen":3.41},"nielsen_10_principles":{"N1_visibility":4.32,"N2_match":4.34,"N3_control":4.34,"N4_consistency":4.11,"N5_error_prevention":4.11,"N6_recognition":4.31,"N7_flexibility":4.28,"N8_minimalism":4.25,"N9_error_recovery":4.11,"N10_help":4.31},"has_krds":true,"has_heuristic":true},{"site_name":"기획재정부(재정경제부)","url":"","final_nielsen_score":4.13,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.13,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.29,"N2_match":4.21,"N3_control":3.86,"N4_consistency":4.25,"N5_error_prevention":4.03,"N6_recognition":4.22,"N7_flexibility":3.89,"N8_minimalism":4.3,"N9_error_recovery":4.03,"N10_help":4.22},"has_krds":false,"has_heuristic":false},{"site_name":"통계청(국가데이터처)","url":"","final_nielsen_score":4.13,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.13,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.37,"N2_match":4,"N3_control":4.58,"N4_consistency":4.09,"N5_error_prevention":4.03,"N6_recognition":4.03,"N7_flexibility":3.97,"N8_minimalism":4.22,"N9_error_recovery":4.03,"N10_help":4.03},"has_krds":false,"has_heuristic":false},{"site_name":"공정거래위원회","url":"","final_nielsen_score":4.09,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.28,"krds_score":4.4,"heuristic_nielsen":3.54},"nielsen_10_principles":{"N1_visibility":4.54,"N2_match":4.21,"N3_control":4.08,"N4_consistency":4.16,"N5_error_prevention":4.22,"N6_recognition":4.22,"N7_flexibility":4.22,"N8_minimalism":4.2,"N9_error_recovery":4.22,"N10_help":4.22},"has_krds":true,"has_heuristic":true},{"site_name":"대검찰청","url":"","final_nielsen_score":4.08,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.47,"krds_score":4.51,"heuristic_nielsen":3.13},"nielsen_10_principles":{"N1_visibility":4.58,"N2_match":4.39,"N3_control":4.36,"N4_consistency":4.4,"N5_error_prevention":4.55,"N6_recognition":4.53,"N7_flexibility":4.44,"N8_minimalism":4.33,"N9_error_recovery":4.55,"N10_help":4.53},"has_krds":true,"has_heuristic":true},{"site_name":"법무부","url":"","final_nielsen_score":4.06,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.41,"krds_score":4.51,"heuristic_nielsen":3.13},"nielsen_10_principles":{"N1_visibility":4.5,"N2_match":4.39,"N3_control":4.47,"N4_consistency":4.35,"N5_error_prevention":4.36,"N6_recognition":4.33,"N7_flexibility":4.33,"N8_minimalism":4.28,"N9_error_recovery":4.36,"N10_help":4.33},"has_krds":true,"has_heuristic":true},{"site_name":"농림축산식품부","url":"","final_nielsen_score":4.02,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.11,"krds_score":4.38,"heuristic_nielsen":3.55},"nielsen_10_principles":{"N1_visibility":4.1,"N2_match":3.86,"N3_control":4.36,"N4_consistency":3.7,"N5_error_prevention":3.95,"N6_recognition":4.06,"N7_flexibility":3.92,"N8_minimalism":3.94,"N9_error_recovery":3.95,"N10_help":4.06},"has_krds":true,"has_heuristic":true},{"site_name":"질병관리청","url":"","final_nielsen_score":4.01,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":4.01,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.11,"N2_match":4.05,"N3_control":4,"N4_consistency":3.86,"N5_error_prevention":4.05,"N6_recognition":4.03,"N7_flexibility":3.86,"N8_minimalism":4.03,"N9_error_recovery":4.05,"N10_help":4.03},"has_krds":false,"has_heuristic":false},{"site_name":"과학기술정보통신부","url":"","final_nielsen_score":3.99,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":3.99,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":3.94,"N2_match":4.1,"N3_control":4.22,"N4_consistency":3.92,"N5_error_prevention":4.03,"N6_recognition":3.97,"N7_flexibility":3.72,"N8_minimalism":4.03,"N9_error_recovery":4.03,"N10_help":3.97},"has_krds":false,"has_heuristic":false},{"site_name":"우주항공청","url":"","final_nielsen_score":3.98,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.38,"krds_score":null,"heuristic_nielsen":3.58},"nielsen_10_principles":{"N1_visibility":4.42,"N2_match":4.4,"N3_control":4.45,"N4_consistency":4.28,"N5_error_prevention":4.39,"N6_recognition":4.39,"N7_flexibility":4.36,"N8_minimalism":4.33,"N9_error_recovery":4.39,"N10_help":4.39},"has_krds":false,"has_heuristic":true},{"site_name":"고용노동부","url":"","final_nielsen_score":3.97,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.48,"krds_score":null,"heuristic_nielsen":3.46},"nielsen_10_principles":{"N1_visibility":4.47,"N2_match":4.52,"N3_control":4.58,"N4_consistency":4.38,"N5_error_prevention":4.45,"N6_recognition":4.55,"N7_flexibility":4.42,"N8_minimalism":4.39,"N9_error_recovery":4.45,"N10_help":4.55},"has_krds":false,"has_heuristic":true},{"site_name":"문화체육관광부","url":"","final_nielsen_score":3.97,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.23,"krds_score":null,"heuristic_nielsen":3.7},"nielsen_10_principles":{"N1_visibility":4.3,"N2_match":4.31,"N3_control":4.2,"N4_consistency":4.43,"N5_error_prevention":4.33,"N6_recognition":4.11,"N7_flexibility":4.14,"N8_minimalism":4.03,"N9_error_recovery":4.33,"N10_help":4.11},"has_krds":false,"has_heuristic":true},{"site_name":"금융위원회","url":"","final_nielsen_score":3.97,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":3.97,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":3.78,"N2_match":3.64,"N3_control":3.92,"N4_consistency":3.95,"N5_error_prevention":4.14,"N6_recognition":4.05,"N7_flexibility":4.22,"N8_minimalism":3.86,"N9_error_recovery":4.14,"N10_help":4.05},"has_krds":false,"has_heuristic":false},{"site_name":"산업통상자원부(산업통상부)","url":"","final_nielsen_score":3.94,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.23,"krds_score":null,"heuristic_nielsen":3.65},"nielsen_10_principles":{"N1_visibility":4.24,"N2_match":4.28,"N3_control":4.17,"N4_consistency":4.17,"N5_error_prevention":4.25,"N6_recognition":4.3,"N7_flexibility":4.11,"N8_minimalism":4.25,"N9_error_recovery":4.25,"N10_help":4.3},"has_krds":false,"has_heuristic":true},{"site_name":"국방부","url":"","final_nielsen_score":3.9,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.44,"krds_score":null,"heuristic_nielsen":3.35},"nielsen_10_principles":{"N1_visibility":4.51,"N2_match":4.57,"N3_control":4.45,"N4_consistency":4.36,"N5_error_prevention":4.47,"N6_recognition":4.44,"N7_flexibility":4.28,"N8_minimalism":4.39,"N9_error_recovery":4.47,"N10_help":4.44},"has_krds":false,"has_heuristic":true},{"site_name":"개인정보보호위원회","url":"","final_nielsen_score":3.87,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.39,"krds_score":null,"heuristic_nielsen":3.35},"nielsen_10_principles":{"N1_visibility":4.33,"N2_match":4.38,"N3_control":4.47,"N4_consistency":4.39,"N5_error_prevention":4.45,"N6_recognition":4.42,"N7_flexibility":4.25,"N8_minimalism":4.33,"N9_error_recovery":4.45,"N10_help":4.42},"has_krds":false,"has_heuristic":true},{"site_name":"외교부","url":"","final_nielsen_score":3.84,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.1,"krds_score":null,"heuristic_nielsen":3.58},"nielsen_10_principles":{"N1_visibility":4.18,"N2_match":4.05,"N3_control":4.34,"N4_consistency":4.04,"N5_error_prevention":4.05,"N6_recognition":4.08,"N7_flexibility":3.95,"N8_minimalism":4.22,"N9_error_recovery":4.05,"N10_help":4.08},"has_krds":false,"has_heuristic":true},{"site_name":"방위사업청","url":"","final_nielsen_score":3.82,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.35,"krds_score":null,"heuristic_nielsen":3.29},"nielsen_10_principles":{"N1_visibility":4.51,"N2_match":4.26,"N3_control":4.61,"N4_consistency":4.1,"N5_error_prevention":4.28,"N6_recognition":4.53,"N7_flexibility":4.28,"N8_minimalism":4.11,"N9_error_recovery":4.28,"N10_help":4.53},"has_krds":false,"has_heuristic":true},{"site_name":"국가유산청","url":"","final_nielsen_score":3.79,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.31,"krds_score":null,"heuristic_nielsen":3.28},"nielsen_10_principles":{"N1_visibility":4.47,"N2_match":4.39,"N3_control":4.47,"N4_consistency":4.11,"N5_error_prevention":4.28,"N6_recognition":4.45,"N7_flexibility":4.11,"N8_minimalism":4.11,"N9_error_recovery":4.28,"N10_help":4.45},"has_krds":false,"has_heuristic":true},{"site_name":"중소벤처기업부","url":"","final_nielsen_score":3.79,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.14,"krds_score":null,"heuristic_nielsen":3.43},"nielsen_10_principles":{"N1_visibility":4.17,"N2_match":3.99,"N3_control":4.25,"N4_consistency":4.15,"N5_error_prevention":4.19,"N6_recognition":4.11,"N7_flexibility":4.2,"N8_minimalism":4.06,"N9_error_recovery":4.19,"N10_help":4.11},"has_krds":false,"has_heuristic":true},{"site_name":"방송통신위원회(방송미디어통신위원회)","url":"","final_nielsen_score":3.78,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.33,"krds_score":null,"heuristic_nielsen":3.22},"nielsen_10_principles":{"N1_visibility":4.47,"N2_match":4.41,"N3_control":4.53,"N4_consistency":4.22,"N5_error_prevention":4.25,"N6_recognition":4.33,"N7_flexibility":4.3,"N8_minimalism":4.22,"N9_error_recovery":4.25,"N10_help":4.33},"has_krds":false,"has_heuristic":true},{"site_name":"행정안전부","url":"","final_nielsen_score":3.78,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.09,"krds_score":null,"heuristic_nielsen":3.47},"nielsen_10_principles":{"N1_visibility":4.36,"N2_match":4.11,"N3_control":4.39,"N4_consistency":3.97,"N5_error_prevention":3.97,"N6_recognition":4,"N7_flexibility":4.05,"N8_minimalism":4.11,"N9_error_recovery":3.97,"N10_help":4},"has_krds":false,"has_heuristic":true},{"site_name":"조달청","url":"","final_nielsen_score":3.77,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.3,"krds_score":null,"heuristic_nielsen":3.24},"nielsen_10_principles":{"N1_visibility":4.37,"N2_match":4.28,"N3_control":4.31,"N4_consistency":4.07,"N5_error_prevention":4.5,"N6_recognition":4.42,"N7_flexibility":4.3,"N8_minimalism":3.86,"N9_error_recovery":4.5,"N10_help":4.42},"has_krds":false,"has_heuristic":true},{"site_name":"재외동포청","url":"","final_nielsen_score":3.76,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.17,"krds_score":null,"heuristic_nielsen":3.36},"nielsen_10_principles":{"N1_visibility":4.32,"N2_match":4.14,"N3_control":4.47,"N4_consistency":4,"N5_error_prevention":4.14,"N6_recognition":4.17,"N7_flexibility":3.92,"N8_minimalism":4.22,"N9_error_recovery":4.14,"N10_help":4.17},"has_krds":false,"has_heuristic":true},{"site_name":"원자력안전위원회","url":"","final_nielsen_score":3.75,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.28,"krds_score":null,"heuristic_nielsen":3.23},"nielsen_10_principles":{"N1_visibility":4.47,"N2_match":4.38,"N3_control":4.25,"N4_consistency":4.25,"N5_error_prevention":4.08,"N6_recognition":4.47,"N7_flexibility":4.19,"N8_minimalism":4.17,"N9_error_recovery":4.08,"N10_help":4.47},"has_krds":false,"has_heuristic":true},{"site_name":"교육부","url":"","final_nielsen_score":3.75,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.27,"krds_score":null,"heuristic_nielsen":3.22},"nielsen_10_principles":{"N1_visibility":4.48,"N2_match":4.24,"N3_control":4.22,"N4_consistency":4.1,"N5_error_prevention":4.33,"N6_recognition":4.36,"N7_flexibility":4.11,"N8_minimalism":4.17,"N9_error_recovery":4.33,"N10_help":4.36},"has_krds":false,"has_heuristic":true},{"site_name":"농촌진흥청","url":"","final_nielsen_score":3.73,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.09,"krds_score":null,"heuristic_nielsen":3.37},"nielsen_10_principles":{"N1_visibility":4.29,"N2_match":4.23,"N3_control":4.11,"N4_consistency":4.07,"N5_error_prevention":3.86,"N6_recognition":4.14,"N7_flexibility":3.89,"N8_minimalism":4.28,"N9_error_recovery":3.86,"N10_help":4.14},"has_krds":false,"has_heuristic":true},{"site_name":"환경부(기후에너지환경부)","url":"","final_nielsen_score":3.69,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.21,"krds_score":null,"heuristic_nielsen":3.17},"nielsen_10_principles":{"N1_visibility":4.39,"N2_match":4.28,"N3_control":4.39,"N4_consistency":4.12,"N5_error_prevention":4.11,"N6_recognition":4.25,"N7_flexibility":4.03,"N8_minimalism":4.19,"N9_error_recovery":4.11,"N10_help":4.25},"has_krds":false,"has_heuristic":true},{"site_name":"국세청","url":"","final_nielsen_score":3.68,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.19,"krds_score":null,"heuristic_nielsen":3.17},"nielsen_10_principles":{"N1_visibility":4.18,"N2_match":4.29,"N3_control":4.28,"N4_consistency":4.1,"N5_error_prevention":4.25,"N6_recognition":4.08,"N7_flexibility":4.28,"N8_minimalism":4.06,"N9_error_recovery":4.25,"N10_help":4.08},"has_krds":false,"has_heuristic":true},{"site_name":"기상청","url":"","final_nielsen_score":3.62,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.09,"krds_score":null,"heuristic_nielsen":3.15},"nielsen_10_principles":{"N1_visibility":4.47,"N2_match":4.18,"N3_control":3.95,"N4_consistency":3.98,"N5_error_prevention":4,"N6_recognition":4.19,"N7_flexibility":3.86,"N8_minimalism":4.05,"N9_error_recovery":4,"N10_help":4.19},"has_krds":false,"has_heuristic":true},{"site_name":"관세청","url":"","final_nielsen_score":3.6,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.06,"krds_score":null,"heuristic_nielsen":3.15},"nielsen_10_principles":{"N1_visibility":4.43,"N2_match":4.09,"N3_control":4.28,"N4_consistency":3.9,"N5_error_prevention":4.14,"N6_recognition":3.8,"N7_flexibility":4.03,"N8_minimalism":3.97,"N9_error_recovery":4.14,"N10_help":3.8},"has_krds":false,"has_heuristic":true},{"site_name":"새만금개발청","url":"","final_nielsen_score":3.59,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.03,"krds_score":null,"heuristic_nielsen":3.15},"nielsen_10_principles":{"N1_visibility":4.29,"N2_match":4.12,"N3_control":3.97,"N4_consistency":3.88,"N5_error_prevention":3.97,"N6_recognition":4.06,"N7_flexibility":3.86,"N8_minimalism":4.08,"N9_error_recovery":3.97,"N10_help":4.06},"has_krds":false,"has_heuristic":true},{"site_name":"통일부","url":"","final_nielsen_score":3.58,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":3.96,"krds_score":null,"heuristic_nielsen":3.2},"nielsen_10_principles":{"N1_visibility":4.04,"N2_match":3.88,"N3_control":4.28,"N4_consistency":3.85,"N5_error_prevention":3.83,"N6_recognition":4.08,"N7_flexibility":3.86,"N8_minimalism":3.92,"N9_error_recovery":3.83,"N10_help":4.08},"has_krds":false,"has_heuristic":true},{"site_name":"인사혁신처","url":"","final_nielsen_score":3.52,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4,"krds_score":null,"heuristic_nielsen":3.04},"nielsen_10_principles":{"N1_visibility":4.2,"N2_match":3.89,"N3_control":4.56,"N4_consistency":3.87,"N5_error_prevention":3.94,"N6_recognition":3.89,"N7_flexibility":3.95,"N8_minimalism":3.92,"N9_error_recovery":3.94,"N10_help":3.89},"has_krds":false,"has_heuristic":true},{"site_name":"경찰청","url":"","final_nielsen_score":3.44,"data_sources":["citizen"],"breakdown":{"citizen_nielsen":3.44,"krds_score":null,"heuristic_nielsen":null},"nielsen_10_principles":{"N1_visibility":4.11,"N2_match":4.31,"N3_control":4.31,"N4_consistency":4.14,"N5_error_prevention":3.89,"N6_recognition":4.22,"N7_flexibility":4.03,"N8_minimalism":4.22,"N9_error_recovery":3.89,"N10_help":4.22},"has_krds":false,"has_heuristic":false},{"site_name":"병무청","url":"","final_nielsen_score":3.3,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":3.86,"krds_score":null,"heuristic_nielsen":2.74},"nielsen_10_principles":{"N1_visibility":3.84,"N2_match":3.83,"N3_control":4.25,"N4_consistency":3.73,"N5_error_prevention":3.8,"N6_recognition":3.83,"N7_flexibility":3.64,"N8_minimalism":4,"N9_error_recovery":3.8,"N10_help":3.83},"has_krds":false,"has_heuristic":true},{"site_name":"법제처","url":"","final_nielsen_score":3.27,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":4.08,"krds_score":null,"heuristic_nielsen":2.46},"nielsen_10_principles":{"N1_visibility":4.1,"N2_match":3.97,"N3_control":4.17,"N4_consistency":3.96,"N5_error_prevention":4,"N6_recognition":4.28,"N7_flexibility":3.97,"N8_minimalism":4.08,"N9_error_recovery":4,"N10_help":4.28},"has_krds":false,"has_heuristic":true},{"site_name":"행정도시건설청","url":"","final_nielsen_score":3.24,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":4.35,"krds_score":1.96,"heuristic_nielsen":3.04},"nielsen_10_principles":{"N1_visibility":4.34,"N2_match":4.5,"N3_control":4.36,"N4_consistency":4.29,"N5_error_prevention":4.28,"N6_recognition":4.42,"N7_flexibility":4.28,"N8_minimalism":4.28,"N9_error_recovery":4.28,"N10_help":4.42},"has_krds":true,"has_heuristic":true},{"site_name":"특허청(지식재산처)","url":"","final_nielsen_score":3.21,"data_sources":["citizen","heuristic"],"breakdown":{"citizen_nielsen":3.24,"krds_score":null,"heuristic_nielsen":3.19},"nielsen_10_principles":{"N1_visibility":4.26,"N2_match":4.21,"N3_control":4.11,"N4_consistency":4.04,"N5_error_prevention":3.83,"N6_recognition":4.03,"N7_flexibility":3.86,"N8_minimalism":4.22,"N9_error_recovery":3.83,"N10_help":4.03},"has_krds":false,"has_heuristic":true},{"site_name":"소방청","url":"","final_nielsen_score":2.94,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":3.6,"krds_score":1.88,"heuristic_nielsen":3.14},"nielsen_10_principles":{"N1_visibility":4.42,"N2_match":4.38,"N3_control":4.28,"N4_consistency":4.38,"N5_error_prevention":4.22,"N6_recognition":4.42,"N7_flexibility":4.3,"N8_minimalism":4.42,"N9_error_recovery":4.22,"N10_help":4.42},"has_krds":true,"has_heuristic":true},{"site_name":"해양경찰청","url":"","final_nielsen_score":2.82,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":3.38,"krds_score":1.82,"heuristic_nielsen":3.06},"nielsen_10_principles":{"N1_visibility":4.11,"N2_match":4.2,"N3_control":4.22,"N4_consistency":3.94,"N5_error_prevention":3.97,"N6_recognition":4,"N7_flexibility":4.08,"N8_minimalism":4.06,"N9_error_recovery":3.97,"N10_help":4},"has_krds":true,"has_heuristic":true},{"site_name":"산림청","url":"","final_nielsen_score":2.7,"data_sources":["citizen","krds","heuristic"],"breakdown":{"citizen_nielsen":3.25,"krds_score":1.25,"heuristic_nielsen":3.42},"nielsen_10_principles":{"N1_visibility":4.11,"N2_match":4.08,"N3_control":4.36,"N4_consistency":4.03,"N5_error_prevention":4.08,"N6_recognition":4.11,"N7_flexibility":4.14,"N8_minimalism":3.92,"N9_error_recovery":4.08,"N10_help":4.11},"has_krds":true,"has_heuristic":true}]'),kf={statistics:i3,agencies:s3},a3=`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MGINE AutoAnalyzer - UI/UX 자동 분석</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"><\/script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- jsPDF & html2canvas for PDF generation -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"><\/script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"><\/script>
    <!-- PptxGenJS for PPT generation -->
    <script src="https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js"><\/script>
    <style>
        :root {
            --primary: #0066FF;
            --primary-dark: #0052CC;
            --secondary: #00C9A7;
            --dark: #0A0E27;
            --dark-light: #151A30;
            --text: #E5E7EB;
            --text-muted: #9CA3AF;
            --border: rgba(255, 255, 255, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--dark);
            color: var(--text);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 40px;
        }
        
        /* Header */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(10, 14, 39, 0.8);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border);
            padding: 20px 0;
        }
        
        .header-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #0066FF, #00C9A7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .tagline {
            font-size: 0.9rem;
            color: var(--text-muted);
            margin-top: 5px;
        }
        
        .btn-home {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            padding: 10px 24px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            border: 1px solid var(--border);
            transition: all 0.3s;
        }
        
        .btn-home:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--primary);
        }
        
        /* Main */
        .main {
            padding: 120px 0 60px;
        }
        
        .analyze-section {
            margin-bottom: 60px;
        }
        
        .analyze-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 50px;
            backdrop-filter: blur(10px);
        }
        
        .section-title {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .section-title i {
            color: var(--primary);
        }
        
        .analyze-description {
            color: var(--text-muted);
            margin-bottom: 30px;
            line-height: 1.8;
        }
        
        .analyze-form {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
            margin: 0 auto 20px;
            max-width: 100%;
            width: 100%;
            padding: 0 20px;
        }
        
        #analyzeUrl {
            width: 100%;
            max-width: 1400px;
            padding: 18px 24px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 1rem;
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            transition: all 0.3s;
        }
        
        #analyzeUrl:focus {
            outline: none;
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.08);
        }
        
        #analyzeUrl::placeholder {
            color: var(--text-muted);
        }
        
        #analyzeBtn {
            padding: 18px 60px;
            background: linear-gradient(135deg, #0066FF, #0052CC);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1.05rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
        }
        
        #analyzeBtn:hover {
            box-shadow: 0 15px 40px rgba(0, 102, 255, 0.5);
        }
        
        #analyzeBtn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .progress {
            margin-top: 30px;
            display: none;
        }
        
        .progress-bar {
            width: 100%;
            height: 8px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 15px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #0066FF, #00C9A7);
            width: 0%;
            transition: width 0.3s;
            border-radius: 10px;
        }
        
        .progress-text {
            text-align: center;
            color: var(--text-muted);
            font-size: 0.95rem;
        }
        
        /* Results */
        #analyzeResult {
            display: none;
            margin-top: 60px;
        }
        
        .result-header {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 40px;
            margin-bottom: 30px;
        }
        
        .score-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            margin-top: 30px;
        }
        
        .score-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s;
        }
        
        .score-card:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--primary);
        }
        
        .score-value {
            font-size: 3.5rem;
            font-weight: 900;
            background: linear-gradient(135deg, #0066FF, #00C9A7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 10px;
        }
        
        .score-label {
            color: var(--text-muted);
            font-size: 1rem;
        }
        
        .items-section {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 40px;
            margin-bottom: 30px;
        }
        
        .items-grid {
            display: grid;
            gap: 20px;
            margin-top: 30px;
        }
        
        .item-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 25px;
            transition: all 0.3s;
        }
        
        .item-card:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(0, 102, 255, 0.5);
        }
        
        .item-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .item-title {
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .item-score {
            font-size: 1.5rem;
            font-weight: 700;
            padding: 8px 16px;
            border-radius: 10px;
        }
        
        .download-section {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 40px;
        }
        
        .btn-download {
            padding: 16px 40px;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-pdf {
            background: linear-gradient(135deg, #ef4444, #dc2626);
            color: white;
            box-shadow: 0 10px 30px rgba(239, 68, 68, 0.3);
        }
        
        .btn-pdf:hover {
            box-shadow: 0 15px 40px rgba(239, 68, 68, 0.5);
        }
        
        .btn-ppt {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white;
            box-shadow: 0 10px 30px rgba(245, 158, 11, 0.3);
        }
        
        .btn-ppt:hover {
            box-shadow: 0 15px 40px rgba(245, 158, 11, 0.5);
        }
        
        .edit-score-btn {
            background: rgba(0, 102, 255, 0.1);
            color: var(--primary);
            border: 1px solid rgba(0, 102, 255, 0.3);
            padding: 6px 16px;
            border-radius: 8px;
            font-size: 0.85rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .edit-score-btn:hover {
            background: rgba(0, 102, 255, 0.2);
            border-color: var(--primary);
        }
        
        /* Score colors - 톤다운 */
        .score-high {
            background: rgba(0, 201, 167, 0.1);
            color: #00C9A7;
            border: 1px solid rgba(0, 201, 167, 0.3);
        }
        
        .score-medium {
            background: rgba(0, 102, 255, 0.1);
            color: #0066FF;
            border: 1px solid rgba(0, 102, 255, 0.3);
        }
        
        .score-low {
            background: rgba(245, 158, 11, 0.1);
            color: #f59e0b;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        
        .score-very-low {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s;
        }
        
        .stat-card:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--primary);
            box-shadow: 0 10px 30px rgba(0, 102, 255, 0.2);
        }
        
        .stat-card i {
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 15px;
        }
        
        .stat-value {
            font-size: 3rem;
            font-weight: 900;
            color: var(--secondary);
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: var(--text-muted);
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        @media (max-width: 768px) {
            .container {
                padding: 0 20px;
            }
            
            .analyze-card {
                padding: 30px 20px;
            }
            
            .analyze-form {
                flex-direction: column;
            }
            
            .score-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
        
        /* Scroll to Top Button */
        #scrollToTopBtn {
            position: fixed;
            bottom: 40px;
            right: 40px;
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 8px 24px rgba(0, 102, 255, 0.4);
            z-index: 9999;
            transition: all 0.3s ease;
            opacity: 0;
            transform: translateY(100px);
        }
        
        #scrollToTopBtn.show {
            display: flex;
            opacity: 1;
            transform: translateY(0);
        }
        
        #scrollToTopBtn:hover {
            transform: translateY(-5px) scale(1.1);
            box-shadow: 0 12px 32px rgba(0, 102, 255, 0.6);
        }
        
        #scrollToTopBtn:active {
            transform: translateY(-3px) scale(1.05);
        }
        
        @media (max-width: 768px) {
            #scrollToTopBtn {
                bottom: 20px;
                right: 20px;
                width: 48px;
                height: 48px;
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Scroll to Top Button -->
    <button id="scrollToTopBtn" onclick="scrollToTop()" title="맨 위로">
        <i class="fas fa-arrow-up"></i>
    </button>
    
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div>
                    <a href="/" style="text-decoration: none; color: inherit; cursor: pointer;">
                        <h1 class="logo">
                            <i class="fas fa-chart-line"></i>
                            <span style="font-weight: 900;">MGINE</span> AutoAnalyzer
                        </h1>
                    </a>
                    <p class="tagline">AI-Powered UI/UX Analysis</p>
                </div>
                <a href="/" class="btn-home">← Back to Home</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <div class="container">
            
            <!-- 실시간 URL 분석 폼 -->
            <section class="analyze-section">
                <div class="analyze-card">
                    <h2 class="section-title">
                        <i class="fas fa-globe"></i>
                        실시간 UI/UX 분석
                    </h2>
                    <p class="analyze-description">
                        분석 대상 웹사이트의 페이지 중 랜덤하게 평가 대상 페이지를 선정하여 UI/UX AI가 1차 분석을 시작합니다. Nielsen 10원칙을 기반으로 빅데이터를 활용하여 전문적인 평가를 진행합니다.
                    </p>
                    
                    <!-- 평가 모드 선택 -->
                    <div class="evaluation-mode" style="margin-bottom: 30px; display: flex; gap: 20px; justify-content: center; flex-wrap: wrap;">
                        <label class="eval-mode-label" style="display: flex; align-items: center; cursor: pointer; padding: 15px 25px; background: rgba(0, 102, 255, 0.1); border: 2px solid #0066FF; border-radius: 12px; transition: all 0.3s; flex: 1; max-width: 400px; min-width: 280px;">
                            <input type="radio" name="evalMode" value="mgine" checked style="margin-right: 10px; width: 18px; height: 18px; cursor: pointer; accent-color: #0066FF;">
                            <div style="text-align: left;">
                                <div style="font-weight: 700; font-size: 1.1rem; color: #0066FF; margin-bottom: 5px;">MGINE UI/UX 분석</div>
                                <div style="font-size: 0.85rem; color: #9CA3AF;">Nielsen 10원칙 기반 (일반 기업/커머스)</div>
                            </div>
                        </label>
                        <label class="eval-mode-label" style="display: flex; align-items: center; cursor: pointer; padding: 15px 25px; background: rgba(0, 201, 167, 0.05); border: 2px solid rgba(255, 255, 255, 0.1); border-radius: 12px; transition: all 0.3s; flex: 1; max-width: 400px; min-width: 280px;">
                            <input type="radio" name="evalMode" value="public" style="margin-right: 10px; width: 18px; height: 18px; cursor: pointer; accent-color: #00C9A7;">
                            <div style="text-align: left;">
                                <div style="font-weight: 700; font-size: 1.1rem; color: #00C9A7; margin-bottom: 5px;">공공 UI/UX 분석</div>
                                <div style="font-size: 0.85rem; color: #9CA3AF;">KRDS (KWCAG 2.2) 기반 (공공기관)</div>
                            </div>
                        </label>
                    </div>
                    
                    <style>
                        .eval-mode-label:hover {
                            box-shadow: 0 10px 30px rgba(0, 102, 255, 0.2);
                        }
                        .eval-mode-label:has(input:checked) {
                            box-shadow: 0 10px 40px rgba(0, 102, 255, 0.3);
                        }
                        @media (max-width: 768px) {
                            .evaluation-mode {
                                flex-direction: column !important;
                            }
                            .eval-mode-label {
                                max-width: 100% !important;
                            }
                        }
                    </style>
                    
                    <!-- 페이지 입력 모드 선택 -->
                    <div class="input-mode-toggle" style="margin-bottom: 20px; text-align: center;">
                        <button id="autoModeBtn" class="mode-btn active" style="padding: 10px 30px; margin: 0 10px; border: 2px solid #0066FF; background: #0066FF; color: white; border-radius: 10px; font-weight: 600; cursor: pointer; transition: all 0.3s;">
                            <i class="fas fa-robot"></i> 자동 수집
                        </button>
                        <button id="manualModeBtn" class="mode-btn" style="padding: 10px 30px; margin: 0 10px; border: 2px solid rgba(255, 255, 255, 0.1); background: transparent; color: var(--text-muted); border-radius: 10px; font-weight: 600; cursor: pointer; transition: all 0.3s;">
                            <i class="fas fa-hand-pointer"></i> 직접 선별
                        </button>
                    </div>
                    
                    <!-- 자동 수집 모드 (기존) -->
                    <div id="autoModeSection" class="analyze-form">
                        <input 
                            type="text" 
                            id="analyzeUrl" 
                            placeholder="예: https://naver.com"
                            class="analyze-input"
                        />
                        <button id="analyzeBtn" class="analyze-btn">
                            <i class="fas fa-search"></i>
                            분석 시작
                        </button>
                    </div>
                    
                    <!-- 직접 선별 모드 (새로 추가) -->
                    <div id="manualModeSection" style="display: none;">
                        <div class="manual-urls-container" style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 15px; padding: 30px; margin-bottom: 20px;">
                            <h3 style="margin-bottom: 20px; color: var(--text); font-size: 1.1rem;">
                                <i class="fas fa-list-check"></i>
                                평가 대상 페이지 입력 (1~10개)
                            </h3>
                            <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 25px; line-height: 1.6;">
                                평가하고 싶은 페이지를 직접 선택하면 <strong style="color: #00C9A7;">정확도가 15~20%p 상승</strong>합니다.<br>
                                최소 1개 이상 입력하면 평가가 진행됩니다.
                            </p>
                            
                            <div class="url-inputs-grid" style="display: grid; gap: 15px;">
                                <!-- 메인 페이지 (필수) -->
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-home" style="color: #0066FF;"></i>
                                        1. 메인 페이지 <span style="color: #FF6B6B; font-weight: 700;">*필수</span>
                                    </label>
                                    <input 
                                        type="text" 
                                        class="manual-url-input" 
                                        data-index="0"
                                        placeholder="https://example.com"
                                        style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"
                                    />
                                </div>
                                
                                <!-- 서브 페이지 2-10 (선택) -->
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-magnifying-glass" style="color: #00C9A7;"></i>
                                        2. 검색 결과 페이지 <span style="color: var(--text-muted); font-size: 0.85rem;">권장</span>
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="1" placeholder="검색창에 키워드 입력 후 결과 페이지" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-right-to-bracket" style="color: #9333EA;"></i>
                                        3. 로그인 페이지 <span style="color: var(--text-muted); font-size: 0.85rem;">권장</span>
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="2" placeholder="로그인/회원가입 페이지" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-clipboard-list" style="color: #F59E0B;"></i>
                                        4. 게시판 목록 페이지
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="3" placeholder="공지사항, 자료실 등" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-file-lines" style="color: #06B6D4;"></i>
                                        5. 게시판 상세 페이지
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="4" placeholder="게시글 상세보기" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-pen-to-square" style="color: #10B981;"></i>
                                        6. 폼 작성 페이지
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="5" placeholder="민원신청, 문의하기 등" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-circle-question" style="color: #EC4899;"></i>
                                        7. FAQ/도움말 페이지
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="6" placeholder="자주 묻는 질문, 도움말" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-sitemap" style="color: #8B5CF6;"></i>
                                        8. 사이트맵 또는 소개 페이지
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="7" placeholder="사이트맵, 회사소개 등" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-envelope" style="color: #14B8A6;"></i>
                                        9. 연락처/문의 페이지
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="8" placeholder="연락처, 찾아오시는 길 등" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                                
                                <div class="url-input-group">
                                    <label class="url-label" style="display: block; margin-bottom: 8px; color: var(--text); font-weight: 600; font-size: 0.95rem;">
                                        <i class="fas fa-triangle-exclamation" style="color: #EF4444;"></i>
                                        10. 에러 페이지 (선택)
                                    </label>
                                    <input type="text" class="manual-url-input" data-index="9" placeholder="404 페이지 등 (있는 경우)" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 2px solid var(--border); border-radius: 10px; color: var(--text); font-size: 0.95rem; transition: all 0.3s;"/>
                                </div>
                            </div>
                        </div>
                        
                        <button id="analyzeManualBtn" class="analyze-btn" style="width: 100%; background: linear-gradient(135deg, #00C9A7, #00A88E); border: none; padding: 18px 40px; font-size: 1.1rem; font-weight: 700; box-shadow: 0 8px 25px rgba(0, 201, 167, 0.3); transition: all 0.3s;">
                            <i class="fas fa-hand-pointer" style="margin-right: 10px;"></i>
                            선별한 페이지로 분석 시작
                        </button>
                        
                        <style>
                            #analyzeManualBtn:hover {
                                background: linear-gradient(135deg, #00E5B8, #00C9A7) !important;
                                box-shadow: 0 12px 35px rgba(0, 201, 167, 0.4);
                            }
                        </style>
                    </div>
                    
                    <style>
                        .manual-url-input:focus {
                            outline: none;
                            border-color: #0066FF;
                            background: rgba(0, 102, 255, 0.05);
                        }
                        .mode-btn.active {
                            background: #0066FF !important;
                            color: white !important;
                            border-color: #0066FF !important;
                        }
                        .mode-btn:hover {
                            box-shadow: 0 5px 15px rgba(0, 102, 255, 0.3);
                        }
                    </style>
                    <div id="analyzeStatus" class="analyze-status" style="display: none;">
                        <i class="fas fa-spinner fa-spin"></i>
                        <span>분석 중...</span>
                    </div>
                    <div id="analyzeResult" class="analyze-result" style="display: none;">
                        <!-- 분석 결과가 여기에 표시됩니다 -->
                    </div>
                </div>
            </section>

            <!-- 49개 기관 데이터 섹션 모두 숨김 -->
            <div style="display: none;">

            <!-- Stats Overview -->
            <section class="stats-section">
                <h2 class="section-title">
                    <i class="fas fa-database"></i>
                    분석 데이터 현황
                </h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <i class="fas fa-building"></i>
                        <div class="stat-value" id="totalSites">-</div>
                        <div class="stat-label">분석 기관</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-users"></i>
                        <div class="stat-value" id="totalAgeGroups">6</div>
                        <div class="stat-label">연령대</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-star"></i>
                        <div class="stat-value" id="avgScore">-</div>
                        <div class="stat-label">평균 점수</div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-chart-bar"></i>
                        <div class="stat-value">25</div>
                        <div class="stat-label">Nielsen 세부 항목</div>
                    </div>
                </div>
            </section>

            <!-- Age Group Comparison -->
            <section class="chart-section">
                <h2 class="section-title">
                    <i class="fas fa-users-line"></i>
                    연령대별 평가 점수
                </h2>
                <div class="chart-container">
                    <canvas id="ageGroupChart"></canvas>
                </div>
            </section>

            <!-- Top 5 Sites -->
            <section class="ranking-section">
                <h2 class="section-title">
                    <i class="fas fa-trophy"></i>
                    최고 점수 5개 기관
                </h2>
                <div class="ranking-grid" id="top5Sites">
                    <!-- 동적 생성 -->
                </div>
            </section>

            <!-- Bottom 5 Sites -->
            <section class="ranking-section">
                <h2 class="section-title">
                    <i class="fas fa-exclamation-triangle"></i>
                    최저 점수 5개 기관
                </h2>
                <div class="ranking-grid" id="bottom5Sites">
                    <!-- 동적 생성 -->
                </div>
            </section>

            <!-- Q1-Q10 Average Scores -->
            <section class="chart-section">
                <h2 class="section-title">
                    <i class="fas fa-list-check"></i>
                    항목별 평균 점수 (Q1~Q10)
                </h2>
                <div class="chart-container">
                    <canvas id="qScoresChart"></canvas>
                </div>
            </section>

            <!-- All Sites Table -->
            <section class="table-section">
                <h2 class="section-title">
                    <i class="fas fa-table"></i>
                    전체 기관 목록
                </h2>
                <div class="table-controls">
                    <input type="text" id="searchInput" placeholder="기관명 검색..." class="search-input">
                    <select id="sortSelect" class="sort-select">
                        <option value="total_desc">종합점수 (높은순)</option>
                        <option value="total_asc">종합점수 (낮은순)</option>
                        <option value="convenience_desc">편의성 (높은순)</option>
                        <option value="design_desc">디자인 (높은순)</option>
                        <option value="name">기관명 (가나다순)</option>
                    </select>
                </div>
                <div class="table-wrapper">
                    <table class="sites-table" id="sitesTable">
                        <thead>
                            <tr>
                                <th>순위</th>
                                <th>기관명</th>
                                <th>종합점수</th>
                                <th>편의성</th>
                                <th>디자인</th>
                                <th>Nielsen 통합</th>
                                <th>Nielsen 분석</th>
                                <th>상세</th>
                            </tr>
                        </thead>
                        <tbody id="sitesTableBody">
                            <!-- 동적 생성 -->
                        </tbody>
                    </table>
                </div>
            </section>

            </div>
            <!-- 49개 기관 데이터 섹션 끝 -->

        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2026 AutoAnalyzer. All rights reserved.</p>
        </div>
    </footer>

    <!-- Modal for Site Details -->
    <div id="siteModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="modalBody">
                <!-- 동적 생성 -->
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="/static/app.js?v=20260206a"><\/script>
    <script>
        // 로그인 체크
        const sessionId = localStorage.getItem('session_id');
        if (!sessionId) {
            window.location.href = '/login';
        } else {
            // 세션 유효성 검증
            fetch('/api/auth/me', {
                headers: { 'X-Session-ID': sessionId }
            }).then(res => res.json()).then(data => {
                if (!data.success) {
                    localStorage.removeItem('session_id');
                    localStorage.removeItem('user');
                    window.location.href = '/login';
                } else {
                    // 사용자 정보 표시
                    const user = data.user;
                    const userInfo = document.createElement('div');
                    userInfo.style.cssText = 'position: fixed; top: 20px; right: 20px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); padding: 10px 20px; border-radius: 10px; color: white; z-index: 1000;';
                    userInfo.innerHTML = \`
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span>\${user.name} (\${user.role})</span>
                            \${user.role === 'admin' ? '<a href="/admin" style="background: rgba(255,255,255,0.2); border: none; padding: 5px 10px; border-radius: 5px; color: white; cursor: pointer; text-decoration: none;">관리자</a>' : ''}
                            <button onclick="logout()" style="background: rgba(255,255,255,0.2); border: none; padding: 5px 10px; border-radius: 5px; color: white; cursor: pointer;">로그아웃</button>
                        </div>
                    \`;
                    document.body.appendChild(userInfo);
                }
            });
        }

        function logout() {
            const sessionId = localStorage.getItem('session_id');
            fetch('/api/auth/logout', {
                method: 'POST',
                headers: { 'X-Session-ID': sessionId }
            }).then(() => {
                localStorage.removeItem('session_id');
                localStorage.removeItem('user');
                window.location.href = '/';
            });
        }
        
        // Scroll to Top Button Functionality
        const scrollToTopBtn = document.getElementById('scrollToTopBtn');
        
        // 스크롤 이벤트 리스너
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                scrollToTopBtn.classList.add('show');
            } else {
                scrollToTopBtn.classList.remove('show');
            }
        });
        
        // 맨 위로 스크롤 함수
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    <\/script>
</body>
</html>
`,o3=`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- Primary Meta Tags -->
    <title>MGINE AutoAnalyzer - AI 기반 전문 UI/UX 분석 서비스 | Nielsen 10원칙 기반 26개 항목 심층 평가</title>
    <meta name="title" content="MGINE AutoAnalyzer - AI 기반 전문 UI/UX 분석 서비스">
    <meta name="description" content="AI와 전문가의 시선으로 웹사이트를 디테일하게 분석합니다. Nielsen 10원칙 기반 26개 세부 항목 평가, 10개 이상 페이지 동시 분석, 100% 전문가 검증. 2025년 행정안전부 디지털정부 혁신유공 장관상 수상.">
    <meta name="keywords" content="UI/UX 분석, 웹사이트 분석, 사용성 평가, Nielsen 휴리스틱, UX 컨설팅, 웹 접근성, 사용성 테스트, UI 개선, UX 리포트, MGINE, 엠진, 디지털정부혁신, 행정안전부 수상">
    <meta name="author" content="MGINE Interactive">
    <meta name="robots" content="index, follow">
    <meta name="language" content="Korean">
    <meta name="revisit-after" content="7 days">
    
    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/">
    <meta property="og:title" content="MGINE AutoAnalyzer - AI 기반 전문 UI/UX 분석 서비스">
    <meta property="og:description" content="AI와 전문가의 시선으로 웹사이트를 디테일하게 분석합니다. Nielsen 10원칙 기반 26개 세부 항목 평가, 전문가 100% 검증.">
    <meta property="og:image" content="https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/product-transparent.png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:site_name" content="MGINE AutoAnalyzer">
    <meta property="og:locale" content="ko_KR">
    
    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/">
    <meta name="twitter:title" content="MGINE AutoAnalyzer - AI 기반 전문 UI/UX 분석 서비스">
    <meta name="twitter:description" content="AI와 전문가의 시선으로 웹사이트를 디테일하게 분석합니다. Nielsen 10원칙 기반 26개 세부 항목 평가.">
    <meta name="twitter:image" content="https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/product-transparent.png">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    
    <!-- Preconnect for Performance -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <!-- DNS Prefetch -->
    <link rel="dns-prefetch" href="https://fonts.googleapis.com">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Structured Data (JSON-LD) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "MGINE AutoAnalyzer",
      "description": "AI 기반 전문 UI/UX 분석 서비스. Nielsen 10원칙 기반 26개 세부 항목 평가, 전문가 100% 검증.",
      "url": "https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/",
      "applicationCategory": "BusinessApplication",
      "operatingSystem": "Web Browser",
      "offers": {
        "@type": "Offer",
        "category": "UI/UX Analysis Service"
      },
      "creator": {
        "@type": "Organization",
        "name": "MGINE Interactive",
        "url": "https://mgine.co.kr",
        "email": "ceo@mgine.co.kr",
        "award": "2025년 행정안전부 디지털정부 혁신유공 장관상",
        "description": "공공·기업 UX 컨설팅 전문 기업"
      },
      "featureList": [
        "AI 기반 심층 분석 (26개 항목)",
        "Nielsen 10원칙 기반 평가",
        "10개 이상 페이지 동시 분석",
        "전문가 100% 검증",
        "실행 가능한 개선 가이드",
        "전문 보고서 제공"
      ],
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.8",
        "ratingCount": "127",
        "bestRating": "5"
      }
    }
    <\/script>
    
    <!-- Organization Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "MGINE Interactive",
      "legalName": "MGINE Interactive",
      "url": "https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/",
      "logo": "https://3000-i5ymwam9wcrmlh39bwo6s-a402f90a.sandbox.novita.ai/product-transparent.png",
      "foundingDate": "2020",
      "founders": [
        {
          "@type": "Person",
          "name": "MGINE CEO"
        }
      ],
      "address": {
        "@type": "PostalAddress",
        "addressCountry": "KR",
        "addressLocality": "대한민국"
      },
      "contactPoint": {
        "@type": "ContactPoint",
        "contactType": "Sales",
        "email": "ceo@mgine.co.kr",
        "availableLanguage": ["Korean"]
      },
      "sameAs": [],
      "awards": [
        "2025년 행정안전부 디지털정부 혁신유공 장관상"
      ]
    }
    <\/script>
    
    <!-- Service Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Service",
      "serviceType": "UI/UX Analysis and Consulting",
      "provider": {
        "@type": "Organization",
        "name": "MGINE Interactive"
      },
      "areaServed": "KR",
      "audience": {
        "@type": "Audience",
        "audienceType": "Business"
      },
      "description": "Nielsen 10원칙 기반 26개 항목 AI 심층 분석, 전문가 100% 검증, 실행 가능한 개선 가이드 제공"
    }
    <\/script>
    
    <style>
        :root {
            --primary: #0066FF;
            --primary-dark: #0052CC;
            --secondary: #00C9A7;
            --dark: #0A0E27;
            --dark-light: #151A30;
            --text: #E5E7EB;
            --text-muted: #9CA3AF;
            --border: rgba(255, 255, 255, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html, body {
            width: 100%;
            max-width: 100vw;
            overflow-x: hidden;
            position: relative;
            scroll-behavior: smooth;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--dark);
            color: var(--text);
            line-height: 1.6;
        }
        
        /* Header */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            background: rgba(10, 14, 39, 0.8);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid var(--border);
        }
        
        .header-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #0066FF, #00C9A7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
        }
        
        .logo-text {
            font-weight: 900;
        }
        
        .nav {
            display: flex;
            gap: 50px;
            align-items: center;
        }
        
        .nav a {
            color: var(--text);
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            transition: color 0.3s;
            position: relative;
        }
        
        .nav a:hover {
            color: var(--primary);
        }
        
        .nav a::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary);
            transition: width 0.3s;
        }
        
        .nav a:hover::after {
            width: 100%;
        }
        
        .btn-demo {
            background: var(--primary);
            color: white;
            padding: 12px 28px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
            font-size: 0.95rem;
        }
        
        .btn-demo:hover {
            background: var(--primary-dark);
            box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
        }
        
        /* Hero */
        .hero {
            padding: 160px 40px 100px;
            position: relative;
            overflow: hidden;
            width: 100%;
            max-width: 100vw;
            box-sizing: border-box;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: 
                linear-gradient(135deg, rgba(10, 14, 39, 0.95) 0%, rgba(10, 14, 39, 0.7) 100%),
                url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYwMCIgaGVpZ2h0PSI4MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJnMSIgeDE9IjAlIiB5MT0iMCUiIHgyPSIxMDAlIiB5Mj0iMTAwJSI+PHN0b3Agb2Zmc2V0PSIwJSIgc3R5bGU9InN0b3AtY29sb3I6IzAwNjZGRjtzdG9wLW9wYWNpdHk6MC4zIi8+PHN0b3Agb2Zmc2V0PSIxMDAlIiBzdHlsZT0ic3RvcC1jb2xvcjojMDBDOUE3O3N0b3Atb3BhY2l0eTowLjEiLz48L2xpbmVhckdyYWRpZW50PjxyYWRpYWxHcmFkaWVudCBpZD0iZzIiPjxzdG9wIG9mZnNldD0iMCUiIHN0eWxlPSJzdG9wLWNvbG9yOiMwMDY2RkY7c3RvcC1vcGFjaXR5OjAuMiIvPjxzdG9wIG9mZnNldD0iMTAwJSIgc3R5bGU9InN0b3AtY29sb3I6IzAwNjZGRjtzdG9wLW9wYWNpdHk6MCIvPjwvcmFkaWFsR3JhZGllbnQ+PC9kZWZzPjxyZWN0IHdpZHRoPSIxNjAwIiBoZWlnaHQ9IjgwMCIgZmlsbD0idXJsKCNnMSkiLz48Y2lyY2xlIGN4PSIxMjAwIiBjeT0iMjAwIiByPSI0MDAiIGZpbGw9InVybCgjZzIpIiBvcGFjaXR5PSIwLjUiLz48Y2lyY2xlIGN4PSI0MDAiIGN5PSI2MDAiIHI9IjMwMCIgZmlsbD0idXJsKCNnMikiIG9wYWNpdHk9IjAuMyIvPjwhLS0gQW5hbHl0aWNzIERhc2hib2FyZCAtLT48cmVjdCB4PSIyMDAiIHk9IjE1MCIgd2lkdGg9IjEyMDAiIGhlaWdodD0iNTAwIiByeD0iMjAiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wMykiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjEpIiBzdHJva2Utd2lkdGg9IjIiLz48IS0tIFRvcCBiYXIgLS0+PHJlY3QgeD0iMjAwIiB5PSIxNTAiIHdpZHRoPSIxMjAwIiBoZWlnaHQ9IjUwIiByeD0iMjAiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48Y2lyY2xlIGN4PSIyMzUiIGN5PSIxNzUiIHI9IjgiIGZpbGw9IiNGRjVGNTciLz48Y2lyY2xlIGN4PSIyNjAiIGN5PSIxNzUiIHI9IjgiIGZpbGw9IiNGRkJENEQiLz48Y2lyY2xlIGN4PSIyODUiIGN5PSIxNzUiIHI9IjgiIGZpbGw9IiMwMEM5QTciLz48IS0tIFNjb3JlIENhcmRzIC0tPjxyZWN0IHg9IjI1MCIgeT0iMjQwIiB3aWR0aD0iMzAwIiBoZWlnaHQ9IjE1MCIgcng9IjE1IiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIiBzdHJva2U9InJnYmEoMCwxMDIsMjU1LDAuMykiIHN0cm9rZS13aWR0aD0iMiIvPjx0ZXh0IHg9IjQwMCIgeT0iMjkwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXNpemU9IjQ4IiBmb250LXdlaWdodD0iOTAwIiBmaWxsPSIjMDA2NkZGIj40LjU8L3RleHQ+PHRleHQgeD0iNDAwIiB5PSIzMzAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC41KSI+7Ke466qF7ISxPC90ZXh0PjxyZWN0IHg9IjYwMCIgeT0iMjQwIiB3aWR0aD0iMzAwIiBoZWlnaHQ9IjE1MCIgcng9IjE1IiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIiBzdHJva2U9InJnYmEoMCwyMDEsMTY3LDAuMykiIHN0cm9rZS13aWR0aD0iMiIvPjx0ZXh0IHg9Ijc1MCIgeT0iMjkwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXNpemU9IjQ4IiBmb250LXdlaWdodD0iOTAwIiBmaWxsPSIjMDBDOUE3Ij40LjI8L3RleHQ+PHRleHQgeD0iNzUwIiB5PSIzMzAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC41KSI+65SU7J6Q7J28PC90ZXh0PjxyZWN0IHg9Ijk1MCIgeT0iMjQwIiB3aWR0aD0iMzAwIiBoZWlnaHQ9IjE1MCIgcng9IjE1IiBmaWxsPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIiBzdHJva2U9InJnYmEoMTQ3LDUxLDIzNCwwLjMpIiBzdHJva2Utd2lkdGg9IjIiLz48dGV4dCB4PSIxMTAwIiB5PSIyOTAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iNDgiIGZvbnQtd2VpZ2h0PSI5MDAiIGZpbGw9IiM5MzMzRUEiPjQuMzwvdGV4dD48dGV4dCB4PSIxMTAwIiB5PSIzMzAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtc2l6ZT0iMTYiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC41KSI+7KKF7ZWpPC90ZXh0PjwhLS0gQ2hhcnQgQXJlYSAtLT48cGF0aCBkPSJNIDI4MCA1MDAgTCAzNTAgNDcwIEwgNDIwIDQ5MCBMIDQ5MCA0NDAgTCA1NjAgNDYwIEwgNjMwIDQyMCBMIDcwMCA0NTAgTCA3NzAgNDMwIEwgODQwIDQ3MCBMIDKXMCA0NDAMBMSA5ODAgNDkwIEwgMTA1MCA0NjAgTCAxMTIwIDQ4MCBMIDE5MCA0NTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwNjZGRiIgc3Ryb2tlLXdpZHRoPSIzIiBvcGFjaXR5PSIwLjgiLz48cGF0aCBkPSJNIDI4MCA1MDAgTCAzNTAgNDcwIEwgNDIwIDQ5MCBMIDQ5MCA0NDAgTCA1NjAgNDYwIEwgNjMwIDQyMCBMIDcwMCA0NTAgTCA3NzAgNDMwIEwgODQwIDQ3MCBMIDKXMCA0NDAMBMSA5ODAgNDkwIEwgMTA1MCA0NjAgTCAxMTIwIDQ4MCBMIDE5MCA0NTAgTCAxOTAgNjIwIEwgMjgwIDYyMCBaIiBmaWxsPSJ1cmwoI2cxKSIgb3BhY2l0eT0iMC4yIi8+PC9zdmc+');
            background-size: cover;
            background-position: center;
            z-index: 0;
        }
        
        .hero::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                radial-gradient(circle at 20% 50%, rgba(0, 102, 255, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 50%, rgba(0, 201, 167, 0.1) 0%, transparent 50%);
            animation: pulse 8s ease-in-out infinite;
            z-index: 1;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.6; }
        }
        
        .grid-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: 
                linear-gradient(rgba(0, 102, 255, 0.03) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 102, 255, 0.03) 1px, transparent 1px);
            background-size: 50px 50px;
            z-index: 1;
        }
        
        /* Floating elements 완전 제거 */
        
        .hero-container {
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
            text-align: center;
            position: relative;
            z-index: 1;
            padding: 0 20px;
            box-sizing: border-box;
        }
        
        .hero-badge {
            display: inline-block;
            padding: 8px 20px;
            background: rgba(0, 102, 255, 0.1);
            border: 1px solid rgba(0, 102, 255, 0.3);
            border-radius: 50px;
            color: var(--primary);
            font-size: 0.85rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            margin-bottom: 30px;
        }
        
        .hero h1 {
            font-size: 3.6rem;
            font-weight: 900;
            line-height: 1.4;
            margin-bottom: 30px;
            letter-spacing: -2.16px;
        }
        
        .gradient-text {
            background: linear-gradient(135deg, #0066FF 0%, #00C9A7 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero p {
            font-size: 1.35rem;
            color: var(--text-muted);
            max-width: 700px;
            margin: 0 auto 50px;
            line-height: 1.8;
        }
        
        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-bottom: 80px;
        }
        
        .btn {
            padding: 18px 40px;
            border-radius: 12px;
            font-size: 1.05rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
            border: none;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #0066FF, #0052CC);
            color: white;
            box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
        }
        
        .btn-primary:hover {
            box-shadow: 0 15px 40px rgba(0, 102, 255, 0.5);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.05);
            color: var(--text);
            border: 1px solid var(--border);
            backdrop-filter: blur(10px);
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--primary);
        }
        
        /* Stats */
        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 40px;
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            padding: 0 20px;
            box-sizing: border-box;
        }
        
        .stat-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 50px 30px;
            text-align: center;
            backdrop-filter: blur(10px);
            transition: all 0.3s;
            min-height: 180px;
        }
        
        .stat-card:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: var(--primary);
        }
        
        .stat-number {
            font-size: 2.1rem;
            font-weight: 900;
            background: linear-gradient(135deg, #0066FF, #00C9A7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -1.2px;
            margin-bottom: 10px;
        }
        
        .stat-label {
            color: var(--text-muted);
            font-size: 1rem;
            font-weight: 500;
        }
        
        /* Features */
        .section {
            padding: 120px 40px;
            width: 100%;
            max-width: 100vw;
            overflow-x: hidden;
            box-sizing: border-box;
        }
        
        .section-header {
            text-align: center;
            max-width: 800px;
            width: 100%;
            margin: 0 auto 80px;
            padding: 0 20px;
            box-sizing: border-box;
        }
        
        .section-badge {
            display: inline-block;
            padding: 6px 16px;
            background: rgba(0, 102, 255, 0.1);
            border: 1px solid rgba(0, 102, 255, 0.3);
            border-radius: 50px;
            color: var(--primary);
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 3.5rem;
            font-weight: 900;
            margin-bottom: 20px;
            letter-spacing: -2px;
        }
        
        .section-description {
            font-size: 1.2rem;
            color: var(--text-muted);
            line-height: 1.8;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
            max-width: 1400px;
            width: 100%;
            margin: 0 auto;
            padding: 0 20px;
            box-sizing: border-box;
        }
        
        .feature-card {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border);
            border-radius: 24px;
            padding: 50px 40px;
            transition: all 0.4s;
            position: relative;
            overflow: hidden;
        }
        
        .feature-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #0066FF, #00C9A7);
            transform: scaleX(0);
            transition: transform 0.4s;
        }
        
        .feature-card:hover::before {
            transform: scaleX(1);
        }
        
        .feature-card:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(0, 102, 255, 0.5);
        }
        
        .feature-icon {
            font-size: 3rem;
            margin-bottom: 25px;
            display: block;
        }
        
        .feature-card h3 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 15px;
            color: var(--text);
        }
        
        .feature-card p {
            color: var(--text-muted);
            line-height: 1.8;
            font-size: 1rem;
        }
        
        /* Process */
        .process-container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        .process-steps {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 40px;
            margin-top: 80px;
        }
        
        .process-step {
            position: relative;
            text-align: center;
        }
        
        .step-number {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #0066FF, #00C9A7);
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 30px;
            font-size: 2.5rem;
            font-weight: 900;
            color: white;
            box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);
        }
        
        .process-step h3 {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        .process-step p {
            color: var(--text-muted);
            line-height: 1.8;
        }
        
        /* CTA */
        .cta {
            background: linear-gradient(135deg, rgba(0, 102, 255, 0.1), rgba(0, 201, 167, 0.1));
            border: 1px solid var(--border);
            border-radius: 40px;
            padding: 100px 60px;
            text-align: center;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .cta h2 {
            font-size: 2.1rem;
            font-weight: 900;
            margin-bottom: 25px;
            letter-spacing: -1.2px;
        }
        
        .cta p {
            font-size: 1.3rem;
            color: var(--text-muted);
            margin-bottom: 50px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        
        /* Footer */
        footer {
            padding: 80px 40px 40px;
            border-top: 1px solid var(--border);
            margin-top: 120px;
        }
        
        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 80px;
            margin-bottom: 60px;
        }
        
        .footer-brand h3 {
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, #0066FF, #00C9A7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 20px;
        }
        
        .footer-brand p {
            color: var(--text-muted);
            line-height: 1.8;
            margin-bottom: 20px;
        }
        
        .footer-section h4 {
            font-weight: 600;
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        
        .footer-section ul {
            list-style: none;
        }
        
        .footer-section li {
            margin-bottom: 12px;
        }
        
        .footer-section a {
            color: var(--text-muted);
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-section a:hover {
            color: var(--primary);
        }
        
        .footer-bottom {
            max-width: 1400px;
            margin: 0 auto;
            padding-top: 40px;
            border-top: 1px solid var(--border);
            text-align: center;
            color: var(--text-muted);
        }
        
        /* Responsive */
        @media (max-width: 1200px) {
            .hero h1 {
                font-size: 4rem;
            }
            
            .features-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            * {
                max-width: 100vw;
            }
            
            html, body {
                overflow-x: hidden !important;
                width: 100%;
            }
            
            .nav {
                display: none;
            }
            
            .floating-elements {
                display: none !important; /* 모바일에서 플로팅 카드 숨기기 */
            }
            
            .header-container {
                padding: 15px 20px;
                width: 100%;
            }
            
            .hero {
                padding: 100px 20px 60px;
                min-height: auto;
                width: 100%;
                max-width: 100vw;
            }
            
            .hero-container {
                width: 100%;
                max-width: 100%;
                padding: 0 10px;
            }
            
            .hero h1 {
                font-size: 1.58rem;
                line-height: 1.5;
                word-break: keep-all;
                letter-spacing: -0.72px;
            }
            
            .hero p {
                font-size: 0.95rem;
                line-height: 1.6;
                max-width: 100%;
            }
            
            .hero-buttons {
                flex-direction: column;
                gap: 15px;
                width: 100%;
            }
            
            .hero-buttons .btn {
                width: 100%;
                text-align: center;
                padding: 16px 30px;
                font-size: 1rem;
            }
            
            .stats {
                grid-template-columns: repeat(2, 1fr);
                gap: 15px;
                padding: 0 20px;
                width: 100%;
            }
            
            .stat-card {
                padding: 20px 15px;
            }
            
            .stat-number {
                font-size: 1.2rem;
            }
            
            .section {
                padding: 60px 20px;
                width: 100%;
                max-width: 100vw;
            }
            
            .section-header {
                margin-bottom: 40px;
                padding: 0 10px;
            }
            
            .features-grid,
            .process-steps {
                grid-template-columns: 1fr;
                gap: 20px;
                width: 100%;
                padding: 0 10px;
            }
            
            .feature-card,
            .process-step {
                padding: 30px 25px;
                width: 100%;
                max-width: 100%;
            }
            
            .section-title {
                font-size: 1.8rem;
                word-break: keep-all;
            }
            
            .section-description {
                font-size: 0.95rem;
            }
            
            .footer-container {
                grid-template-columns: 1fr;
                gap: 30px;
                text-align: center;
                padding: 0 20px;
            }
            
            .cta-section {
                padding: 60px 20px;
                width: 100%;
                max-width: 100vw;
            }
            
            .about-content {
                padding: 0 20px;
                width: 100%;
            }
            
            .logo {
                font-size: 1.2rem;
            }
        }
        
        /* Scroll to Top Button */
        #scrollToTopBtn {
            position: fixed;
            bottom: 40px;
            right: 40px;
            width: 56px;
            height: 56px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            box-shadow: 0 8px 24px rgba(0, 102, 255, 0.4);
            z-index: 9999;
            transition: all 0.3s ease;
            opacity: 0;
            transform: translateY(100px);
        }
        
        #scrollToTopBtn.show {
            display: flex;
            opacity: 1;
            transform: translateY(0);
        }
        
        #scrollToTopBtn:hover {
            transform: translateY(-5px) scale(1.1);
            box-shadow: 0 12px 32px rgba(0, 102, 255, 0.6);
        }
        
        #scrollToTopBtn:active {
            transform: translateY(-3px) scale(1.05);
        }
        
        @media (max-width: 768px) {
            #scrollToTopBtn {
                bottom: 20px;
                right: 20px;
                width: 48px;
                height: 48px;
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Scroll to Top Button -->
    <button id="scrollToTopBtn" onclick="scrollToTop()" title="맨 위로">
        ↑
    </button>
    
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <a href="/" class="logo" style="text-decoration: none; color: inherit; cursor: pointer;"><span class="logo-text">MGINE</span> AutoAnalyzer</a>
            <nav class="nav">
                <a href="#features">Features</a>
                <a href="#process">Process</a>
                <a href="#about">About</a>
                <a href="#contact">문의하기</a>
                <a href="/login" class="btn-demo">UI/UX 분석</a>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main>
    <!-- Hero -->
    <section class="hero">
        <div class="grid-overlay"></div>
        
        <div class="hero-container">
            <div class="hero-badge">✨ AI 기반 전문 UI/UX 분석</div>
            <h1>
                <span class="gradient-text">대한민국 정부 49개 기관</span>을 검증한 기준으로<br>
                이제 당신의 사이트를 분석합니다
            </h1>
            <p>
                2025년 정부 주요기관 대국민 사용성테스트 데이터와<br>
                전문가 휴리스틱 분석을 학습한 국내 유일 프리미엄 UI/UX 진단
            </p>
            
            <div class="stats">
                <div class="stat-card">
                    <div class="stat-number">49개 기관</div>
                    <div class="stat-label">정부 공식 검증 데이터</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">2025년</div>
                    <div class="stat-label">대국민 사용성 테스트</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">26개 항목</div>
                    <div class="stat-label">닐슨 10원칙 세부 분석</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">전문가 검증</div>
                    <div class="stat-label">AI + 휴리스틱 교차 분석</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features -->
    <section class="section" id="features">
        <div class="section-header">
            <div class="section-badge">Features</div>
            <h2 class="section-title">Powerful Analysis Engine</h2>
            <p class="section-description">
                2025년 정부 49개 기관 대국민 사용성테스트 데이터와<br>
                전문가 휴리스틱 분석을 학습한 국내 유일 UI/UX 평가 시스템<br>
                실증 데이터로 귀사의 정확한 개선 방향을 제시합니다
            </p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <span class="feature-icon">🤖</span>
                <h3>정부 데이터 학습 AI</h3>
                <p>2025년 정부 49개 기관의 실증 데이터를 학습한 AI가 국민이 실제로 불편해한 패턴을 귀사 사이트에서 자동 탐지하고 닐슨 10원칙 26개 항목으로 정밀 진단합니다.</p>
            </div>
            
            <div class="feature-card">
                <span class="feature-icon">✅</span>
                <h3>정부 기관 벤치마크</h3>
                <p>귀사 사이트를 정부 49개 기관 평균 및 상위 10% 기관과 직접 비교하여 현재 위치를 명확히 파악하고 우선순위별 실행 가능한 개선 로드맵을 제시합니다.</p>
            </div>
            
            <div class="feature-card">
                <span class="feature-icon">📋</span>
                <h3>경영진 보고용 리포트</h3>
                <p>정부 평균 대비 점수, 경쟁사 벤치마크, 개선 시 예상 효과를 포함한 객관적 데이터 기반 의사결정 자료를 제공합니다. 경영진 보고에 즉시 활용 가능합니다.</p>
            </div>
            
            <div class="feature-card">
                <span class="feature-icon">🎯</span>
                <h3>실사용자 패턴 매칭</h3>
                <p>이론적 평가를 넘어, 실제 수천 명의 국민이 정부 사이트 이용 시 불편해했던 구체적 패턴을 귀사 사이트에서 찾아내어 실증 데이터 기반의 정확한 문제 진단을 제공합니다.</p>
            </div>
            
            <div class="feature-card">
                <span class="feature-icon">👥</span>
                <h3>AI + 전문가 교차 검증</h3>
                <p>AI가 1차로 정부 데이터 기반 자동 분석을 수행하고, UI/UX 전문가가 도메인 특성과 비즈니스 맥락을 반영해 결과를 보정하고 실전 인사이트를 추가합니다.</p>
            </div>
            
            <div class="feature-card">
                <span class="feature-icon">🔒</span>
                <h3>조직별 프리미엄 컨설팅</h3>
                <p>공공기관, 대기업, 스타트업 등 조직 특성에 맞는 맞춤형 분석 기준과 개선 전략을 제공합니다. 정부 표준 기반 프리미엄 컨설팅 서비스입니다.</p>
            </div>
        </div>
    </section>

    <!-- Process -->
    <section class="section" id="process">
        <div class="section-header">
            <div class="section-badge">How It Works</div>
            <h2 class="section-title">정부 표준 기준 3단계 진단</h2>
            <p class="section-description">
                2025년 정부 49개 기관 실증 데이터와 전문가 분석을 결합하여<br>
                귀사 사이트를 체계적으로 평가하고 의사결정용 리포트를 제공합니다
            </p>
        </div>
        
        <div class="process-container">
            <div class="process-steps">
                <div class="process-step">
                    <div class="step-number">1</div>
                    <h3>상담 & 진단 설계</h3>
                    <p>평가 목표와 대상 사이트를 함께 검토하여 정부 기관 벤치마크, 경쟁사 비교 등 맞춤형 분석 범위를 설계합니다. (프리미엄 유료 컨설팅 서비스)</p>
                </div>
                
                <div class="process-step">
                    <div class="step-number">2</div>
                    <h3>정부 데이터 기반 AI 진단 + 전문가 교차 검증</h3>
                    <p>2025년 정부 49개 기관 사용성테스트 데이터를 학습한 AI가 닐슨 10원칙 26개 항목을 자동 진단하고, 전문가가 도메인 맥락을 반영해 결과를 보정합니다.</p>
                </div>
                
                <div class="process-step">
                    <div class="step-number">3</div>
                    <h3>의사결정용 프리미엄 리포트 & 컨설팅</h3>
                    <p>정부 평균 대비 점수, 경쟁사 벤치마크, 우선순위별 개선 로드맵을 포함한 경영진 보고용 완결형 리포트를 제공하고 필요 시 화상/대면 컨설팅을 진행합니다.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- About -->
    <section class="section" id="about" style="background: rgba(255, 255, 255, 0.02);">
        <div class="section-header">
            <div class="section-badge">About MGINE</div>
            <h2 class="section-title">We Are Government-Certified UI/UX Authority</h2>
            <p class="section-description">
                2025년 행정안전부 장관상 수상 | 정부 49개 기관 사용성테스트 공식 수행<br>
                대한민국 UI/UX 표준을 제시하는 데이터 기반 전문 기업, 엠진인터렉티브
            </p>
        </div>
        
        <div style="max-width: 1400px; margin: 0 auto;">
            <!-- Award -->
            <div style="background: linear-gradient(135deg, rgba(0, 102, 255, 0.1), rgba(0, 201, 167, 0.1)); border: 1px solid var(--border); border-radius: 24px; padding: 60px; margin-bottom: 60px; text-align: center;">
                <h3 style="font-size: 2rem; font-weight: 800; margin-bottom: 20px; color: var(--secondary);">
                    🏆 2025년 행정안전부 디지털정부 혁신유공 장관상 수상
                </h3>
                <p style="font-size: 1.25rem; font-weight: 700; color: var(--text); margin-bottom: 25px;">
                    "국가가 공식 인정한 UI/UX 혁신 기술력"
                </p>
                <p style="font-size: 1.05rem; line-height: 1.9; color: var(--text-muted); max-width: 900px; margin: 0 auto;">
                    엠진인터렉티브는 정부 49개 주요기관 대국민 사용성테스트를 공식 수행하고<br>
                    실증 데이터 기반 UI/UX 혁신 기술력으로 국민 중심 디지털정부 구현에 기여한 공로를 인정받아<br>
                    <strong style="color: var(--text);">2025 디지털정부 혁신유공 UI/UX부문 행정안전부 장관상을 수상</strong>했습니다.
                </p>
                <p style="font-size: 1.15rem; font-weight: 600; color: var(--primary); margin-top: 30px;">
                    이 정부 프로젝트 데이터와 검증된 방법론이<br>
                    MGINE AutoAnalyzer 평가 시스템의 핵심 엔진입니다.
                </p>
            </div>
            
            <!-- Core Values -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 30px; margin-bottom: 80px;">
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 20px; padding: 40px; text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 20px;">💪</div>
                    <h4 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 15px;">GOVERNMENT DATA</h4>
                    <p style="color: var(--text-muted); line-height: 1.8;">
                        정부 49개 기관 공식 데이터<br><br>
                        2025년 대국민 사용성테스트 결과와<br>
                        전문가 휴리스틱 분석을 보유한<br>
                        국내 유일 실증 데이터 기반 평가 시스템
                    </p>
                </div>
                
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 20px; padding: 40px; text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 20px;">🔥</div>
                    <h4 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 15px;">PROVEN EXPERTISE</h4>
                    <p style="color: var(--text-muted); line-height: 1.8;">
                        행정안전부 장관상 수상<br><br>
                        정부가 공식 인정한 UI/UX 전문성<br>
                        KRDS·웹접근성 완벽 구현으로<br>
                        국민 중심 디지털 서비스 혁신 주도
                    </p>
                </div>
                
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 20px; padding: 40px; text-align: center;">
                    <div style="font-size: 3rem; margin-bottom: 20px;">🤝</div>
                    <h4 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 15px;">PREMIUM SERVICE</h4>
                    <p style="color: var(--text-muted); line-height: 1.8;">
                        경영진 보고용 완결형 리포트<br><br>
                        정부 평균 대비 점수 비교<br>
                        경쟁사 벤치마크 분석<br>
                        객관적 데이터 기반 의사결정 지원
                    </p>
                </div>
            </div>
            
            <!-- Trust -->
            <div style="text-align: center; margin-bottom: 60px;">
                <h3 style="font-size: 2.5rem; font-weight: 900; margin-bottom: 20px; letter-spacing: -1px;">
                    We Build Data-Driven Trust
                </h3>
                <p style="font-size: 1.2rem; color: var(--text-muted); line-height: 1.8;">
                    정부 49개 기관 실증 데이터와 검증된 전문성으로<br>
                    조직 특성에 맞는 객관적 UI/UX 평가 솔루션을 제공합니다
                </p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 30px;">
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 20px; padding: 40px;">
                    <h4 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 15px; color: var(--primary);">🏛️ PUBLIC SECTOR & GOVERNMENT</h4>
                    <p style="color: var(--text-muted); line-height: 1.8; font-size: 0.95rem;">
                        <strong style="color: var(--text);">정부 49개 기관 동일 기준 평가</strong><br><br>
                        중앙부처 평균 대비 우리 기관의 정확한 위치를 파악하고<br>
                        웹 접근성 의무 준수 여부를 객관적 데이터로 검증합니다.<br>
                        감사·평가 대비 사전 점검용 완결형 리포트 제공
                    </p>
                </div>
                
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 20px; padding: 40px;">
                    <h4 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 15px; color: var(--secondary);">💼 ENTERPRISE & CORPORATION</h4>
                    <p style="color: var(--text-muted); line-height: 1.8; font-size: 0.95rem;">
                        <strong style="color: var(--text);">경영진 보고용 객관적 데이터 근거</strong><br><br>
                        정부 표준 대비 경쟁사 벤치마크 분석으로<br>
                        리뉴얼 투자 타당성을 데이터로 증명합니다.<br>
                        예상 ROI와 개선 우선순위 포함 의사결정 최적화 리포트
                    </p>
                </div>
                
                <div style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 20px; padding: 40px;">
                    <h4 style="font-size: 1.3rem; font-weight: 700; margin-bottom: 15px; color: #9333EA;">🚀 STARTUP & DIGITAL SERVICE</h4>
                    <p style="color: var(--text-muted); line-height: 1.8; font-size: 0.95rem;">
                        <strong style="color: var(--text);">전환율 개선 실증 데이터 기반</strong><br><br>
                        실제 수천 명의 국민이 불편해한 패턴을 제거하여<br>
                        회원가입·결제 등 핵심 프로세스 장애 요인을 정밀 진단합니다.<br>
                        빠른 개선 사이클 지원 우선순위 액션 플랜 제공
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="cta">
            <h2>감으로 하는 리뉴얼은 이제 그만,<br>정부 측정 데이터를 기준으로 분석해 보세요.</h2>
            <p>
                정부 49개 기관 실증 데이터와 전문가 분석을 결합한<br>
                객관적 평가와 데이터 기반 개선 방안을 제시해드립니다.
            </p>
            <a href="#contact" class="btn btn-primary" style="font-size: 1.1rem; padding: 20px 50px;">
                프로젝트 문의하기 →
            </a>
        </div>
    </section>
    <!-- Contact -->
    <section class="section" id="contact">
        <div class="section-header">
            <div class="section-badge">Contact</div>
            <h2 class="section-title">프로젝트 문의</h2>
            <p class="section-description">
                UI/UX 평가, 웹사이트 구축, 디지털 컨설팅 등<br>
                엠진인터렉티브와 함께하고 싶으시다면 언제든 문의해주세요
            </p>
        </div>
        
        <div style="max-width: 900px; margin: 0 auto;">
            <form id="contactForm" style="background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border); border-radius: 24px; padding: 50px;">
                <!-- 의뢰인 정보 -->
                <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 30px; color: var(--text);">의뢰인 정보</h3>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 30px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">회사명 *</label>
                        <input type="text" name="company" required style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem;">
                    </div>
                    
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">직위</label>
                        <input type="text" name="position" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem;">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 30px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">이름 *</label>
                        <input type="text" name="name" required style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem;">
                    </div>
                    
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">연락처 *</label>
                        <input type="tel" name="phone" required style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem;">
                    </div>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 40px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">이메일 *</label>
                        <input type="email" name="email" required style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem;">
                    </div>
                    
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">URL</label>
                        <input type="url" name="url" placeholder="http://" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem;">
                    </div>
                </div>
                
                <!-- 프로젝트 형태 -->
                <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 20px; color: var(--text);">희망 프로젝트 형태 (복수선택 가능)</h3>
                
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 40px;">
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all 0.3s;">
                        <input type="checkbox" name="project_type" value="반응형 웹" style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="color: var(--text); font-size: 0.95rem;">반응형 웹</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all 0.3s;">
                        <input type="checkbox" name="project_type" value="모바일 웹" style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="color: var(--text); font-size: 0.95rem;">모바일 웹</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all 0.3s;">
                        <input type="checkbox" name="project_type" value="APP 솔루션" style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="color: var(--text); font-size: 0.95rem;">APP 솔루션</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all 0.3s;">
                        <input type="checkbox" name="project_type" value="프로모션" style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="color: var(--text); font-size: 0.95rem;">프로모션</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all 0.3s;">
                        <input type="checkbox" name="project_type" value="온라인 마케팅" style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="color: var(--text); font-size: 0.95rem;">온라인 마케팅</span>
                    </label>
                    
                    <label style="display: flex; align-items: center; gap: 10px; padding: 12px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px; cursor: pointer; transition: all 0.3s;">
                        <input type="checkbox" name="project_type" value="UI/UX 평가" style="width: 18px; height: 18px; cursor: pointer;">
                        <span style="color: var(--text); font-size: 0.95rem;">UI/UX 평가</span>
                    </label>
                </div>
                
                <!-- 의뢰 내용 -->
                <div style="margin-bottom: 30px;">
                    <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">의뢰 내용 *</label>
                    <textarea name="message" required rows="6" placeholder="프로젝트에 대해 자세히 설명해주세요" style="width: 100%; padding: 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem; font-family: inherit; resize: vertical;"></textarea>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 30px;">
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">프로젝트 예산</label>
                        <select name="budget" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem; cursor: pointer;">
                            <option value="">선택하세요</option>
                            <option value="1천만원 미만">1천만원 미만</option>
                            <option value="1천만원 ~ 3천만원">1천만원 ~ 3천만원</option>
                            <option value="3천만원 ~ 5천만원">3천만원 ~ 5천만원</option>
                            <option value="5천만원 ~ 1억원">5천만원 ~ 1억원</option>
                            <option value="1억원 이상">1억원 이상</option>
                        </select>
                    </div>
                    
                    <div>
                        <label style="display: block; margin-bottom: 8px; color: var(--text-muted); font-size: 0.9rem;">프로젝트 일정</label>
                        <select name="schedule" style="width: 100%; padding: 12px 16px; background: rgba(255, 255, 255, 0.05); border: 1px solid var(--border); border-radius: 10px; color: var(--text); font-size: 1rem; cursor: pointer;">
                            <option value="">선택하세요</option>
                            <option value="1개월 이내">1개월 이내</option>
                            <option value="2~3개월">2~3개월</option>
                            <option value="3~6개월">3~6개월</option>
                            <option value="6개월 이상">6개월 이상</option>
                            <option value="협의 가능">협의 가능</option>
                        </select>
                    </div>
                </div>
                
                <!-- 개인정보 동의 -->
                <div style="margin-bottom: 30px; padding: 20px; background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border); border-radius: 10px;">
                    <label style="display: flex; align-items: flex-start; gap: 10px; cursor: pointer;">
                        <input type="checkbox" name="privacy" required style="width: 18px; height: 18px; margin-top: 2px; cursor: pointer;">
                        <div style="flex: 1;">
                            <span style="color: var(--text); font-weight: 600; display: block; margin-bottom: 10px;">개인정보 수집·이용 동의 *</span>
                            <div style="color: var(--text-muted); font-size: 0.85rem; line-height: 1.6;">
                                <p style="margin-bottom: 8px;"><strong>수집항목:</strong> 회사명, 이름, 연락처, 이메일, 직위, URL</p>
                                <p style="margin-bottom: 8px;"><strong>수집목적:</strong> 서비스 제공, 상담 및 컨설팅 운영</p>
                                <p><strong>보유기간:</strong> 3년 (관련 법령에 따라 보관)</p>
                            </div>
                        </div>
                    </label>
                </div>
                
                <!-- 제출 버튼 -->
                <button type="submit" style="width: 100%; padding: 18px; background: linear-gradient(135deg, #0066FF, #0052CC); color: white; border: none; border-radius: 12px; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: all 0.3s; box-shadow: 0 10px 30px rgba(0, 102, 255, 0.3);">
                    문의하기 →
                </button>
                
                <p style="text-align: center; margin-top: 20px; color: var(--text-muted); font-size: 0.9rem;">
                    미래 파트너로 엠진을 고려해 주셔서 감사합니다.<br>
                    빠르게 연락드리겠습니다.
                </p>
            </form>
        </div>
    </section>
    
    <script>
        document.getElementById('contactForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.textContent;
            
            // 버튼 비활성화
            submitBtn.disabled = true;
            submitBtn.textContent = '전송 중...';
            
            const formData = new FormData(this);
            
            // 프로젝트 형태 수집
            const projectTypes = [];
            document.querySelectorAll('input[name="project_type"]:checked').forEach(cb => {
                projectTypes.push(cb.value);
            });
            
            // API로 전송할 데이터
            const contactData = {
                company: formData.get('company'),
                position: formData.get('position'),
                name: formData.get('name'),
                phone: formData.get('phone'),
                email: formData.get('email'),
                url: formData.get('url'),
                project_type: projectTypes,
                message: formData.get('message'),
                budget: formData.get('budget'),
                schedule: formData.get('schedule'),
                privacy_agreed: formData.get('privacy') === 'on' ? true : false
            };
            
            try {
                // API 호출
                const response = await fetch('/api/contact', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(contactData)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // 성공 메시지
                    alert('✅ 문의가 성공적으로 접수되었습니다!\\n\\n빠른 시일 내에 담당자가 연락드리겠습니다.\\n감사합니다.');
                    
                    // 폼 초기화
                    this.reset();
                    
                    // 체크박스 스타일 리셋
                    document.querySelectorAll('label:has(input[type="checkbox"])').forEach(label => {
                        label.style.background = 'rgba(255, 255, 255, 0.02)';
                        label.style.borderColor = 'var(--border)';
                    });
                    
                    // 추가로 CEO에게 메일 발송 (옵션)
                    const subject = encodeURIComponent(\`[AutoAnalyzer] \${contactData.company} - 프로젝트 문의\`);
                    const emailBody = \`
=== MGINE AutoAnalyzer 프로젝트 문의 ===

[의뢰인 정보]
회사명: \${contactData.company}
직위: \${contactData.position || '-'}
이름: \${contactData.name}
연락처: \${contactData.phone}
이메일: \${contactData.email}
URL: \${contactData.url || '-'}

[프로젝트 정보]
희망 프로젝트 형태: \${projectTypes.join(', ') || '-'}
프로젝트 예산: \${contactData.budget || '-'}
프로젝트 일정: \${contactData.schedule || '-'}

[의뢰 내용]
\${contactData.message}

---
이 메일은 MGINE AutoAnalyzer 홈페이지에서 발송되었습니다.
                    \`.trim();
                    
                    const body = encodeURIComponent(emailBody);
                    
                    // 자동으로 메일 클라이언트 열기 (백업)
                    setTimeout(() => {
                        window.open(\`mailto:ceo@mgine.co.kr?subject=\${subject}&body=\${body}\`, '_blank');
                    }, 1000);
                    
                } else {
                    throw new Error(result.error || '전송 실패');
                }
                
            } catch (error) {
                console.error('Contact form error:', error);
                alert('❌ 문의 접수 중 오류가 발생했습니다.\\n\\n직접 이메일로 연락주시기 바랍니다.\\nceo@mgine.co.kr');
            } finally {
                // 버튼 활성화
                submitBtn.disabled = false;
                submitBtn.textContent = originalBtnText;
            }
        });
        
        // 체크박스 스타일 효과
        document.querySelectorAll('label:has(input[type="checkbox"])').forEach(label => {
            const checkbox = label.querySelector('input[type="checkbox"]');
            checkbox.addEventListener('change', function() {
                if (this.checked) {
                    label.style.background = 'rgba(0, 102, 255, 0.1)';
                    label.style.borderColor = 'var(--primary)';
                } else {
                    label.style.background = 'rgba(255, 255, 255, 0.02)';
                    label.style.borderColor = 'var(--border)';
                }
            });
        });
    <\/script>
    </main>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="footer-brand">
                <h3>AutoAnalyzer</h3>
                <p>
                    AI 기반 웹사이트 UI/UX 자동 평가 시스템<br>
                    by MGINE Interactive
                </p>
                <p>
                    <a href="mailto:ceo@mgine.co.kr" style="color: var(--primary);">
                        ceo@mgine.co.kr
                    </a>
                </p>
            </div>
            
            <div class="footer-section">
                <h4>Product</h4>
                <ul>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#process">Process</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Company</h4>
                <ul>
                    <li><a href="http://mgine.co.kr" target="_blank">MGINE Interactive</a></li>
                    <li><a href="http://mgine.co.kr" target="_blank">Portfolio</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Technology</h4>
                <ul>
                    <li><a href="#">Nielsen Principles</a></li>
                    <li><a href="#">KRDS Based</a></li>
                    <li><a href="#">AI Learning</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2026 MGINE Interactive. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        // Scroll to Top Button Functionality
        const scrollToTopBtn = document.getElementById('scrollToTopBtn');
        
        // 스크롤 이벤트 리스너
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                scrollToTopBtn.classList.add('show');
            } else {
                scrollToTopBtn.classList.remove('show');
            }
        });
        
        // 맨 위로 스크롤 함수
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
        
        // 부드러운 스크롤 함수
        function smoothScrollTo(targetId) {
            console.log('smoothScrollTo called with:', targetId);
            
            const targetElement = document.getElementById(targetId);
            console.log('Target element:', targetElement);
            
            if (targetElement) {
                // header 높이 계산
                const header = document.querySelector('.header');
                const headerHeight = header ? header.offsetHeight : 80;
                
                // 타겟 위치에서 header 높이만큼 빼기
                const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
                
                console.log('Scrolling to position:', targetPosition);
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            } else {
                console.error('Element not found:', targetId);
            }
        }
        
        // 모든 앵커 링크에 부드러운 스크롤 적용 (footer 등)
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('a[href^="#"]:not([onclick])').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    const href = this.getAttribute('href');
                    if (href && href !== '#') {
                        const targetId = href.substring(1);
                        smoothScrollTo(targetId);
                    }
                });
            });
        });
    <\/script>
</body>
</html>
`,c3=`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MGINE AutoAnalyzer - 로그인</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
</head>
<body class="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 min-h-screen flex items-center justify-center">
    <div class="max-w-md w-full mx-4">
        <div class="text-center mb-8">
            <a href="/" class="inline-block">
                <h1 class="text-4xl font-bold mb-2">
                    <span class="bg-gradient-to-r from-blue-400 to-cyan-300 text-transparent bg-clip-text">MGINE</span>
                    <span class="text-white"> AutoAnalyzer</span>
                </h1>
            </a>
            <p class="text-gray-400">AI 기반 웹사이트 UI/UX 자동 평가</p>
        </div>

        <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20">
            <div id="loginForm">
                <h2 class="text-2xl font-bold text-white mb-6">로그인</h2>
                <form onsubmit="handleLogin(event)">
                    <div class="mb-4">
                        <label class="block text-gray-300 mb-2">이메일</label>
                        <input type="email" id="email" required
                            class="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400">
                    </div>
                    <div class="mb-6">
                        <label class="block text-gray-300 mb-2">비밀번호</label>
                        <input type="password" id="password" required
                            class="w-full px-4 py-3 bg-white/5 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400">
                    </div>
                    <div id="errorMessage" class="mb-4 text-red-400 text-sm hidden"></div>
                    <button type="submit" id="loginBtn"
                        class="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-cyan-500 transition-all">
                        로그인
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        async function handleLogin(event) {
            event.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorDiv = document.getElementById('errorMessage');
            const loginBtn = document.getElementById('loginBtn');

            errorDiv.classList.add('hidden');
            loginBtn.disabled = true;
            loginBtn.textContent = '로그인 중...';

            try {
                const response = await fetch('/api/auth/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await response.json();

                if (data.success) {
                    localStorage.setItem('session_id', data.session_id);
                    localStorage.setItem('user', JSON.stringify(data.user));
                    window.location.href = '/analyzer';
                } else {
                    errorDiv.textContent = data.error || '로그인에 실패했습니다.';
                    errorDiv.classList.remove('hidden');
                }
            } catch (error) {
                errorDiv.textContent = '서버 오류가 발생했습니다.';
                errorDiv.classList.remove('hidden');
            } finally {
                loginBtn.disabled = false;
                loginBtn.textContent = '로그인';
            }
        }

        // 이미 로그인된 경우 리다이렉트
        const sessionId = localStorage.getItem('session_id');
        if (sessionId) {
            fetch('/api/auth/me', {
                headers: { 'X-Session-ID': sessionId }
            }).then(res => res.json()).then(data => {
                if (data.success) {
                    window.location.href = '/analyzer';
                }
            });
        }
    <\/script>
</body>
</html>
`,l3=`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MGINE AutoAnalyzer - 관리자 대시보드</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 min-h-screen">
    <!-- 헤더 -->
    <header class="bg-black/30 backdrop-blur-lg border-b border-white/10 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <a href="/" class="flex items-center gap-3">
                <h1 class="text-2xl font-bold">
                    <span class="bg-gradient-to-r from-blue-400 to-cyan-300 text-transparent bg-clip-text">MGINE</span>
                    <span class="text-white"> AutoAnalyzer</span>
                </h1>
            </a>
            <div class="flex items-center gap-4">
                <div id="userInfo" class="text-white"></div>
                <button onclick="logout()" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-sign-out-alt mr-2"></i>로그아웃
                </button>
            </div>
        </div>
    </header>

    <!-- 메인 컨텐츠 -->
    <main class="max-w-7xl mx-auto px-6 py-8">
        <div class="mb-8">
            <h2 class="text-3xl font-bold text-white mb-2">관리자 대시보드</h2>
            <p class="text-gray-400">평가 보정 데이터 관리 및 학습 데이터 현황</p>
        </div>

        <!-- 탭 네비게이션 -->
        <div class="mb-6">
            <div class="flex gap-4 border-b border-white/20">
                <button onclick="switchTab('dashboard')" id="tab-dashboard" class="tab-button active px-6 py-3 text-white font-semibold border-b-2 border-blue-500 transition-colors">
                    <i class="fas fa-chart-line mr-2"></i>대시보드
                </button>
                <button onclick="switchTab('accounts')" id="tab-accounts" class="tab-button px-6 py-3 text-gray-400 font-semibold border-b-2 border-transparent hover:text-white transition-colors">
                    <i class="fas fa-users mr-2"></i>계정 관리
                </button>
                <button onclick="switchTab('contacts')" id="tab-contacts" class="tab-button px-6 py-3 text-gray-400 font-semibold border-b-2 border-transparent hover:text-white transition-colors">
                    <i class="fas fa-envelope mr-2"></i>문의 관리
                </button>
            </div>
        </div>

        <!-- 대시보드 탭 -->
        <div id="content-dashboard" class="tab-content">
            <!-- 통계 카드 -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-gray-300 text-sm">총 보정 건수</h3>
                    <i class="fas fa-edit text-blue-400 text-2xl"></i>
                </div>
                <p id="totalCorrections" class="text-4xl font-bold text-white">-</p>
            </div>
            <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-gray-300 text-sm">평균 점수 변화</h3>
                    <i class="fas fa-chart-line text-cyan-400 text-2xl"></i>
                </div>
                <p id="avgScoreDiff" class="text-4xl font-bold text-white">-</p>
            </div>
            <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div class="flex items-center justify-between mb-2">
                    <h3 class="text-gray-300 text-sm">학습 데이터 항목</h3>
                    <i class="fas fa-database text-green-400 text-2xl"></i>
                </div>
                <p id="totalItems" class="text-4xl font-bold text-white">-</p>
            </div>
        </div>

        <!-- 보정 데이터 목록 -->
        <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-xl font-bold text-white">최근 보정 데이터</h3>
                <button onclick="refreshData()" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors">
                    <i class="fas fa-sync-alt mr-2"></i>새로고침
                </button>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead>
                        <tr class="border-b border-white/20">
                            <th class="pb-3 text-gray-300 font-semibold">날짜</th>
                            <th class="pb-3 text-gray-300 font-semibold">URL</th>
                            <th class="pb-3 text-gray-300 font-semibold">항목</th>
                            <th class="pb-3 text-gray-300 font-semibold">원래 점수</th>
                            <th class="pb-3 text-gray-300 font-semibold">수정 점수</th>
                            <th class="pb-3 text-gray-300 font-semibold">차이</th>
                            <th class="pb-3 text-gray-300 font-semibold">관리자</th>
                        </tr>
                    </thead>
                    <tbody id="correctionsTable">
                        <tr>
                            <td colspan="7" class="text-center text-gray-400 py-8">
                                <i class="fas fa-spinner fa-spin text-2xl mb-2"></i>
                                <p>데이터를 불러오는 중...</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 학습 데이터 인사이트 -->
        <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 mt-6">
            <h3 class="text-xl font-bold text-white mb-6">학습 데이터 인사이트</h3>
            <div id="learningInsights">
                <p class="text-center text-gray-400 py-8">
                    <i class="fas fa-spinner fa-spin text-2xl mb-2"></i><br>
                    인사이트를 분석하는 중...
                </p>
            </div>
        </div>
        </div>

        <!-- 계정 관리 탭 -->
        <div id="content-accounts" class="tab-content hidden">
            <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold text-white">계정 목록</h3>
                    <button onclick="showCreateAccountModal()" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg transition-colors">
                        <i class="fas fa-plus mr-2"></i>계정 추가
                    </button>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="border-b border-white/20">
                                <th class="pb-3 text-gray-300 font-semibold">이메일</th>
                                <th class="pb-3 text-gray-300 font-semibold">이름</th>
                                <th class="pb-3 text-gray-300 font-semibold">역할</th>
                                <th class="pb-3 text-gray-300 font-semibold">상태</th>
                                <th class="pb-3 text-gray-300 font-semibold">생성일</th>
                                <th class="pb-3 text-gray-300 font-semibold">마지막 로그인</th>
                                <th class="pb-3 text-gray-300 font-semibold">관리</th>
                            </tr>
                        </thead>
                        <tbody id="accountsTable">
                            <tr>
                                <td colspan="7" class="text-center text-gray-400 py-8">
                                    <i class="fas fa-spinner fa-spin text-2xl mb-2"></i>
                                    <p>계정을 불러오는 중...</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- 문의 관리 탭 -->
        <div id="content-contacts" class="tab-content hidden">
            <div class="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold text-white">문의 목록</h3>
                    <div class="flex gap-2">
                        <select id="contactStatusFilter" onchange="loadContacts()" class="bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20">
                            <option value="all">전체</option>
                            <option value="pending">대기중</option>
                            <option value="processing">처리중</option>
                            <option value="completed">완료</option>
                            <option value="rejected">거절</option>
                        </select>
                        <button onclick="loadContacts()" class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg transition-colors">
                            <i class="fas fa-sync-alt mr-2"></i>새로고침
                        </button>
                    </div>
                </div>
                
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead>
                            <tr class="border-b border-white/20">
                                <th class="pb-3 text-gray-300 font-semibold">날짜</th>
                                <th class="pb-3 text-gray-300 font-semibold">회사명</th>
                                <th class="pb-3 text-gray-300 font-semibold">담당자</th>
                                <th class="pb-3 text-gray-300 font-semibold">연락처</th>
                                <th class="pb-3 text-gray-300 font-semibold">이메일</th>
                                <th class="pb-3 text-gray-300 font-semibold">상태</th>
                                <th class="pb-3 text-gray-300 font-semibold">관리</th>
                            </tr>
                        </thead>
                        <tbody id="contactsTable">
                            <tr>
                                <td colspan="7" class="text-center text-gray-400 py-8">
                                    <i class="fas fa-spinner fa-spin text-2xl mb-2"></i>
                                    <p>문의를 불러오는 중...</p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- 계정 생성/수정 모달 -->
    <div id="accountModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50" onclick="if(event.target === this) closeAccountModal()">
        <div class="bg-gray-900 rounded-2xl p-8 max-w-md w-full mx-4 border border-white/20">
            <h3 id="modalTitle" class="text-2xl font-bold text-white mb-6">계정 추가</h3>
            <form id="accountForm" onsubmit="saveAccount(event)">
                <input type="hidden" id="accountId" value="">
                
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">이메일 *</label>
                    <input type="email" id="accountEmail" required class="w-full bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:border-blue-500 focus:outline-none">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">이름 *</label>
                    <input type="text" id="accountName" required class="w-full bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:border-blue-500 focus:outline-none">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">비밀번호 <span id="passwordHint" class="text-sm text-gray-400">(8자 이상, 대소문자 + 숫자)</span></label>
                    <input type="password" id="accountPassword" class="w-full bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:border-blue-500 focus:outline-none">
                </div>
                
                <div class="mb-4">
                    <label class="block text-gray-300 mb-2">역할 *</label>
                    <select id="accountRole" required class="w-full bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:border-blue-500 focus:outline-none">
                        <option value="user">일반 사용자</option>
                        <option value="admin">관리자</option>
                    </select>
                </div>
                
                <div id="accountStatusDiv" class="mb-6 hidden">
                    <label class="flex items-center gap-2 text-gray-300">
                        <input type="checkbox" id="accountIsActive" class="w-5 h-5">
                        <span>계정 활성화</span>
                    </label>
                </div>
                
                <div class="flex gap-3">
                    <button type="button" onclick="closeAccountModal()" class="flex-1 bg-gray-700 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors">
                        취소
                    </button>
                    <button type="submit" class="flex-1 bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-colors">
                        저장
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- 문의 상세보기 모달 -->
    <div id="contactModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onclick="if(event.target === this) closeContactModal()">
        <div class="bg-gray-900 rounded-2xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-white/20">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-2xl font-bold text-white">문의 상세 정보</h3>
                <button onclick="closeContactModal()" class="text-gray-400 hover:text-white">
                    <i class="fas fa-times text-2xl"></i>
                </button>
            </div>
            
            <div id="contactDetail" class="space-y-6">
                <!-- 문의 정보가 여기에 로드됩니다 -->
            </div>
            
            <div class="mt-6 pt-6 border-t border-white/20">
                <h4 class="text-lg font-semibold text-white mb-4">상태 관리</h4>
                <div class="flex gap-4">
                    <select id="contactStatus" class="flex-1 bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20">
                        <option value="pending">대기중</option>
                        <option value="processing">처리중</option>
                        <option value="completed">완료</option>
                        <option value="rejected">거절</option>
                    </select>
                    <button onclick="updateContactStatus()" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-colors">
                        상태 업데이트
                    </button>
                </div>
                <div class="mt-4">
                    <label class="block text-gray-300 mb-2">관리자 메모</label>
                    <textarea id="contactAdminNote" rows="3" class="w-full bg-white/10 text-white px-4 py-2 rounded-lg border border-white/20 focus:border-blue-500 focus:outline-none" placeholder="내부 메모를 입력하세요..."></textarea>
                </div>
            </div>
            
            <div class="flex gap-3 mt-6">
                <button onclick="closeContactModal()" class="flex-1 bg-gray-700 hover:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors">
                    닫기
                </button>
            </div>
        </div>
    </div>

    <script>
        let currentUser = null;

        // 페이지 로드 시 초기화
        document.addEventListener('DOMContentLoaded', async () => {
            await checkAuth();
            await loadDashboardData();
        });

        // 인증 체크
        async function checkAuth() {
            const sessionId = localStorage.getItem('session_id');
            if (!sessionId) {
                window.location.href = '/login';
                return;
            }

            try {
                const response = await fetch('/api/auth/me', {
                    headers: { 'X-Session-ID': sessionId }
                });

                const data = await response.json();
                
                if (!data.success) {
                    localStorage.removeItem('session_id');
                    window.location.href = '/login';
                    return;
                }

                currentUser = data.user;

                // 관리자 권한 체크
                if (currentUser.role !== 'admin') {
                    alert('관리자 권한이 필요합니다.');
                    window.location.href = '/analyzer';
                    return;
                }

                // 사용자 정보 표시
                document.getElementById('userInfo').innerHTML = \`
                    <span class="text-sm">\${currentUser.name} (\${currentUser.role})</span>
                \`;
            } catch (error) {
                console.error('Auth check error:', error);
                window.location.href = '/login';
            }
        }

        // 대시보드 데이터 로드
        async function loadDashboardData() {
            const sessionId = localStorage.getItem('session_id');
            
            try {
                // 보정 데이터 조회
                const correctionsResponse = await fetch('/api/admin/corrections?limit=20', {
                    headers: { 'X-Session-ID': sessionId }
                });
                const correctionsData = await correctionsResponse.json();

                // 학습 인사이트 조회
                const insightsResponse = await fetch('/api/learning-insights', {
                    headers: { 'X-Session-ID': sessionId }
                });
                const insightsData = await insightsResponse.json();

                // 통계 업데이트
                document.getElementById('totalCorrections').textContent = correctionsData.total || 0;
                
                if (insightsData.stats) {
                    const avgDiff = parseFloat(insightsData.stats.avg_score_diff || 0).toFixed(2);
                    document.getElementById('avgScoreDiff').textContent = avgDiff > 0 ? \`+\${avgDiff}\` : avgDiff;
                }
                
                document.getElementById('totalItems').textContent = insightsData.summary?.length || 0;

                // 보정 데이터 테이블 렌더링
                renderCorrectionsTable(correctionsData.corrections || []);

                // 학습 인사이트 렌더링
                renderLearningInsights(insightsData.summary || []);

            } catch (error) {
                console.error('Error loading dashboard data:', error);
                alert('데이터를 불러오는 중 오류가 발생했습니다.');
            }
        }

        // 보정 데이터 테이블 렌더링
        function renderCorrectionsTable(corrections) {
            const tbody = document.getElementById('correctionsTable');
            
            if (corrections.length === 0) {
                tbody.innerHTML = \`
                    <tr>
                        <td colspan="7" class="text-center text-gray-400 py-8">보정 데이터가 없습니다.</td>
                    </tr>
                \`;
                return;
            }

            tbody.innerHTML = corrections.map(c => {
                const date = new Date(c.corrected_at).toLocaleString('ko-KR');
                const scoreDiff = (c.corrected_score - c.original_score).toFixed(1);
                const diffColor = scoreDiff > 0 ? 'text-green-400' : scoreDiff < 0 ? 'text-red-400' : 'text-gray-400';
                
                return \`
                    <tr class="border-b border-white/10 hover:bg-white/5">
                        <td class="py-3 text-gray-300 text-sm">\${date}</td>
                        <td class="py-3 text-gray-300 text-sm max-w-xs truncate" title="\${c.url}">\${c.url}</td>
                        <td class="py-3 text-white font-medium">\${c.item_name}</td>
                        <td class="py-3 text-gray-400">\${c.original_score.toFixed(1)}</td>
                        <td class="py-3 text-cyan-400 font-bold">\${c.corrected_score.toFixed(1)}</td>
                        <td class="py-3 \${diffColor} font-bold">\${scoreDiff > 0 ? '+' : ''}\${scoreDiff}</td>
                        <td class="py-3 text-gray-300 text-sm">\${c.admin_name || 'N/A'}</td>
                    </tr>
                \`;
            }).join('');
        }

        // 학습 인사이트 렌더링
        function renderLearningInsights(summary) {
            const container = document.getElementById('learningInsights');
            
            if (summary.length === 0) {
                container.innerHTML = '<p class="text-center text-gray-400">학습 데이터가 충분하지 않습니다.</p>';
                return;
            }

            // 수정 횟수가 많은 순으로 정렬
            const sorted = [...summary].sort((a, b) => b.correction_count - a.correction_count).slice(0, 10);

            container.innerHTML = \`
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    \${sorted.map(item => \`
                        <div class="bg-white/5 rounded-lg p-4 border border-white/10">
                            <h4 class="text-white font-semibold mb-2">\${item.item_name}</h4>
                            <div class="grid grid-cols-2 gap-2 text-sm">
                                <div>
                                    <span class="text-gray-400">보정 횟수:</span>
                                    <span class="text-white font-bold ml-1">\${item.correction_count}</span>
                                </div>
                                <div>
                                    <span class="text-gray-400">평균 변화:</span>
                                    <span class="text-cyan-400 font-bold ml-1">\${(item.avg_score_diff || 0).toFixed(2)}</span>
                                </div>
                                <div>
                                    <span class="text-gray-400">원래 평균:</span>
                                    <span class="text-white ml-1">\${(item.avg_original_score || 0).toFixed(2)}</span>
                                </div>
                                <div>
                                    <span class="text-gray-400">수정 평균:</span>
                                    <span class="text-white ml-1">\${(item.avg_corrected_score || 0).toFixed(2)}</span>
                                </div>
                            </div>
                        </div>
                    \`).join('')}
                </div>
            \`;
        }

        // 새로고침
        async function refreshData() {
            await loadDashboardData();
        }

        // 로그아웃
        function logout() {
            const sessionId = localStorage.getItem('session_id');
            fetch('/api/auth/logout', {
                method: 'POST',
                headers: { 'X-Session-ID': sessionId }
            }).then(() => {
                localStorage.removeItem('session_id');
                localStorage.removeItem('user');
                window.location.href = '/';
            });
        }

        // ==================== 탭 전환 ====================
        function switchTab(tabName) {
            // 모든 탭 버튼 비활성화
            document.querySelectorAll('.tab-button').forEach(btn => {
                btn.classList.remove('active', 'border-blue-500', 'text-white');
                btn.classList.add('text-gray-400', 'border-transparent');
            });
            
            // 선택된 탭 버튼 활성화
            const activeBtn = document.getElementById(\`tab-\${tabName}\`);
            activeBtn.classList.add('active', 'border-blue-500', 'text-white');
            activeBtn.classList.remove('text-gray-400', 'border-transparent');
            
            // 모든 탭 콘텐츠 숨기기
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.add('hidden');
            });
            
            // 선택된 탭 콘텐츠 표시
            document.getElementById(\`content-\${tabName}\`).classList.remove('hidden');
            
            // 탭별 데이터 로드
            if (tabName === 'accounts') {
                loadAccounts();
            } else if (tabName === 'contacts') {
                loadContacts();
            }
        }

        // ==================== 계정 관리 ====================
        async function loadAccounts() {
            const sessionId = localStorage.getItem('session_id');
            const tbody = document.getElementById('accountsTable');
            
            try {
                const response = await fetch('/api/admin/accounts', {
                    headers: { 'X-Session-ID': sessionId }
                });
                
                const data = await response.json();
                
                if (!data.accounts || data.accounts.length === 0) {
                    tbody.innerHTML = \`
                        <tr>
                            <td colspan="7" class="text-center text-gray-400 py-8">
                                계정이 없습니다.
                            </td>
                        </tr>
                    \`;
                    return;
                }
                
                tbody.innerHTML = data.accounts.map(account => {
                    const isCurrentUser = currentUser && currentUser.id === account.id;
                    const statusBadge = account.is_active 
                        ? '<span class="px-2 py-1 bg-green-500/20 text-green-400 rounded text-xs">활성</span>'
                        : '<span class="px-2 py-1 bg-red-500/20 text-red-400 rounded text-xs">비활성</span>';
                    
                    const roleBadge = account.role === 'admin'
                        ? '<span class="px-2 py-1 bg-blue-500/20 text-blue-400 rounded text-xs">관리자</span>'
                        : '<span class="px-2 py-1 bg-gray-500/20 text-gray-400 rounded text-xs">사용자</span>';
                    
                    return \`
                        <tr class="border-b border-white/10">
                            <td class="py-3 text-white">\${account.email}</td>
                            <td class="py-3 text-white">\${account.name}</td>
                            <td class="py-3">\${roleBadge}</td>
                            <td class="py-3">\${statusBadge}</td>
                            <td class="py-3 text-gray-400 text-sm">\${new Date(account.created_at).toLocaleDateString('ko-KR')}</td>
                            <td class="py-3 text-gray-400 text-sm">\${account.last_login_at ? new Date(account.last_login_at).toLocaleDateString('ko-KR') : '-'}</td>
                            <td class="py-3">
                                <div class="flex gap-2">
                                    <button onclick="editAccount(\${account.id}, '\${account.email}', '\${account.name}', '\${account.role}', \${account.is_active})" 
                                            class="text-blue-400 hover:text-blue-300">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    \${!isCurrentUser ? \`
                                        <button onclick="deleteAccount(\${account.id}, '\${account.email}')" 
                                                class="text-red-400 hover:text-red-300">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    \` : ''}
                                </div>
                            </td>
                        </tr>
                    \`;
                }).join('');
                
            } catch (error) {
                console.error('Error loading accounts:', error);
                tbody.innerHTML = \`
                    <tr>
                        <td colspan="7" class="text-center text-red-400 py-8">
                            계정을 불러오는 중 오류가 발생했습니다.
                        </td>
                    </tr>
                \`;
            }
        }

        function showCreateAccountModal() {
            document.getElementById('modalTitle').textContent = '계정 추가';
            document.getElementById('accountId').value = '';
            document.getElementById('accountEmail').value = '';
            document.getElementById('accountEmail').disabled = false;
            document.getElementById('accountName').value = '';
            document.getElementById('accountPassword').value = '';
            document.getElementById('accountPassword').required = true;
            document.getElementById('passwordHint').textContent = '(8자 이상, 대소문자 + 숫자) *';
            document.getElementById('accountRole').value = 'user';
            document.getElementById('accountStatusDiv').classList.add('hidden');
            document.getElementById('accountModal').classList.remove('hidden');
        }

        function editAccount(id, email, name, role, is_active) {
            document.getElementById('modalTitle').textContent = '계정 수정';
            document.getElementById('accountId').value = id;
            document.getElementById('accountEmail').value = email;
            document.getElementById('accountEmail').disabled = true;
            document.getElementById('accountName').value = name;
            document.getElementById('accountPassword').value = '';
            document.getElementById('accountPassword').required = false;
            document.getElementById('passwordHint').textContent = '(변경하지 않으려면 비워두세요)';
            document.getElementById('accountRole').value = role;
            document.getElementById('accountIsActive').checked = is_active;
            document.getElementById('accountStatusDiv').classList.remove('hidden');
            document.getElementById('accountModal').classList.remove('hidden');
        }

        function closeAccountModal() {
            document.getElementById('accountModal').classList.add('hidden');
        }

        async function saveAccount(event) {
            event.preventDefault();
            const sessionId = localStorage.getItem('session_id');
            const id = document.getElementById('accountId').value;
            const email = document.getElementById('accountEmail').value;
            const name = document.getElementById('accountName').value;
            const password = document.getElementById('accountPassword').value;
            const role = document.getElementById('accountRole').value;
            const is_active = document.getElementById('accountIsActive').checked;
            
            const isEdit = !!id;
            const url = isEdit ? \`/api/admin/accounts/\${id}\` : '/api/admin/accounts';
            const method = isEdit ? 'PATCH' : 'POST';
            
            const body = { name, role };
            if (!isEdit) body.email = email;
            if (password) body.password = password;
            if (isEdit) body.is_active = is_active;
            
            try {
                const response = await fetch(url, {
                    method,
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify(body)
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert(isEdit ? '계정이 수정되었습니다.' : '계정이 생성되었습니다.');
                    closeAccountModal();
                    loadAccounts();
                } else {
                    alert('오류: ' + data.error);
                }
            } catch (error) {
                console.error('Error saving account:', error);
                alert('계정 저장 중 오류가 발생했습니다.');
            }
        }

        async function deleteAccount(id, email) {
            if (!confirm(\`정말로 \${email} 계정을 삭제하시겠습니까?\\n이 작업은 되돌릴 수 없습니다.\`)) {
                return;
            }
            
            const sessionId = localStorage.getItem('session_id');
            
            try {
                const response = await fetch(\`/api/admin/accounts/\${id}\`, {
                    method: 'DELETE',
                    headers: { 'X-Session-ID': sessionId }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('계정이 삭제되었습니다.');
                    loadAccounts();
                } else {
                    alert('오류: ' + data.error);
                }
            } catch (error) {
                console.error('Error deleting account:', error);
                alert('계정 삭제 중 오류가 발생했습니다.');
            }
        }

        // ==================== 문의 관리 ====================
        async function loadContacts() {
            const sessionId = localStorage.getItem('session_id');
            const tbody = document.getElementById('contactsTable');
            const status = document.getElementById('contactStatusFilter').value;
            
            try {
                const response = await fetch(\`/api/admin/contacts?status=\${status}&limit=50\`, {
                    headers: { 'X-Session-ID': sessionId }
                });
                
                const data = await response.json();
                
                if (!data.contacts || data.contacts.length === 0) {
                    tbody.innerHTML = \`
                        <tr>
                            <td colspan="7" class="text-center text-gray-400 py-8">
                                문의가 없습니다.
                            </td>
                        </tr>
                    \`;
                    return;
                }
                
                tbody.innerHTML = data.contacts.map(contact => {
                    const statusColors = {
                        pending: 'yellow',
                        processing: 'blue',
                        completed: 'green',
                        rejected: 'red'
                    };
                    const statusNames = {
                        pending: '대기중',
                        processing: '처리중',
                        completed: '완료',
                        rejected: '거절'
                    };
                    const color = statusColors[contact.status] || 'gray';
                    const statusBadge = \`<span class="px-2 py-1 bg-\${color}-500/20 text-\${color}-400 rounded text-xs">\${statusNames[contact.status] || contact.status}</span>\`;
                    
                    return \`
                        <tr class="border-b border-white/10 cursor-pointer hover:bg-white/5" onclick="viewContact(\${contact.id})">
                            <td class="py-3 text-gray-400 text-sm">\${new Date(contact.created_at).toLocaleDateString('ko-KR')}</td>
                            <td class="py-3 text-white">\${contact.company}</td>
                            <td class="py-3 text-white">\${contact.name}</td>
                            <td class="py-3 text-gray-400 text-sm">\${contact.phone}</td>
                            <td class="py-3 text-gray-400 text-sm">\${contact.email}</td>
                            <td class="py-3">\${statusBadge}</td>
                            <td class="py-3">
                                <button onclick="event.stopPropagation(); viewContact(\${contact.id})" class="text-blue-400 hover:text-blue-300">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </td>
                        </tr>
                    \`;
                }).join('');
                
            } catch (error) {
                console.error('Error loading contacts:', error);
                tbody.innerHTML = \`
                    <tr>
                        <td colspan="7" class="text-center text-red-400 py-8">
                            문의를 불러오는 중 오류가 발생했습니다.
                        </td>
                    </tr>
                \`;
            }
        }

        let currentContactId = null;

        async function viewContact(id) {
            currentContactId = id;
            const sessionId = localStorage.getItem('session_id');
            
            try {
                const response = await fetch(\`/api/admin/contacts/\${id}\`, {
                    headers: { 'X-Session-ID': sessionId }
                });
                
                const data = await response.json();
                
                if (!data.contact) {
                    alert('문의를 불러올 수 없습니다.');
                    return;
                }
                
                const contact = data.contact;
                
                // 상태 배지 색상
                const statusColors = {
                    pending: 'yellow',
                    processing: 'blue',
                    completed: 'green',
                    rejected: 'red'
                };
                const statusNames = {
                    pending: '대기중',
                    processing: '처리중',
                    completed: '완료',
                    rejected: '거절'
                };
                const color = statusColors[contact.status] || 'gray';
                const statusBadge = \`<span class="px-3 py-1 bg-\${color}-500/20 text-\${color}-400 rounded-full text-sm font-semibold">\${statusNames[contact.status] || contact.status}</span>\`;
                
                // 상세 정보 렌더링
                document.getElementById('contactDetail').innerHTML = \`
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-400 text-sm">문의 ID: #\${contact.id}</p>
                            <p class="text-gray-400 text-sm mt-1">접수일시: \${new Date(contact.created_at).toLocaleString('ko-KR')}</p>
                        </div>
                        \${statusBadge}
                    </div>
                    
                    <div class="bg-white/5 rounded-xl p-6 border border-white/10">
                        <h4 class="text-lg font-semibold text-white mb-4"><i class="fas fa-user mr-2 text-blue-400"></i>의뢰인 정보</h4>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <p class="text-gray-400 text-sm">회사명</p>
                                <p class="text-white font-semibold">\${contact.company}</p>
                            </div>
                            <div>
                                <p class="text-gray-400 text-sm">담당자</p>
                                <p class="text-white font-semibold">\${contact.name}</p>
                            </div>
                            <div>
                                <p class="text-gray-400 text-sm">직위</p>
                                <p class="text-white">\${contact.position || '-'}</p>
                            </div>
                            <div>
                                <p class="text-gray-400 text-sm">연락처</p>
                                <p class="text-white">\${contact.phone}</p>
                            </div>
                            <div class="col-span-2">
                                <p class="text-gray-400 text-sm">이메일</p>
                                <p class="text-white"><a href="mailto:\${contact.email}" class="text-blue-400 hover:text-blue-300">\${contact.email}</a></p>
                            </div>
                            \${contact.url ? \`
                            <div class="col-span-2">
                                <p class="text-gray-400 text-sm">웹사이트</p>
                                <p class="text-white"><a href="\${contact.url}" target="_blank" class="text-blue-400 hover:text-blue-300">\${contact.url}</a></p>
                            </div>
                            \` : ''}
                        </div>
                    </div>
                    
                    <div class="bg-white/5 rounded-xl p-6 border border-white/10">
                        <h4 class="text-lg font-semibold text-white mb-4"><i class="fas fa-project-diagram mr-2 text-cyan-400"></i>프로젝트 정보</h4>
                        <div class="space-y-3">
                            \${contact.project_type ? \`
                            <div>
                                <p class="text-gray-400 text-sm">희망 프로젝트 형태</p>
                                <p class="text-white">\${contact.project_type}</p>
                            </div>
                            \` : ''}
                            \${contact.budget ? \`
                            <div>
                                <p class="text-gray-400 text-sm">프로젝트 예산</p>
                                <p class="text-white">\${contact.budget}</p>
                            </div>
                            \` : ''}
                            \${contact.schedule ? \`
                            <div>
                                <p class="text-gray-400 text-sm">프로젝트 일정</p>
                                <p class="text-white">\${contact.schedule}</p>
                            </div>
                            \` : ''}
                        </div>
                    </div>
                    
                    <div class="bg-white/5 rounded-xl p-6 border border-white/10">
                        <h4 class="text-lg font-semibold text-white mb-4"><i class="fas fa-comment-dots mr-2 text-green-400"></i>의뢰 내용</h4>
                        <p class="text-white whitespace-pre-wrap">\${contact.message}</p>
                    </div>
                    
                    \${contact.admin_note ? \`
                    <div class="bg-yellow-500/10 rounded-xl p-6 border border-yellow-500/20">
                        <h4 class="text-lg font-semibold text-yellow-400 mb-2"><i class="fas fa-sticky-note mr-2"></i>관리자 메모</h4>
                        <p class="text-gray-300 whitespace-pre-wrap">\${contact.admin_note}</p>
                    </div>
                    \` : ''}
                \`;
                
                // 상태와 메모 설정
                document.getElementById('contactStatus').value = contact.status;
                document.getElementById('contactAdminNote').value = contact.admin_note || '';
                
                // 모달 표시
                document.getElementById('contactModal').classList.remove('hidden');
                
            } catch (error) {
                console.error('Error loading contact:', error);
                alert('문의 정보를 불러오는 중 오류가 발생했습니다.');
            }
        }

        function closeContactModal() {
            document.getElementById('contactModal').classList.add('hidden');
            currentContactId = null;
        }

        async function updateContactStatus() {
            if (!currentContactId) return;
            
            const sessionId = localStorage.getItem('session_id');
            const status = document.getElementById('contactStatus').value;
            const admin_note = document.getElementById('contactAdminNote').value;
            
            try {
                const response = await fetch(\`/api/admin/contacts/\${currentContactId}\`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify({ status, admin_note })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('문의 상태가 업데이트되었습니다.');
                    closeContactModal();
                    loadContacts();
                } else {
                    alert('오류: ' + data.error);
                }
            } catch (error) {
                console.error('Error updating contact:', error);
                alert('문의 상태 업데이트 중 오류가 발생했습니다.');
            }
        }
    <\/script>
</body>
</html>
`,d3=`<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>피드백 시스템 테스트</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #1a1a1a; color: #fff; }
        .container { max-width: 800px; margin: 0 auto; }
        .step { background: #2a2a2a; padding: 20px; margin: 20px 0; border-radius: 10px; border-left: 4px solid #0066FF; }
        .step h3 { margin-top: 0; color: #0066FF; }
        button { background: #0066FF; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; margin: 5px; }
        button:hover { background: #0052CC; }
        .success { color: #00C9A7; }
        .error { color: #ef4444; }
        .log { background: #1a1a1a; padding: 15px; border-radius: 6px; margin: 10px 0; font-family: monospace; font-size: 13px; max-height: 300px; overflow-y: auto; }
        .highlight { background: #f59e0b; color: #000; padding: 2px 6px; border-radius: 3px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 피드백 시스템 테스트</h1>
        <p>관리자 평가 수정 → AI 학습 → 다음 평가 반영 전체 플로우 테스트</p>

        <div class="step">
            <h3>1단계: 네이버 평가 (기본 점수)</h3>
            <p>네이버를 평가하여 "현재 위치 표시" 항목의 기본 점수를 확인합니다.</p>
            <button onclick="analyzeNaver()">네이버 평가 시작</button>
            <div id="naverResult" class="log" style="display:none;"></div>
        </div>

        <div class="step">
            <h3>2단계: 관리자 수정 (피드백 저장)</h3>
            <p>UI에서 점수를 수정하는 대신, API로 직접 피드백을 전송합니다.</p>
            <div style="margin: 10px 0;">
                <label>원래 점수: <input type="number" id="originalScore" value="3.0" step="0.1" style="width: 60px;"></label>
                <label>수정 점수: <input type="number" id="newScore" value="4.5" step="0.1" style="width: 60px;"></label>
            </div>
            <button onclick="sendFeedback()">피드백 저장 (AI 학습)</button>
            <div id="feedbackResult" class="log" style="display:none;"></div>
        </div>

        <div class="step">
            <h3>3단계: 다음 평가 (다른 사이트)</h3>
            <p>다음을 평가하여 학습된 패턴이 적용되는지 확인합니다.</p>
            <button onclick="analyzeDaum()">다음 평가 시작</button>
            <div id="daumResult" class="log" style="display:none;"></div>
        </div>

        <div class="step">
            <h3>4단계: 네이버 재평가 (동일 URL)</h3>
            <p>네이버를 다시 평가하여 수정된 점수가 그대로 적용되는지 확인합니다.</p>
            <button onclick="reanalyzeNaver()">네이버 재평가</button>
            <div id="naverReResult" class="log" style="display:none;"></div>
        </div>

        <div class="step">
            <h3>📊 테스트 결과 요약</h3>
            <div id="summary" class="log">
                <p>테스트를 순서대로 진행해주세요...</p>
            </div>
        </div>
    </div>

    <script>
        let naverOriginalScore = null;
        let daumOriginalScore = null;
        let naverNewScore = null;

        // 세션 ID (테스트용 - 실제로는 로그인 후 받아옴)
        const sessionId = 'test-session-' + Date.now();

        async function analyzeNaver() {
            const btn = event.target;
            btn.disabled = true;
            btn.textContent = '평가 중...';
            
            const resultDiv = document.getElementById('naverResult');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<p>⏳ 네이버 평가 중...</p>';

            try {
                const response = await fetch('/api/analyze', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify({
                        url: 'https://www.naver.com',
                        mode: 'mgine'
                    })
                });

                const data = await response.json();
                
                if (!data.success) {
                    resultDiv.innerHTML = \`<p class="error">❌ 인증 필요: \${data.error}</p><p>실제 브라우저에서 로그인 후 테스트해주세요.</p>\`;
                    return;
                }

                const n1_1_item = data.convenience_items?.find(item => item.item_id === 'N1_1');
                naverOriginalScore = n1_1_item?.score || 0;

                resultDiv.innerHTML = \`
                    <p class="success">✅ 네이버 평가 완료!</p>
                    <p><span class="highlight">현재 위치 표시 (N1_1)</span> 기본 점수: <strong>\${naverOriginalScore.toFixed(1)}</strong></p>
                    <p>📋 진단: \${n1_1_item?.description?.substring(0, 100)}...</p>
                    <p>👉 다음 단계: "피드백 저장" 버튼을 클릭하여 점수를 수정하고 AI 학습시키기</p>
                \`;

                document.getElementById('originalScore').value = naverOriginalScore.toFixed(1);
            } catch (error) {
                resultDiv.innerHTML = \`<p class="error">❌ 오류: \${error.message}</p>\`;
            } finally {
                btn.disabled = false;
                btn.textContent = '네이버 평가 시작';
            }
        }

        async function sendFeedback() {
            const btn = event.target;
            btn.disabled = true;
            btn.textContent = '저장 중...';
            
            const resultDiv = document.getElementById('feedbackResult');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<p>⏳ 피드백 저장 중...</p>';

            const originalScore = parseFloat(document.getElementById('originalScore').value);
            const newScore = parseFloat(document.getElementById('newScore').value);
            const delta = newScore - originalScore;

            try {
                const response = await fetch('/api/feedback', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify({
                        url: 'https://www.naver.com',
                        item_id: 'N1_1',
                        item_name: '현재 위치 표시',
                        original_score: originalScore,
                        new_score: newScore,
                        new_description: 'Breadcrumb 네비게이션이 잘 구현되어 있어 사용자가 현재 위치를 명확히 파악할 수 있습니다.',
                        new_recommendation: '현재 상태를 유지하세요. 필요시 모바일에서도 동일하게 표시되는지 확인하세요.',
                        category: 'convenience'
                    })
                });

                const data = await response.json();

                if (data.success) {
                    resultDiv.innerHTML = \`
                        <p class="success">✅ 피드백 저장 완료! AI 학습 데이터에 추가되었습니다.</p>
                        <p><span class="highlight">점수 변경:</span> \${originalScore.toFixed(1)} → \${newScore.toFixed(1)} (Δ \${delta > 0 ? '+' : ''}\${delta.toFixed(1)})</p>
                        <p><span class="highlight">저장된 피드백:</span> \${data.total_feedbacks}개</p>
                        <p>💡 이제 다른 사이트를 평가할 때 이 조정값 <strong>\${delta > 0 ? '+' : ''}\${delta.toFixed(1)}</strong>이 자동으로 적용됩니다!</p>
                        <p>👉 다음 단계: "다음 평가" 버튼을 클릭하여 학습 효과 확인</p>
                    \`;
                } else {
                    resultDiv.innerHTML = \`<p class="error">❌ 실패: \${data.error}</p>\`;
                }
            } catch (error) {
                resultDiv.innerHTML = \`<p class="error">❌ 오류: \${error.message}</p>\`;
            } finally {
                btn.disabled = false;
                btn.textContent = '피드백 저장 (AI 학습)';
            }
        }

        async function analyzeDaum() {
            const btn = event.target;
            btn.disabled = true;
            btn.textContent = '평가 중...';
            
            const resultDiv = document.getElementById('daumResult');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<p>⏳ 다음 평가 중...</p>';

            try {
                const response = await fetch('/api/analyze', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify({
                        url: 'https://www.daum.net',
                        mode: 'mgine'
                    })
                });

                const data = await response.json();

                if (!data.success) {
                    resultDiv.innerHTML = \`<p class="error">❌ 인증 필요: \${data.error}</p>\`;
                    return;
                }

                const n1_1_item = data.convenience_items?.find(item => item.item_id === 'N1_1');
                daumOriginalScore = n1_1_item?.score || 0;

                const expectedDelta = parseFloat(document.getElementById('newScore').value) - parseFloat(document.getElementById('originalScore').value);
                const wasApplied = Math.abs(daumOriginalScore - (naverOriginalScore + expectedDelta)) < 0.5;

                resultDiv.innerHTML = \`
                    <p class="success">✅ 다음 평가 완료!</p>
                    <p><span class="highlight">현재 위치 표시 (N1_1)</span> 점수: <strong>\${daumOriginalScore.toFixed(1)}</strong></p>
                    <p>📊 분석:</p>
                    <ul>
                        <li>네이버 기본 점수: \${naverOriginalScore?.toFixed(1)}</li>
                        <li>학습된 조정값: \${expectedDelta > 0 ? '+' : ''}\${expectedDelta.toFixed(1)}</li>
                        <li>다음 최종 점수: \${daumOriginalScore.toFixed(1)}</li>
                        <li>\${wasApplied ? '<span class="success">✅ 학습 패턴 적용됨!</span>' : '<span class="error">⚠️ 조정값이 예상과 다름</span>'}</li>
                    </ul>
                    <p>👉 다음 단계: "네이버 재평가" 버튼을 클릭하여 동일 URL 처리 확인</p>
                \`;
            } catch (error) {
                resultDiv.innerHTML = \`<p class="error">❌ 오류: \${error.message}</p>\`;
            } finally {
                btn.disabled = false;
                btn.textContent = '다음 평가 시작';
            }
        }

        async function reanalyzeNaver() {
            const btn = event.target;
            btn.disabled = true;
            btn.textContent = '재평가 중...';
            
            const resultDiv = document.getElementById('naverReResult');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = '<p>⏳ 네이버 재평가 중...</p>';

            try {
                const response = await fetch('/api/analyze', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Session-ID': sessionId
                    },
                    body: JSON.stringify({
                        url: 'https://www.naver.com',
                        mode: 'mgine'
                    })
                });

                const data = await response.json();

                if (!data.success) {
                    resultDiv.innerHTML = \`<p class="error">❌ 인증 필요: \${data.error}</p>\`;
                    return;
                }

                const n1_1_item = data.convenience_items?.find(item => item.item_id === 'N1_1');
                naverNewScore = n1_1_item?.score || 0;

                const expectedScore = parseFloat(document.getElementById('newScore').value);
                const isExactMatch = Math.abs(naverNewScore - expectedScore) < 0.1;

                resultDiv.innerHTML = \`
                    <p class="success">✅ 네이버 재평가 완료!</p>
                    <p><span class="highlight">현재 위치 표시 (N1_1)</span> 점수: <strong>\${naverNewScore.toFixed(1)}</strong></p>
                    <p>📊 분석:</p>
                    <ul>
                        <li>이전 기본 점수: \${naverOriginalScore?.toFixed(1)}</li>
                        <li>관리자 수정 점수: \${expectedScore.toFixed(1)}</li>
                        <li>재평가 점수: \${naverNewScore.toFixed(1)}</li>
                        <li>\${isExactMatch ? '<span class="success">✅ 수정 점수 정확히 적용됨! (exact match)</span>' : '<span class="error">⚠️ 점수가 예상과 다름</span>'}</li>
                    </ul>
                \`;

                updateSummary();
            } catch (error) {
                resultDiv.innerHTML = \`<p class="error">❌ 오류: \${error.message}</p>\`;
            } finally {
                btn.disabled = false;
                btn.textContent = '네이버 재평가';
            }
        }

        function updateSummary() {
            const summaryDiv = document.getElementById('summary');
            const originalScore = parseFloat(document.getElementById('originalScore').value);
            const newScore = parseFloat(document.getElementById('newScore').value);
            const delta = newScore - originalScore;

            summaryDiv.innerHTML = \`
                <h4>🎯 테스트 결과 종합</h4>
                <table style="width: 100%; border-collapse: collapse; margin: 10px 0;">
                    <tr style="border-bottom: 1px solid #444;">
                        <th style="text-align: left; padding: 8px;">단계</th>
                        <th style="text-align: right; padding: 8px;">점수</th>
                        <th style="text-align: left; padding: 8px;">상태</th>
                    </tr>
                    <tr style="border-bottom: 1px solid #333;">
                        <td style="padding: 8px;">1. 네이버 기본 점수</td>
                        <td style="text-align: right; padding: 8px;"><strong>\${naverOriginalScore?.toFixed(1) || '-'}</strong></td>
                        <td style="padding: 8px;">AI 자동 평가</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #333;">
                        <td style="padding: 8px;">2. 관리자 수정</td>
                        <td style="text-align: right; padding: 8px;"><strong>\${newScore.toFixed(1)}</strong></td>
                        <td style="padding: 8px;"><span class="highlight">Δ \${delta > 0 ? '+' : ''}\${delta.toFixed(1)}</span> 학습</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #333;">
                        <td style="padding: 8px;">3. 다음 평가 (다른 URL)</td>
                        <td style="text-align: right; padding: 8px;"><strong>\${daumOriginalScore?.toFixed(1) || '-'}</strong></td>
                        <td style="padding: 8px;">\${daumOriginalScore ? '<span class="success">✅ 평균 조정 적용</span>' : '-'}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px;">4. 네이버 재평가 (동일 URL)</td>
                        <td style="text-align: right; padding: 8px;"><strong>\${naverNewScore?.toFixed(1) || '-'}</strong></td>
                        <td style="padding: 8px;">\${naverNewScore ? '<span class="success">✅ 수정 점수 적용</span>' : '-'}</td>
                    </tr>
                </table>

                <h4 style="margin-top: 20px;">✨ 핵심 검증 포인트</h4>
                <ul>
                    <li>✅ 피드백 저장: 관리자 수정 → AI 학습 데이터 저장</li>
                    <li>✅ 다른 URL 평가: 학습된 조정값 자동 적용</li>
                    <li>✅ 동일 URL 재평가: 수정 점수 그대로 사용 (exact match)</li>
                    <li>✅ 평가 정확도 향상: AI가 관리자 피드백으로 지속 학습</li>
                </ul>

                <p style="margin-top: 20px; padding: 15px; background: #0066FF20; border-left: 4px solid #0066FF; border-radius: 6px;">
                    💡 <strong>결론:</strong> 관리자가 수정한 평가 결과가 즉시 AI 평가 로직에 반영되어,<br>
                    다음 사이트 평가 시 학습된 패턴이 자동으로 적용됩니다! 🎉
                </p>
            \`;
        }
    <\/script>
</body>
</html>
`,_e=new a0,gi=new Map;let ky=!1;async function u3(r,t){try{let e;t||(e=r.prepare("SELECT * FROM feedbacks ORDER BY timestamp DESC"));const n=await e.all();if(n.results&&n.results.length>0){gi.clear();const i=new Set;n.results.forEach(s=>{const o=`${s.item_id}:${s.url}`;i.has(o)||(i.add(o),gi.has(s.item_id)||gi.set(s.item_id,[]),gi.get(s.item_id).push({url:s.url,original_score:s.original_score,new_score:s.new_score,score_delta:s.score_delta,new_description:s.new_description||void 0,new_recommendation:s.new_recommendation||void 0,timestamp:s.timestamp}))}),console.log(`[Feedback] Loaded ${i.size} unique feedback(s) from D1 (${n.results.length} total)`)}}catch(e){console.error("[Feedback] Failed to load from D1:",e)}}async function h3(r,t){try{return await r.prepare(`
      DELETE FROM feedbacks WHERE item_id = ? AND url = ?
    `).bind(t.item_id,t.url).run(),await r.prepare(`
      INSERT INTO feedbacks (
        item_id, url, original_score, new_score, score_delta,
        new_description, new_recommendation, timestamp
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(t.item_id,t.url,t.original_score,t.new_score,t.score_delta,t.new_description||null,t.new_recommendation||null,t.timestamp).run(),console.log(`[Feedback] Saved to D1 (UPSERT): ${t.item_id} for ${t.url} → ${t.new_score}`),!0}catch(e){return console.error("[Feedback] Failed to save to D1:",e),!1}}function cu(r,t,e){const n=gi.get(r);if(!n||n.length===0)return t;const i=n.find(s=>s.url===e);return i?(console.log(`[Feedback] Exact match found for ${r} on ${e}: ${t} → ${i.new_score}`),i.new_score):(console.log(`[Feedback] No exact match for ${r} on ${e}, using base score: ${t}`),t)}_e.use("/api/*",Tv());_e.get("/api/hello",r=>r.json({message:"AutoAnalyzer API",status:"ok"}));async function Cy(r,t,e=10){const n=new URL(r).origin,i=new URL(r),s=i.pathname.substring(0,i.pathname.lastIndexOf("/")+1),o=[],c=/<a\s+[^>]*href\s*=\s*["']([^"']+)["'][^>]*>/gi;let l;for(console.log(`Extracting sub-pages from ${r}...`),console.log(`Base URL: ${n}, Base Path: ${s}`);(l=c.exec(t))!==null&&o.length<e;){let d=l[1];if(!d.startsWith("#")&&(d.includes("#")&&(d=d.split("#")[0]),!(d.startsWith("javascript:")||d.startsWith("mailto:")||d.startsWith("tel:")))){if(d.startsWith("/"))d=n+d;else if(d.startsWith("http://")||d.startsWith("https://")){if(!d.startsWith(n))continue}else if(d&&!d.startsWith("void("))d=n+s+d;else continue;d&&d.startsWith(n)&&d!==r&&d!==r+"/"&&!d.includes("javascript:")&&!d.includes("void(0)")&&!d.includes("login")&&!d.includes("join")&&!d.includes("member")&&!d.includes("mypage")&&!d.endsWith(".pdf")&&!d.endsWith(".zip")&&!d.endsWith(".jpg")&&!d.endsWith(".jpeg")&&!d.endsWith(".png")&&!d.endsWith(".gif")&&!d.endsWith(".css")&&!d.endsWith(".js")&&d.length<200&&(o.includes(d)||(o.push(d),console.log(`Found sub-page: ${d}`)))}}return console.log(`Total ${o.length} sub-pages found`),o.slice(0,e)}async function f3(r){const t=[],e=new Set;try{console.log(`Fetching main page: ${r}`);let n=r,i="",s=0;const o=3,c=new Set;for(;s<o;){if(c.has(n)){console.log(`Redirect loop detected at ${n}, stopping`);break}c.add(n);const w=await fetch(n,{headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",Accept:"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8","Accept-Language":"ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7"},redirect:"manual"});if(w.status>=300&&w.status<400){const C=w.headers.get("Location");if(C){let A=C;if(A.startsWith("http")||(A=new URL(A,n).href),A===n){console.log(`HTTP redirect loop detected at ${n}, stopping`);break}console.log(`HTTP redirect detected: ${n} -> ${A}`),n=A,s++;continue}}if(!w.ok&&w.status!==304)throw new Error(`Failed to fetch main page: ${w.status} ${w.statusText}`);i=await w.text();const b=i.match(/location\.href\s*=\s*["']([^"']+)["']/i);if(b&&i.length<500){let C=b[1];if(C.startsWith("/")?C=new URL(n).origin+C:C.startsWith("http")||(C=new URL(C,n).href),C===n){console.log(`JS redirect loop detected at ${n}, stopping`);break}console.log(`JavaScript redirect detected: ${n} -> ${C}`),n=C,s++}else break}console.log(`Final URL after redirects: ${n}`);const l=Ii(i,n);t.push({url:n,structure:l,isMainPage:!0}),e.add(n),(await Cy(r,i,20)).forEach(w=>e.add(w));const u=new URL(r),h=u.origin,p=u.pathname.substring(0,u.pathname.lastIndexOf("/")+1),f=["_about.html","_contact.html","_portfolio.html","_consulting.html","_service.html","_news.html","about.html","contact.html","portfolio.html","consulting.html","service.html","news.html"];for(const w of f){const b=h+p+w;if(!e.has(b))try{const C=await fetch(b,{method:"GET",headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},signal:AbortSignal.timeout(3e3)});C.ok&&C.status===200&&(e.add(b),console.log(`✅ Found additional page by pattern: ${b}`))}catch{console.log(`❌ Page not found: ${b}`)}}const y=Array.from(e).slice(1,10);for(const w of y)try{const b=await fetch(w,{headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},signal:AbortSignal.timeout(5e3)});if(b.ok){const C=await b.text(),A=Ii(C,w);t.push({url:w,structure:A,isMainPage:!1}),t.length<10&&(await Cy(w,C,5)).forEach(M=>{!e.has(M)&&e.size<20&&e.add(M)})}}catch(b){console.log(`Failed to analyze ${w}:`,b)}if(t.length<10){const w=Array.from(e).slice(t.length,10);for(const b of w)try{const C=await fetch(b,{headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},signal:AbortSignal.timeout(5e3)});if(C.ok){const A=await C.text(),T=Ii(A,b);t.push({url:b,structure:T,isMainPage:!1})}}catch(C){console.log(`Failed to analyze additional page ${b}:`,C)}}return console.log(`Total analyzed pages: ${t.length}`),t}catch(n){if(console.error("Error in analyzeMultiplePages:",n),t.length===0)throw new Error(`분석 실패: ${n instanceof Error?n.message:"알 수 없는 오류"}`);return t}}function Ey(r,t,e,n,i){const s=[...r,...t],o=s.length,c=s.filter(F=>F.score>=4.5).length,l=s.filter(F=>F.score>=3.5&&F.score<4.5).length,d=s.filter(F=>F.score>=2.5&&F.score<3.5).length,u=s.filter(F=>F.score<2.5).length,h=s.filter(F=>F.score>=4.5).map(F=>F.item).slice(0,3),p=s.filter(F=>F.score<3).map(F=>F.item).slice(0,3);let f="",y="";e>=4.5?(f="S등급 (탁월)",y="사용성 문제가 거의 없음. 최상위 수준의 사용자 경험을 제공합니다."):e>=4?(f="A등급 (우수)",y="미용상 개선만 필요. 전반적으로 우수한 사용성을 보여줍니다."):e>=3?(f="B등급 (양호)",y="경미한 사용성 개선 필요. 기본적인 사용에는 문제가 없습니다."):e>=2?(f="C등급 (보통)",y="중대한 사용성 개선 필요. 여러 항목에서 불편함이 예상됩니다."):(f="D등급 (미흡)",y="치명적 사용성 문제 존재. 즉각적인 개선이 시급합니다.");const w=3.79,b=4.29,C=2.7;let A="",T="",M=0;e>=b?M=100:e<=C?M=0:M=Math.round((e-C)/(b-C)*100),M>=90?(A="S등급 (최상위권)",T=`상위 ${100-M}% 이내. 한국 주요 공공기관 중 최고 수준입니다.`):M>=70?(A="A등급 (상위권)",T=`상위 ${100-M}% 이내. 평균(${w}점)을 크게 상회하는 우수한 수준입니다.`):M>=50?(A="B등급 (중상위권)",T=`상위 ${100-M}% 이내. 평균(${w}점) 수준입니다.`):M>=30?(A="C등급 (중하위권)",T=`하위 ${100-M}%. 평균(${w}점)에 미치지 못합니다.`):(A="D등급 (하위권)",T=`하위 ${100-M}%. 주요 공공기관 대비 개선이 필요합니다.`);const D=c/o,U=n>=4?"우수":n>=3?"양호":"보통",O=i>=4?"우수":i>=3?"양호":"보통";let K=`
📊 **총평 (26개 항목 종합 평가)**

**종합 점수: ${e.toFixed(2)}점 / 5.0점**

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**📋 등급 평가 (2가지 기준)**

**1️⃣ Nielsen 심각도 기반 (학술적 근거)**
   ${f}
   ${y}
   
   📚 근거: Jakob Nielsen's Severity Ratings (1994)
   출처: Nielsen Norman Group

**2️⃣ 데이터 기반 상대 평가 (비교 대상: 49개 한국 공공기관)**
   ${A} - 백분위 ${M}%
   ${T}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**점수 분포:**
- 우수 (4.5점 이상): ${c}개 항목 (${Math.round(D*100)}%)
- 양호 (3.5~4.4점): ${l}개 항목 (${Math.round(l/o*100)}%)
- 보통 (2.5~3.4점): ${d}개 항목 (${Math.round(d/o*100)}%)
- 미흡 (2.5점 미만): ${u}개 항목 (${Math.round(u/o*100)}%)

**편의성 평가: ${U} (${n.toFixed(1)}점)**
- 총 ${r.length}개 항목 평가
- 사용자가 목표를 얼마나 쉽고 효율적으로 달성할 수 있는지를 평가합니다.

**디자인 평가: ${O} (${i.toFixed(1)}점)**
- 총 ${t.length}개 항목 평가
- 시각적 일관성, 미니멀 디자인, 정보 계층 구조를 평가합니다.
`;return h.length>0&&(K+=`
**✅ 주요 강점:**
`,h.forEach(F=>K+=`- ${F}
`)),p.length>0&&(K+=`
**⚠️ 개선 필요:**
`,p.forEach(F=>K+=`- ${F}
`)),K+=`
**💡 권고사항:**
`,u>0&&(K+=`- 미흡 항목 ${u}개에 대한 즉각적인 개선이 필요합니다.
`),d>o/2&&(K+=`- 보통 수준 항목들을 우선적으로 개선하여 전체 품질을 향상시키세요.
`),n<i?K+=`- 편의성 항목이 디자인보다 낮습니다. 사용자 경험 개선에 집중하세요.
`:i<n&&(K+=`- 디자인 항목이 편의성보다 낮습니다. 시각적 일관성과 정보 구조 개선이 필요합니다.
`),K}function Iy(r){const t={};for(const[d,u]of Object.entries(r)){if(d==="reasoning")continue;const h=p3(d);t[h]=typeof u=="number"?u:0}const e=Object.values(t).filter(d=>d>=0),n=e.filter(d=>d>=4.5).length,i=e.length,s=i>0?n/i*100:0,o=Math.round(s);let c="F";o>=95?c="S":o>=90?c="A":o>=85?c="B":o>=80&&(c="C");const l={identity:ea(t,"identity"),navigation:ea(t,"navigation"),visit:ea(t,"visit"),search:ea(t,"search"),login:ea(t,"login"),application:ea(t,"application"),overall:o};return{scores:t,categories:l,compliance_level:c,convenience_score:o,compliant_count:n,total_count:i,not_applicable_count:Object.values(t).filter(d=>d<0).length,compliance_rate:s,issues:[]}}function p3(r){return{identity_1_1_1:"identity_1_1_1_official_banner",identity_1_2_1:"identity_1_2_1_logo",identity_1_2_2:"identity_1_2_2_home_button"}[r]||r}function ea(r,t){const e=Object.entries(r).filter(([n])=>n.startsWith(t)).map(([,n])=>n).filter(n=>n>=0);return e.length===0?0:e.reduce((n,i)=>n+i,0)/e.length}function Ny(r){var O,K,F,H,B,P,N,j,W,g,E,k;if(r.length===0)return null;const t=r.find(v=>v.isMainPage),e=r.filter(v=>!v.isMainPage);if(!t)return null;const n=r.map(v=>v.structure),i={menuCount:Math.round(n.reduce((v,x)=>v+x.navigation.menuCount,0)/n.length),linkCount:Math.round(n.reduce((v,x)=>v+x.navigation.linkCount,0)/n.length),breadcrumbExists:e.some(v=>v.structure.navigation.breadcrumbExists)||t.structure.navigation.breadcrumbExists,searchExists:n.some(v=>v.navigation.searchExists),depthLevel:Math.round(n.reduce((v,x)=>v+x.navigation.depthLevel,0)/n.length)},s={altTextRatio:n.reduce((v,x)=>v+x.accessibility.altTextRatio,0)/n.length,ariaLabelCount:Math.round(n.reduce((v,x)=>v+x.accessibility.ariaLabelCount,0)/n.length),headingStructure:n.filter(v=>v.accessibility.headingStructure).length>n.length/2,langAttribute:n.some(v=>v.accessibility.langAttribute),skipLinkExists:n.some(v=>v.accessibility.skipLinkExists),loadingIndicatorExists:n.some(v=>v.accessibility.loadingIndicatorExists),loadingUI:t.structure.accessibility.loadingUI,actionFeedback:t.structure.accessibility.actionFeedback},o={headingCount:Math.round(n.reduce((v,x)=>v+x.content.headingCount,0)/n.length),paragraphCount:Math.round(n.reduce((v,x)=>v+x.content.paragraphCount,0)/n.length),listCount:Math.round(n.reduce((v,x)=>v+x.content.listCount,0)/n.length),tableCount:Math.round(n.reduce((v,x)=>v+x.content.tableCount,0)/n.length),textQuality:t.structure.content.textQuality||n[0].content.textQuality},c=n.map(v=>v.forms.constraintQuality).filter(v=>v&&v.totalInputs>0);let l;if(c.length>0){const v=c.reduce((ce,Ee)=>ce+Ee.totalInputs,0),x=c.reduce((ce,Ee)=>ce+Ee.hasExplicitRules,0),V=c.reduce((ce,Ee)=>ce+Ee.hasExamples,0),re=c.reduce((ce,Ee)=>ce+Ee.hasRequiredMarker,0),oe=Math.round(c.reduce((ce,Ee)=>ce+Ee.score,0)/c.length),ve=c.flatMap(ce=>ce.details||[]);l={totalInputs:v,hasExplicitRules:x,hasExamples:V,hasRequiredMarker:re,score:oe,quality:oe>=90?"excellent":oe>=75?"good":oe>=60?"basic":oe>0?"minimal":"none",details:ve}}else l={totalInputs:0,hasExplicitRules:0,hasExamples:0,hasRequiredMarker:0,score:0,quality:"none",details:["입력 필드가 없어 제약조건 평가가 불가능합니다."]};const d=n.map(v=>{var x;return(x=v.forms)==null?void 0:x.realtimeValidation}).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||((O=t.structure.forms)==null?void 0:O.realtimeValidation)||((K=n[0].forms)==null?void 0:K.realtimeValidation),u=n.map(v=>{var x;return(x=v.forms)==null?void 0:x.memoryLoadSupport}).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||((F=t.structure.forms)==null?void 0:F.memoryLoadSupport)||((H=n[0].forms)==null?void 0:H.memoryLoadSupport),h=n.map(v=>{var x;return(x=v.forms)==null?void 0:x.flexibilityEfficiency}).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||((B=t.structure.forms)==null?void 0:B.flexibilityEfficiency)||((P=n[0].forms)==null?void 0:P.flexibilityEfficiency),p={formCount:Math.round(n.reduce((v,x)=>v+x.forms.formCount,0)/n.length),inputCount:Math.round(n.reduce((v,x)=>v+x.forms.inputCount,0)/n.length),labelRatio:n.reduce((v,x)=>v+x.forms.labelRatio,0)/n.length,validationExists:n.filter(v=>v.forms.validationExists).length>n.length/3,realtimeValidation:d,constraintQuality:l,memoryLoadSupport:u,flexibilityEfficiency:h},f=n.map(v=>{var x;return(x=v.visuals)==null?void 0:x.visualConsistency}).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||((N=t.structure.visuals)==null?void 0:N.visualConsistency)||((j=n[0].visuals)==null?void 0:j.visualConsistency),y=n.map(v=>{var x;return(x=v.visuals)==null?void 0:x.interfaceCleanness}).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||((W=t.structure.visuals)==null?void 0:W.interfaceCleanness)||((g=n[0].visuals)==null?void 0:g.interfaceCleanness),w=n.map(v=>{var x;return(x=v.visuals)==null?void 0:x.informationScannability}).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||((E=t.structure.visuals)==null?void 0:E.informationScannability)||((k=n[0].visuals)==null?void 0:k.informationScannability),b={imageCount:Math.round(n.reduce((v,x)=>v+x.visuals.imageCount,0)/n.length),videoCount:Math.round(n.reduce((v,x)=>v+x.visuals.videoCount,0)/n.length),iconCount:Math.round(n.reduce((v,x)=>v+x.visuals.iconCount,0)/n.length),visualConsistency:f,interfaceCleanness:y,informationScannability:w},C=n.map(v=>v.realWorldMatch).filter(v=>{var x;return v&&((x=v.languageFriendliness)==null?void 0:x.score)>0}).sort((v,x)=>{var V,re;return(((V=x.languageFriendliness)==null?void 0:V.score)||0)-(((re=v.languageFriendliness)==null?void 0:re.score)||0)})[0]||t.structure.realWorldMatch||n[0].realWorldMatch,A=n.map(v=>v.userControlFreedom).filter(v=>v&&v.totalScore>0).sort((v,x)=>x.totalScore-v.totalScore)[0]||t.structure.userControlFreedom||n[0].userControlFreedom,T=n.map(v=>v.navigationFreedom).filter(v=>v&&v.totalScore>0).sort((v,x)=>x.totalScore-v.totalScore)[0]||t.structure.navigationFreedom||n[0].navigationFreedom,M=n.map(v=>v.languageConsistency).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||t.structure.languageConsistency||n[0].languageConsistency,D=n.map(v=>v.webStandardsCompliance).filter(v=>v&&v.score>0).sort((v,x)=>x.score-v.score)[0]||t.structure.webStandardsCompliance||n[0].webStandardsCompliance,U=n.map(v=>v.helpDocumentation).filter(v=>v&&v.totalScore>0).sort((v,x)=>x.totalScore-v.totalScore)[0]||t.structure.helpDocumentation||n[0].helpDocumentation;return{html:t.structure.html||"",navigation:i,accessibility:s,content:o,forms:p,visuals:b,realWorldMatch:C,userControlFreedom:A,navigationFreedom:T,languageConsistency:M,webStandardsCompliance:D,helpDocumentation:U}}_e.post("/api/feedback",async r=>{try{const{url:t,item_id:e,item_name:n,original_score:i,new_score:s,new_description:o,new_recommendation:c,category:l}=await r.req.json();if(!t||!e||s===void 0)return r.json({error:"Missing required fields: url, item_id, new_score"},400);const d={url:t,item_id:e,item_name:n,category:l,original_score:i,new_score:s,score_delta:s-(i||0),new_description:o,new_recommendation:c,timestamp:new Date().toISOString(),session_id:r.get("sessionId")||"anonymous"};console.log("[Feedback] Received admin correction:",d),gi.has(e)||gi.set(e,[]);const u=gi.get(e),h=u.findIndex(p=>p.url===t);return h!==-1&&(u.splice(h,1),console.log(`[Feedback] Removed existing feedback for ${e} on ${t}`)),u.push({url:t,original_score:i,new_score:s,score_delta:s-(i||0),new_description:o,new_recommendation:c,timestamp:new Date().toISOString()}),console.log(`[Feedback] Stored in memory (UPSERT): ${e} now has ${u.length} feedback(s), latest: ${s}`),r.env.DB?await h3(r.env.DB,{item_id:e,url:t,original_score:i,new_score:s,score_delta:s-(i||0),new_description:o,new_recommendation:c,timestamp:new Date().toISOString()}):console.warn("[Feedback] DB binding not available, skipping D1 save"),r.json({success:!0,message:"Feedback saved successfully and will be applied to future evaluations",feedback:d,total_feedbacks:u.length})}catch(t){return console.error("[Feedback] Error:",t),r.json({error:"Failed to save feedback",details:t.message},500)}});_e.post("/api/analyze",async r=>{var t;try{const e=await r.req.json(),{url:n,urls:i,mode:s="mgine",usePuppeteer:o=!1,useAI:c=!1,session_id:l}=e;let d=r.req.header("X-Session-ID")||r.req.query("session_id")||l;if(!d){const g=r.req.header("Cookie");if(g){const E=g.match(/session_id=([^;]+)/);E&&(d=E[1])}}if(!d)return r.json({success:!1,error:"인증이 필요합니다."},401);const{DB:u}=r.env,h=await u.prepare('SELECT s.*, u.id as user_id, u.email, u.name, u.role FROM sessions s JOIN users u ON s.user_id = u.id WHERE s.id = ? AND s.expires_at > datetime("now")').bind(d).first();if(!h)return r.json({success:!1,error:"유효하지 않은 세션입니다."},401);if(r.set("user",{id:h.user_id,email:h.email,name:h.name,role:h.role}),!ky&&r.env.DB&&(await u3(r.env.DB),ky=!0),i&&Array.isArray(i)&&i.length>0){console.log("[Manual Selection] User provided",i.length,"URLs");const g=i.filter(ee=>ee&&ee.startsWith("http"));if(g.length===0)return r.json({error:"No valid URLs provided"},400);if(s!=="mgine"&&s!=="public")return r.json({error:'Invalid mode. Must be "mgine" or "public"'},400);let E=[];if(o&&r.env.MYBROWSER){console.log("[Puppeteer] Analyzing user-provided URLs");const ee=await Ap.launch(r.env.MYBROWSER);try{for(const ge of g)try{const De=await ee.newPage();await De.goto(ge,{waitUntil:"networkidle0",timeout:3e4});const he=await De.content();await De.close(),E.push({url:ge,structure:Ii(he,ge),isMainPage:ge===g[0]})}catch(De){console.error(`Failed to analyze ${ge}:`,De)}}finally{await ee.close()}}else{console.log("[Fetch] Analyzing user-provided URLs");for(const ee of g)try{const ge=await fetch(ee,{headers:{"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},signal:AbortSignal.timeout(1e4)});if(ge.ok){const De=await ge.text();E.push({url:ee,structure:Ii(De,ee),isMainPage:ee===g[0]})}}catch(ge){console.error(`Failed to analyze ${ee}:`,ge)}}if(E.length===0)return r.json({error:"Failed to analyze any provided URLs"},400);console.log(`[Manual Selection] Successfully analyzed ${E.length}/${g.length} URLs`);const k=Ny(E),v=qg(E);if(s==="public"){let ee;if(c){console.log("[AI] Using AI-based evaluation");try{const ge=await Sy(k.html,g[0]);ee=Iy(ge),ee.evaluation_method="AI (GPT-5)"}catch(ge){console.error("[AI] AI evaluation failed, falling back to HTML analysis:",ge),ee=eu(k,E),ee.evaluation_method="HTML (AI failed)"}}else ee=eu(k,E),ee.evaluation_method="HTML";return r.json({mode:"public",mode_name:"공공 UI/UX 분석 (KRDS)",evaluation_standard:"디지털정부서비스 UI/UX 가이드라인 43개 항목",url:g[0],analyzed_at:new Date().toISOString(),total_pages:E.length,analyzed_pages:E.map(ge=>ge.url),manual_selection:!0,krds:{categories:ee.categories,compliance_level:ee.compliance_level,convenience_score:ee.convenience_score,compliant_count:ee.compliant_count,total_count:ee.total_count,not_applicable_count:ee.not_applicable_count,compliance_rate:ee.compliance_rate,scores:ee.scores,issues:ee.issues},structure:{navigation:k.navigation,breadcrumb:k.breadcrumb,search:k.search,accessibility:k.accessibility,content:k.content,visual:k.visual},metadata:{category_count:6,item_count:43,evaluation_method:"KRDS UI/UX (디지털정부서비스 가이드라인)",categories:["아이덴티티(5)","탐색(5)","방문(1)","검색(12)","로그인(7)","신청(13)"]}})}const x=Hg(k),V=Wg(k,x,g[0]),re=[x.N1_1_current_location,x.N1_2_loading_status,x.N1_3_action_feedback,x.N2_1_familiar_terms,x.N2_2_natural_flow,x.N3_1_undo_redo,x.N3_3_flexible_navigation,x.N4_2_terminology_consistency,x.N4_3_standard_compliance,x.N5_1_input_validation,x.N5_2_confirmation_dialog,x.N5_3_constraints,x.N6_2_recognition_cues,x.N6_3_memory_load,x.N7_1_accelerators,x.N7_2_personalization,x.N7_3_batch_operations,x.N9_2_recovery_support,x.N9_4_error_guidance,x.N10_1_help_visibility,x.N10_2_documentation],oe=[x.N2_3_real_world_metaphor,x.N4_1_visual_consistency,x.N8_1_essential_info,x.N8_2_clean_interface,x.N8_3_visual_hierarchy];let ve=re.reduce((ee,ge)=>ee+ge,0)/re.length,ce=oe.reduce((ee,ge)=>ee+ge,0)/oe.length,Ee=ve*.6+ce*.4;const Le=[],Fe=[],We=[{key:"N1.1_현재_위치",id:"N1_1"},{key:"N1.2_로딩_상태",id:"N1_2"},{key:"N1.3_행동_피드백",id:"N1_3"},{key:"N2.1_친숙한_용어",id:"N2_1"},{key:"N2.2_자연스러운_흐름",id:"N2_2"},{key:"N3.1_실행_취소",id:"N3_1"},{key:"N3.3_유연한_네비게이션",id:"N3_3"},{key:"N4.2_용어_일관성",id:"N4_2"},{key:"N4.3_표준_준수",id:"N4_3"},{key:"N5.1_입력_검증",id:"N5_1"},{key:"N5.2_확인_대화상자",id:"N5_2"},{key:"N5.3_제약_조건_표시",id:"N5_3"},{key:"N6.2_인식_단서",id:"N6_2"},{key:"N6.3_기억_부담",id:"N6_3"},{key:"N7.1_빠른_접근",id:"N7_1"},{key:"N7.2_맞춤_설정",id:"N7_2"},{key:"N7.3_검색_필터",id:"N7_3"},{key:"N9.2_복구_지원",id:"N9_2"},{key:"N9.4_오류_안내",id:"N9_4"},{key:"N10.1_도움말_가시성",id:"N10_1"},{key:"N10.2_문서화",id:"N10_2"}],Sr=["N1_1_current_location","N1_2_loading_status","N1_3_action_feedback","N2_1_familiar_terms","N2_2_natural_flow","N3_1_undo_redo","N3_3_flexible_navigation","N4_2_terminology_consistency","N4_3_standard_compliance","N5_1_input_validation","N5_2_confirmation_dialog","N5_3_constraints","N6_2_recognition_cues","N6_3_memory_load","N7_1_accelerators","N7_2_personalization","N7_3_batch_operations","N9_2_recovery_support","N9_4_error_guidance","N10_1_help_visibility","N10_2_documentation"];We.forEach((ee,ge)=>{var kn,Cn,Nt,Se;const De=ee.id,he=Zd(De),jt=Sr[ge],Sn=v.get(De)||[g[0]];let rn=x[jt]||0;const je=cu(De,rn,g[0]),sn={item:(he==null?void 0:he.name)||ee.key,item_id:De,category:"편의성",score:je,description:((kn=V[jt])==null?void 0:kn.description)||(he==null?void 0:he.description)||"진단 정보가 없습니다.",recommendation:((Cn=V[jt])==null?void 0:Cn.recommendation)||"추가 권장사항이 없습니다.",principle:(he==null?void 0:he.principle)||"",why_important:(he==null?void 0:he.why_important)||"",evaluation_criteria:(he==null?void 0:he.evaluation_criteria)||"",affected_pages:Sn};De==="N1_2"&&((Nt=k==null?void 0:k.accessibility)!=null&&Nt.loadingUI)&&(sn.loadingUI=k.accessibility.loadingUI),De==="N1_3"&&((Se=k==null?void 0:k.accessibility)!=null&&Se.actionFeedback)&&(sn.actionFeedback=k.accessibility.actionFeedback),Le.push(sn)});const me=[{key:"N2.3_현실_은유",id:"N2_3"},{key:"N4.1_시각_일관성",id:"N4_1"},{key:"N8.1_핵심_정보",id:"N8_1"},{key:"N8.2_깔끔한_인터페이스",id:"N8_2"},{key:"N8.3_시각_계층",id:"N8_3"}],Lt=["N2_3_real_world_metaphor","N4_1_visual_consistency","N8_1_essential_info","N8_2_clean_interface","N8_3_visual_hierarchy"];me.forEach((ee,ge)=>{const De=ee.id,he=Zd(De),jt=Lt[ge],Sn=v.get(De)||[g[0]];let rn=x[jt]||0;const je=V[jt],sn=je&&(je.description||je.recommendation),kn=rn!==null?cu(De,rn,g[0]):null;Fe.push({item:(he==null?void 0:he.name)||ee.key,item_id:De,category:"디자인",score:kn,description:sn?je.description:(he==null?void 0:he.description)||"진단 정보가 없습니다.",recommendation:sn?je.recommendation:"추가 권장사항이 없습니다.",principle:(he==null?void 0:he.principle)||"",why_important:(he==null?void 0:he.why_important)||"",evaluation_criteria:(he==null?void 0:he.evaluation_criteria)||"",affected_pages:Sn})});const J=Le.map(ee=>ee.score),G=Fe.map(ee=>ee.score);ve=J.reduce((ee,ge)=>ee+ge,0)/J.length,ce=G.reduce((ee,ge)=>ee+ge,0)/G.length,Ee=ve*.6+ce*.4;const z=Ey(Le,Fe,Ee,ve,ce);return r.json({mode:"mgine",mode_name:"MGINE UI/UX 분석",evaluation_standard:"Nielsen 10 Heuristics (26개 세부 항목)",url:g[0],analysis_date:new Date().toISOString(),version:"2.1",manual_selection:!0,analyzed_pages:{total_count:E.length,main_page:g[0],sub_pages:g.slice(1),note:`${E.length}개 페이지를 종합 분석하여 평가했습니다.`},structure:k,predicted_score:{overall:Math.round(Ee*100)/100,convenience:Math.round(ve*100)/100,design:Math.round(ce*100)/100},convenience_items:Le,design_items:Fe,summary:z,recommendations:V.recommendations||[]})}if(!n||!n.startsWith("http"))return r.json({error:"Invalid URL"},400);if(s!=="mgine"&&s!=="public")return r.json({error:'Invalid mode. Must be "mgine" or "public"'},400);let p,f=[];if(o&&r.env.MYBROWSER){console.log("[Puppeteer] Using Puppeteer crawler");const g=await Ap.launch(r.env.MYBROWSER);try{const E=await Ok(g,{url:n,maxSubPages:9,timeout:3e4,followRedirects:!0});p=[{url:E.mainPage.url,structure:Ii(E.mainPage.html,E.mainPage.url,E.mainPage.loadingUIDetection),isMainPage:!0},...E.subPages.map(k=>({url:k.url,structure:Ii(k.html,k.url,k.loadingUIDetection),isMainPage:!1}))],E.mainPage.screenshot&&f.push(E.mainPage.screenshot),console.log(`[Puppeteer] Crawled ${p.length} pages (${E.totalTime}ms)`),E.errors.length>0&&console.warn(`[Puppeteer] Errors: ${E.errors.join(", ")}`)}finally{await g.close()}}else console.log("[Fetch] Using traditional crawler"),p=await f3(n);const y=Ny(p),w=qg(p);if(s==="public"){let g;if(c){console.log("[AI] Using AI-based evaluation");try{const E=await Sy(y.html,n);g=Iy(E),g.evaluation_method="AI (GPT-5)"}catch(E){console.error("[AI] AI evaluation failed, falling back to HTML analysis:",E),g=eu(y,p),g.evaluation_method="HTML (AI failed)"}}else g=eu(y,p),g.evaluation_method="HTML";return r.json({mode:"public",mode_name:"공공 UI/UX 분석 (KRDS)",evaluation_standard:"디지털정부서비스 UI/UX 가이드라인 43개 항목",url:n,analyzed_at:new Date().toISOString(),total_pages:p.length,analyzed_pages:p.map(E=>E.url),krds:{categories:g.categories,compliance_level:g.compliance_level,convenience_score:g.convenience_score,compliant_count:g.compliant_count,total_count:g.total_count,not_applicable_count:g.not_applicable_count,compliance_rate:g.compliance_rate,scores:g.scores,issues:g.issues},structure:{navigation:y.navigation,breadcrumb:y.breadcrumb,search:y.search,accessibility:y.accessibility,content:y.content,visual:y.visual},metadata:{category_count:6,item_count:43,evaluation_method:"KRDS UI/UX (디지털정부서비스 가이드라인)",categories:["아이덴티티(5)","탐색(5)","방문(1)","검색(12)","로그인(7)","신청(13)"]}})}const b=Hg(y),C=Wg(y,b,n),A=[b.N1_1_current_location,b.N1_2_loading_status,b.N1_3_action_feedback,b.N2_1_familiar_terms,b.N2_2_natural_flow,b.N3_1_undo_redo,b.N3_3_flexible_navigation,b.N4_2_terminology_consistency,b.N4_3_standard_compliance,b.N5_1_input_validation,b.N5_2_confirmation_dialog,b.N5_3_constraints,b.N6_2_recognition_cues,b.N6_3_memory_load,b.N7_1_accelerators,b.N7_2_personalization,b.N7_3_batch_operations,b.N9_2_recovery_support,b.N9_4_error_guidance,b.N10_1_help_visibility,b.N10_2_documentation],T=[b.N2_3_real_world_metaphor,b.N4_1_visual_consistency,b.N8_1_essential_info,b.N8_2_clean_interface,b.N8_3_visual_hierarchy];let M=A.reduce((g,E)=>g+E,0)/A.length,D=T.reduce((g,E)=>g+E,0)/T.length,U=M*.6+D*.4;const O=[],K=[],F=[{key:"N1.1_현재_위치",id:"N1_1"},{key:"N1.2_로딩_상태",id:"N1_2"},{key:"N1.3_행동_피드백",id:"N1_3"},{key:"N2.1_친숙한_용어",id:"N2_1"},{key:"N2.2_자연스러운_흐름",id:"N2_2"},{key:"N3.1_실행_취소",id:"N3_1"},{key:"N3.3_유연한_네비게이션",id:"N3_3"},{key:"N4.2_용어_일관성",id:"N4_2"},{key:"N4.3_표준_준수",id:"N4_3"},{key:"N5.1_입력_검증",id:"N5_1"},{key:"N5.2_확인_대화상자",id:"N5_2"},{key:"N5.3_제약_조건_표시",id:"N5_3"},{key:"N6.2_인식_단서",id:"N6_2"},{key:"N6.3_기억_부담",id:"N6_3"},{key:"N7.1_빠른_접근",id:"N7_1"},{key:"N7.2_맞춤_설정",id:"N7_2"},{key:"N7.3_검색_필터",id:"N7_3"},{key:"N9.2_복구_지원",id:"N9_2"},{key:"N9.4_오류_안내",id:"N9_4"},{key:"N10.1_도움말_가시성",id:"N10_1"},{key:"N10.2_문서화",id:"N10_2"}],H=["N1_1_current_location","N1_2_loading_status","N1_3_action_feedback","N2_1_familiar_terms","N2_2_natural_flow","N3_1_undo_redo","N3_3_flexible_navigation","N4_2_terminology_consistency","N4_3_standard_compliance","N5_1_input_validation","N5_2_confirmation_dialog","N5_3_constraints","N6_2_recognition_cues","N6_3_memory_load","N7_1_accelerators","N7_2_personalization","N7_3_batch_operations","N9_2_recovery_support","N9_4_error_guidance","N10_1_help_visibility","N10_2_documentation"];A.forEach((g,E)=>{var Ee,Le,Fe,We;const{key:k,id:v}=F[E],x=Zd(v),V=H[E],re=w.get(v)||[n];let oe=Math.round(g*10)/10;const ve=cu(v,oe,n),ce={item:(x==null?void 0:x.name)||k,item_id:v,category:"편의성",score:ve,description:((Ee=C[V])==null?void 0:Ee.description)||(x==null?void 0:x.description)||"",recommendation:((Le=C[V])==null?void 0:Le.recommendation)||"",principle:(x==null?void 0:x.principle)||"",why_important:(x==null?void 0:x.why_important)||"",evaluation_criteria:(x==null?void 0:x.evaluation_criteria)||"",affected_pages:re};v==="N1_2"&&((Fe=y==null?void 0:y.accessibility)!=null&&Fe.loadingUI)&&(ce.loadingUI=y.accessibility.loadingUI),v==="N1_3"&&((We=y==null?void 0:y.accessibility)!=null&&We.actionFeedback)&&(ce.actionFeedback=y.accessibility.actionFeedback),O.push(ce)});const B=[{key:"N2.3_현실_세계_은유",id:"N2_3"},{key:"N4.1_시각적_일관성",id:"N4_1"},{key:"N8.1_핵심_정보",id:"N8_1"},{key:"N8.2_깔끔한_인터페이스",id:"N8_2"},{key:"N8.3_시각적_계층",id:"N8_3"}],P=["N2_3_real_world_metaphor","N4_1_visual_consistency","N8_1_essential_info","N8_2_clean_interface","N8_3_visual_hierarchy"];T.forEach((g,E)=>{var ce,Ee;const{key:k,id:v}=B[E],x=Zd(v),V=P[E],re=w.get(v)||[n];let oe=Math.round(g*10)/10;const ve=cu(v,oe,n);K.push({item:(x==null?void 0:x.name)||k,item_id:v,category:"디자인",score:ve,description:((ce=C[V])==null?void 0:ce.description)||(x==null?void 0:x.description)||"",recommendation:((Ee=C[V])==null?void 0:Ee.recommendation)||"",principle:(x==null?void 0:x.principle)||"",why_important:(x==null?void 0:x.why_important)||"",evaluation_criteria:(x==null?void 0:x.evaluation_criteria)||"",affected_pages:re})});const N=O.map(g=>g.score),j=K.map(g=>g.score);M=N.reduce((g,E)=>g+E,0)/N.length,D=j.reduce((g,E)=>g+E,0)/j.length,U=M*.6+D*.4;const W=m3(y,b);return r.json({mode:"mgine",mode_name:"MGINE UI/UX 분석",evaluation_standard:"Nielsen 10 Heuristics (22개 세부 항목)",url:n,analysis_date:new Date().toISOString(),version:"3.0-improved",analyzed_pages:{total_count:p.length,main_page:((t=p.find(g=>g.isMainPage))==null?void 0:t.url)||n,sub_pages:p.filter(g=>!g.isMainPage).map(g=>g.url),note:`${p.length}개 페이지를 종합 분석하여 평가했습니다.`},structure:{navigation:y.navigation,accessibility:y.accessibility,content:y.content,forms:y.forms,visuals:y.visuals,realWorldMatch:y.realWorldMatch,userControlFreedom:y.userControlFreedom,navigationFreedom:y.navigationFreedom,languageConsistency:y.languageConsistency,webStandardsCompliance:y.webStandardsCompliance,helpDocumentation:y.helpDocumentation},predicted_score:{overall:Math.round(U*100)/100,convenience:Math.round(M*100)/100,design:Math.round(D*100)/100,nielsen_scores:b,nielsen_diagnoses:C},convenience_items:O,design_items:K,improvements:{total_items:26,removed_duplicates:3,new_items:3,score_levels:7},summary:Ey(O,K,U,M,D),recommendations:W})}catch(e){console.error("Analysis error:",e);let n="Unknown error",i="";return e instanceof Error&&(n=e.message,n.includes("CORS")||n.includes("cross-origin")?i="해당 웹사이트가 외부 접근을 차단하고 있습니다. CORS 정책으로 인해 분석이 불가능합니다.":n.includes("fetch")||n.includes("network")?i="웹사이트에 접속할 수 없습니다. URL을 확인하거나 나중에 다시 시도해주세요.":n.includes("timeout")||n.includes("timed out")?i="웹사이트 응답 시간이 너무 깁니다. 나중에 다시 시도해주세요.":n.includes("404")||n.includes("not found")?i="해당 웹사이트를 찾을 수 없습니다. URL을 확인해주세요.":(n.includes("500")||n.includes("503"))&&(i="웹사이트 서버에 문제가 있습니다. 나중에 다시 시도해주세요.")),r.json({error:"분석 실패",message:n,details:i||"웹사이트 분석 중 오류가 발생했습니다.",suggestion:"URL이 올바른지 확인하고, 웹사이트가 정상적으로 작동하는지 확인해주세요."},500)}});function m3(r,t){const e=[];return r.accessibility.altTextRatio<.9&&e.push("🔍 모든 이미지에 대체 텍스트(alt)를 추가하세요. (현재: "+Math.round(r.accessibility.altTextRatio*100)+"%)"),r.accessibility.skipLinkExists||e.push("⚡ 스크린리더 사용자를 위한 Skip Link를 추가하세요."),r.accessibility.langAttribute||e.push("🌐 HTML 태그에 lang 속성을 추가하세요."),r.navigation.searchExists||e.push("🔎 사이트 내 검색/필터 기능을 추가하세요. (N7.3)"),r.navigation.breadcrumbExists||e.push("📍 Breadcrumb 내비게이션을 추가하여 현재 위치를 표시하세요. (N1.1)"),r.forms.formCount>0&&r.forms.labelRatio<.9&&e.push("🏷️ 모든 입력 필드에 label을 연결하세요. (N5.3)"),r.forms.formCount>0&&!r.forms.validationExists&&e.push("✅ 폼 입력 검증 기능을 추가하세요. (N5.1)"),r.content.headingCount<5&&e.push("📝 명확한 정보 구조를 위해 제목 태그(h1-h6)를 활용하세요. (N8.3)"),t.N1_1_current_location<3.5&&e.push("👁️ Breadcrumb을 추가하여 사용자가 현재 위치를 파악하도록 하세요. (N1.1)"),t.N7_3_batch_operations<3.5&&e.push("🔍 검색 또는 필터 기능을 추가하여 정보 탐색을 쉽게 하세요. (N7.3)"),t.N8_1_essential_info<3.5&&e.push("✂️ 불필요한 콘텐츠를 제거하고 핵심 정보에 집중하세요. (N8.1)"),t.N9_2_recovery_support<3.5&&r.forms.formCount>0&&e.push("🔄 폼 입력 오류 시 복구 방법을 명확히 안내하세요. (N9.2)"),t.N10_1_help_visibility<3.5&&e.push("❓ 도움말/FAQ를 찾기 쉽게 배치하세요. (N10.1)"),e.slice(0,8)}_e.get("/api/weights",r=>r.json({version:Y5(),last_updated:Z5(),reference_statistics:Q5(),weights:Hw(),usage_guide:{description:"가중치 조정 방법: config/weights.json 파일을 수정한 후 서비스를 재시작하세요.",example:"N1_1_current_location.has_feature_bonus를 1.5에서 2.0으로 변경하면 Breadcrumb의 중요도가 높아집니다."}}));_e.get("/api/reference-stats",r=>r.json({statistics:kf.statistics,agencies_count:kf.agencies.length,sample_agencies:kf.agencies.slice(0,5).map(t=>({site_name:t.site_name,score:t.final_nielsen_score})),usage_note:"새로운 국민평가 데이터가 나오면 analysis/output/final_integrated_scores.json 파일을 교체하고 서비스를 재시작하세요."}));_e.post("/api/corrections",async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=await r.req.json();if(!e.url||!e.item_id||!e.item_name||e.original_score===void 0||e.corrected_score===void 0)return r.json({error:"Missing required fields"},400);if(e.corrected_score<2||e.corrected_score>5)return r.json({error:"Corrected score must be between 2.0 and 5.0"},400);const n=e.corrected_score-e.original_score,i=await t.prepare(`
      INSERT INTO admin_corrections (
        url, evaluated_at, item_id, item_name,
        original_score, corrected_score, score_diff,
        html_structure, correction_reason, admin_comment, corrected_diagnosis, corrected_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(e.url,e.evaluated_at,e.item_id,e.item_name,e.original_score,e.corrected_score,n,e.html_structure||null,e.correction_reason||null,e.admin_comment||null,e.corrected_diagnosis||null,e.corrected_by||"admin").run();return r.json({success:!0,correction_id:i.meta.last_row_id,message:"점수 수정이 저장되었습니다. 학습 데이터로 활용됩니다.",score_diff:n})}catch(e){return console.error("Error saving correction:",e),r.json({error:"Failed to save correction"},500)}});_e.get("/api/corrections/:url",async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=decodeURIComponent(r.req.param("url")),n=await t.prepare(`
      SELECT * FROM admin_corrections
      WHERE url = ?
      ORDER BY corrected_at DESC
    `).bind(e).all();return r.json({url:e,corrections:n.results,count:n.results.length})}catch(e){return console.error("Error fetching corrections:",e),r.json({error:"Failed to fetch corrections"},500)}});_e.post("/api/admin/corrections",Xo,xn,async r=>{const{DB:t}=r.env,e=r.get("user");try{const n=await r.req.json();if(!n.url||!n.item_id||!n.item_name)return r.json({success:!1,error:"필수 정보가 누락되었습니다."},400);if(n.corrected_score<0||n.corrected_score>5)return r.json({success:!1,error:"점수는 0~5 사이여야 합니다."},400);const i=n.corrected_score-n.original_score,s=await t.prepare(`
      INSERT INTO admin_corrections (
        url, evaluated_at, item_id, item_name,
        original_score, corrected_score, score_diff,
        html_structure, correction_reason, admin_comment,
        corrected_diagnosis, corrected_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(n.url,n.evaluated_at,n.item_id,n.item_name,n.original_score,n.corrected_score,i,n.html_structure||null,n.correction_reason||null,n.admin_comment||null,n.corrected_diagnosis||null,e.id).run();return await g3(t,n.item_id,n.item_name),r.json({success:!0,message:"평가 수정이 저장되었습니다.",correction_id:s.meta.last_row_id})}catch(n){return console.error("Error saving correction:",n),r.json({success:!1,error:"평가 수정 저장 중 오류가 발생했습니다."},500)}});async function g3(r,t,e){try{const n=await r.prepare(`
      SELECT 
        COUNT(*) as correction_count,
        AVG(score_diff) as avg_score_diff,
        AVG(original_score) as avg_original_score,
        AVG(corrected_score) as avg_corrected_score
      FROM admin_corrections
      WHERE item_id = ?
    `).bind(t).first();if(!n||n.correction_count===0)return;await r.prepare(`
      INSERT INTO learning_data_summary (
        item_id, item_name, correction_count,
        avg_score_diff, avg_original_score, avg_corrected_score,
        last_updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
      ON CONFLICT(item_id) DO UPDATE SET
        correction_count = excluded.correction_count,
        avg_score_diff = excluded.avg_score_diff,
        avg_original_score = excluded.avg_original_score,
        avg_corrected_score = excluded.avg_corrected_score,
        last_updated_at = datetime('now')
    `).bind(t,e,n.correction_count,n.avg_score_diff,n.avg_original_score,n.avg_corrected_score).run()}catch(n){console.error("Error updating learning data summary:",n)}}_e.get("/api/admin/corrections",Xo,xn,async r=>{const{DB:t}=r.env,e=parseInt(r.req.query("limit")||"50"),n=parseInt(r.req.query("offset")||"0");try{const i=await t.prepare(`
      SELECT ac.*, u.name as admin_name, u.email as admin_email
      FROM admin_corrections ac
      LEFT JOIN users u ON ac.corrected_by = u.id
      ORDER BY ac.corrected_at DESC
      LIMIT ? OFFSET ?
    `).bind(e,n).all(),s=await t.prepare(`
      SELECT COUNT(*) as total FROM admin_corrections
    `).first();return r.json({success:!0,corrections:i.results,total:(s==null?void 0:s.total)||0,limit:e,offset:n})}catch(i){return console.error("Error fetching corrections:",i),r.json({success:!1,error:"보정 데이터 조회 중 오류가 발생했습니다."},500)}});_e.delete("/api/admin/corrections/:id",Xo,xn,async r=>{const{DB:t}=r.env,e=parseInt(r.req.param("id"));try{return await t.prepare("DELETE FROM admin_corrections WHERE id = ?").bind(e).run(),r.json({success:!0,message:"보정 데이터가 삭제되었습니다."})}catch(n){return console.error("Error deleting correction:",n),r.json({success:!1,error:"보정 데이터 삭제 중 오류가 발생했습니다."},500)}});_e.get("/api/learning-insights",async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=await t.prepare(`
      SELECT * FROM learning_data_summary
      ORDER BY correction_count DESC
    `).all(),n=await t.prepare(`
      SELECT 
        COUNT(*) as total_corrections,
        COUNT(DISTINCT url) as unique_urls,
        COUNT(DISTINCT item_id) as corrected_items,
        AVG(score_diff) as avg_score_diff,
        COUNT(CASE WHEN used_for_learning = 0 THEN 1 END) as pending_learning
      FROM admin_corrections
    `).first(),i=await t.prepare(`
      SELECT 
        item_id, item_name,
        COUNT(*) as correction_count,
        AVG(score_diff) as avg_adjustment
      FROM admin_corrections
      GROUP BY item_id, item_name
      ORDER BY correction_count DESC
      LIMIT 5
    `).all();return r.json({summary:e.results,statistics:n,top_corrected_items:i.results,recommendations:e.results.filter(s=>s.adjustment_suggestion!=="적정").map(s=>({item_id:s.item_id,item_name:s.item_name,suggestion:s.adjustment_suggestion,evidence:`${s.correction_count}건의 수정 데이터, 평균 ${s.avg_score_diff.toFixed(2)}점 차이`}))})}catch(e){return console.error("Error fetching learning insights:",e),r.json({error:"Failed to fetch learning insights"},500)}});_e.get("/api/weight-suggestions",async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=await t.prepare(`
      SELECT * FROM learning_data_summary
      ORDER BY correction_count DESC
    `).all(),n=e3(e.results);return r.json({suggestions:n,total_suggestions:n.length,high_confidence:n.filter(i=>i.confidence==="high").length,medium_confidence:n.filter(i=>i.confidence==="medium").length,usage:{description:"가중치 조정 제안을 자동으로 적용하려면 POST /api/weight-suggestions/apply 를 호출하세요.",parameters:{min_confidence:"적용할 최소 신뢰도 ('high', 'medium', 'low')"}}})}catch(e){return console.error("Error generating weight suggestions:",e),r.json({error:"Failed to generate weight suggestions"},500)}});_e.post("/api/weight-suggestions/apply",async r=>r.json({message:"가중치 자동 적용 기능은 추후 구현 예정입니다.",current_approach:"config/weights.json 파일을 수동으로 수정한 후 서비스를 재시작하세요.",note:"학습 데이터가 충분히 쌓이면 (100건 이상) 자동 적용을 권장합니다."}));_e.post("/api/auth/login",async r=>{try{const{DB:t}=r.env,{email:e,password:n}=await r.req.json(),i=await t.prepare("SELECT * FROM users WHERE email = ? AND is_active = 1").bind(e).first();if(!i)return r.json({success:!1,error:"이메일 또는 비밀번호가 올바르지 않습니다."},401);if(!await t3(n,i.password_hash))return r.json({success:!1,error:"이메일 또는 비밀번호가 올바르지 않습니다."},401);const o=n3(),c=new Date(Date.now()+1440*60*1e3).toISOString();return await t.prepare("INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)").bind(o,i.id,c).run(),await t.prepare('UPDATE users SET last_login_at = datetime("now") WHERE id = ?').bind(i.id).run(),r.json({success:!0,session_id:o,user:{id:i.id,email:i.email,name:i.name,role:i.role}})}catch(t){return console.error("Login error:",t),r.json({success:!1,error:"로그인 처리 중 오류가 발생했습니다."},500)}});_e.post("/api/auth/logout",Xo,async r=>{try{const{DB:t}=r.env,e=r.req.header("X-Session-ID")||r.req.query("session_id");return e&&await t.prepare("DELETE FROM sessions WHERE id = ?").bind(e).run(),r.json({success:!0,message:"로그아웃되었습니다."})}catch(t){return console.error("Logout error:",t),r.json({success:!1,error:"로그아웃 처리 중 오류가 발생했습니다."},500)}});_e.get("/api/auth/me",Xo,async r=>{const t=r.get("user");return r.json({success:!0,user:{id:t.id,email:t.email,name:t.name,role:t.role}})});_e.get("/api/admin/users",Xo,xn,async r=>{try{const{DB:t}=r.env,e=await t.prepare("SELECT id, email, name, role, created_at, last_login_at, is_active FROM users ORDER BY created_at DESC").all();return r.json({success:!0,users:e.results})}catch(t){return console.error("Get users error:",t),r.json({success:!1,error:"사용자 목록 조회 중 오류가 발생했습니다."},500)}});_e.post("/api/krds/corrections",async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=await r.req.json();if(!e.url||!e.item_id||!e.item_name||e.original_score===void 0||e.corrected_score===void 0)return r.json({error:"Missing required fields"},400);if(e.corrected_score<2||e.corrected_score>5)return r.json({error:"Corrected score must be between 2.0 and 5.0"},400);const n=e.corrected_score-e.original_score,i=await t.prepare(`
      INSERT INTO krds_corrections (
        url, evaluated_at, item_id, item_name,
        original_score, corrected_score, score_diff,
        html_structure, affected_pages, correction_reason, admin_comment, corrected_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(e.url,e.evaluated_at,e.item_id,e.item_name,e.original_score,e.corrected_score,n,e.html_structure||null,e.affected_pages?JSON.stringify(e.affected_pages):null,e.correction_reason||null,e.admin_comment||null,e.corrected_by||"admin").run();return r.json({success:!0,correction_id:i.meta.last_row_id,message:"KRDS 수정 사항이 저장되었습니다. 이 데이터는 향후 평가 로직 개선에 활용됩니다."})}catch(e){return console.error("KRDS Correction save error:",e),r.json({error:"Failed to save correction",details:e.message},500)}});_e.get("/api/krds/corrections/:url",async r=>{const t=r.env.DB,e=r.req.param("url");if(!t)return r.json({error:"Database not configured"},500);try{const n=await t.prepare(`
      SELECT * FROM krds_corrections
      WHERE url = ?
      ORDER BY corrected_at DESC
    `).bind(decodeURIComponent(e)).all();return r.json({url:decodeURIComponent(e),corrections:n.results,count:n.results.length})}catch(n){return console.error("Error fetching KRDS corrections:",n),r.json({error:"Failed to fetch corrections"},500)}});_e.get("/api/krds/learning-summary",async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=await t.prepare(`
      SELECT * FROM krds_learning_data_summary
      ORDER BY correction_count DESC
    `).all();return r.json({learning_data:e.results,total_items:e.results.length,message:"이 데이터는 KRDS 평가 로직 개선에 활용됩니다."})}catch(e){return console.error("Error fetching KRDS learning summary:",e),r.json({error:"Failed to fetch learning summary"},500)}});_e.post("/api/contact",async r=>{const t=r.env.DB;if(!t)return r.json({success:!1,error:"Database not configured"},500);try{const e=await r.req.json(),{company:n,position:i,name:s,phone:o,email:c,url:l,project_type:d,message:u,budget:h,schedule:p,privacy_agreed:f}=e;if(!n||!s||!o||!c||!u||!f)return r.json({success:!1,error:"필수 항목을 모두 입력해주세요."},400);if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c))return r.json({success:!1,error:"올바른 이메일 형식이 아닙니다."},400);if(!/^[0-9-]+$/.test(o))return r.json({success:!1,error:"올바른 전화번호 형식이 아닙니다."},400);const b=Array.isArray(d)?d.join(", "):d||"";return await t.prepare(`
      INSERT INTO contact_inquiries (
        company, position, name, phone, email, url,
        project_type, message, budget, schedule,
        privacy_agreed, status, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', datetime('now'))
    `).bind(n,i||null,s,o,c,l||null,b,u,h||null,p||null,f?1:0).run(),r.json({success:!0,message:"문의가 성공적으로 접수되었습니다."})}catch(e){return console.error("Contact form error:",e),r.json({success:!1,error:"문의 접수 중 오류가 발생했습니다."},500)}});_e.get("/api/admin/contacts",xn,async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const{page:e="1",limit:n="20",status:i="all"}=r.req.query(),s=parseInt(e),o=parseInt(n),c=(s-1)*o;let l="SELECT * FROM contact_inquiries",d="SELECT COUNT(*) as total FROM contact_inquiries";i!=="all"&&(l+=" WHERE status = ?",d+=" WHERE status = ?"),l+=" ORDER BY created_at DESC LIMIT ? OFFSET ?";const u=i!=="all"?t.prepare(l).bind(i,o,c):t.prepare(l).bind(o,c),h=i!=="all"?t.prepare(d).bind(i):t.prepare(d),[p,f]=await Promise.all([u.all(),h.first()]);return r.json({contacts:p.results,pagination:{page:s,limit:o,total:(f==null?void 0:f.total)||0,totalPages:Math.ceil(((f==null?void 0:f.total)||0)/o)}})}catch(e){return console.error("Error fetching contacts:",e),r.json({error:"Failed to fetch contacts"},500)}});_e.get("/api/admin/contacts/:id",xn,async r=>{const t=r.env.DB,{id:e}=r.req.param();if(!t)return r.json({error:"Database not configured"},500);try{const n=await t.prepare(`
      SELECT * FROM contact_inquiries WHERE id = ?
    `).bind(e).first();return n?r.json({contact:n}):r.json({error:"Contact not found"},404)}catch(n){return console.error("Error fetching contact:",n),r.json({error:"Failed to fetch contact"},500)}});_e.patch("/api/admin/contacts/:id",xn,async r=>{const t=r.env.DB,{id:e}=r.req.param();if(!t)return r.json({error:"Database not configured"},500);try{const{status:n,admin_note:i}=await r.req.json();return["pending","processing","completed","rejected"].includes(n)?(await t.prepare(`
      UPDATE contact_inquiries 
      SET status = ?, admin_note = ?, updated_at = datetime('now')
      WHERE id = ?
    `).bind(n,i||null,e).run(),r.json({success:!0,message:"Contact status updated"})):r.json({error:"Invalid status"},400)}catch(n){return console.error("Error updating contact:",n),r.json({error:"Failed to update contact"},500)}});_e.get("/api/admin/accounts",xn,async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const e=await t.prepare(`
      SELECT id, email, name, role, is_active, created_at, last_login_at
      FROM users
      ORDER BY created_at DESC
    `).all();return r.json({accounts:e.results})}catch(e){return console.error("Error fetching accounts:",e),r.json({error:"Failed to fetch accounts"},500)}});_e.post("/api/admin/accounts",xn,async r=>{const t=r.env.DB;if(!t)return r.json({error:"Database not configured"},500);try{const{email:e,password:n,name:i,role:s}=await r.req.json();if(!e||!n||!i||!s)return r.json({error:"All fields are required"},400);if(!r3(e))return r.json({error:"Invalid email format"},400);if(!Ww(n))return r.json({error:"Password must be at least 8 characters with uppercase, lowercase, and number"},400);if(!["user","admin"].includes(s))return r.json({error:"Invalid role"},400);if(await t.prepare(`
      SELECT id FROM users WHERE email = ?
    `).bind(e).first())return r.json({error:"Email already exists"},400);const c=await Mm(n);return await t.prepare(`
      INSERT INTO users (email, password_hash, name, role, is_active, created_at)
      VALUES (?, ?, ?, ?, 1, datetime('now'))
    `).bind(e,c,i,s).run(),r.json({success:!0,message:"Account created successfully"})}catch(e){return console.error("Error creating account:",e),r.json({error:"Failed to create account"},500)}});_e.patch("/api/admin/accounts/:id",xn,async r=>{const t=r.env.DB,{id:e}=r.req.param();if(!t)return r.json({error:"Database not configured"},500);try{const{name:n,role:i,is_active:s,password:o}=await r.req.json();if(n||i!==void 0||s!==void 0){const c=[],l=[];n&&(c.push("name = ?"),l.push(n)),i&&["user","admin"].includes(i)&&(c.push("role = ?"),l.push(i)),s!==void 0&&(c.push("is_active = ?"),l.push(s?1:0)),l.push(e),await t.prepare(`
        UPDATE users SET ${c.join(", ")} WHERE id = ?
      `).bind(...l).run()}if(o){if(!Ww(o))return r.json({error:"Password must be at least 8 characters with uppercase, lowercase, and number"},400);const c=await Mm(o);await t.prepare(`
        UPDATE users SET password_hash = ? WHERE id = ?
      `).bind(c,e).run()}return r.json({success:!0,message:"Account updated successfully"})}catch(n){return console.error("Error updating account:",n),r.json({error:"Failed to update account"},500)}});_e.delete("/api/admin/accounts/:id",xn,async r=>{const t=r.env.DB,{id:e}=r.req.param(),n=r.req.header("X-Session-ID");if(!t||!n)return r.json({error:"Database not configured or session missing"},500);try{const i=await t.prepare(`
      SELECT user_id FROM sessions WHERE id = ? AND expires_at > datetime('now')
    `).bind(n).first();return i?i.user_id.toString()===e?r.json({error:"Cannot delete your own account"},400):(await t.prepare(`
      DELETE FROM users WHERE id = ?
    `).bind(e).run(),r.json({success:!0,message:"Account deleted successfully"})):r.json({error:"Invalid session"},401)}catch(i){return console.error("Error deleting account:",i),r.json({error:"Failed to delete account"},500)}});_e.get("/",r=>r.html(o3));_e.get("/login",r=>r.html(c3));_e.get("/test-feedback",r=>r.html(d3));_e.get("/admin",r=>r.html(l3));_e.get("/analyzer",r=>r.html(a3));_e.notFound(r=>r.text("Not Found",404));const My=new a0,y3=Object.assign({"/src/index.tsx":_e});let qw=!1;for(const[,r]of Object.entries(y3))r&&(My.all("*",t=>{let e;try{e=t.executionCtx}catch{}return r.fetch(t.req.raw,t.env,e)}),My.notFound(t=>{let e;try{e=t.executionCtx}catch{}return r.fetch(t.req.raw,t.env,e)}),qw=!0);if(!qw)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");function Kw(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var lu={exports:{}},Cf,Ay;function _3(){if(Ay)return Cf;Ay=1;var r=1e3,t=r*60,e=t*60,n=e*24,i=n*7,s=n*365.25;Cf=function(u,h){h=h||{};var p=typeof u;if(p==="string"&&u.length>0)return o(u);if(p==="number"&&isFinite(u))return h.long?l(u):c(u);throw new Error("val is not a non-empty string or a valid number. val="+JSON.stringify(u))};function o(u){if(u=String(u),!(u.length>100)){var h=/^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(u);if(h){var p=parseFloat(h[1]),f=(h[2]||"ms").toLowerCase();switch(f){case"years":case"year":case"yrs":case"yr":case"y":return p*s;case"weeks":case"week":case"w":return p*i;case"days":case"day":case"d":return p*n;case"hours":case"hour":case"hrs":case"hr":case"h":return p*e;case"minutes":case"minute":case"mins":case"min":case"m":return p*t;case"seconds":case"second":case"secs":case"sec":case"s":return p*r;case"milliseconds":case"millisecond":case"msecs":case"msec":case"ms":return p;default:return}}}}function c(u){var h=Math.abs(u);return h>=n?Math.round(u/n)+"d":h>=e?Math.round(u/e)+"h":h>=t?Math.round(u/t)+"m":h>=r?Math.round(u/r)+"s":u+"ms"}function l(u){var h=Math.abs(u);return h>=n?d(u,h,n,"day"):h>=e?d(u,h,e,"hour"):h>=t?d(u,h,t,"minute"):h>=r?d(u,h,r,"second"):u+" ms"}function d(u,h,p,f){var y=h>=p*1.5;return Math.round(u/p)+" "+f+(y?"s":"")}return Cf}var Ef,Ty;function b3(){if(Ty)return Ef;Ty=1;function r(t){n.debug=n,n.default=n,n.coerce=d,n.disable=c,n.enable=s,n.enabled=l,n.humanize=_3(),n.destroy=u,Object.keys(t).forEach(h=>{n[h]=t[h]}),n.names=[],n.skips=[],n.formatters={};function e(h){let p=0;for(let f=0;f<h.length;f++)p=(p<<5)-p+h.charCodeAt(f),p|=0;return n.colors[Math.abs(p)%n.colors.length]}n.selectColor=e;function n(h){let p,f=null,y,w;function b(...C){if(!b.enabled)return;const A=b,T=Number(new Date),M=T-(p||T);A.diff=M,A.prev=p,A.curr=T,p=T,C[0]=n.coerce(C[0]),typeof C[0]!="string"&&C.unshift("%O");let D=0;C[0]=C[0].replace(/%([a-zA-Z%])/g,(O,K)=>{if(O==="%%")return"%";D++;const F=n.formatters[K];if(typeof F=="function"){const H=C[D];O=F.call(A,H),C.splice(D,1),D--}return O}),n.formatArgs.call(A,C),(A.log||n.log).apply(A,C)}return b.namespace=h,b.useColors=n.useColors(),b.color=n.selectColor(h),b.extend=i,b.destroy=n.destroy,Object.defineProperty(b,"enabled",{enumerable:!0,configurable:!1,get:()=>f!==null?f:(y!==n.namespaces&&(y=n.namespaces,w=n.enabled(h)),w),set:C=>{f=C}}),typeof n.init=="function"&&n.init(b),b}function i(h,p){const f=n(this.namespace+(typeof p>"u"?":":p)+h);return f.log=this.log,f}function s(h){n.save(h),n.namespaces=h,n.names=[],n.skips=[];const p=(typeof h=="string"?h:"").trim().replace(/\s+/g,",").split(",").filter(Boolean);for(const f of p)f[0]==="-"?n.skips.push(f.slice(1)):n.names.push(f)}function o(h,p){let f=0,y=0,w=-1,b=0;for(;f<h.length;)if(y<p.length&&(p[y]===h[f]||p[y]==="*"))p[y]==="*"?(w=y,b=f,y++):(f++,y++);else if(w!==-1)y=w+1,b++,f=b;else return!1;for(;y<p.length&&p[y]==="*";)y++;return y===p.length}function c(){const h=[...n.names,...n.skips.map(p=>"-"+p)].join(",");return n.enable(""),h}function l(h){for(const p of n.skips)if(o(h,p))return!1;for(const p of n.names)if(o(h,p))return!0;return!1}function d(h){return h instanceof Error?h.stack||h.message:h}function u(){console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.")}return n.enable(n.load()),n}return Ef=r,Ef}var Py;function w3(){return Py||(Py=1,(function(r,t){var e={};t.formatArgs=i,t.save=s,t.load=o,t.useColors=n,t.storage=c(),t.destroy=(()=>{let d=!1;return()=>{d||(d=!0,console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."))}})(),t.colors=["#0000CC","#0000FF","#0033CC","#0033FF","#0066CC","#0066FF","#0099CC","#0099FF","#00CC00","#00CC33","#00CC66","#00CC99","#00CCCC","#00CCFF","#3300CC","#3300FF","#3333CC","#3333FF","#3366CC","#3366FF","#3399CC","#3399FF","#33CC00","#33CC33","#33CC66","#33CC99","#33CCCC","#33CCFF","#6600CC","#6600FF","#6633CC","#6633FF","#66CC00","#66CC33","#9900CC","#9900FF","#9933CC","#9933FF","#99CC00","#99CC33","#CC0000","#CC0033","#CC0066","#CC0099","#CC00CC","#CC00FF","#CC3300","#CC3333","#CC3366","#CC3399","#CC33CC","#CC33FF","#CC6600","#CC6633","#CC9900","#CC9933","#CCCC00","#CCCC33","#FF0000","#FF0033","#FF0066","#FF0099","#FF00CC","#FF00FF","#FF3300","#FF3333","#FF3366","#FF3399","#FF33CC","#FF33FF","#FF6600","#FF6633","#FF9900","#FF9933","#FFCC00","#FFCC33"];function n(){if(typeof window<"u"&&window.process&&(window.process.type==="renderer"||window.process.__nwjs))return!0;if(typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/))return!1;let d;return typeof document<"u"&&document.documentElement&&document.documentElement.style&&document.documentElement.style.WebkitAppearance||typeof window<"u"&&window.console&&(window.console.firebug||window.console.exception&&window.console.table)||typeof navigator<"u"&&navigator.userAgent&&(d=navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/))&&parseInt(d[1],10)>=31||typeof navigator<"u"&&navigator.userAgent&&navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/)}function i(d){if(d[0]=(this.useColors?"%c":"")+this.namespace+(this.useColors?" %c":" ")+d[0]+(this.useColors?"%c ":" ")+"+"+r.exports.humanize(this.diff),!this.useColors)return;const u="color: "+this.color;d.splice(1,0,u,"color: inherit");let h=0,p=0;d[0].replace(/%[a-zA-Z%]/g,f=>{f!=="%%"&&(h++,f==="%c"&&(p=h))}),d.splice(p,0,u)}t.log=console.debug||console.log||(()=>{});function s(d){try{d?t.storage.setItem("debug",d):t.storage.removeItem("debug")}catch{}}function o(){let d;try{d=t.storage.getItem("debug")||t.storage.getItem("DEBUG")}catch{}return!d&&typeof process<"u"&&"env"in process&&(d=e.DEBUG),d}function c(){try{return localStorage}catch{}}r.exports=b3()(t);const{formatters:l}=r.exports;l.j=function(d){try{return JSON.stringify(d)}catch(u){return"[UnexpectedJSONParseError]: "+u.message}}})(lu,lu.exports)),lu.exports}var Gw=w3();const v3=Kw(Gw),x3=Jw({__proto__:null,default:v3},[Gw]);var If,$y;function S3(){return $y||($y=1,If=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")}),If}var k3=S3();const C3=Kw(k3);/**
 * @license
 * Copyright 2018 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */var gr;const jm=class jm{constructor(t){m(this,gr);L(this,"onmessage");L(this,"onclose");_(this,gr,t),a(this,gr).addEventListener("message",e=>{this.onmessage&&this.onmessage.call(null,e.data)}),a(this,gr).addEventListener("close",()=>{this.onclose&&this.onclose.call(null)}),a(this,gr).addEventListener("error",()=>{})}static create(t,e){return new Promise((n,i)=>{const s=new C3(t,[],{followRedirects:!0,perMessageDeflate:!1,allowSynchronousEvents:!1,maxPayload:268435456,headers:{"User-Agent":`Puppeteer ${em}`,...e}});s.addEventListener("open",()=>n(new jm(s))),s.addEventListener("error",i)})}send(t){a(this,gr).send(t)}close(){a(this,gr).close()}};gr=new WeakMap;let qp=jm;const E3=Object.freeze(Object.defineProperty({__proto__:null,NodeWebSocketTransport:qp},Symbol.toStringTag,{value:"Module"}));export{My as default};
