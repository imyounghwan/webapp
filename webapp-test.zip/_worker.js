// 최소한의 테스트 Worker
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    
    // 기본 응답
    if (url.pathname === '/') {
      return new Response(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>UIUX 평가 시스템</title>
        </head>
        <body>
          <h1>✅ Worker 작동 확인!</h1>
          <p>D1 연결 테스트 중...</p>
          <a href="/test-db">D1 테스트</a>
        </body>
        </html>
      `, {
        headers: { 'Content-Type': 'text/html; charset=utf-8' }
      });
    }
    
    // D1 연결 테스트
    if (url.pathname === '/test-db') {
      try {
        if (!env.DB) {
          return new Response('❌ D1이 연결되지 않았습니다.', { status: 500 });
        }
        
        const result = await env.DB.prepare('SELECT 1 as test').first();
        return new Response(`✅ D1 연결 성공! Result: ${JSON.stringify(result)}`, {
          headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      } catch (error) {
        return new Response(`❌ D1 오류: ${error.message}`, { status: 500 });
      }
    }
    
    return new Response('Not Found', { status: 404 });
  }
};
